import { describe, expect, it } from "vitest";
import { validateLocalPassword } from "../server/_core/password-hash";

describe("local account password policy", () => {
  it("accepts the requested six-character minimum", () => {
    expect(validateLocalPassword("123456")).toBe(true);
  });

  it("rejects passwords shorter than six bytes", () => {
    expect(validateLocalPassword("12345")).toBe(false);
  });

  it("rejects passwords above the 256-byte maximum", () => {
    expect(validateLocalPassword("a".repeat(257))).toBe(false);
  });
});
