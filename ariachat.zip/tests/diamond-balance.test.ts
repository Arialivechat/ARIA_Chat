import { describe, expect, it } from "vitest";
import { canSpendDiamonds, diamondBalanceLabel, isSafeDiamondAmount, isWalletSnapshotReady } from "../lib/diamond-balance";

describe("Diamond balance availability", () => {
  it("allows the server-designated unlimited account to wager when its cached balance is zero", () => {
    expect(canSpendDiamonds(250, 0, true)).toBe(true);
  });

  it("enforces the stored balance for ordinary accounts", () => {
    expect(canSpendDiamonds(25, 25, false)).toBe(true);
    expect(canSpendDiamonds(26, 25, false)).toBe(false);
  });

  it("rejects invalid wagers even for an unlimited account", () => {
    expect(canSpendDiamonds(0, 0, true)).toBe(false);
    expect(canSpendDiamonds(-1, 0, true)).toBe(false);
    expect(canSpendDiamonds(Number.MAX_SAFE_INTEGER, 0, true, 1_000)).toBe(false);
  });

  it("shows infinity instead of a misleading numeric wallet balance", () => {
    expect(diamondBalanceLabel(0, true)).toBe("∞");
    expect(diamondBalanceLabel(25, false)).toBe("25");
    expect(diamondBalanceLabel(undefined, false)).toBe("—");
  });

  it("accepts transfers above one million while rejecting unsafe or non-positive amounts", () => {
    expect(isSafeDiamondAmount(1_000_001)).toBe(true);
    expect(isSafeDiamondAmount(Number.MAX_SAFE_INTEGER)).toBe(true);
    expect(isSafeDiamondAmount(Number.MAX_SAFE_INTEGER + 1)).toBe(false);
    expect(isSafeDiamondAmount(0)).toBe(false);
  });

  it("requires current wallet data before allowing money actions", () => {
    expect(isWalletSnapshotReady(true, false, false)).toBe(true);
    expect(isWalletSnapshotReady(false, false, false)).toBe(false);
    expect(isWalletSnapshotReady(true, true, false)).toBe(false);
    expect(isWalletSnapshotReady(true, false, true)).toBe(false);
  });
});
