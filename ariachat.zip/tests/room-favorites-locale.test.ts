import { describe, expect, it } from "vitest";
import { roomFavoriteText } from "../lib/ui-locale-room-favorites";
import type { Locale } from "../lib/locales";

const supported: Locale[] = ["fa", "en", "ar", "de", "tg", "ps", "ur", "sw", "es", "it", "tr", "hi"];
describe("favorite-room and Diamond audit labels", () => {
  it("provides localized labels for all supported locales", () => {
    for (const locale of supported) {
      expect(roomFavoriteText(locale, "favorites").trim()).not.toBe("");
      expect(roomFavoriteText(locale, "recentDiamondTransactions").trim()).not.toBe("");
      expect(roomFavoriteText(locale, "account").trim()).not.toBe("");
    }
  });
});
