import { describe, expect, it } from "vitest";
import { ARIA_CHAT_PUBLIC_API_BASE_URL, resolveApiBaseUrl } from "../lib/api-base-url";

describe("API base URL selection", () => {
  const sessionUrl = "https://3000-session-id.us5.manus.computer";

  it("uses the stable app API instead of a session-scoped host in release builds", () => {
    expect(resolveApiBaseUrl(sessionUrl, "native", false)).toBe(ARIA_CHAT_PUBLIC_API_BASE_URL);
    expect(resolveApiBaseUrl(sessionUrl, "web", false)).toBe(ARIA_CHAT_PUBLIC_API_BASE_URL);
  });

  it("preserves the session API during development preview", () => {
    expect(resolveApiBaseUrl(sessionUrl, "native", true)).toBe(sessionUrl);
  });

  it("uses the stable app API when release configuration has no host", () => {
    expect(resolveApiBaseUrl("", "native", false)).toBe(ARIA_CHAT_PUBLIC_API_BASE_URL);
  });

  it("preserves an explicitly configured non-session production API", () => {
    const custom = "https://api.example.test";
    expect(resolveApiBaseUrl(custom, "native", false)).toBe(custom);
  });

  it("derives the paired API endpoint for a development web preview", () => {
    expect(resolveApiBaseUrl("", "web", true, {
      protocol: "https:",
      hostname: "8081-preview-id.us5.manus.computer",
    })).toBe("https://3000-preview-id.us5.manus.computer");
  });
});
