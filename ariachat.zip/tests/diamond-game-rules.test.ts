import { describe, expect, it } from "vitest";
import { createDiamondMiniOutcome, createRockPaperScissorsOutcome, diamondMiniPayout } from "../server/diamond-game-rules";

const fixedRandom = (value: number) => (min: number, max: number) => Math.max(min, Math.min(max - 1, value));

describe("server-authoritative Diamond mini-game rules", () => {
  it.each([0, 1, 2])("uses exactly the three winning slots out of ten (%i)", (roll) => {
    expect(createDiamondMiniOutcome("tic_tac_toe", undefined, fixedRandom(roll)).outcome).toBe("win");
    expect(createDiamondMiniOutcome("memory_match", undefined, fixedRandom(roll)).outcome).toBe("win");
  });

  it.each([3, 4, 5, 6, 7, 8, 9])("marks the other seven slots as losses (%i)", (roll) => {
    expect(createDiamondMiniOutcome("tic_tac_toe", undefined, fixedRandom(roll)).outcome).toBe("loss");
    expect(createDiamondMiniOutcome("memory_match", undefined, fixedRandom(roll)).outcome).toBe("loss");
  });

  it("returns an unambiguous board matching the server outcome", () => {
    const win = createDiamondMiniOutcome("tic_tac_toe", undefined, fixedRandom(0));
    const loss = createDiamondMiniOutcome("tic_tac_toe", undefined, fixedRandom(9));
    expect(win.board?.slice(0, 3)).toEqual(["X", "X", "X"]);
    expect(loss.board?.slice(0, 3)).toEqual(["O", "O", "O"]);
  });

  it("generates a shuffled memory deck and discloses only the matched pairs", () => {
    const win = createDiamondMiniOutcome("memory_match", undefined, fixedRandom(0));
    const loss = createDiamondMiniOutcome("memory_match", undefined, fixedRandom(9));
    expect(win.memoryDeck).toHaveLength(8);
    expect([...win.memoryDeck!].sort()).toEqual([0, 0, 1, 1, 2, 2, 3, 3]);
    expect(win.matchedPairs).toBe(4);
    expect(win.matchedCards).toHaveLength(8);
    expect(loss.matchedPairs).toBeLessThan(4);
    expect(loss.matchedCards).toHaveLength(loss.matchedPairs! * 2);
  });

  it.each(["guess_number", "treasure_hunt"] as const)("exposes exactly 3 of 10 choices for %s", (gameType) => {
    const result = createDiamondMiniOutcome(gameType, 1, fixedRandom(0));
    const revealed = gameType === "guess_number" ? result.winningNumbers : result.treasureSpots;
    expect(revealed).toHaveLength(3);
    expect(revealed!.every((value) => value >= 1 && value <= 10)).toBe(true);
    expect(result.outcome).toBe(revealed!.includes(1) ? "win" : "loss");
  });

  it("requires a valid player choice for number and treasure games", () => {
    expect(() => createDiamondMiniOutcome("guess_number", undefined, fixedRandom(0))).toThrow();
    expect(() => createDiamondMiniOutcome("treasure_hunt", 11, fixedRandom(0))).toThrow();
  });

  it("pays three times the amount as total credit on a win and nothing on a loss", () => {
    expect(diamondMiniPayout(1, "win")).toBe(3);
    expect(diamondMiniPayout(17, "win")).toBe(51);
    expect(diamondMiniPayout(17, "loss")).toBe(0);
  });

  it.each([0, 1, 2])("gives RPS an exact 30%% win slot (%i) and reveals a losing move", (roll) => {
    expect(createRockPaperScissorsOutcome("rock", fixedRandom(roll))).toMatchObject({ outcome: "win", opponentChoice: "scissors" });
  });

  it.each([3, 4, 5])("gives RPS an exact 30%% tie slot (%i)", (roll) => {
    expect(createRockPaperScissorsOutcome("rock", fixedRandom(roll))).toMatchObject({ outcome: "tie", opponentChoice: "rock" });
  });

  it.each([6, 7, 8, 9])("gives RPS the remaining 40%% loss slots (%i) and reveals a winning move", (roll) => {
    expect(createRockPaperScissorsOutcome("rock", fixedRandom(roll))).toMatchObject({ outcome: "loss", opponentChoice: "paper" });
  });
});
