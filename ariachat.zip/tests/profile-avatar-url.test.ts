import { describe, expect, it } from "vitest";
import { isProfileAvatarUrl } from "../lib/profile-avatar-url";

describe("profile avatar URL validation", () => {
  it("accepts stable managed-storage paths returned by private image uploads", () => {
    expect(isProfileAvatarUrl("/manus-storage/avatars/42/9fd2a1.webp")).toBe(true);
  });

  it("accepts external HTTP(S) URLs without embedded credentials", () => {
    expect(isProfileAvatarUrl("https://cdn.example.test/avatar.webp")).toBe(true);
    expect(isProfileAvatarUrl("http://images.example.test/avatar.png")).toBe(true);
    expect(isProfileAvatarUrl("https://user:secret@cdn.example.test/avatar.png")).toBe(false);
  });

  it("rejects malformed, unsafe, non-web and traversal paths", () => {
    expect(isProfileAvatarUrl("https://...")).toBe(false);
    expect(isProfileAvatarUrl("https://-bad.example")).toBe(false);
    expect(isProfileAvatarUrl("https://example..com")).toBe(false);
    expect(isProfileAvatarUrl("https://localhost")).toBe(true);
    expect(isProfileAvatarUrl("data:image/png;base64,AAAA")).toBe(false);
    expect(isProfileAvatarUrl("file:///storage/avatar.jpg")).toBe(false);
    expect(isProfileAvatarUrl("/manus-storage/avatars/../private.jpg")).toBe(false);
    expect(isProfileAvatarUrl("/manus-storage//avatar.jpg")).toBe(false);
    expect(isProfileAvatarUrl("/manus-storage/avatar.jpg?download=1")).toBe(false);
    expect(isProfileAvatarUrl(null)).toBe(false);
    expect(isProfileAvatarUrl(42)).toBe(false);
  });
});
