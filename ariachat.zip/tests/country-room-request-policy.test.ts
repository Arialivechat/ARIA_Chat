import { describe, expect, it } from "vitest";
import { countryRoomDecisionRefunds, mayDecideCountryRoomRequest, maySettleCountryRoomRequest } from "../server/_core/country-room-request-policy";

describe("country room request policy", () => {
  it("allows decisions only for Administrator account #1", () => {
    expect(mayDecideCountryRoomRequest({ accountNumber: 1, role: "admin" })).toBe(true);
    expect(mayDecideCountryRoomRequest({ accountNumber: 2, role: "admin" })).toBe(false);
    expect(mayDecideCountryRoomRequest({ accountNumber: 1, role: "superadmin" })).toBe(false);
    expect(mayDecideCountryRoomRequest({ accountNumber: null, role: "admin" })).toBe(false);
  });
  it("allows settlement only once from pending and refunds only rejection", () => {
    expect(maySettleCountryRoomRequest("pending")).toBe(true);
    for (const status of ["approved", "rejected"]) expect(maySettleCountryRoomRequest(status)).toBe(false);
    expect(countryRoomDecisionRefunds("rejected")).toBe(true);
    expect(countryRoomDecisionRefunds("approved")).toBe(false);
  });
});
