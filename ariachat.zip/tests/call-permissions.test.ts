import { describe, expect, it } from "vitest";
import { canInitiateVoiceCall } from "../server/_core/call-permissions";

const base = {
  callerUserId: 12,
  targetUserId: 34,
  callerAccountNumber: 112,
  callerRole: "user",
  mutualFriendship: false,
  blocked: false,
};

describe("voice-call permissions", () => {
  it("allows a symmetric friendship", () => {
    expect(canInitiateVoiceCall({ ...base, mutualFriendship: true })).toBe(true);
  });

  it("rejects a one-sided or absent friendship for ordinary users", () => {
    expect(canInitiateVoiceCall(base)).toBe(false);
  });

  it("allows only account number 1 with the Administrator role to initiate with a non-friend", () => {
    expect(canInitiateVoiceCall({ ...base, callerUserId: 1, callerAccountNumber: 1, callerRole: "admin" })).toBe(true);
    expect(canInitiateVoiceCall({ ...base, callerUserId: 1, callerAccountNumber: 2, callerRole: "admin" })).toBe(false);
    expect(canInitiateVoiceCall({ ...base, callerUserId: 1, callerAccountNumber: 1, callerRole: "user" })).toBe(false);
  });

  it("does not allow the Administrator exception to bypass a block", () => {
    expect(canInitiateVoiceCall({ ...base, callerUserId: 1, callerAccountNumber: 1, callerRole: "admin", blocked: true })).toBe(false);
  });

  it("rejects calls to oneself", () => {
    expect(canInitiateVoiceCall({ ...base, targetUserId: base.callerUserId, mutualFriendship: true })).toBe(false);
  });
});
