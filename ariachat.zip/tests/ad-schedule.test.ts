import { describe, expect, it } from "vitest";
import { AD_VISIBILITY_WINDOW_MS, isAdVisibleAt } from "../lib/ad-schedule";

const origin = new Date("2026-01-01T12:00:00.000Z");
const row = (overrides: Record<string, unknown> = {}) => ({
  status: "active",
  startsAt: origin,
  endsAt: new Date(origin.getTime() + AD_VISIBILITY_WINDOW_MS),
  createdAt: origin,
  ...overrides,
});

describe("24-hour ad visibility", () => {
  it("shows only active ads within the scheduled 24-hour window", () => {
    expect(isAdVisibleAt(row(), origin)).toBe(true);
    expect(isAdVisibleAt(row(), new Date(origin.getTime() + AD_VISIBILITY_WINDOW_MS))).toBe(true);
    expect(isAdVisibleAt(row(), new Date(origin.getTime() + AD_VISIBILITY_WINDOW_MS + 1))).toBe(false);
    expect(isAdVisibleAt(row({ startsAt: new Date(origin.getTime() + 1) }), origin)).toBe(false);
    expect(isAdVisibleAt(row({ status: "paused" }), origin)).toBe(false);
  });

  it("uses startsAt then createdAt as the legacy 24-hour cutoff when endsAt is null", () => {
    expect(isAdVisibleAt(row({ endsAt: null }), new Date(origin.getTime() + AD_VISIBILITY_WINDOW_MS - 1))).toBe(true);
    expect(isAdVisibleAt(row({ endsAt: null }), new Date(origin.getTime() + AD_VISIBILITY_WINDOW_MS + 1))).toBe(false);
    expect(isAdVisibleAt(row({ startsAt: null, endsAt: null }), new Date(origin.getTime() + AD_VISIBILITY_WINDOW_MS + 1))).toBe(false);
  });

  it("caps legacy rows with an overlong endsAt at 24 hours", () => {
    expect(isAdVisibleAt(row({ endsAt: new Date(origin.getTime() + 72 * 60 * 60 * 1000) }), new Date(origin.getTime() + 25 * 60 * 60 * 1000))).toBe(false);
  });

  it("respects a shorter scheduled end", () => {
    const earlyEnd = new Date(origin.getTime() + 60 * 60 * 1000);
    expect(isAdVisibleAt(row({ endsAt: earlyEnd }), earlyEnd)).toBe(true);
    expect(isAdVisibleAt(row({ endsAt: earlyEnd }), new Date(earlyEnd.getTime() + 1))).toBe(false);
  });
});
