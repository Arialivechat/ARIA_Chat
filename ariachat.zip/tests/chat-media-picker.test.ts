import { beforeEach, describe, expect, it, vi } from "vitest";

const { readAsStringAsync } = vi.hoisted(() => ({ readAsStringAsync: vi.fn() }));
vi.mock("expo-file-system/legacy", () => ({
  EncodingType: { Base64: "base64" },
  readAsStringAsync,
}));

import { AttachmentTooLargeError, readPickerAssetBase64 } from "../lib/chat-media-picker";

describe("readPickerAssetBase64", () => {
  beforeEach(() => readAsStringAsync.mockReset());

  it("reads copied picker URIs as Base64 when the picker omitted base64", async () => {
    readAsStringAsync.mockResolvedValue("aGVsbG8=");
    await expect(readPickerAssetBase64({ uri: "file:///cache/photo.png" }, 100)).resolves.toEqual({
      base64Data: "aGVsbG8=",
      sizeBytes: 5,
    });
    expect(readAsStringAsync).toHaveBeenCalledWith("file:///cache/photo.png", { encoding: "base64" });
  });

  it("strips data URL prefixes and calculates actual decoded bytes instead of trusting metadata", async () => {
    const result = await readPickerAssetBase64({ base64: "data:image/png;base64,aGVsbG8=", size: 1 }, 100);
    expect(result).toEqual({ base64Data: "aGVsbG8=", sizeBytes: 5 });
    expect(readAsStringAsync).not.toHaveBeenCalled();
  });

  it("rejects a known oversized asset before reading it", async () => {
    await expect(readPickerAssetBase64({ uri: "file:///cache/large.png", size: 101 }, 100)).rejects.toBeInstanceOf(AttachmentTooLargeError);
    expect(readAsStringAsync).not.toHaveBeenCalled();
  });

  it("rejects an oversized decoded payload when picker metadata is missing", async () => {
    readAsStringAsync.mockResolvedValue("aGVsbG8=");
    await expect(readPickerAssetBase64({ uri: "file:///cache/file" }, 4)).rejects.toBeInstanceOf(AttachmentTooLargeError);
  });
});
