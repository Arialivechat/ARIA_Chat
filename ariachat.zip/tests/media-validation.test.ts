import { Buffer } from "node:buffer";
import { describe, expect, it } from "vitest";
import { MAX_IMAGE_UPLOAD_BYTES, MAX_NON_IMAGE_UPLOAD_BYTES } from "../lib/media-limits";
import { validateChatMedia } from "../server/media-validation";

describe("validateChatMedia", () => {
  it("accepts a valid PNG and removes path segments from its filename", () => {
    const bytes = Buffer.concat([
      Buffer.from("89504e470d0a1a0a", "hex"),
      Buffer.from("aria-chat-test"),
    ]);
    const result = validateChatMedia({
      base64Data: bytes.toString("base64"),
      contentType: "image/png",
      fileName: "../../private/photo.png",
    });
    expect(result.kind).toBe("image");
    expect(result.fileName).toBe(".._.._private_photo.png");
    expect(result.sizeBytes).toBe(bytes.length);
  });

  it("rejects a claimed MIME type that does not match the bytes", () => {
    const bytes = Buffer.from("not a png");
    expect(() => validateChatMedia({
      base64Data: bytes.toString("base64"),
      contentType: "image/png",
      fileName: "photo.png",
    })).toThrow("محتوای فایل با نوع اعلام‌شده سازگار نیست.");
  });

  it("rejects unsupported types and malformed Base64", () => {
    expect(() => validateChatMedia({ base64Data: "eA==", contentType: "text/html", fileName: "x.html" }))
      .toThrow("این نوع فایل پشتیبانی نمی‌شود.");
    expect(() => validateChatMedia({ base64Data: "%%%", contentType: "image/png", fileName: "x.png" }))
      .toThrow("محتوای فایل معتبر نیست.");
  });

  it("allows images up to 25 MiB and rejects images above that limit", () => {
    const bytes = Buffer.alloc(MAX_IMAGE_UPLOAD_BYTES + 1);
    bytes.set(Buffer.from("89504e470d0a1a0a", "hex"));
    expect(() => validateChatMedia({
      base64Data: bytes.toString("base64"),
      contentType: "image/png",
      fileName: "oversized.png",
    })).toThrow("حجم تصویر از حد مجاز ۲۵ مگابایت بیشتر است.");
  });

  it("keeps the server-side 10 MiB cap for non-image files", () => {
    const bytes = Buffer.alloc(MAX_NON_IMAGE_UPLOAD_BYTES + 1);
    bytes.set(Buffer.from("%PDF-", "ascii"));
    expect(() => validateChatMedia({
      base64Data: bytes.toString("base64"),
      contentType: "application/pdf",
      fileName: "oversized.pdf",
    })).toThrow("حجم فایل از حد مجاز ۱۰ مگابایت بیشتر است.");
  });
});
