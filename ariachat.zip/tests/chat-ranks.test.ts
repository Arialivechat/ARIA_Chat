import { describe, expect, it } from "vitest";
import {
  chatRankTitles,
  getChatRankLevel,
  getChatRankProgress,
  getPrivateMessageRank,
} from "../lib/chat-ranks";

describe("chat activity ranks", () => {
  it("uses the requested inclusive message thresholds", () => {
    expect([0, 999, 1_000, 19_999, 20_000, 99_999, 100_000, 299_999, 300_000, 699_999, 700_000]
      .map(getChatRankLevel))
      .toEqual([0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5]);
    expect(chatRankTitles).toEqual(["سرباز", "لورد", "دوک", "کینگ", "امپراتور", "افسانه"]);
  });

  it("clamps invalid and negative counts safely", () => {
    expect(getChatRankLevel(-12)).toBe(0);
    expect(getChatRankLevel(Number.NaN)).toBe(0);
    expect(getChatRankLevel(Number.POSITIVE_INFINITY)).toBe(0);
  });

  it("reports progress to the next title and caps the final title", () => {
    expect(getChatRankProgress(500)).toMatchObject({ level: 0, progress: 50, remaining: 500, nextTitle: "لورد" });
    expect(getChatRankProgress(700_000)).toMatchObject({ level: 5, progress: 100, remaining: 0, nextTitle: null });
  });

  it("keeps personal colors below the first threshold and assigns gender palettes above it", () => {
    expect(getPrivateMessageRank(999, "female", "#123456", "#FFFFFF")).toMatchObject({
      tier: 0,
      label: "سرباز",
      backgroundColor: "#123456",
    });
    const male = getPrivateMessageRank(1_000, "male", "#123456", "#FFFFFF");
    const female = getPrivateMessageRank(1_000, "female", "#123456", "#FFFFFF");
    expect(male).toMatchObject({ tier: 1, label: "لورد", textColor: "#FFFFFF" });
    expect(female).toMatchObject({ tier: 1, label: "لورد", textColor: "#FFFFFF" });
    expect(male.backgroundColor).not.toBe(female.backgroundColor);
  });
});
