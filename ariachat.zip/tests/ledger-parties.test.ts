import { describe, expect, it } from "vitest";
import { getLedgerTransferParties, type LedgerPublicAccount } from "../lib/ledger-parties";

const sender: LedgerPublicAccount = { name: "Sender", username: "sender", accountNumber: 101 };
const recipient: LedgerPublicAccount = { name: "Recipient", username: "recipient", accountNumber: 202 };

describe("Diamond transfer ledger parties", () => {
  it("maps a debit row to the account as sender and counterparty as recipient", () => {
    expect(getLedgerTransferParties("debit", sender, recipient)).toEqual({ sender, recipient });
  });

  it("maps a credit row to the counterparty as sender and account as recipient", () => {
    expect(getLedgerTransferParties("credit", recipient, sender)).toEqual({ sender, recipient });
  });
});
