import { describe, expect, it } from "vitest";
import { mayChangeAccountRole, type RoleSubject } from "../server/_core/admin-role-permissions";

const rootAdmin: RoleSubject = { userId: 5, accountNumber: 1, role: "admin" };
const regularTarget: RoleSubject = { userId: 41, accountNumber: 120, role: "user" };

describe("manager role authorization", () => {
  it("allows the designated Administrator #1 to add or remove another account's role", () => {
    expect(mayChangeAccountRole(rootAdmin, regularTarget)).toBe(true);
  });

  it("rejects administrators with another public account number", () => {
    expect(mayChangeAccountRole({ ...rootAdmin, accountNumber: 101 }, regularTarget)).toBe(false);
  });

  it("rejects superadmins, self-targets, and any attempt to change account #1", () => {
    expect(mayChangeAccountRole({ ...rootAdmin, role: "superadmin" }, regularTarget)).toBe(false);
    expect(mayChangeAccountRole(rootAdmin, { ...rootAdmin })).toBe(false);
    expect(mayChangeAccountRole(rootAdmin, { userId: 6, accountNumber: 1, role: "admin" })).toBe(false);
  });
});
