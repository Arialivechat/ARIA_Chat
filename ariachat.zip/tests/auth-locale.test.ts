import { describe, expect, it } from "vitest";
import { LOCALES } from "../lib/locales";
import { AUTH_LOCALE_KEYS, translateAuth } from "../lib/ui-locale-auth";

describe("authentication screen localization", () => {
  it("provides non-empty login and registration copy in all twelve supported locales", () => {
    expect(LOCALES).toHaveLength(12);
    for (const locale of LOCALES) {
      for (const key of AUTH_LOCALE_KEYS) {
        expect(translateAuth(locale.code, key), `${locale.code}.${key}`).toMatch(/\S/);
      }
    }
  });
});
