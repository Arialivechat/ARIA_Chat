import { describe, expect, it } from "vitest";
import { isAdminBlockDurationHours, isSuspensionExpired } from "../lib/account-suspensions";
import { getProfileCrownTone, isProfileAvatarEmoji, PROFILE_AVATAR_OPTIONS } from "../lib/profile-avatars";
import { canViewPrivateProfile } from "../lib/profile-visibility";

describe("profile emoji avatars", () => {
  it("contains the exact requested set without duplicates", () => {
    expect(PROFILE_AVATAR_OPTIONS).toEqual([
      "🤶", "🎅", "👸", "🤵‍♀️", "🤵‍♂️", "👷‍♀️", "👩‍🎨", "👨‍💻", "🧑‍🏭", "🧑‍🔧",
      "👱‍♀️", "🧑‍🦰", "👱‍♂️", "👩‍🦰", "👨", "🧔‍♂️", "👶", "🐱", "🐶", "🐬",
      "🐔", "🐣", "🦆", "🌸", "🌻", "🏵", "🌹", "🦂", "🪰", "🕷",
    ]);
    expect(new Set(PROFILE_AVATAR_OPTIONS).size).toBe(PROFILE_AVATAR_OPTIONS.length);
  });

  it("accepts only an avatar in the fixed allow-list", () => {
    expect(isProfileAvatarEmoji("👸")).toBe(true);
    expect(isProfileAvatarEmoji("🧑‍🔧")).toBe(true);
    expect(isProfileAvatarEmoji("🧙")).toBe(false);
    expect(isProfileAvatarEmoji(null)).toBe(false);
  });
});

describe("profile role crowns", () => {
  it("uses gold for global administration and blue only for room-local managers", () => {
    expect(getProfileCrownTone("admin", "owner")).toBe("gold");
    expect(getProfileCrownTone("superadmin", "moderator")).toBe("gold");
    expect(getProfileCrownTone("moderator", "member")).toBe("gold");
    expect(getProfileCrownTone("user", "owner")).toBe("blue");
    expect(getProfileCrownTone("user", "moderator")).toBe("blue");
    expect(getProfileCrownTone("user", "member")).toBeNull();
  });
});

describe("private profile visibility", () => {
  it("allows public profiles, owners, and mutual friends but hides private profiles from others", () => {
    expect(canViewPrivateProfile(false, false, false)).toBe(true);
    expect(canViewPrivateProfile(true, false, false)).toBe(false);
    expect(canViewPrivateProfile(true, true, false)).toBe(true);
    expect(canViewPrivateProfile(true, false, true)).toBe(true);
  });
});

describe("temporary and permanent account blocks", () => {
  it("accepts only the explicit one-hour, one-day, one-week, and one-month durations", () => {
    expect(isAdminBlockDurationHours(1)).toBe(true);
    expect(isAdminBlockDurationHours(24)).toBe(true);
    expect(isAdminBlockDurationHours(168)).toBe(true);
    expect(isAdminBlockDurationHours(720)).toBe(true);
    expect(isAdminBlockDurationHours(0)).toBe(false);
    expect(isAdminBlockDurationHours(48)).toBe(false);
    expect(isAdminBlockDurationHours("24")).toBe(false);
    expect(isAdminBlockDurationHours(null)).toBe(false);
  });

  it("expires only timed suspensions at or after their stored deadline", () => {
    const now = new Date("2026-01-01T00:00:00.000Z");
    expect(isSuspensionExpired("suspended", new Date("2025-12-31T23:59:59.000Z"), now)).toBe(true);
    expect(isSuspensionExpired("suspended", now, now)).toBe(true);
    expect(isSuspensionExpired("suspended", new Date("2026-01-01T00:00:01.000Z"), now)).toBe(false);
    expect(isSuspensionExpired("suspended", null, now)).toBe(false);
    expect(isSuspensionExpired("active", new Date("2025-12-31T00:00:00.000Z"), now)).toBe(false);
    expect(isSuspensionExpired("suspended", "invalid-date", now)).toBe(false);
  });
});
