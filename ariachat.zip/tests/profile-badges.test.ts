import { describe, expect, it } from "vitest";
import { PROFILE_BADGE_TITLES, PROFILE_CROWN_STYLES, isProfileBadgeTitle, isProfileCrownStyle } from "../lib/profile-badges";
import { profileBadgeText, profileBadgeTitleLabel, profileCrownLabel } from "../lib/ui-locale-profile-badges";

const locales = ["fa", "en", "ar", "de", "tg", "ps", "ur", "sw", "es", "it", "tr", "hi"];

describe("administrator-assigned profile presentation", () => {
  it("allows only the curated display titles and the three requested crown styles", () => {
    expect(PROFILE_BADGE_TITLES).toEqual(["none", "support", "sales_agent", "top_manager", "room_manager", "admin_assistant", "featured_member"]);
    expect(PROFILE_CROWN_STYLES).toEqual(["gold_blue", "gold_red", "black_gold"]);
    for (const title of PROFILE_BADGE_TITLES) expect(isProfileBadgeTitle(title)).toBe(true);
    for (const style of PROFILE_CROWN_STYLES) expect(isProfileCrownStyle(style)).toBe(true);
    expect(isProfileBadgeTitle("administrator")).toBe(false);
    expect(isProfileCrownStyle("rainbow")).toBe(false);
    expect(isProfileCrownStyle(null)).toBe(false);
  });

  it("provides a localized title, crown, picker, and saved label for all 12 app languages", () => {
    for (const locale of locales) {
      expect(profileBadgeTitleLabel(locale, "support")).toBeTruthy();
      expect(profileBadgeTitleLabel(locale, "sales_agent")).toBeTruthy();
      expect(profileCrownLabel(locale, "gold_blue")).toBeTruthy();
      expect(profileCrownLabel(locale, "gold_red")).toBeTruthy();
      expect(profileCrownLabel(locale, "black_gold")).toBeTruthy();
      expect(profileBadgeText(locale, "displayTitle")).toBeTruthy();
      expect(profileBadgeText(locale, "saved")).toBeTruthy();
    }
    expect(profileBadgeTitleLabel("fa", "none")).toBeNull();
  });
});
