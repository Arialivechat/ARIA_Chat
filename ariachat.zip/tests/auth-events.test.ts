import { describe, expect, it, vi } from "vitest";
import { publishAuthState, subscribeAuthState } from "../lib/_core/auth-events";
import type { User } from "../lib/_core/auth";

const sampleUser: User = {
  id: 12,
  openId: "test-user-12",
  name: "Test User",
  email: null,
  loginMethod: "local",
  lastSignedIn: new Date("2026-11-14T20:00:00.000Z"),
};

describe("auth state notifications", () => {
  it("updates every mounted hook and notifies when the session is cleared", () => {
    const first = vi.fn();
    const second = vi.fn();
    const unsubscribeFirst = subscribeAuthState(first);
    const unsubscribeSecond = subscribeAuthState(second);

    publishAuthState(sampleUser);
    publishAuthState(null);

    expect(first).toHaveBeenNthCalledWith(1, sampleUser);
    expect(first).toHaveBeenNthCalledWith(2, null);
    expect(second).toHaveBeenCalledTimes(2);
    unsubscribeFirst();
    unsubscribeSecond();
  });

  it("does not notify a listener after it unsubscribes", () => {
    const listener = vi.fn();
    const unsubscribe = subscribeAuthState(listener);
    unsubscribe();
    publishAuthState(sampleUser);
    expect(listener).not.toHaveBeenCalled();
  });
});
