import { describe, expect, it, vi } from "vitest";
import { createCorsMiddleware, PUBLIC_APP_ORIGIN } from "../server/_core/cors";

describe("ARIA Chat web API CORS", () => {
  function invoke(origin?: string) {
    const req = {
      headers: origin ? { origin } : {},
      hostname: "ariachat-centgf3y.manus.space",
    } as any;
    const res = {
      vary: vi.fn(),
      header: vi.fn(),
      json: vi.fn(),
    } as any;
    res.status = vi.fn(() => res);
    const next = vi.fn();
    createCorsMiddleware(new Set([PUBLIC_APP_ORIGIN]), () => false)(req, res, next);
    return { res, next };
  }

  it("allows the exact canonical ARIA Chat origin", () => {
    const { res, next } = invoke(PUBLIC_APP_ORIGIN);
    expect(next).toHaveBeenCalledOnce();
    expect(res.header).toHaveBeenCalledWith("Access-Control-Allow-Origin", PUBLIC_APP_ORIGIN);
  });

  it("continues to reject unrelated web origins", () => {
    const { res, next } = invoke("https://untrusted.example");
    expect(next).not.toHaveBeenCalled();
    expect(res.status).toHaveBeenCalledWith(403);
    expect(res.json).toHaveBeenCalledWith({ error: "origin_not_allowed" });
  });

  it("allows native requests that do not carry an Origin header", () => {
    const { res, next } = invoke();
    expect(next).toHaveBeenCalledOnce();
    expect(res.header).not.toHaveBeenCalled();
  });
});
