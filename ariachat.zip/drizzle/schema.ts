import {
  bigint,
  boolean,
  foreignKey,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const APP_ROLES = ["user", "admin", "superadmin", "moderator", "support", "sales_agent"] as const;
export type AppRole = (typeof APP_ROLES)[number];

/**
 * Core user table backing OAuth-linked and local username/password accounts.
 * Local password hashes live in password_credentials; no device IMEIs are stored.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  /** OAuth or server-generated local-login identifier; never supplied by the client. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", APP_ROLES).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const profiles = mysqlTable(
  "profiles",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    // Nullable until the member selects a name. MySQL unique indexes allow
    // multiple NULLs while enforcing uniqueness for every selected username.
    username: varchar("username", { length: 32 }),
    avatarUrl: varchar("avatarUrl", { length: 2048 }),
    avatarEmoji: varchar("avatarEmoji", { length: 32 }),
    /** Admin-assigned display title; it does not change the user's security role. */
    badgeTitle: varchar("badgeTitle", { length: 32 }),
    /** Admin-assigned visual crown style, validated against the application allow-list. */
    crownStyle: varchar("crownStyle", { length: 32 }),
    chatMessageCount: int("chatMessageCount").default(0).notNull(),
    rankOverride: int("rankOverride"),
    age: int("age"),
    gender: mysqlEnum("gender", ["unspecified", "male", "female", "nonbinary"])
      .default("unspecified")
      .notNull(),
    city: varchar("city", { length: 120 }),
    country: varchar("country", { length: 120 }),
    bio: text("bio"),
    /** Private accounts are hidden from public discovery and their details are redacted. */
    isPrivate: boolean("isPrivate").default(false).notNull(),
    /** Private application identifier; never included in public user metadata. */
    privateId: varchar("privateId", { length: 128 }),
    language: varchar("language", { length: 16 }).default("fa").notNull(),
    darkMode: boolean("darkMode").default(false).notNull(),
    messageBubbleColor: varchar("messageBubbleColor", { length: 16 }),
    messageTextColor: varchar("messageTextColor", { length: 16 }),
    /** Paid invisibility hides online presence until this expiry; it never bypasses moderation. */
    invisibleUntil: timestamp("invisibleUntil"),
    /** A client-generated random UUID install ID. No IMEI or hardware ID is stored. */
    installId: varchar("installId", { length: 36 }),
    lastSeenAt: timestamp("lastSeenAt"),
    accountStatus: mysqlEnum("accountStatus", ["active", "muted", "suspended", "deleted"])
      .default("active")
      .notNull(),
    deletedAt: timestamp("deletedAt"),
    mutedUntil: timestamp("mutedUntil"),
    suspendedUntil: timestamp("suspendedUntil"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    uniqueIndex("profiles_user_id_unique").on(table.userId),
    uniqueIndex("profiles_username_unique").on(table.username),
    uniqueIndex("profiles_private_id_unique").on(table.privateId),
    uniqueIndex("profiles_install_id_unique").on(table.installId),
    index("profiles_location_idx").on(table.country, table.city),
    index("profiles_last_seen_idx").on(table.lastSeenAt),
  ],
);

export const rooms = mysqlTable(
  "rooms",
  {
    id: int("id").autoincrement().primaryKey(),
    title: varchar("title", { length: 120 }).notNull(),
    description: text("description"),
    type: mysqlEnum("type", ["public", "private", "country", "official"])
      .default("public")
      .notNull(),
    country: varchar("country", { length: 120 }),
    creatorId: int("creatorId")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    announcement: varchar("announcement", { length: 1000 }),
    announcementAt: timestamp("announcementAt"),
    score: bigint("score", { mode: "number" }).default(0).notNull(),
    status: mysqlEnum("status", ["active", "locked", "archived"])
      .default("active")
      .notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    index("rooms_discovery_idx").on(table.type, table.status, table.id),
    index("rooms_creator_idx").on(table.creatorId),
    index("rooms_country_idx").on(table.country, table.status),
  ],
);

export const favoriteRooms = mysqlTable(
  "favorite_rooms",
  {
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    roomId: int("roomId").notNull().references(() => rooms.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("favorite_rooms_user_room_unique").on(table.userId, table.roomId), index("favorite_rooms_room_idx").on(table.roomId)],
);
export const roomMemberships = mysqlTable(
  "room_memberships",
  {
    id: int("id").autoincrement().primaryKey(),
    roomId: int("roomId")
      .notNull()
      .references(() => rooms.id, { onDelete: "cascade" }),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    role: mysqlEnum("role", ["owner", "moderator", "member"])
      .default("member")
      .notNull(),
    mutedUntil: timestamp("mutedUntil"),
    joinedAt: timestamp("joinedAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("room_memberships_room_user_unique").on(table.roomId, table.userId),
    index("room_memberships_user_idx").on(table.userId, table.roomId),
  ],
);

export const messages = mysqlTable(
  "messages",
  {
    id: int("id").autoincrement().primaryKey(),
    roomId: int("roomId").references(() => rooms.id, { onDelete: "cascade" }),
    senderId: int("senderId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    /** Used only for a direct/private message; room messages leave this null. */
    recipientUserId: int("recipientUserId").references(() => users.id, {
      onDelete: "cascade",
    }),
    type: mysqlEnum("type", ["text", "image", "audio", "asset", "system"])
      .default("text")
      .notNull(),
    body: text("body"),
    assetUrl: varchar("assetUrl", { length: 2048 }),
    assetMetadata: text("assetMetadata"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    /** Read timestamp applies to direct messages; public room messages stay null. */
    readAt: timestamp("readAt"),
    editedAt: timestamp("editedAt"),
    deletedAt: timestamp("deletedAt"),
    deletedByUserId: int("deletedByUserId").references(() => users.id, { onDelete: "set null" }),
  },
  (table) => [
    index("messages_room_id_idx").on(table.roomId, table.id),
    index("messages_direct_idx").on(table.senderId, table.recipientUserId, table.id),
    index("messages_recipient_idx").on(table.recipientUserId, table.senderId, table.id),
    index("messages_created_at_idx").on(table.createdAt),
  ],
);

/** A user can hide a private message from their own history without affecting its recipient. */
export const messageHides = mysqlTable(
  "message_hides",
  {
    id: int("id").autoincrement().primaryKey(),
    messageId: int("messageId")
      .notNull()
      .references(() => messages.id, { onDelete: "cascade" }),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("message_hides_message_user_unique").on(table.messageId, table.userId),
    index("message_hides_user_idx").on(table.userId, table.messageId),
  ],
);

export const pointAccounts = mysqlTable(
  "point_accounts",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    balance: bigint("balance", { mode: "number" }).default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [uniqueIndex("point_accounts_user_id_unique").on(table.userId)],
);

export const pointTransactions = mysqlTable(
  "point_transactions",
  {
    id: int("id").autoincrement().primaryKey(),
    accountUserId: int("accountUserId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    counterpartyUserId: int("counterpartyUserId").references(() => users.id, {
      onDelete: "set null",
    }),
    roomId: int("roomId").references(() => rooms.id, { onDelete: "set null" }),
    type: mysqlEnum("type", [
      "transfer",
      "room_tip",
      "admin_adjustment",
      "purchase",
      "reward",
      "refund",
      "lottery_entry",
      "lottery_prize",
    ]).notNull(),
    direction: mysqlEnum("direction", ["credit", "debit"]).notNull(),
    amount: bigint("amount", { mode: "number" }).notNull(),
    balanceAfter: bigint("balanceAfter", { mode: "number" }).notNull(),
    note: varchar("note", { length: 500 }),
    performedByUserId: int("performedByUserId").references(() => users.id, {
      onDelete: "set null",
    }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("point_transactions_history_idx").on(table.accountUserId, table.id),
    index("point_transactions_room_idx").on(table.roomId, table.id),
  ],
);

export const auditLogs = mysqlTable(
  "audit_logs",
  {
    id: int("id").autoincrement().primaryKey(),
    actorUserId: int("actorUserId")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    action: varchar("action", { length: 100 }).notNull(),
    targetUserId: int("targetUserId").references(() => users.id, {
      onDelete: "set null",
    }),
    targetRoomId: int("targetRoomId").references(() => rooms.id, {
      onDelete: "set null",
    }),
    metadata: text("metadata"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("audit_logs_actor_idx").on(table.actorUserId, table.id),
    index("audit_logs_created_idx").on(table.createdAt, table.id),
  ],
);

export const friendships = mysqlTable(
  "friendships",
  {
    id: int("id").autoincrement().primaryKey(),
    /** The lower numeric user ID of the pair, maintained server-side. */
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    /** The higher numeric user ID of the pair, maintained server-side. */
    friendUserId: int("friendUserId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("friendships_pair_unique").on(table.userId, table.friendUserId),
    index("friendships_user_idx").on(table.userId),
    index("friendships_friend_idx").on(table.friendUserId),
  ],
);

export const roomInvitations = mysqlTable(
  "room_invitations",
  {
    id: int("id").autoincrement().primaryKey(),
    roomId: int("roomId").notNull().references(() => rooms.id, { onDelete: "cascade" }),
    inviterUserId: int("inviterUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    inviteeUserId: int("inviteeUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    status: mysqlEnum("status", ["pending", "accepted", "declined"]).default("pending").notNull(),
    /** Non-null only while pending, preventing concurrent duplicate invitations. */
    pendingKey: varchar("pendingKey", { length: 64 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    respondedAt: timestamp("respondedAt"),
  },
  (table) => [
    uniqueIndex("room_inv_pending_key_unique").on(table.pendingKey),
    index("room_inv_invitee_status_idx").on(table.inviteeUserId, table.status, table.id),
    index("room_inv_room_invitee_idx").on(table.roomId, table.inviteeUserId),
  ],
);

export const blockedUsers = mysqlTable(
  "blocked_users",
  {
    id: int("id").autoincrement().primaryKey(),
    blockerUserId: int("blockerUserId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    blockedUserId: int("blockedUserId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("blocked_users_pair_unique").on(table.blockerUserId, table.blockedUserId),
    index("blocked_users_blocked_idx").on(table.blockedUserId),
  ],
);

export const moderationReports = mysqlTable(
  "moderation_reports",
  {
    id: int("id").autoincrement().primaryKey(),
    reporterUserId: int("reporterUserId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    reportedUserId: int("reportedUserId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    roomId: int("roomId").references(() => rooms.id, { onDelete: "set null" }),
    messageId: int("messageId").references(() => messages.id, { onDelete: "set null" }),
    reason: varchar("reason", { length: 500 }).notNull(),
    details: text("details"),
    status: mysqlEnum("status", ["open", "reviewed", "resolved", "dismissed"])
      .default("open")
      .notNull(),
    reviewedByUserId: int("reviewedByUserId").references(() => users.id, {
      onDelete: "set null",
    }),
    reviewedAt: timestamp("reviewedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("moderation_reports_queue_idx").on(table.status, table.id),
    index("moderation_reports_reported_idx").on(table.reportedUserId, table.id),
  ],
);

export const moderationWarnings = mysqlTable(
  "moderation_warnings",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    issuedByUserId: int("issuedByUserId")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    reason: varchar("reason", { length: 500 }).notNull(),
    expiresAt: timestamp("expiresAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [index("moderation_warnings_user_idx").on(table.userId, table.id)],
);

export const ads = mysqlTable(
  "ads",
  {
    id: int("id").autoincrement().primaryKey(),
    createdByUserId: int("createdByUserId")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    title: varchar("title", { length: 160 }).notNull(),
    body: text("body"),
    assetUrl: varchar("assetUrl", { length: 2048 }),
    targetUrl: varchar("targetUrl", { length: 2048 }),
    status: mysqlEnum("status", ["draft", "active", "paused", "archived"])
      .default("draft")
      .notNull(),
    startsAt: timestamp("startsAt"),
    endsAt: timestamp("endsAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [index("ads_status_schedule_idx").on(table.status, table.startsAt, table.endsAt)],
);

export const gameRecords = mysqlTable(
  "game_records",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    opponentUserId: int("opponentUserId").references(() => users.id, {
      onDelete: "set null",
    }),
    roomId: int("roomId").references(() => rooms.id, { onDelete: "set null" }),
    gameType: varchar("gameType", { length: 80 }).notNull(),
    /** Client-generated idempotency key; nullable for legacy game rows. */
    requestId: varchar("requestId", { length: 36 }),
    status: mysqlEnum("status", ["ongoing", "completed", "abandoned"])
      .default("ongoing")
      .notNull(),
    score: bigint("score", { mode: "number" }),
    outcome: varchar("outcome", { length: 32 }),
    metadata: text("metadata"),
    startedAt: timestamp("startedAt").defaultNow().notNull(),
    endedAt: timestamp("endedAt"),
  },
  (table) => [
    index("game_records_user_idx").on(table.userId, table.id),
    uniqueIndex("game_records_user_request_unique").on(table.userId, table.requestId),
  ],
);

export const salesAgentDiscounts = mysqlTable(
  "sales_agent_discounts",
  {
    id: int("id").autoincrement().primaryKey(),
    agentUserId: int("agentUserId")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    code: varchar("code", { length: 64 }).notNull(),
    /** Percentage in basis points: 1250 means 12.50%. */
    discountBps: int("discountBps").notNull(),
    isActive: boolean("isActive").default(true).notNull(),
    startsAt: timestamp("startsAt"),
    expiresAt: timestamp("expiresAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    uniqueIndex("sales_agent_discounts_code_unique").on(table.code),
    index("sales_agent_discounts_agent_idx").on(table.agentUserId),
  ],
);

/** Paid owner requests to convert an existing room to a country room. */
export const countryRoomRequests = mysqlTable("country_room_requests", {
 id: int("id").autoincrement().primaryKey(), roomId: int("roomId").notNull().references(() => rooms.id, { onDelete: "cascade" }), requesterUserId: int("requesterUserId").notNull().references(() => users.id, { onDelete: "restrict" }), country: varchar("country", { length: 120 }).notNull(), fee: bigint("fee", { mode: "number" }).notNull(), status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(), pendingRoomKey: varchar("pendingRoomKey", { length: 32 }), reason: varchar("reason", { length: 500 }), decidedByUserId: int("decidedByUserId").references(() => users.id, { onDelete: "set null" }), requestedAt: timestamp("requestedAt").defaultNow().notNull(), decidedAt: timestamp("decidedAt"),
}, (table) => [uniqueIndex("country_room_pending_unique").on(table.pendingRoomKey), index("country_room_queue_idx").on(table.status, table.id), index("country_room_owner_idx").on(table.roomId, table.requesterUserId, table.id)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;


/** Persistent admin notices shown in the client as a centered floating card. */
export const adminNotices = mysqlTable(
  "admin_notices",
  {
    id: int("id").autoincrement().primaryKey(),
    createdByUserId: int("createdByUserId")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    targetUserId: int("targetUserId").references(() => users.id, { onDelete: "cascade" }),
    title: varchar("title", { length: 160 }).notNull(),
    body: text("body").notNull(),
    status: mysqlEnum("status", ["active", "archived"]).default("active").notNull(),
    expiresAt: timestamp("expiresAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("admin_notices_status_idx").on(table.status, table.id),
    index("admin_notices_target_idx").on(table.targetUserId, table.status),
  ],
);


/** Public account numbers are separate from internal database user IDs. */
export const accountNumbers = mysqlTable(
  "account_numbers",
  {
    accountNumber: int("accountNumber").autoincrement().primaryKey(),
    userId: int("userId").references(() => users.id, { onDelete: "set null" }),
    isReserved: boolean("isReserved").default(false).notNull(),
    claimedAt: timestamp("claimedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("account_numbers_user_unique").on(table.userId),
    index("account_numbers_reserved_idx").on(table.isReserved, table.userId),
  ],
);

/** Local credentials exist only for owner-created reserved accounts 2–100. */
export const specialAccountCredentials = mysqlTable(
  "special_account_credentials",
  {
    userId: int("userId").primaryKey().references(() => users.id, { onDelete: "cascade" }),
    accountNumber: int("accountNumber").notNull(),
    username: varchar("username", { length: 32 }).notNull(),
    passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    foreignKey({
      name: "special_credentials_account_fk",
      columns: [table.accountNumber],
      foreignColumns: [accountNumbers.accountNumber],
    }).onDelete("cascade"),
    uniqueIndex("special_credentials_account_unique").on(table.accountNumber),
    uniqueIndex("special_credentials_username_unique").on(table.username),
  ],
);

/** Scrypt hashes for public accounts created through the unified username/password form. */
export const passwordCredentials = mysqlTable(
  "password_credentials",
  {
    userId: int("userId").primaryKey().references(() => users.id, { onDelete: "cascade" }),
    username: varchar("username", { length: 32 }).notNull(),
    passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [uniqueIndex("password_credentials_username_unique").on(table.username)],
);


/** Non-sensitive bot alerts for rate limits and suspicious repeated messages. */
export const securityEvents = mysqlTable(
  "security_events",
  {
    id: int("id").autoincrement().primaryKey(),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
    eventType: mysqlEnum("eventType", ["message_flood", "duplicate_message"]).notNull(),
    severity: mysqlEnum("severity", ["warning", "high"]).default("warning").notNull(),
    summary: varchar("summary", { length: 240 }).notNull(),
    status: mysqlEnum("status", ["open", "reviewed", "dismissed"]).default("open").notNull(),
    reviewedByUserId: int("reviewedByUserId").references(() => users.id, { onDelete: "set null" }),
    reviewedAt: timestamp("reviewedAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    index("security_events_queue_idx").on(table.status, table.id),
    index("security_events_user_idx").on(table.userId, table.id),
  ],
);

/** Ownership index for durable chat files stored in Manus Managed Storage. */
export const mediaAssets = mysqlTable(
  "media_assets",
  {
    id: int("id").autoincrement().primaryKey(),
    ownerUserId: int("ownerUserId")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    storageKey: varchar("storageKey", { length: 512 }).notNull(),
    stableUrl: varchar("stableUrl", { length: 512 }).notNull(),
    fileName: varchar("fileName", { length: 255 }).notNull(),
    contentType: varchar("contentType", { length: 127 }).notNull(),
    sizeBytes: int("sizeBytes").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("media_assets_storage_key_unique").on(table.storageKey),
    uniqueIndex("media_assets_stable_url_unique").on(table.stableUrl),
    index("media_assets_owner_idx").on(table.ownerUserId, table.id),
  ],
);

/** Associates a published Heartbeat callback identity with its maintenance job. */
export const scheduledMaintenance = mysqlTable(
  "scheduled_maintenance",
  {
    id: int("id").autoincrement().primaryKey(),
    jobKey: varchar("jobKey", { length: 64 }).notNull(),
    taskUid: varchar("taskUid", { length: 128 }),
    enabled: boolean("enabled").default(true).notNull(),
    lastRunAt: timestamp("lastRunAt"),
    lastDeletedMessages: int("lastDeletedMessages").default(0).notNull(),
    lastError: varchar("lastError", { length: 240 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [
    uniqueIndex("scheduled_maintenance_job_key_unique").on(table.jobKey),
    uniqueIndex("scheduled_maintenance_task_uid_unique").on(table.taskUid),
    index("scheduled_maintenance_enabled_idx").on(table.enabled, table.id),
  ],
);

/** UTC-aligned, exactly 24-hour diamond lottery rounds. Fee is floor(gross / 10). */
export const lotteryRounds = mysqlTable(
  "lottery_rounds",
  {
    id: int("id").autoincrement().primaryKey(),
    startAt: timestamp("startAt").notNull(),
    endAt: timestamp("endAt").notNull(),
    status: mysqlEnum("status", ["open", "settled"]).default("open").notNull(),
    grossPool: bigint("grossPool", { mode: "number" }).default(0).notNull(),
    winnerUserId: int("winnerUserId").references(() => users.id, { onDelete: "set null" }),
    fee: bigint("fee", { mode: "number" }).default(0).notNull(),
    prize: bigint("prize", { mode: "number" }).default(0).notNull(),
    settledAt: timestamp("settledAt"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [uniqueIndex("lottery_rounds_start_unique").on(table.startAt), index("lottery_rounds_status_end_idx").on(table.status, table.endAt)],
);

/** Immutable contribution audit rows; multiple entries per user/round are allowed. */
export const lotteryEntries = mysqlTable(
  "lottery_entries",
  {
    id: int("id").autoincrement().primaryKey(),
    roundId: int("roundId").notNull().references(() => lotteryRounds.id, { onDelete: "restrict" }),
    userId: int("userId").notNull().references(() => users.id, { onDelete: "restrict" }),
    amount: bigint("amount", { mode: "number" }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [index("lottery_entries_round_user_idx").on(table.roundId, table.userId), index("lottery_entries_user_idx").on(table.userId, table.id)],
);

/** Opaque one-to-one voice call state; LiveKit credentials and PII are never persisted here. */
export const callSessions = mysqlTable(
  "call_sessions",
  {
    id: varchar("id", { length: 36 }).primaryKey(),
    callerUserId: int("callerUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    calleeUserId: int("calleeUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
    roomName: varchar("roomName", { length: 80 }).notNull().unique(),
    status: mysqlEnum("status", ["pending", "accepted", "declined", "ended", "expired"]).default("pending").notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => [index("call_sessions_incoming_idx").on(table.calleeUserId, table.status, table.createdAt), index("call_sessions_caller_idx").on(table.callerUserId, table.status, table.createdAt)],
);
