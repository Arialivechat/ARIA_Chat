CREATE TABLE `account_numbers` (
	`accountNumber` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`isReserved` boolean NOT NULL DEFAULT false,
	`claimedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `account_numbers_accountNumber` PRIMARY KEY(`accountNumber`),
	CONSTRAINT `account_numbers_user_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `admin_notices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`createdByUserId` int NOT NULL,
	`targetUserId` int,
	`title` varchar(160) NOT NULL,
	`body` text NOT NULL,
	`status` enum('active','archived') NOT NULL DEFAULT 'active',
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_notices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `ads` (
	`id` int AUTO_INCREMENT NOT NULL,
	`createdByUserId` int NOT NULL,
	`title` varchar(160) NOT NULL,
	`body` text,
	`assetUrl` varchar(2048),
	`targetUrl` varchar(2048),
	`status` enum('draft','active','paused','archived') NOT NULL DEFAULT 'draft',
	`startsAt` timestamp,
	`endsAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `ads_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`actorUserId` int NOT NULL,
	`action` varchar(100) NOT NULL,
	`targetUserId` int,
	`targetRoomId` int,
	`metadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `blocked_users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`blockerUserId` int NOT NULL,
	`blockedUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `blocked_users_id` PRIMARY KEY(`id`),
	CONSTRAINT `blocked_users_pair_unique` UNIQUE(`blockerUserId`,`blockedUserId`)
);
--> statement-breakpoint
CREATE TABLE `friendships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`friendUserId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `friendships_id` PRIMARY KEY(`id`),
	CONSTRAINT `friendships_pair_unique` UNIQUE(`userId`,`friendUserId`)
);
--> statement-breakpoint
CREATE TABLE `game_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`opponentUserId` int,
	`roomId` int,
	`gameType` varchar(80) NOT NULL,
	`status` enum('ongoing','completed','abandoned') NOT NULL DEFAULT 'ongoing',
	`score` int,
	`outcome` varchar(32),
	`metadata` text,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`endedAt` timestamp,
	CONSTRAINT `game_records_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roomId` int,
	`senderId` int NOT NULL,
	`recipientUserId` int,
	`type` enum('text','image','audio','asset','system') NOT NULL DEFAULT 'text',
	`body` text,
	`assetUrl` varchar(2048),
	`assetMetadata` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`editedAt` timestamp,
	CONSTRAINT `messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `moderation_reports` (
	`id` int AUTO_INCREMENT NOT NULL,
	`reporterUserId` int NOT NULL,
	`reportedUserId` int NOT NULL,
	`roomId` int,
	`messageId` int,
	`reason` varchar(500) NOT NULL,
	`details` text,
	`status` enum('open','reviewed','resolved','dismissed') NOT NULL DEFAULT 'open',
	`reviewedByUserId` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `moderation_reports_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `moderation_warnings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`issuedByUserId` int NOT NULL,
	`reason` varchar(500) NOT NULL,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `moderation_warnings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `point_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`balance` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `point_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `point_accounts_user_id_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `point_transactions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`accountUserId` int NOT NULL,
	`counterpartyUserId` int,
	`roomId` int,
	`type` enum('transfer','room_tip','admin_adjustment','purchase','reward','refund') NOT NULL,
	`direction` enum('credit','debit') NOT NULL,
	`amount` int NOT NULL,
	`balanceAfter` int NOT NULL,
	`note` varchar(500),
	`performedByUserId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `point_transactions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`username` varchar(32),
	`avatarUrl` varchar(2048),
	`chatMessageCount` int NOT NULL DEFAULT 0,
	`rankOverride` int,
	`age` int,
	`gender` enum('unspecified','male','female','nonbinary') NOT NULL DEFAULT 'unspecified',
	`city` varchar(120),
	`country` varchar(120),
	`bio` text,
	`isPrivate` boolean NOT NULL DEFAULT false,
	`privateId` varchar(128),
	`language` varchar(16) NOT NULL DEFAULT 'fa',
	`darkMode` boolean NOT NULL DEFAULT false,
	`messageBubbleColor` varchar(16),
	`messageTextColor` varchar(16),
	`installId` varchar(36),
	`lastSeenAt` timestamp,
	`accountStatus` enum('active','muted','suspended') NOT NULL DEFAULT 'active',
	`mutedUntil` timestamp,
	`suspendedUntil` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `profiles_user_id_unique` UNIQUE(`userId`),
	CONSTRAINT `profiles_username_unique` UNIQUE(`username`),
	CONSTRAINT `profiles_private_id_unique` UNIQUE(`privateId`),
	CONSTRAINT `profiles_install_id_unique` UNIQUE(`installId`)
);
--> statement-breakpoint
CREATE TABLE `room_memberships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roomId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('owner','moderator','member') NOT NULL DEFAULT 'member',
	`joinedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `room_memberships_id` PRIMARY KEY(`id`),
	CONSTRAINT `room_memberships_room_user_unique` UNIQUE(`roomId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `rooms` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(120) NOT NULL,
	`description` text,
	`type` enum('public','private','country','official') NOT NULL DEFAULT 'public',
	`country` varchar(120),
	`creatorId` int NOT NULL,
	`score` int NOT NULL DEFAULT 0,
	`status` enum('active','locked','archived') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `rooms_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `sales_agent_discounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`agentUserId` int NOT NULL,
	`code` varchar(64) NOT NULL,
	`discountBps` int NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`startsAt` timestamp,
	`expiresAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `sales_agent_discounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `sales_agent_discounts_code_unique` UNIQUE(`code`)
);
--> statement-breakpoint
CREATE TABLE `security_events` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`eventType` enum('message_flood','duplicate_message') NOT NULL,
	`severity` enum('warning','high') NOT NULL DEFAULT 'warning',
	`summary` varchar(240) NOT NULL,
	`status` enum('open','reviewed','dismissed') NOT NULL DEFAULT 'open',
	`reviewedByUserId` int,
	`reviewedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `security_events_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `special_account_credentials` (
	`userId` int NOT NULL,
	`accountNumber` int NOT NULL,
	`username` varchar(32) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `special_account_credentials_userId` PRIMARY KEY(`userId`),
	CONSTRAINT `special_credentials_account_unique` UNIQUE(`accountNumber`),
	CONSTRAINT `special_credentials_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','superadmin','moderator','support','sales_agent') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `account_numbers` ADD CONSTRAINT `account_numbers_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `admin_notices` ADD CONSTRAINT `admin_notices_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `admin_notices` ADD CONSTRAINT `admin_notices_targetUserId_users_id_fk` FOREIGN KEY (`targetUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `ads` ADD CONSTRAINT `ads_createdByUserId_users_id_fk` FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_actorUserId_users_id_fk` FOREIGN KEY (`actorUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_targetUserId_users_id_fk` FOREIGN KEY (`targetUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `audit_logs` ADD CONSTRAINT `audit_logs_targetRoomId_rooms_id_fk` FOREIGN KEY (`targetRoomId`) REFERENCES `rooms`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `blocked_users` ADD CONSTRAINT `blocked_users_blockerUserId_users_id_fk` FOREIGN KEY (`blockerUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `blocked_users` ADD CONSTRAINT `blocked_users_blockedUserId_users_id_fk` FOREIGN KEY (`blockedUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `friendships` ADD CONSTRAINT `friendships_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `friendships` ADD CONSTRAINT `friendships_friendUserId_users_id_fk` FOREIGN KEY (`friendUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `game_records` ADD CONSTRAINT `game_records_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `game_records` ADD CONSTRAINT `game_records_opponentUserId_users_id_fk` FOREIGN KEY (`opponentUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `game_records` ADD CONSTRAINT `game_records_roomId_rooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `rooms`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `messages` ADD CONSTRAINT `messages_roomId_rooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `rooms`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `messages` ADD CONSTRAINT `messages_senderId_users_id_fk` FOREIGN KEY (`senderId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `messages` ADD CONSTRAINT `messages_recipientUserId_users_id_fk` FOREIGN KEY (`recipientUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `moderation_reports` ADD CONSTRAINT `moderation_reports_reporterUserId_users_id_fk` FOREIGN KEY (`reporterUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `moderation_reports` ADD CONSTRAINT `moderation_reports_reportedUserId_users_id_fk` FOREIGN KEY (`reportedUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `moderation_reports` ADD CONSTRAINT `moderation_reports_roomId_rooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `rooms`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `moderation_reports` ADD CONSTRAINT `moderation_reports_messageId_messages_id_fk` FOREIGN KEY (`messageId`) REFERENCES `messages`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `moderation_reports` ADD CONSTRAINT `moderation_reports_reviewedByUserId_users_id_fk` FOREIGN KEY (`reviewedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `moderation_warnings` ADD CONSTRAINT `moderation_warnings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `moderation_warnings` ADD CONSTRAINT `moderation_warnings_issuedByUserId_users_id_fk` FOREIGN KEY (`issuedByUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `point_accounts` ADD CONSTRAINT `point_accounts_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `point_transactions` ADD CONSTRAINT `point_transactions_accountUserId_users_id_fk` FOREIGN KEY (`accountUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `point_transactions` ADD CONSTRAINT `point_transactions_counterpartyUserId_users_id_fk` FOREIGN KEY (`counterpartyUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `point_transactions` ADD CONSTRAINT `point_transactions_roomId_rooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `rooms`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `point_transactions` ADD CONSTRAINT `point_transactions_performedByUserId_users_id_fk` FOREIGN KEY (`performedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `profiles` ADD CONSTRAINT `profiles_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `room_memberships` ADD CONSTRAINT `room_memberships_roomId_rooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `rooms`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `room_memberships` ADD CONSTRAINT `room_memberships_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `rooms` ADD CONSTRAINT `rooms_creatorId_users_id_fk` FOREIGN KEY (`creatorId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `sales_agent_discounts` ADD CONSTRAINT `sales_agent_discounts_agentUserId_users_id_fk` FOREIGN KEY (`agentUserId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `security_events` ADD CONSTRAINT `security_events_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `security_events` ADD CONSTRAINT `security_events_reviewedByUserId_users_id_fk` FOREIGN KEY (`reviewedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `special_account_credentials` ADD CONSTRAINT `special_account_credentials_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `special_account_credentials` ADD CONSTRAINT `special_credentials_account_fk` FOREIGN KEY (`accountNumber`) REFERENCES `account_numbers`(`accountNumber`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `account_numbers_reserved_idx` ON `account_numbers` (`isReserved`,`userId`);--> statement-breakpoint
CREATE INDEX `admin_notices_status_idx` ON `admin_notices` (`status`,`id`);--> statement-breakpoint
CREATE INDEX `admin_notices_target_idx` ON `admin_notices` (`targetUserId`,`status`);--> statement-breakpoint
CREATE INDEX `ads_status_schedule_idx` ON `ads` (`status`,`startsAt`,`endsAt`);--> statement-breakpoint
CREATE INDEX `audit_logs_actor_idx` ON `audit_logs` (`actorUserId`,`id`);--> statement-breakpoint
CREATE INDEX `audit_logs_created_idx` ON `audit_logs` (`createdAt`,`id`);--> statement-breakpoint
CREATE INDEX `blocked_users_blocked_idx` ON `blocked_users` (`blockedUserId`);--> statement-breakpoint
CREATE INDEX `friendships_user_idx` ON `friendships` (`userId`);--> statement-breakpoint
CREATE INDEX `friendships_friend_idx` ON `friendships` (`friendUserId`);--> statement-breakpoint
CREATE INDEX `game_records_user_idx` ON `game_records` (`userId`,`id`);--> statement-breakpoint
CREATE INDEX `messages_room_id_idx` ON `messages` (`roomId`,`id`);--> statement-breakpoint
CREATE INDEX `messages_direct_idx` ON `messages` (`senderId`,`recipientUserId`,`id`);--> statement-breakpoint
CREATE INDEX `messages_recipient_idx` ON `messages` (`recipientUserId`,`senderId`,`id`);--> statement-breakpoint
CREATE INDEX `moderation_reports_queue_idx` ON `moderation_reports` (`status`,`id`);--> statement-breakpoint
CREATE INDEX `moderation_reports_reported_idx` ON `moderation_reports` (`reportedUserId`,`id`);--> statement-breakpoint
CREATE INDEX `moderation_warnings_user_idx` ON `moderation_warnings` (`userId`,`id`);--> statement-breakpoint
CREATE INDEX `point_transactions_history_idx` ON `point_transactions` (`accountUserId`,`id`);--> statement-breakpoint
CREATE INDEX `point_transactions_room_idx` ON `point_transactions` (`roomId`,`id`);--> statement-breakpoint
CREATE INDEX `profiles_location_idx` ON `profiles` (`country`,`city`);--> statement-breakpoint
CREATE INDEX `profiles_last_seen_idx` ON `profiles` (`lastSeenAt`);--> statement-breakpoint
CREATE INDEX `room_memberships_user_idx` ON `room_memberships` (`userId`,`roomId`);--> statement-breakpoint
CREATE INDEX `rooms_discovery_idx` ON `rooms` (`type`,`status`,`id`);--> statement-breakpoint
CREATE INDEX `rooms_creator_idx` ON `rooms` (`creatorId`);--> statement-breakpoint
CREATE INDEX `rooms_country_idx` ON `rooms` (`country`,`status`);--> statement-breakpoint
CREATE INDEX `sales_agent_discounts_agent_idx` ON `sales_agent_discounts` (`agentUserId`);--> statement-breakpoint
CREATE INDEX `security_events_queue_idx` ON `security_events` (`status`,`id`);--> statement-breakpoint
CREATE INDEX `security_events_user_idx` ON `security_events` (`userId`,`id`);
