CREATE TABLE `call_sessions` (
	`id` varchar(36) NOT NULL,
	`callerUserId` int NOT NULL,
	`calleeUserId` int NOT NULL,
	`roomName` varchar(80) NOT NULL,
	`status` enum('pending','accepted','declined','ended','expired') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `call_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `call_sessions_roomName_unique` UNIQUE(`roomName`)
);
--> statement-breakpoint
CREATE TABLE `lottery_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roundId` int NOT NULL,
	`userId` int NOT NULL,
	`amount` bigint NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lottery_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lottery_rounds` (
	`id` int AUTO_INCREMENT NOT NULL,
	`startAt` timestamp NOT NULL,
	`endAt` timestamp NOT NULL,
	`status` enum('open','settled') NOT NULL DEFAULT 'open',
	`grossPool` bigint NOT NULL DEFAULT 0,
	`winnerUserId` int,
	`fee` bigint NOT NULL DEFAULT 0,
	`prize` bigint NOT NULL DEFAULT 0,
	`settledAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lottery_rounds_id` PRIMARY KEY(`id`),
	CONSTRAINT `lottery_rounds_start_unique` UNIQUE(`startAt`)
);
--> statement-breakpoint
ALTER TABLE `point_transactions` MODIFY COLUMN `type` enum('transfer','room_tip','admin_adjustment','purchase','reward','refund','lottery_entry','lottery_prize') NOT NULL;--> statement-breakpoint
ALTER TABLE `call_sessions` ADD CONSTRAINT `call_sessions_callerUserId_users_id_fk` FOREIGN KEY (`callerUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `call_sessions` ADD CONSTRAINT `call_sessions_calleeUserId_users_id_fk` FOREIGN KEY (`calleeUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `lottery_entries` ADD CONSTRAINT `lottery_entries_roundId_lottery_rounds_id_fk` FOREIGN KEY (`roundId`) REFERENCES `lottery_rounds`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `lottery_entries` ADD CONSTRAINT `lottery_entries_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `lottery_rounds` ADD CONSTRAINT `lottery_rounds_winnerUserId_users_id_fk` FOREIGN KEY (`winnerUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `call_sessions_incoming_idx` ON `call_sessions` (`calleeUserId`,`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `call_sessions_caller_idx` ON `call_sessions` (`callerUserId`,`status`,`createdAt`);--> statement-breakpoint
CREATE INDEX `lottery_entries_round_user_idx` ON `lottery_entries` (`roundId`,`userId`);--> statement-breakpoint
CREATE INDEX `lottery_entries_user_idx` ON `lottery_entries` (`userId`,`id`);--> statement-breakpoint
CREATE INDEX `lottery_rounds_status_end_idx` ON `lottery_rounds` (`status`,`endAt`);