CREATE TABLE `media_assets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ownerUserId` int NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`stableUrl` varchar(512) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`contentType` varchar(127) NOT NULL,
	`sizeBytes` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `media_assets_id` PRIMARY KEY(`id`),
	CONSTRAINT `media_assets_storage_key_unique` UNIQUE(`storageKey`),
	CONSTRAINT `media_assets_stable_url_unique` UNIQUE(`stableUrl`)
);
--> statement-breakpoint
CREATE TABLE `message_hides` (
	`id` int AUTO_INCREMENT NOT NULL,
	`messageId` int NOT NULL,
	`userId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `message_hides_id` PRIMARY KEY(`id`),
	CONSTRAINT `message_hides_message_user_unique` UNIQUE(`messageId`,`userId`)
);
--> statement-breakpoint
CREATE TABLE `password_credentials` (
	`userId` int NOT NULL,
	`username` varchar(32) NOT NULL,
	`passwordHash` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `password_credentials_userId` PRIMARY KEY(`userId`),
	CONSTRAINT `password_credentials_username_unique` UNIQUE(`username`)
);
--> statement-breakpoint
ALTER TABLE `messages` ADD `deletedAt` timestamp;--> statement-breakpoint
ALTER TABLE `messages` ADD `deletedByUserId` int;--> statement-breakpoint
ALTER TABLE `profiles` ADD `invisibleUntil` timestamp;--> statement-breakpoint
ALTER TABLE `room_memberships` ADD `mutedUntil` timestamp;--> statement-breakpoint
ALTER TABLE `rooms` ADD `announcement` varchar(1000);--> statement-breakpoint
ALTER TABLE `rooms` ADD `announcementAt` timestamp;--> statement-breakpoint
ALTER TABLE `media_assets` ADD CONSTRAINT `media_assets_ownerUserId_users_id_fk` FOREIGN KEY (`ownerUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `message_hides` ADD CONSTRAINT `message_hides_messageId_messages_id_fk` FOREIGN KEY (`messageId`) REFERENCES `messages`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `message_hides` ADD CONSTRAINT `message_hides_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `password_credentials` ADD CONSTRAINT `password_credentials_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `media_assets_owner_idx` ON `media_assets` (`ownerUserId`,`id`);--> statement-breakpoint
CREATE INDEX `message_hides_user_idx` ON `message_hides` (`userId`,`messageId`);--> statement-breakpoint
ALTER TABLE `messages` ADD CONSTRAINT `messages_deletedByUserId_users_id_fk` FOREIGN KEY (`deletedByUserId`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;