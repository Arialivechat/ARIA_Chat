CREATE TABLE `room_invitations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`roomId` int NOT NULL,
	`inviterUserId` int NOT NULL,
	`inviteeUserId` int NOT NULL,
	`status` enum('pending','accepted','declined') NOT NULL DEFAULT 'pending',
	`pendingKey` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`respondedAt` timestamp,
	CONSTRAINT `room_invitations_id` PRIMARY KEY(`id`),
	CONSTRAINT `room_inv_pending_key_unique` UNIQUE(`pendingKey`)
);
--> statement-breakpoint
ALTER TABLE `room_invitations` ADD CONSTRAINT `room_invitations_roomId_rooms_id_fk` FOREIGN KEY (`roomId`) REFERENCES `rooms`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `room_invitations` ADD CONSTRAINT `room_invitations_inviterUserId_users_id_fk` FOREIGN KEY (`inviterUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `room_invitations` ADD CONSTRAINT `room_invitations_inviteeUserId_users_id_fk` FOREIGN KEY (`inviteeUserId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `room_inv_invitee_status_idx` ON `room_invitations` (`inviteeUserId`,`status`,`id`);--> statement-breakpoint
CREATE INDEX `room_inv_room_invitee_idx` ON `room_invitations` (`roomId`,`inviteeUserId`);