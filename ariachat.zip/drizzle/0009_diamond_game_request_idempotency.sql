ALTER TABLE `game_records` ADD `requestId` varchar(36);--> statement-breakpoint
ALTER TABLE `game_records` ADD CONSTRAINT `game_records_user_request_unique` UNIQUE(`userId`,`requestId`);