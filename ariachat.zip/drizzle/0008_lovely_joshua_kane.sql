ALTER TABLE `profiles` ADD `badgeTitle` varchar(32);--> statement-breakpoint
ALTER TABLE `profiles` ADD `crownStyle` varchar(32);