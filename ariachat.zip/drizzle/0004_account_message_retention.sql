CREATE TABLE `scheduled_maintenance` (
	`id` int AUTO_INCREMENT NOT NULL,
	`jobKey` varchar(64) NOT NULL,
	`taskUid` varchar(128),
	`enabled` boolean NOT NULL DEFAULT true,
	`lastRunAt` timestamp,
	`lastDeletedMessages` int NOT NULL DEFAULT 0,
	`lastError` varchar(240),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `scheduled_maintenance_id` PRIMARY KEY(`id`),
	CONSTRAINT `scheduled_maintenance_job_key_unique` UNIQUE(`jobKey`),
	CONSTRAINT `scheduled_maintenance_task_uid_unique` UNIQUE(`taskUid`)
);
--> statement-breakpoint
ALTER TABLE `game_records` MODIFY COLUMN `score` bigint;--> statement-breakpoint
ALTER TABLE `point_accounts` MODIFY COLUMN `balance` bigint NOT NULL;--> statement-breakpoint
ALTER TABLE `point_transactions` MODIFY COLUMN `amount` bigint NOT NULL;--> statement-breakpoint
ALTER TABLE `point_transactions` MODIFY COLUMN `balanceAfter` bigint NOT NULL;--> statement-breakpoint
ALTER TABLE `profiles` MODIFY COLUMN `accountStatus` enum('active','muted','suspended','deleted') NOT NULL DEFAULT 'active';--> statement-breakpoint
ALTER TABLE `rooms` MODIFY COLUMN `score` bigint NOT NULL;--> statement-breakpoint
ALTER TABLE `messages` ADD `readAt` timestamp;--> statement-breakpoint
ALTER TABLE `profiles` ADD `deletedAt` timestamp;--> statement-breakpoint
CREATE INDEX `scheduled_maintenance_enabled_idx` ON `scheduled_maintenance` (`enabled`,`id`);--> statement-breakpoint
CREATE INDEX `messages_created_at_idx` ON `messages` (`createdAt`);