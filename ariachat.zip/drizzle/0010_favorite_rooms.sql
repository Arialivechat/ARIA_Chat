CREATE TABLE `favorite_rooms` (`userId` int NOT NULL, `roomId` int NOT NULL, `createdAt` timestamp NOT NULL DEFAULT (now()), CONSTRAINT `favorite_rooms_user_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE, CONSTRAINT `favorite_rooms_room_fk` FOREIGN KEY (`roomId`) REFERENCES `rooms`(`id`) ON DELETE CASCADE);--> statement-breakpoint
CREATE UNIQUE INDEX `favorite_rooms_user_room_unique` ON `favorite_rooms` (`userId`,`roomId`);--> statement-breakpoint
CREATE INDEX `favorite_rooms_room_idx` ON `favorite_rooms` (`roomId`);
