import { and, eq } from "drizzle-orm";
import { scheduledMaintenance } from "../drizzle/schema";
import { getDb } from "../server/db";
import {
  createHeartbeatJob,
  deleteHeartbeatJob,
  listHeartbeatJobs,
  updateHeartbeatJob,
} from "../server/_core/heartbeat";

const JOB_KEY = "message-retention";
const JOB_NAME = "aria-chat-message-retention";
const CRON_UTC = "0 15 3 * * *";
const CALLBACK_PATH = "/api/scheduled/message-retention";
const DESCRIPTION = "Delete ARIA Chat messages older than four days and clear unreferenced media index rows.";

async function main() {
  const db = await getDb();
  if (!db) throw new Error("Managed database is not available in this runtime.");

  try {
    const existing = await listHeartbeatJobs("", { page: 1, pageSize: 200 });
    const job = (existing.jobs ?? []).find((candidate) => candidate.name === JOB_NAME);
    let taskUid: string;
    let createdNow = false;

    if (job) {
      taskUid = job.taskUid;
      await updateHeartbeatJob(taskUid, {
        cron: CRON_UTC,
        path: CALLBACK_PATH,
        method: "POST",
        payload: {},
        description: DESCRIPTION,
        enable: true,
      }, "");
    } else {
      const created = await createHeartbeatJob({
        name: JOB_NAME,
        cron: CRON_UTC,
        path: CALLBACK_PATH,
        method: "POST",
        payload: {},
        description: DESCRIPTION,
      }, "");
      taskUid = created.taskUid;
      createdNow = true;
    }

    try {
      await db.insert(scheduledMaintenance).values({ jobKey: JOB_KEY, taskUid, enabled: true })
        .onDuplicateKeyUpdate({ set: { taskUid, enabled: true, lastError: null } });
    } catch (error) {
      if (createdNow) await deleteHeartbeatJob(taskUid, "").catch(() => undefined);
      throw error;
    }

    console.info(`Scheduled retention job is enabled (${JOB_NAME}, ${CRON_UTC} UTC).`);
  } finally {
    await db.$client.end();
  }
}

main().catch((error) => {
  // Avoid printing environment values or callback credentials in task output.
  console.error(error instanceof Error ? error.message : "Could not register the retention job.");
  process.exitCode = 1;
});
