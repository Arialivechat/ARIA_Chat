import { useCallback } from "react";
import { useAudioPlayer } from "expo-audio";

/** Small, opt-in UI sound effects. Playback only starts when a returned function is called. */
export function useSoundEffects() {
  const privateMessagePlayer = useAudioPlayer(
    require("../assets/sounds/private-message.wav"),
  );
  const gameWinPlayer = useAudioPlayer(require("../assets/sounds/game-win.wav"));
  const gameLossPlayer = useAudioPlayer(require("../assets/sounds/game-loss.wav"));

  const play = useCallback((player: typeof privateMessagePlayer) => {
    try {
      player.volume = 0.22;
      // Seeking before replay also makes repeated, rapid calls restart the short cue.
      void player.seekTo(0).then(() => player.play()).catch(() => undefined);
    } catch {
      // Audio may be unavailable (for example, browser autoplay restrictions).
    }
  }, []);

  return {
    playPrivateMessage: useCallback(() => play(privateMessagePlayer), [play, privateMessagePlayer]),
    playGameWin: useCallback(() => play(gameWinPlayer), [play, gameWinPlayer]),
    playGameLoss: useCallback(() => play(gameLossPlayer), [play, gameLossPlayer]),
  };
}
