import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { LOCALE_STORAGE_KEY, isLocale, translate, type Locale } from "@/lib/locales";
import { translateExtra, type ExtraLocaleKey } from "@/lib/locale-extras";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/hooks/use-auth";

type LanguageContextValue = { locale: Locale; isRTL: boolean; isLocaleManuallySelected: boolean; setLocale: (locale: Locale) => void; t: (key: Parameters<typeof translate>[1]) => string; tExtra: (key: ExtraLocaleKey, values?: { count?: number }) => string };
const LanguageContext = createContext<LanguageContextValue | null>(null);
export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("fa");
  const [isLocaleManuallySelected, setIsLocaleManuallySelected] = useState(false);
  const { isAuthenticated } = useAuth();
  const profile = trpc.profile.me.useQuery(undefined, { enabled: isAuthenticated });
  const update = trpc.profile.update.useMutation();
  const userSelected = useRef(false);
  const didHydrate = useRef(false);
  const setLocale = useCallback((next: Locale) => {
    userSelected.current = true;
    setIsLocaleManuallySelected(true);
    setLocaleState(next);
    void AsyncStorage.setItem(LOCALE_STORAGE_KEY, next).catch(() => {});
    if (isAuthenticated) update.mutate({ language: next }, { onError: () => {} });
  }, [isAuthenticated, update]);
  useEffect(() => { let active = true; void AsyncStorage.getItem(LOCALE_STORAGE_KEY).then((stored) => { if (active && !userSelected.current && isLocale(stored)) setLocaleState(stored); }).catch(() => {}); return () => { active = false; }; }, []);
  useEffect(() => {
    if (!isAuthenticated || !profile.data || didHydrate.current) return;
    didHydrate.current = true;
    if (!userSelected.current && isLocale(profile.data.language)) {
      setLocaleState(profile.data.language);
      void AsyncStorage.setItem(LOCALE_STORAGE_KEY, profile.data.language).catch(() => {});
    }
  }, [isAuthenticated, profile.data]);
  useEffect(() => { if (!isAuthenticated) didHydrate.current = false; }, [isAuthenticated]);
  const value = useMemo(() => ({ locale, isRTL: ["fa", "ar", "ps", "ur"].includes(locale), isLocaleManuallySelected, setLocale, t: (key: Parameters<typeof translate>[1]) => translate(locale, key), tExtra: (key: ExtraLocaleKey, values?: { count?: number }) => translateExtra(locale, key, values) }), [locale, isLocaleManuallySelected, setLocale]);
  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}
export function useLanguage() { const context = useContext(LanguageContext); if (!context) throw new Error("useLanguage must be used inside LanguageProvider"); return context; }
