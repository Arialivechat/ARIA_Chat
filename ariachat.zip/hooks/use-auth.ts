import * as Api from "@/lib/_core/api";
import * as Auth from "@/lib/_core/auth";
import { subscribeAuthState } from "@/lib/_core/auth-events";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Platform } from "react-native";

type UseAuthOptions = {
  autoFetch?: boolean;
};

export function useAuth(options?: UseAuthOptions) {
  const { autoFetch = true } = options ?? {};
  const [user, setUser] = useState<Auth.User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const requestGeneration = useRef(0);

  const fetchUser = useCallback(async () => {
    console.log("[useAuth] fetchUser called");
    const requestId = ++requestGeneration.current;
    let cachedUser: Auth.User | null = null;
    try {
      if (Platform.OS !== "web") cachedUser = await Auth.getUserInfo();
      if (requestId !== requestGeneration.current) return;
      setLoading(true);
      setError(null);

      // Both platforms validate the session server-side. Web uses its session cookie;
      // native requests use the stored bearer token through the shared API client.
      const apiUser = await Api.getMe();
      if (requestId !== requestGeneration.current) return;
      if (apiUser) {
        const userInfo: Auth.User = {
          id: apiUser.id,
          openId: apiUser.openId,
          name: apiUser.name,
          email: apiUser.email,
          loginMethod: apiUser.loginMethod,
          lastSignedIn: new Date(apiUser.lastSignedIn),
        };
        setUser(userInfo);
        await Auth.setUserInfo(userInfo);
      } else {
        setUser(null);
        await Auth.clearUserInfo();
        if (Platform.OS !== "web") await Auth.removeSessionToken();
      }
    } catch (err) {
      if (requestId !== requestGeneration.current) return;
      const error = err instanceof Error ? err : new Error("Failed to fetch user");
      console.error("[useAuth] Session validation unavailable");
      setError(error);
      setUser(cachedUser);
    } finally {
      if (requestId === requestGeneration.current) {
        setLoading(false);
        console.log("[useAuth] fetchUser completed, loading:", false);
      }
    }
  }, []);

  const logout = useCallback(async () => {
    try {
      await Api.logout();
    } catch {
      console.error("[Auth] Logout API call failed");
      // Continue with logout even if API call fails
    } finally {
      await Auth.removeSessionToken();
      await Auth.clearUserInfo();
      setUser(null);
      setError(null);
    }
  }, []);

  const isAuthenticated = useMemo(() => Boolean(user), [user]);

  useEffect(() => subscribeAuthState((nextUser) => {
    requestGeneration.current += 1;
    setUser(nextUser);
    setError(null);
    setLoading(false);
  }), []);

  useEffect(() => {
    console.log("[useAuth] useEffect triggered");
    if (autoFetch) {
      fetchUser();
    } else {
      console.log("[useAuth] autoFetch disabled, setting loading to false");
      setLoading(false);
    }
  }, [autoFetch, fetchUser]);

  return {
    user,
    loading,
    error,
    isAuthenticated,
    refresh: fetchUser,
    logout,
  };
}
