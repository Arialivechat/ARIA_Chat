const MANAGED_STORAGE_PREFIX = "/manus-storage/";
const MAX_AVATAR_URL_LENGTH = 2_048;

/**
 * Avatar records may hold a durable platform storage path or an external HTTP(S) URL.
 * Signed CDN URLs are for rendering only; uploaded avatars should persist the stable path.
 */
export function isProfileAvatarUrl(value: unknown): value is string {
  if (typeof value !== "string") return false;
  const normalized = value.trim();
  if (!normalized || normalized.length > MAX_AVATAR_URL_LENGTH) return false;

  if (normalized.startsWith(MANAGED_STORAGE_PREFIX)) {
    const key = normalized.slice(MANAGED_STORAGE_PREFIX.length);
    if (!key || !/^[\x21-\x7e]+$/.test(key) || /[?#\\]/.test(key)) return false;
    return key.split("/").every((segment) => segment.length > 0 && segment !== "." && segment !== "..");
  }

  try {
    const url = new URL(normalized);
    const hostname = url.hostname.replace(/\.$/, "");
    const isIpLiteral = hostname.startsWith("[") && hostname.endsWith("]");
    const isValidHostname = isIpLiteral || hostname.split(".").every((label) =>
      label.length > 0 && label.length <= 63 && /^[a-z0-9-]+$/i.test(label) && !label.startsWith("-") && !label.endsWith("-"),
    );
    return (url.protocol === "https:" || url.protocol === "http:")
      && Boolean(hostname)
      && isValidHostname
      && !url.username
      && !url.password;
  } catch {
    return false;
  }
}
