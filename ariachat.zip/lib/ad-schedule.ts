export const AD_VISIBILITY_WINDOW_MS = 24 * 60 * 60 * 1000;

export interface ScheduledAd {
  status: string;
  startsAt: Date | string | null;
  endsAt: Date | string | null;
  createdAt: Date | string;
}

function asDate(value: Date | string): Date {
  return value instanceof Date ? value : new Date(value);
}

/** Active ads are visible only during their schedule and for at most 24 hours. */
export function isAdVisibleAt(ad: ScheduledAd, now: Date): boolean {
  if (ad.status !== "active") return false;

  const start = asDate(ad.startsAt ?? ad.createdAt);
  if (!Number.isFinite(start.getTime()) || start.getTime() > now.getTime()) return false;

  const expiry = start.getTime() + AD_VISIBILITY_WINDOW_MS;
  const scheduledEnd = ad.endsAt == null ? expiry : asDate(ad.endsAt).getTime();
  if (!Number.isFinite(scheduledEnd)) return false;

  return now.getTime() <= Math.min(expiry, scheduledEnd);
}
