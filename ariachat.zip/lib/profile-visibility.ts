/** A private profile is fully visible only to its owner or a confirmed mutual friend. */
export function canViewPrivateProfile(isPrivate: unknown, isFriend: unknown, isSelf: unknown): boolean {
  return !Boolean(isPrivate) || Boolean(isFriend) || Boolean(isSelf);
}
