import type { Locale } from "./locales";

const gameExtra = {
  fa: {
    chooseParity: "زوج یا فرد را انتخاب کن؛ شانس برد ۳۰٪ است و عدد تاس با نتیجه هماهنگ نمایش داده می‌شود.", even: "زوج", odd: "فرد", yourChoice: "انتخاب شما", rolled: "عدد تاس",
    miniRules: "در هر دور، نتیجه را سرور به‌صورت تصادفی تعیین می‌کند: احتمال برد ۳۰٪ است؛ در برد، ۳ برابر مبلغ بازی به کیف اضافه می‌شود و در باخت جایزه‌ای پرداخت نمی‌شود. الماس‌ها پول واقعی نیستند.",
    miniAmountLabel: "مبلغ الماس (۱ یا بیشتر)", ticTacToe: "دوز الماسی", memoryMatch: "حافظهٔ الماسی", guessNumber: "حدس عدد", treasureHunt: "کشف گنج",
    chooseNumber: "یک عدد از ۱ تا ۱۰ انتخاب کن", chooseChest: "یک صندوق از ۱ تا ۱۰ انتخاب کن", winningNumbers: "عددهای برنده", treasureSpots: "صندوق‌های دارای گنج", memoryPairs: "جفت‌های پیدا‌شده", playRound: "شروع دور", gameResult: "نتیجهٔ ثبت‌شده در سرور",
  },
  en: {
    chooseParity: "Choose odd or even. The disclosed win chance is 30%, and the displayed die always matches the result.", even: "Even", odd: "Odd", yourChoice: "Your choice", rolled: "Die roll",
    miniRules: "The server randomly determines each round: 30% win chance. A win credits 3× the game amount; a loss credits nothing. Diamonds are not real money.",
    miniAmountLabel: "Diamond amount (1 or more)", ticTacToe: "Diamond Tic-Tac-Toe", memoryMatch: "Diamond Memory Match", guessNumber: "Guess the Number", treasureHunt: "Treasure Hunt",
    chooseNumber: "Choose one number from 1 to 10", chooseChest: "Choose one chest from 1 to 10", winningNumbers: "Winning numbers", treasureSpots: "Treasure chests", memoryPairs: "Pairs found", playRound: "Play round", gameResult: "Result recorded by the server",
  },
  ar: {
    chooseParity: "اختر الزوجي أو الفردي. احتمال الفوز المعلن 30٪، ويطابق النرد المعروض النتيجة دائمًا.", even: "زوجي", odd: "فردي", yourChoice: "اختيارك", rolled: "نتيجة النرد",
    miniRules: "يحدد الخادم نتيجة كل جولة عشوائياً: احتمال الفوز 30٪. عند الفوز يُضاف إلى المحفظة 3 أضعاف مبلغ اللعبة؛ ولا تُضاف جائزة عند الخسارة. الماسات ليست أموالاً حقيقية.",
    miniAmountLabel: "مبلغ الماس (1 أو أكثر)", ticTacToe: "إكس-أو بالماس", memoryMatch: "ذاكرة بالماس", guessNumber: "خمن الرقم", treasureHunt: "البحث عن الكنز",
    chooseNumber: "اختر رقماً من 1 إلى 10", chooseChest: "اختر صندوقاً من 1 إلى 10", winningNumbers: "الأرقام الفائزة", treasureSpots: "صناديق الكنز", memoryPairs: "الأزواج المكتشفة", playRound: "ابدأ الجولة", gameResult: "النتيجة المسجلة لدى الخادم",
  },
  de: {
    chooseParity: "Wähle gerade oder ungerade. Die offengelegte Gewinnchance beträgt 30 %; der Würfel zeigt immer das passende Ergebnis.", even: "Gerade", odd: "Ungerade", yourChoice: "Deine Wahl", rolled: "Würfelwurf",
    miniRules: "Der Server bestimmt jede Runde zufällig: 30 % Gewinnchance. Bei einem Gewinn werden 3× des Spieleinsatzes gutgeschrieben; bei Verlust gibt es keine Gutschrift. Diamonds sind kein echtes Geld.",
    miniAmountLabel: "Diamond-Betrag (1 oder mehr)", ticTacToe: "Diamond-Tic-Tac-Toe", memoryMatch: "Diamond-Memory", guessNumber: "Zahl erraten", treasureHunt: "Schatzsuche",
    chooseNumber: "Wähle eine Zahl von 1 bis 10", chooseChest: "Wähle eine Truhe von 1 bis 10", winningNumbers: "Gewinnzahlen", treasureSpots: "Schatztruhen", memoryPairs: "Gefundene Paare", playRound: "Runde spielen", gameResult: "Vom Server gespeichertes Ergebnis",
  },
  tg: {
    chooseParity: "Ҷуфт ё тоқро интихоб кунед. Эҳтимоли ошкорои бурд ۳۰% аст ва рӯи зар ба натиҷа мувофиқ аст.", even: "Ҷуфт", odd: "Тоқ", yourChoice: "Интихоби шумо", rolled: "Рӯи зар",
    miniRules: "Натиҷаи ҳар даврро сервер тасодуфӣ муайян мекунад: эҳтимоли бурд ۳۰%. Ҳангоми бурд ۳ баробари маблағи бозӣ ба ҳамён илова мешавад; ҳангоми бохт ҷоиза нест. Diamonds пули воқеӣ нестанд.",
    miniAmountLabel: "Маблағи алмос (1 ё бештар)", ticTacToe: "Дози алмосӣ", memoryMatch: "Хотираи алмосӣ", guessNumber: "Рақамро ёбед", treasureHunt: "Ҷустуҷӯи ганҷ",
    chooseNumber: "Як рақамро аз 1 то 10 интихоб кунед", chooseChest: "Як сандуқро аз 1 то 10 интихоб кунед", winningNumbers: "Рақамҳои бурднок", treasureSpots: "Сандуқҳои ганҷ", memoryPairs: "Ҷуфтҳои ёфтшуда", playRound: "Оғози давр", gameResult: "Натиҷаи сабткардаи сервер",
  },
  ps: {
    chooseParity: "جفت یا طاق وټاکئ. د ګټلو ښکاره چانس ۳۰٪ دی او د تاس مخ له پایلې سره سمون لري.", even: "جفت", odd: "طاق", yourChoice: "ستاسو ټاکنه", rolled: "د تاس مخ",
    miniRules: "سرور د هر پړاو پایله په تصادفي ډول ټاکي: د ګټلو چانس ۳۰٪ دی. په بریا کې د لوبې د اندازې ۳ برابره ستاسو بټوې ته جمع کېږي؛ په بایللو کې انعام نشته. الماس رښتینې پیسې نه دي.",
    miniAmountLabel: "د الماسو اندازه (۱ یا زیاته)", ticTacToe: "د الماسو ټیک ټیک ټو", memoryMatch: "د الماسو حافظه", guessNumber: "شمېره اټکل کړئ", treasureHunt: "د خزانې لټون",
    chooseNumber: "له ۱ تر ۱۰ یوه شمېره وټاکئ", chooseChest: "له ۱ تر ۱۰ یو صندوق وټاکئ", winningNumbers: "ګټونکې شمېرې", treasureSpots: "د خزانې صندوقونه", memoryPairs: "موندل شوې جوړې", playRound: "پړاو پیل کړئ", gameResult: "د سرور ثبت شوې پایله",
  },
  ur: {
    chooseParity: "جفت یا طاق منتخب کریں۔ جیت کا واضح امکان 30٪ ہے اور دکھایا گیا ڈائس نتیجے سے مطابقت رکھتا ہے۔", even: "جفت", odd: "طاق", yourChoice: "آپ کا انتخاب", rolled: "ڈائس کا نتیجہ",
    miniRules: "سرور ہر دور کا نتیجہ تصادفی طور پر طے کرتا ہے: جیت کا امکان 30٪ ہے۔ جیتنے پر کھیل کی رقم سے 3 گنا آپ کے والٹ میں جمع ہوگا؛ ہارنے پر کوئی انعام نہیں۔ ڈائمنڈ حقیقی رقم نہیں ہیں۔",
    miniAmountLabel: "ڈائمنڈ کی رقم (1 یا زیادہ)", ticTacToe: "ڈائمنڈ ٹک ٹیک ٹو", memoryMatch: "ڈائمنڈ میموری میچ", guessNumber: "نمبر کا اندازہ", treasureHunt: "خزانے کی تلاش",
    chooseNumber: "1 سے 10 تک ایک نمبر چنیں", chooseChest: "1 سے 10 تک ایک صندوق چنیں", winningNumbers: "جیتنے والے نمبر", treasureSpots: "خزانے والے صندوق", memoryPairs: "ملنے والے جوڑے", playRound: "دور شروع کریں", gameResult: "سرور پر محفوظ نتیجہ",
  },
  sw: {
    chooseParity: "Chagua jozi au witiri. Nafasi ya ushindi iliyotangazwa ni 30%, na uso wa dadu hulingana na matokeo.", even: "Jozi", odd: "Witiri", yourChoice: "Chaguo lako", rolled: "Matokeo ya dadu",
    miniRules: "Seva huchagua matokeo ya kila raundi kwa nasibu: nafasi ya ushindi ni 30%. Ukishinda, salio huongezwa mara 3 ya kiasi cha mchezo; ukishindwa, hakuna zawadi. Diamonds si pesa halisi.",
    miniAmountLabel: "Kiasi cha Diamond (1 au zaidi)", ticTacToe: "Tic-Tac-Toe ya Diamond", memoryMatch: "Kumbukumbu ya Diamond", guessNumber: "Bashiri Namba", treasureHunt: "Tafuta Hazina",
    chooseNumber: "Chagua namba moja kati ya 1 na 10", chooseChest: "Chagua sanduku moja kati ya 1 na 10", winningNumbers: "Namba zilizoshinda", treasureSpots: "Masanduku yenye hazina", memoryPairs: "Jozi zilizopatikana", playRound: "Anza raundi", gameResult: "Matokeo yaliyohifadhiwa na seva",
  },
  es: {
    chooseParity: "Elige par o impar. La probabilidad declarada es del 30 % y el dado mostrado coincide con el resultado.", even: "Par", odd: "Impar", yourChoice: "Tu elección", rolled: "Resultado del dado",
    miniRules: "El servidor determina cada ronda al azar: 30 % de probabilidad de ganar. Si ganas, se acreditan 3 veces la cantidad del juego; si pierdes, no se acredita ningún premio. Los Diamonds no son dinero real.",
    miniAmountLabel: "Cantidad de Diamonds (1 o más)", ticTacToe: "Tres en raya Diamond", memoryMatch: "Memoria Diamond", guessNumber: "Adivina el número", treasureHunt: "Busca el tesoro",
    chooseNumber: "Elige un número del 1 al 10", chooseChest: "Elige un cofre del 1 al 10", winningNumbers: "Números ganadores", treasureSpots: "Cofres con tesoro", memoryPairs: "Parejas encontradas", playRound: "Jugar ronda", gameResult: "Resultado guardado por el servidor",
  },
  it: {
    chooseParity: "Scegli pari o dispari. La probabilità dichiarata è del 30% e il dado mostrato corrisponde al risultato.", even: "Pari", odd: "Dispari", yourChoice: "La tua scelta", rolled: "Risultato del dado",
    miniRules: "Il server determina casualmente ogni turno: probabilità di vittoria del 30%. In caso di vittoria vengono accreditati 3× l’importo del gioco; in caso di sconfitta non viene accreditato alcun premio. I Diamonds non sono denaro reale.",
    miniAmountLabel: "Importo dei Diamonds (1 o più)", ticTacToe: "Tris Diamond", memoryMatch: "Memory Diamond", guessNumber: "Indovina il numero", treasureHunt: "Caccia al tesoro",
    chooseNumber: "Scegli un numero da 1 a 10", chooseChest: "Scegli un forziere da 1 a 10", winningNumbers: "Numeri vincenti", treasureSpots: "Forzieri con tesoro", memoryPairs: "Coppie trovate", playRound: "Gioca il turno", gameResult: "Risultato salvato dal server",
  },
  tr: {
    chooseParity: "Çift veya tek seç. Açıklanan kazanma olasılığı %30'dur ve gösterilen zar sonuçla tutarlıdır.", even: "Çift", odd: "Tek", yourChoice: "Seçimin", rolled: "Zar sonucu",
    miniRules: "Her turun sonucunu sunucu rastgele belirler: kazanma olasılığı %30. Kazanırsan oyun miktarının 3 katı bakiyene eklenir; kaybedersen ödül eklenmez. Diamonds gerçek para değildir.",
    miniAmountLabel: "Diamond miktarı (1 veya daha fazla)", ticTacToe: "Diamond Tic-Tac-Toe", memoryMatch: "Diamond Hafıza", guessNumber: "Sayıyı Tahmin Et", treasureHunt: "Hazine Avı",
    chooseNumber: "1 ile 10 arasında bir sayı seç", chooseChest: "1 ile 10 arasında bir sandık seç", winningNumbers: "Kazanan sayılar", treasureSpots: "Hazine sandıkları", memoryPairs: "Bulunan çiftler", playRound: "Turu başlat", gameResult: "Sunucuya kaydedilen sonuç",
  },
  hi: {
    chooseParity: "सम या विषम चुनें। घोषित जीत की संभावना 30% है और दिखाया गया पासा परिणाम से मेल खाता है।", even: "सम", odd: "विषम", yourChoice: "आपकी पसंद", rolled: "पासे का परिणाम",
    miniRules: "हर दौर का नतीजा सर्वर यादृच्छिक रूप से तय करता है: जीत की संभावना 30% है। जीतने पर खेल की राशि का 3 गुना वॉलेट में जुड़ता है; हारने पर कोई इनाम नहीं मिलता। Diamonds असली पैसा नहीं हैं।",
    miniAmountLabel: "डायमंड राशि (1 या अधिक)", ticTacToe: "डायमंड टिक-टैक-टो", memoryMatch: "डायमंड मेमोरी मैच", guessNumber: "संख्या का अनुमान लगाएँ", treasureHunt: "खजाने की खोज",
    chooseNumber: "1 से 10 तक एक संख्या चुनें", chooseChest: "1 से 10 तक एक संदूक चुनें", winningNumbers: "जीतने वाली संख्याएँ", treasureSpots: "खजाने वाले संदूक", memoryPairs: "मिले हुए जोड़े", playRound: "दौर शुरू करें", gameResult: "सर्वर में दर्ज परिणाम",
  },
} satisfies Record<Locale, Record<string, string>>;

export type GameExtraKey = keyof (typeof gameExtra)["fa"];

export function translateGameExtra(locale: Locale, key: GameExtraKey): string {
  return gameExtra[locale]?.[key] ?? gameExtra.en[key];
}
