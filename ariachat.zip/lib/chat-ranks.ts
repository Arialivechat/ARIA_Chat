export type ChatGender = "unspecified" | "male" | "female" | "nonbinary";

export type PrivateMessageRankStyle = {
  tier: number;
  label: string;
  rankLabel: string;
  backgroundColor: string;
  textColor: string;
  headerColor: string;
  headerTextColor: string;
  bodyColor: string;
  bodyTextColor: string;
  borderColor: string;
  buttonColor: string;
  isSpecialRole: boolean;
};

const thresholds = [1_000, 20_000, 100_000, 300_000, 700_000];
export const chatRankTitles = ["سرباز", "لورد", "دوک", "کینگ", "امپراتور", "افسانه"] as const;

// Palette indices map directly to Soldier, Lord, Duke, King, Emperor, Legend.
// Blue/cyan/purple shades follow the supplied male reference; pink/coral/red shades follow its female reference.
const palettes: Record<ChatGender, string[]> = {
  male: ["#62B9C9", "#1677B8", "#7137C8", "#0795CC", "#2349D5", "#9A5B12"],
  female: ["#D85AB6", "#B423C7", "#B61D86", "#F06C58", "#D6232B", "#971B43"],
  nonbinary: ["#64748B", "#0F766E", "#4F46E5", "#6D28D9", "#1D4ED8", "#7C3AED"],
  unspecified: ["#64748B", "#0F766E", "#4F46E5", "#6D28D9", "#1D4ED8", "#7C3AED"],
};

const roleStyles: Record<string, { label: string; color: string }> = {
  admin: { label: "Administrator", color: "#B45309" },
  superadmin: { label: "سوپرمدیر", color: "#A16207" },
  moderator: { label: "مدیر", color: "#15803D" },
  support: { label: "پشتیبانی", color: "#0F766E" },
  sales_agent: { label: "نماینده", color: "#C2410C" },
  owner: { label: "سازنده", color: "#047857" },
};

function tint(hex: string, whiteMix = 0.84) {
  const value = hex.replace("#", "");
  const channels = [0, 2, 4].map((offset) => Number.parseInt(value.slice(offset, offset + 2), 16));
  return `#${channels.map((channel) => Math.round(channel + (255 - channel) * whiteMix).toString(16).padStart(2, "0")).join("")}`;
}

function relativeLuminance(hex: string) {
  const channels = [0, 2, 4].map((offset) => Number.parseInt(hex.slice(offset + 1, offset + 3), 16) / 255);
  const linear = channels.map((channel) => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4);
  return linear[0] * 0.2126 + linear[1] * 0.7152 + linear[2] * 0.0722;
}

function contrastingText(hex: string) {
  const luminance = relativeLuminance(hex);
  const whiteContrast = 1.05 / (luminance + 0.05);
  const darkContrast = (luminance + 0.05) / (relativeLuminance("#18212F") + 0.05);
  return whiteContrast >= darkContrast ? "#FFFFFF" : "#18212F";
}

export function getChatRankLevel(chatMessageCount: number) {
  const count = Number.isFinite(chatMessageCount) ? Math.max(0, chatMessageCount) : 0;
  let level = 0;
  for (let index = 0; index < thresholds.length; index += 1) {
    if (count >= thresholds[index]) level = index + 1;
  }
  return level;
}

export function getChatRankProgress(chatMessageCount: number) {
  const count = Number.isFinite(chatMessageCount) ? Math.max(0, chatMessageCount) : 0;
  const level = getChatRankLevel(count);
  if (level >= thresholds.length) {
    return { level, title: chatRankTitles[level], progress: 100, remaining: 0, nextTitle: null as string | null };
  }
  const currentThreshold = level === 0 ? 0 : thresholds[level - 1];
  const nextThreshold = thresholds[level];
  const range = nextThreshold - currentThreshold;
  return {
    level,
    title: chatRankTitles[level],
    progress: Math.max(0, Math.min(100, ((count - currentThreshold) / range) * 100)),
    remaining: Math.max(0, nextThreshold - count),
    nextTitle: chatRankTitles[level + 1],
  };
}

/** The card body keeps its normal/personal color at Soldier level; the title bar always identifies gender and rank. */
export function getPrivateMessageRank(
  chatMessageCount: number,
  gender: ChatGender,
  fallbackBackground: string,
  fallbackText: string,
  overrideLevel?: number,
  role?: string,
): PrivateMessageRankStyle {
  const calculated = getChatRankLevel(chatMessageCount);
  const tier = Number.isInteger(overrideLevel) ? Math.max(0, Math.min(5, overrideLevel as number)) : calculated;
  const rankLabel = chatRankTitles[tier];
  const privilege = role ? roleStyles[role.toLowerCase()] : undefined;
  const headerColor = privilege?.color ?? (palettes[gender] ?? palettes.unspecified)[tier];
  const isSpecialRole = Boolean(privilege);
  const bodyColor = tier === 0 && !isSpecialRole ? fallbackBackground : tint(headerColor);
  return {
    tier,
    label: privilege?.label ?? rankLabel,
    rankLabel,
    backgroundColor: tier === 0 && !isSpecialRole ? fallbackBackground : headerColor,
    textColor: tier === 0 && !isSpecialRole ? fallbackText : contrastingText(headerColor),
    headerColor,
    headerTextColor: contrastingText(headerColor),
    bodyColor,
    bodyTextColor: tier === 0 && !isSpecialRole ? fallbackText : contrastingText(bodyColor),
    borderColor: headerColor,
    buttonColor: headerColor,
    isSpecialRole,
  };
}
