export const ARIA_CHAT_PUBLIC_API_BASE_URL = "https://ariachat-centgf3y.manus.space";

export type ApiPlatform = "web" | "native";

export type BrowserLocation = {
  protocol: string;
  hostname: string;
};

function isSessionScopedApiUrl(value: string): boolean {
  try {
    return new URL(value).hostname.toLowerCase().endsWith(".manus.computer");
  } catch {
    return false;
  }
}

export function resolveApiBaseUrl(
  configuredUrl: string,
  platform: ApiPlatform,
  isDevelopment: boolean,
  browserLocation?: BrowserLocation,
): string {
  const configured = configuredUrl.trim().replace(/\/+$/, "");

  if (configured) {
    if (!isDevelopment && isSessionScopedApiUrl(configured)) {
      return ARIA_CHAT_PUBLIC_API_BASE_URL;
    }
    return configured;
  }

  if (!isDevelopment) return ARIA_CHAT_PUBLIC_API_BASE_URL;

  if (platform === "web" && browserLocation) {
    const apiHostname = browserLocation.hostname.replace(/^8081-/, "3000-");
    if (apiHostname !== browserLocation.hostname) {
      return `${browserLocation.protocol}//${apiHostname}`;
    }
  }

  return "";
}
