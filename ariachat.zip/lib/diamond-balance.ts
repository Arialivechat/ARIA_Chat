export function isSafeDiamondAmount(amount: number): boolean {
  return Number.isSafeInteger(amount) && amount > 0;
}

export function canSpendDiamonds(
  amount: number,
  balance: number | null | undefined,
  isUnlimited: boolean,
  maxAmount = Number.MAX_SAFE_INTEGER,
): boolean {
  if (!isSafeDiamondAmount(amount) || amount > maxAmount) return false;
  return isUnlimited || amount <= (balance ?? 0);
}

export function isWalletSnapshotReady(hasData: boolean, isFetching: boolean, hasError: boolean): boolean {
  return hasData && !isFetching && !hasError;
}

export function diamondBalanceLabel(
  balance: number | null | undefined,
  isUnlimited: boolean,
): string {
  if (isUnlimited) return "∞";
  return balance == null ? "—" : String(balance);
}
