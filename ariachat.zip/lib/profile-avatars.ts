export const PROFILE_AVATAR_OPTIONS = [
  "🤶",
  "🎅",
  "👸",
  "🤵‍♀️",
  "🤵‍♂️",
  "👷‍♀️",
  "👩‍🎨",
  "👨‍💻",
  "🧑‍🏭",
  "🧑‍🔧",
  "👱‍♀️",
  "🧑‍🦰",
  "👱‍♂️",
  "👩‍🦰",
  "👨",
  "🧔‍♂️",
  "👶",
  "🐱",
  "🐶",
  "🐬",
  "🐔",
  "🐣",
  "🦆",
  "🌸",
  "🌻",
  "🏵",
  "🌹",
  "🦂",
  "🪰",
  "🕷",
] as const;

export type ProfileAvatarEmoji = (typeof PROFILE_AVATAR_OPTIONS)[number];
export type CrownTone = "gold" | "blue" | null;

const allowedAvatars = new Set<string>(PROFILE_AVATAR_OPTIONS);

export function isProfileAvatarEmoji(value: unknown): value is ProfileAvatarEmoji {
  return typeof value === "string" && allowedAvatars.has(value);
}

/** Global administration always takes precedence over a room-local role. */
export function getProfileCrownTone(globalRole?: string | null, roomRole?: string | null): CrownTone {
  if (globalRole === "admin" || globalRole === "superadmin" || globalRole === "moderator") return "gold";
  if (roomRole === "owner" || roomRole === "moderator") return "blue";
  return null;
}
