import type { Locale } from "@/lib/locales";

type BlockKey =
  | "blockUser"
  | "duration"
  | "oneHour"
  | "oneDay"
  | "sevenDays"
  | "thirtyDays"
  | "permanent"
  | "reason"
  | "reasonHint"
  | "confirmBlock"
  | "confirmBlockDetails"
  | "blockedUntil"
  | "permanentlyBlocked"
  | "restoreAccess"
  | "confirmRestore"
  | "blockRecorded"
  | "restoreRecorded";

type BlockCopy = Record<BlockKey, string>;

const en: BlockCopy = {
  blockUser: "Block user",
  duration: "Block duration",
  oneHour: "1 hour",
  oneDay: "24 hours",
  sevenDays: "7 days",
  thirtyDays: "30 days",
  permanent: "Permanent",
  reason: "Reason for block",
  reasonHint: "At least 3 characters; recorded in the audit log.",
  confirmBlock: "Confirm block",
  confirmBlockDetails: "Access stays restricted until the selected expiry. A permanent block remains until an administrator restores access.",
  blockedUntil: "Blocked until",
  permanentlyBlocked: "Permanently blocked",
  restoreAccess: "Restore access",
  confirmRestore: "This removes the block and reactivates the account. Continue?",
  blockRecorded: "The account block was recorded.",
  restoreRecorded: "The account block was removed.",
};

export const adminBlockLocaleCopy: Record<Locale, BlockCopy> = {
  en,
  fa: { blockUser: "مسدودسازی کاربر", duration: "مدت مسدودسازی", oneHour: "۱ ساعت", oneDay: "۲۴ ساعت", sevenDays: "۷ روز", thirtyDays: "۳۰ روز", permanent: "دائم", reason: "دلیل مسدودسازی", reasonHint: "حداقل ۳ نویسه؛ در سابقهٔ مدیریتی ثبت می‌شود.", confirmBlock: "تأیید مسدودسازی", confirmBlockDetails: "دسترسی تا زمان انتخاب‌شده محدود می‌ماند؛ مسدودسازی دائم فقط با رفع دستی مدیر پایان می‌یابد.", blockedUntil: "مسدود تا", permanentlyBlocked: "مسدود دائم", restoreAccess: "رفع مسدودی", confirmRestore: "مسدودسازی برداشته و حساب فعال می‌شود. ادامه می‌دهی؟", blockRecorded: "مسدودسازی حساب ثبت شد.", restoreRecorded: "مسدودسازی حساب برداشته شد." },
  ar: { blockUser: "حظر المستخدم", duration: "مدة الحظر", oneHour: "ساعة واحدة", oneDay: "٢٤ ساعة", sevenDays: "٧ أيام", thirtyDays: "٣٠ يومًا", permanent: "دائم", reason: "سبب الحظر", reasonHint: "٣ أحرف على الأقل؛ يُسجل في سجل التدقيق.", confirmBlock: "تأكيد الحظر", confirmBlockDetails: "يبقى الوصول مقيدًا حتى وقت الانتهاء المحدد؛ ولا ينتهي الحظر الدائم إلا بإعادة التفعيل يدويًا من المسؤول.", blockedUntil: "محظور حتى", permanentlyBlocked: "حظر دائم", restoreAccess: "إلغاء الحظر", confirmRestore: "سيُرفع الحظر ويُعاد تفعيل الحساب. هل تريد المتابعة؟", blockRecorded: "تم تسجيل حظر الحساب.", restoreRecorded: "تم رفع حظر الحساب." },
  de: { blockUser: "Nutzer sperren", duration: "Sperrdauer", oneHour: "1 Stunde", oneDay: "24 Stunden", sevenDays: "7 Tage", thirtyDays: "30 Tage", permanent: "Dauerhaft", reason: "Sperrgrund", reasonHint: "Mindestens 3 Zeichen; wird im Prüfprotokoll gespeichert.", confirmBlock: "Sperre bestätigen", confirmBlockDetails: "Der Zugriff bleibt bis zum gewählten Ablauf eingeschränkt. Eine dauerhafte Sperre endet erst nach manueller Freigabe durch die Administration.", blockedUntil: "Gesperrt bis", permanentlyBlocked: "Dauerhaft gesperrt", restoreAccess: "Zugriff wiederherstellen", confirmRestore: "Die Sperre wird aufgehoben und das Konto reaktiviert. Fortfahren?", blockRecorded: "Kontosperre wurde gespeichert.", restoreRecorded: "Kontosperre wurde aufgehoben." },
  tg: { blockUser: "Корбарро масдуд кардан", duration: "Муддати масдудсозӣ", oneHour: "1 соат", oneDay: "24 соат", sevenDays: "7 рӯз", thirtyDays: "30 рӯз", permanent: "Доимӣ", reason: "Сабаби масдудсозӣ", reasonHint: "Ҳадди ақал 3 аломат; дар сабти санҷиш сабт мешавад.", confirmBlock: "Масдудсозиро тасдиқ кунед", confirmBlockDetails: "Дастрасӣ то вақти интихобшуда маҳдуд мемонад. Масдудсозии доимӣ танҳо бо барқарорсозии дастии маъмур анҷом меёбад.", blockedUntil: "Масдуд то", permanentlyBlocked: "Доимӣ масдуд шудааст", restoreAccess: "Барқарор кардани дастрасӣ", confirmRestore: "Масдудсозӣ бардошта ва ҳисоб фаъол мешавад. Идома медиҳед?", blockRecorded: "Масдудсозии ҳисоб сабт шуд.", restoreRecorded: "Масдудсозии ҳисоб бардошта шуд." },
  ps: { blockUser: "کارن بندول", duration: "د بند موده", oneHour: "۱ ساعت", oneDay: "۲۴ ساعته", sevenDays: "۷ ورځې", thirtyDays: "۳۰ ورځې", permanent: "دایمي", reason: "د بندولو دلیل", reasonHint: "لږ تر لږه ۳ توري؛ د پلټنې په ثبت کې خوندي کېږي.", confirmBlock: "بندول تایید کړئ", confirmBlockDetails: "لاسرسی تر ټاکلي وخت پورې محدود وي؛ دایمي بند یوازې د مدیر په لاسي بېرته فعالولو ختمېږي.", blockedUntil: "تر دې وخته بند", permanentlyBlocked: "دایمي بند شوی", restoreAccess: "لاسرسی بېرته فعالول", confirmRestore: "بند لرې او حساب فعال شي. دوام ورکړئ؟", blockRecorded: "د حساب بند ثبت شو.", restoreRecorded: "د حساب بند لرې شو." },
  ur: { blockUser: "صارف کو بلاک کریں", duration: "بلاک کی مدت", oneHour: "۱ گھنٹہ", oneDay: "۲۴ گھنٹے", sevenDays: "۷ دن", thirtyDays: "۳۰ دن", permanent: "مستقل", reason: "بلاک کرنے کی وجہ", reasonHint: "کم از کم ۳ حروف؛ آڈٹ لاگ میں درج ہوگی۔", confirmBlock: "بلاک کی تصدیق کریں", confirmBlockDetails: "منتخب اختتامی وقت تک رسائی محدود رہے گی؛ مستقل بلاک صرف منتظم کے دستی بحال کرنے سے ختم ہوگا۔", blockedUntil: "اس وقت تک بلاک", permanentlyBlocked: "مستقل بلاک", restoreAccess: "رسائی بحال کریں", confirmRestore: "بلاک ہٹا کر اکاؤنٹ فعال کیا جائے گا۔ جاری رکھیں؟", blockRecorded: "اکاؤنٹ بلاک درج ہوگیا۔", restoreRecorded: "اکاؤنٹ بلاک ہٹا دیا گیا۔" },
  sw: { blockUser: "Mzuie mtumiaji", duration: "Muda wa zuio", oneHour: "Saa 1", oneDay: "Saa 24", sevenDays: "Siku 7", thirtyDays: "Siku 30", permanent: "Kudumu", reason: "Sababu ya kuzuia", reasonHint: "Angalau herufi 3; itawekwa kwenye kumbukumbu ya ukaguzi.", confirmBlock: "Thibitisha zuio", confirmBlockDetails: "Ufikiaji utaendelea kuzuiwa hadi muda uliochaguliwa. Zuio la kudumu huondolewa tu na msimamizi.", blockedUntil: "Amezuiwa hadi", permanentlyBlocked: "Amezuiwa kabisa", restoreAccess: "Rejesha ufikiaji", confirmRestore: "Zuio litaondolewa na akaunti kuwashwa tena. Endelea?", blockRecorded: "Zuio la akaunti limerekodiwa.", restoreRecorded: "Zuio la akaunti limeondolewa." },
  es: { blockUser: "Bloquear usuario", duration: "Duración del bloqueo", oneHour: "1 hora", oneDay: "24 horas", sevenDays: "7 días", thirtyDays: "30 días", permanent: "Permanente", reason: "Motivo del bloqueo", reasonHint: "Al menos 3 caracteres; se guardará en el registro de auditoría.", confirmBlock: "Confirmar bloqueo", confirmBlockDetails: "El acceso seguirá restringido hasta la fecha elegida. Un bloqueo permanente solo termina cuando un administrador lo revierte.", blockedUntil: "Bloqueado hasta", permanentlyBlocked: "Bloqueado permanentemente", restoreAccess: "Restaurar acceso", confirmRestore: "Se quitará el bloqueo y se reactivará la cuenta. ¿Continuar?", blockRecorded: "Se registró el bloqueo de la cuenta.", restoreRecorded: "Se quitó el bloqueo de la cuenta." },
  it: { blockUser: "Blocca utente", duration: "Durata del blocco", oneHour: "1 ora", oneDay: "24 ore", sevenDays: "7 giorni", thirtyDays: "30 giorni", permanent: "Permanente", reason: "Motivo del blocco", reasonHint: "Almeno 3 caratteri; sarà registrato nel registro di controllo.", confirmBlock: "Conferma blocco", confirmBlockDetails: "L'accesso resta limitato fino alla scadenza scelta. Un blocco permanente termina solo quando un amministratore ripristina l'accesso.", blockedUntil: "Bloccato fino al", permanentlyBlocked: "Bloccato permanentemente", restoreAccess: "Ripristina accesso", confirmRestore: "Il blocco sarà rimosso e l'account riattivato. Continuare?", blockRecorded: "Blocco dell'account registrato.", restoreRecorded: "Blocco dell'account rimosso." },
  tr: { blockUser: "Kullanıcıyı engelle", duration: "Engelleme süresi", oneHour: "1 saat", oneDay: "24 saat", sevenDays: "7 gün", thirtyDays: "30 gün", permanent: "Kalıcı", reason: "Engelleme nedeni", reasonHint: "En az 3 karakter; denetim kaydına eklenir.", confirmBlock: "Engellemeyi onayla", confirmBlockDetails: "Erişim seçilen sona erme zamanına kadar kısıtlanır. Kalıcı engel yalnızca yönetici tarafından kaldırılabilir.", blockedUntil: "Şu tarihe kadar engelli", permanentlyBlocked: "Kalıcı olarak engelli", restoreAccess: "Erişimi geri aç", confirmRestore: "Engel kaldırılıp hesap yeniden etkinleştirilecek. Devam edilsin mi?", blockRecorded: "Hesap engeli kaydedildi.", restoreRecorded: "Hesap engeli kaldırıldı." },
  hi: { blockUser: "उपयोगकर्ता को ब्लॉक करें", duration: "ब्लॉक अवधि", oneHour: "1 घंटा", oneDay: "24 घंटे", sevenDays: "7 दिन", thirtyDays: "30 दिन", permanent: "स्थायी", reason: "ब्लॉक करने का कारण", reasonHint: "कम से कम 3 अक्षर; ऑडिट लॉग में दर्ज होगा।", confirmBlock: "ब्लॉक की पुष्टि करें", confirmBlockDetails: "चुनी गई समाप्ति तक पहुँच सीमित रहेगी। स्थायी ब्लॉक केवल व्यवस्थापक द्वारा बहाल करने पर हटेगा।", blockedUntil: "इस समय तक ब्लॉक", permanentlyBlocked: "स्थायी रूप से ब्लॉक", restoreAccess: "पहुँच बहाल करें", confirmRestore: "ब्लॉक हटाकर खाते को फिर सक्रिय किया जाएगा। जारी रखें?", blockRecorded: "खाता ब्लॉक दर्ज किया गया।", restoreRecorded: "खाता ब्लॉक हटा दिया गया।" },
};

export function adminBlockText(locale: Locale, key: BlockKey): string {
  return adminBlockLocaleCopy[locale][key];
}

export type AdminBlockLocaleKey = BlockKey;
