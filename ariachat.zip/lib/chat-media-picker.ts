import * as FileSystem from "expo-file-system/legacy";

export type PickerMediaAsset = {
  uri?: string | null;
  base64?: string | null;
  size?: number | null;
};

export class AttachmentTooLargeError extends Error {
  constructor() {
    super("Attachment exceeds the permitted size.");
    this.name = "AttachmentTooLargeError";
  }
}

export class AttachmentReadError extends Error {
  constructor() {
    super("Unable to read attachment data.");
    this.name = "AttachmentReadError";
  }
}

/** Read picker data while avoiding a Base64 allocation when picker metadata already exceeds the limit. */
export async function readPickerAssetBase64(asset: PickerMediaAsset, maxBytes: number) {
  if (typeof asset.size === "number" && asset.size > maxBytes) {
    throw new AttachmentTooLargeError();
  }

  const source = asset.base64 ?? (asset.uri
    ? await FileSystem.readAsStringAsync(asset.uri, { encoding: FileSystem.EncodingType.Base64 })
    : "");
  const base64Data = source.replace(/^data:[^,]*,/, "");
  if (!base64Data) throw new AttachmentReadError();

  const padding = base64Data.endsWith("==") ? 2 : base64Data.endsWith("=") ? 1 : 0;
  const sizeBytes = Math.max(0, Math.floor((base64Data.length * 3) / 4) - padding);
  if (sizeBytes > maxBytes) throw new AttachmentTooLargeError();
  return { base64Data, sizeBytes };
}
