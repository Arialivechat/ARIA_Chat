export const PROFILE_BADGE_TITLES = [
  "none",
  "support",
  "sales_agent",
  "top_manager",
  "room_manager",
  "admin_assistant",
  "featured_member",
] as const;
export type ProfileBadgeTitle = (typeof PROFILE_BADGE_TITLES)[number];

export const PROFILE_CROWN_STYLES = ["gold_blue", "gold_red", "black_gold"] as const;
export type ProfileCrownStyle = (typeof PROFILE_CROWN_STYLES)[number];

export function isProfileBadgeTitle(value: unknown): value is ProfileBadgeTitle {
  return typeof value === "string" && (PROFILE_BADGE_TITLES as readonly string[]).includes(value);
}

export function isProfileCrownStyle(value: unknown): value is ProfileCrownStyle {
  return typeof value === "string" && (PROFILE_CROWN_STYLES as readonly string[]).includes(value);
}
