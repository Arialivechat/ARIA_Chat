import type { Locale } from "./locales";
import { translateExtra, type ExtraLocaleKey } from "./locale-extras";

export function formatLastSeen(
  value: Date | string | null | undefined,
  isOnline: boolean,
  locale: Locale,
  t: (key: ExtraLocaleKey, values?: { count?: number }) => string = (key, values) => translateExtra(locale, key, values),
): string {
  if (isOnline) return t("onlineNow");
  if (!value) return t("lastSeenUnknown");

  const date = value instanceof Date ? value : new Date(value);
  const timestamp = date.getTime();
  if (!Number.isFinite(timestamp)) return t("lastSeenUnknown");
  const elapsed = Math.max(0, Date.now() - timestamp);

  if (elapsed < 60_000) return t("justNow");
  if (elapsed < 60 * 60_000) return t("minutesAgo", { count: Math.floor(elapsed / 60_000) });
  if (elapsed < 24 * 60 * 60_000) return t("hoursAgo", { count: Math.floor(elapsed / (60 * 60_000)) });
  if (elapsed < 7 * 24 * 60 * 60_000) return t("daysAgo", { count: Math.floor(elapsed / (24 * 60 * 60_000)) });

  try {
    return date.toLocaleString(locale, { dateStyle: "short", timeStyle: "short" });
  } catch {
    return date.toLocaleString();
  }
}
