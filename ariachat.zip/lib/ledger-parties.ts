export interface LedgerPublicAccount {
  name: string | null;
  username: string | null;
  accountNumber: number | null;
}

/** Map a transfer ledger row to its real sender and recipient using the row's wallet direction. */
export function getLedgerTransferParties(
  direction: "debit" | "credit",
  account: LedgerPublicAccount,
  counterparty: LedgerPublicAccount,
) {
  return direction === "debit"
    ? { sender: account, recipient: counterparty }
    : { sender: counterparty, recipient: account };
}
