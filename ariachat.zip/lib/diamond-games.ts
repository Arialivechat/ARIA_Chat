export const DIAMOND_MINI_GAME_TYPES = [
  "tic_tac_toe",
  "memory_match",
  "guess_number",
  "treasure_hunt",
] as const;

export type DiamondMiniGameType = (typeof DIAMOND_MINI_GAME_TYPES)[number];
export type DiamondMiniGameOutcome = "win" | "loss";

export interface DiamondMiniGameResult {
  gameRecordId: number;
  gameType: DiamondMiniGameType;
  bet: number;
  outcome: DiamondMiniGameOutcome;
  payout: number;
  balance: number;
  multiplier: number;
  choice?: number;
  board?: Array<"X" | "O" | null>;
  memoryDeck?: number[];
  matchedCards?: number[];
  matchedPairs?: number;
  winningNumbers?: number[];
  treasureSpots?: number[];
  rules: {
    winProbability: 0.3;
    payout: "3x total credit including the game amount";
  };
}

/**
 * Request IDs are idempotency keys, not credentials. Use platform crypto where
 * present and a UUID-shaped collision-resistant fallback for React Native runtimes
 * that do not expose Web Crypto.
 */
export function createGameRequestId(): string {
  if (typeof globalThis.crypto?.randomUUID === "function") {
    return globalThis.crypto.randomUUID();
  }

  const hex = (length: number) => Array.from({ length }, () => Math.floor(Math.random() * 16).toString(16)).join("");
  const variant = (8 + Math.floor(Math.random() * 4)).toString(16);
  return `${hex(8)}-${hex(4)}-4${hex(3)}-${variant}${hex(3)}-${hex(12)}`;
}
