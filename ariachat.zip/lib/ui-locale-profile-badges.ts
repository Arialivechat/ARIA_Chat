import type { ProfileBadgeTitle, ProfileCrownStyle } from "./profile-badges";

const LOCALES = ["fa", "en", "ar", "de", "tg", "ps", "ur", "sw", "es", "it", "tr", "hi"] as const;
type Locale = (typeof LOCALES)[number];
type CopyKey = "displayTitle" | "crownStyle" | "clearTitle" | "noCrown" | "auditReason" | "reasonHint" | "savePresentation";
type BadgeKey = ProfileBadgeTitle | ProfileCrownStyle;

type Copy = Record<Locale, Record<CopyKey, string>>;
type BadgeLabels = Record<Locale, Record<BadgeKey, string>>;

const copy: Copy = {
  fa: { displayTitle: "عنوان نمایشی", crownStyle: "طرح تاج", clearTitle: "بدون عنوان", noCrown: "تاج پیش‌فرض نقش", auditReason: "دلیل تغییر", reasonHint: "حداقل ۳ نویسه", savePresentation: "ذخیرهٔ عنوان و تاج" },
  en: { displayTitle: "Display title", crownStyle: "Crown style", clearTitle: "No title", noCrown: "Use role default", auditReason: "Reason for change", reasonHint: "At least 3 characters", savePresentation: "Save title and crown" },
  ar: { displayTitle: "المسمى الظاهر", crownStyle: "نمط التاج", clearTitle: "بلا مسمى", noCrown: "استخدم تاج الدور الافتراضي", auditReason: "سبب التغيير", reasonHint: "ثلاثة أحرف على الأقل", savePresentation: "حفظ المسمى والتاج" },
  de: { displayTitle: "Anzeigetitel", crownStyle: "Kronenstil", clearTitle: "Kein Titel", noCrown: "Rollen-Standard verwenden", auditReason: "Änderungsgrund", reasonHint: "Mindestens 3 Zeichen", savePresentation: "Titel und Krone speichern" },
  tg: { displayTitle: "Унвони намоишӣ", crownStyle: "Намуди тоҷ", clearTitle: "Бе унвон", noCrown: "Тоҷи пешфарзи нақш", auditReason: "Сабаби тағйир", reasonHint: "Ҳадди ақал 3 аломат", savePresentation: "Захира кардани унвон ва тоҷ" },
  ps: { displayTitle: "ښکاره کېدونکی لقب", crownStyle: "د تاج بڼه", clearTitle: "بې لقب", noCrown: "د رول اصلي تاج", auditReason: "د بدلون لامل", reasonHint: "لږ تر لږه ۳ توري", savePresentation: "لقب او تاج خوندي کړئ" },
  ur: { displayTitle: "ظاہری عہدہ", crownStyle: "تاج کا انداز", clearTitle: "کوئی عہدہ نہیں", noCrown: "کردار کا طے شدہ تاج", auditReason: "تبدیلی کی وجہ", reasonHint: "کم از کم ۳ حروف", savePresentation: "عہدہ اور تاج محفوظ کریں" },
  sw: { displayTitle: "Cheo cha kuonyesha", crownStyle: "Mtindo wa taji", clearTitle: "Hakuna cheo", noCrown: "Tumia taji la jukumu", auditReason: "Sababu ya mabadiliko", reasonHint: "Angalau herufi 3", savePresentation: "Hifadhi cheo na taji" },
  es: { displayTitle: "Título visible", crownStyle: "Estilo de corona", clearTitle: "Sin título", noCrown: "Usar corona del rol", auditReason: "Motivo del cambio", reasonHint: "Al menos 3 caracteres", savePresentation: "Guardar título y corona" },
  it: { displayTitle: "Titolo visualizzato", crownStyle: "Stile della corona", clearTitle: "Nessun titolo", noCrown: "Usa la corona del ruolo", auditReason: "Motivo della modifica", reasonHint: "Almeno 3 caratteri", savePresentation: "Salva titolo e corona" },
  tr: { displayTitle: "Görünen unvan", crownStyle: "Taç stili", clearTitle: "Unvan yok", noCrown: "Rolün varsayılan tacı", auditReason: "Değişiklik nedeni", reasonHint: "En az 3 karakter", savePresentation: "Unvanı ve tacı kaydet" },
  hi: { displayTitle: "दिखने वाला पद", crownStyle: "मुकुट शैली", clearTitle: "कोई पद नहीं", noCrown: "भूमिका का डिफ़ॉल्ट मुकुट", auditReason: "बदलाव का कारण", reasonHint: "कम से कम 3 अक्षर", savePresentation: "पद और मुकुट सहेजें" },
};

const badgeLabels: BadgeLabels = {
  fa: { none: "بدون عنوان", support: "پشتیبانی", sales_agent: "نمایندهٔ فروش", top_manager: "مدیر برتر", room_manager: "مدیر روم", admin_assistant: "دستیار مدیریت", featured_member: "عضو ویژه", gold_blue: "تاج طلایی · نشان آبی · چشمک‌زن", gold_red: "تاج طلایی · نشان قرمز · چشمک‌زن", black_gold: "تاج مشکی · نشان طلایی · چشمک‌زن" },
  en: { none: "No title", support: "Support", sales_agent: "Sales representative", top_manager: "Top manager", room_manager: "Room manager", admin_assistant: "Admin assistant", featured_member: "Featured member", gold_blue: "Gold crown · blue jewel · blinking", gold_red: "Gold crown · red jewel · blinking", black_gold: "Black crown · gold jewel · blinking" },
  ar: { none: "بلا مسمى", support: "الدعم", sales_agent: "مندوب مبيعات", top_manager: "المدير المتميز", room_manager: "مدير الغرفة", admin_assistant: "مساعد الإدارة", featured_member: "عضو مميز", gold_blue: "تاج ذهبي · جوهرة زرقاء · وامض", gold_red: "تاج ذهبي · جوهرة حمراء · وامض", black_gold: "تاج أسود · جوهرة ذهبية · وامض" },
  de: { none: "Kein Titel", support: "Support", sales_agent: "Vertriebsvertretung", top_manager: "Top-Manager", room_manager: "Raumverwaltung", admin_assistant: "Admin-Assistenz", featured_member: "Besonderes Mitglied", gold_blue: "Goldene Krone · blauer Stein · blinkend", gold_red: "Goldene Krone · roter Stein · blinkend", black_gold: "Schwarze Krone · goldener Stein · blinkend" },
  tg: { none: "Бе унвон", support: "Дастгирӣ", sales_agent: "Намояндаи фурӯш", top_manager: "Мудири беҳтарин", room_manager: "Мудири ҳуҷра", admin_assistant: "Ёвари маъмур", featured_member: "Узви махсус", gold_blue: "Тоҷи тиллоӣ · санги кабуд · чашмакзан", gold_red: "Тоҷи тиллоӣ · санги сурх · чашмакзан", black_gold: "Тоҷи сиёҳ · санги тиллоӣ · чашмакзан" },
  ps: { none: "بې لقب", support: "ملاتړ", sales_agent: "د پلور استازی", top_manager: "غوره مدیر", room_manager: "د خونې مدیر", admin_assistant: "د ادارې مرستیال", featured_member: "ځانګړی غړی", gold_blue: "طلایي تاج · آبي ګاڼه · رپېدونکی", gold_red: "طلایي تاج · سره ګاڼه · رپېدونکی", black_gold: "تور تاج · طلایي ګاڼه · رپېدونکی" },
  ur: { none: "کوئی عہدہ نہیں", support: "سپورٹ", sales_agent: "سیلز نمائندہ", top_manager: "اعلیٰ منتظم", room_manager: "روم منتظم", admin_assistant: "ایڈمن معاون", featured_member: "خصوصی رکن", gold_blue: "سنہرا تاج · نیلا نگینہ · چمکتا ہوا", gold_red: "سنہرا تاج · سرخ نگینہ · چمکتا ہوا", black_gold: "سیاہ تاج · سنہرا نگینہ · چمکتا ہوا" },
  sw: { none: "Hakuna cheo", support: "Usaidizi", sales_agent: "Mwakilishi wa mauzo", top_manager: "Msimamizi bora", room_manager: "Msimamizi wa chumba", admin_assistant: "Msaidizi wa msimamizi", featured_member: "Mwanachama maalum", gold_blue: "Taji la dhahabu · jiwe la bluu · linameta", gold_red: "Taji la dhahabu · jiwe jekundu · linameta", black_gold: "Taji jeusi · jiwe la dhahabu · linameta" },
  es: { none: "Sin título", support: "Soporte", sales_agent: "Representante de ventas", top_manager: "Gerente destacado", room_manager: "Moderador de sala", admin_assistant: "Asistente de administración", featured_member: "Miembro destacado", gold_blue: "Corona dorada · gema azul · parpadeante", gold_red: "Corona dorada · gema roja · parpadeante", black_gold: "Corona negra · gema dorada · parpadeante" },
  it: { none: "Nessun titolo", support: "Assistenza", sales_agent: "Rappresentante vendite", top_manager: "Responsabile principale", room_manager: "Responsabile stanza", admin_assistant: "Assistente amministrativo", featured_member: "Membro in evidenza", gold_blue: "Corona oro · gemma blu · lampeggiante", gold_red: "Corona oro · gemma rossa · lampeggiante", black_gold: "Corona nera · gemma oro · lampeggiante" },
  tr: { none: "Unvan yok", support: "Destek", sales_agent: "Satış temsilcisi", top_manager: "Üst yönetici", room_manager: "Oda yöneticisi", admin_assistant: "Yönetici yardımcısı", featured_member: "Öne çıkan üye", gold_blue: "Altın taç · mavi taş · yanıp söner", gold_red: "Altın taç · kırmızı taş · yanıp söner", black_gold: "Siyah taç · altın taş · yanıp söner" },
  hi: { none: "कोई पद नहीं", support: "सहायता", sales_agent: "बिक्री प्रतिनिधि", top_manager: "शीर्ष प्रबंधक", room_manager: "रूम प्रबंधक", admin_assistant: "प्रशासन सहायक", featured_member: "विशेष सदस्य", gold_blue: "सुनहरा मुकुट · नीला रत्न · चमकता हुआ", gold_red: "सुनहरा मुकुट · लाल रत्न · चमकता हुआ", black_gold: "काला मुकुट · सुनहरा रत्न · चमकता हुआ" },
};

const saved: Record<Locale, string> = {
  fa: "عنوان و تاج ذخیره شد.", en: "Title and crown saved.", ar: "تم حفظ المسمى والتاج.", de: "Titel und Krone gespeichert.",
  tg: "Унвон ва тоҷ захира шуд.", ps: "لقب او تاج خوندي شول.", ur: "عہدہ اور تاج محفوظ ہو گئے۔", sw: "Cheo na taji vimehifadhiwa.",
  es: "Título y corona guardados.", it: "Titolo e corona salvati.", tr: "Unvan ve taç kaydedildi.", hi: "पद और मुकुट सहेजे गए।",
};

export function profileBadgeText(locale: string, key: CopyKey | "saved"): string {
  const language = LOCALES.includes(locale as Locale) ? (locale as Locale) : "en";
  return key === "saved" ? saved[language] : copy[language][key];
}

export function profileBadgeTitleLabel(locale: string, value: ProfileBadgeTitle | string | null | undefined): string | null {
  if (!value || value === "none") return null;
  const language = LOCALES.includes(locale as Locale) ? (locale as Locale) : "en";
  return badgeLabels[language][value as BadgeKey] ?? null;
}

export function profileCrownLabel(locale: string, value: ProfileCrownStyle | string | null | undefined): string | null {
  if (!value) return null;
  const language = LOCALES.includes(locale as Locale) ? (locale as Locale) : "en";
  return badgeLabels[language][value as BadgeKey] ?? null;
}
