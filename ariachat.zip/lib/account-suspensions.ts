export const ADMIN_BLOCK_DURATIONS_HOURS = [1, 24, 168, 720] as const;

export function isAdminBlockDurationHours(value: unknown): value is (typeof ADMIN_BLOCK_DURATIONS_HOURS)[number] {
  return typeof value === "number" && ADMIN_BLOCK_DURATIONS_HOURS.some((duration) => duration === value);
}

export function isSuspensionExpired(accountStatus: unknown, suspendedUntil: unknown, now: Date): boolean {
  if (accountStatus !== "suspended" || suspendedUntil == null) return false;
  const expiry = suspendedUntil instanceof Date ? suspendedUntil : new Date(String(suspendedUntil));
  return !Number.isNaN(expiry.getTime()) && expiry.getTime() <= now.getTime();
}
