import type { User } from "./auth";

export type AuthStateListener = (user: User | null) => void;

const listeners = new Set<AuthStateListener>();

export function subscribeAuthState(listener: AuthStateListener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function publishAuthState(user: User | null): void {
  for (const listener of [...listeners]) listener(user);
}
