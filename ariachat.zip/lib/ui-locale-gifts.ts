import type { Locale } from "./locales";

export type DiamondGiftKey = "title" | "hint" | "rose" | "star" | "present" | "heart";

type GiftCopy = Record<DiamondGiftKey, string>;

const copy: Record<Locale, GiftCopy> = {
  fa: { title: "هدیه‌های سریع الماسی", hint: "یک پیشنهاد را انتخاب کنید؛ مبلغ و یادداشت پر می‌شود و پیش از ارسال قابل تغییر است.", rose: "گل سرخ", star: "ستاره", present: "جعبه هدیه", heart: "قلب" },
  en: { title: "Quick Diamond gifts", hint: "Choose a suggestion to fill the amount and note; review or change them before sending.", rose: "Rose", star: "Star", present: "Gift box", heart: "Heart" },
  ar: { title: "هدايا ألماس سريعة", hint: "اختر اقتراحاً لملء المبلغ والملاحظة؛ يمكنك مراجعتهما أو تغييرهما قبل الإرسال.", rose: "وردة", star: "نجمة", present: "صندوق هدية", heart: "قلب" },
  de: { title: "Schnelle Diamantgeschenke", hint: "Wähle einen Vorschlag; Betrag und Notiz lassen sich vor dem Senden prüfen und ändern.", rose: "Rose", star: "Stern", present: "Geschenkbox", heart: "Herz" },
  tg: { title: "Тӯҳфаҳои зуди алмосӣ", hint: "Пешниҳодро интихоб кунед; маблағ ва қайд пеш аз фиристодан тағйир дода мешаванд.", rose: "Гули садбарг", star: "Ситора", present: "Қуттии тӯҳфа", heart: "Дил" },
  ps: { title: "د الماسو چټکې ډالۍ", hint: "یو وړاندیز وټاکئ؛ اندازه او یادښت له لېږلو مخکې بدلولای شئ.", rose: "ګلاب", star: "ستوری", present: "د ډالۍ بکس", heart: "زړه" },
  ur: { title: "فوری ڈائمنڈ تحائف", hint: "ایک تجویز منتخب کریں؛ بھیجنے سے پہلے رقم اور نوٹ تبدیل کر سکتے ہیں۔", rose: "گلاب", star: "ستارہ", present: "تحفے کا ڈبہ", heart: "دل" },
  sw: { title: "Zawadi za Haraka za Diamond", hint: "Chagua pendekezo; unaweza kubadilisha kiasi na ujumbe kabla ya kutuma.", rose: "Waridi", star: "Nyota", present: "Kisanduku cha zawadi", heart: "Moyo" },
  es: { title: "Regalos rápidos de Diamonds", hint: "Elige una sugerencia; puedes revisar o cambiar la cantidad y la nota antes de enviar.", rose: "Rosa", star: "Estrella", present: "Caja de regalo", heart: "Corazón" },
  it: { title: "Regali rapidi in Diamonds", hint: "Scegli un suggerimento; puoi rivedere o modificare importo e nota prima dell'invio.", rose: "Rosa", star: "Stella", present: "Scatola regalo", heart: "Cuore" },
  tr: { title: "Hızlı Diamond hediyeleri", hint: "Bir öneri seç; göndermeden önce tutarı ve notu inceleyip değiştirebilirsin.", rose: "Gül", star: "Yıldız", present: "Hediye kutusu", heart: "Kalp" },
  hi: { title: "झटपट डायमंड उपहार", hint: "एक सुझाव चुनें; भेजने से पहले राशि और नोट बदल सकते हैं।", rose: "गुलाब", star: "तारा", present: "उपहार बॉक्स", heart: "दिल" },
};

export function translateDiamondGift(locale: Locale, key: DiamondGiftKey): string {
  return copy[locale]?.[key] ?? copy.en[key];
}
