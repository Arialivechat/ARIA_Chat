import { Ionicons } from "@expo/vector-icons";
import * as FileSystem from "expo-file-system/legacy";
import { router } from "expo-router";
import { useCallback, useEffect, useState } from "react";
import { Alert, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { Page, PageHeader, PrimaryButton, SectionTitle, Surface, ui } from "@/components/aria-ui";
import { useColors } from "@/hooks/use-colors";

const DOWNLOADS_DIR = `${FileSystem.documentDirectory ?? ""}Downloads/`;
const CATEGORIES = [
  { key: "Images", label: "Images", icon: "image-outline" as const, extensions: ["jpg", "jpeg", "png", "gif", "webp", "heic"] },
  { key: "Videos", label: "Videos", icon: "videocam-outline" as const, extensions: ["mp4", "mov", "m4v", "webm"] },
  { key: "Files", label: "Files", icon: "document-text-outline" as const, extensions: ["pdf", "doc", "docx", "txt", "zip", "csv"] },
  { key: "Audio", label: "Audio", icon: "musical-notes-outline" as const, extensions: ["mp3", "m4a", "wav", "aac", "ogg"] },
];
type Totals = { bytes: number; count: number };
type Usage = { all: Totals; cache: Totals; downloads: Totals; categories: Record<string, Totals> };
const emptyTotals = (): Totals => ({ bytes: 0, count: 0 });
const formatBytes = (bytes: number) => {
  if (!bytes) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
  return `${(bytes / 1024 ** index).toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
};
async function measureTree(uri: string, include: (path: string) => boolean = () => true): Promise<Totals> {
  const result = emptyTotals();
  if (!uri) return result;
  let entries: string[];
  try { entries = await FileSystem.readDirectoryAsync(uri); } catch { return result; }
  for (const name of entries) {
    const path = `${uri}${name}`;
    try {
      const info = await FileSystem.getInfoAsync(path);
      if (!info.exists) continue;
      if (info.isDirectory) {
        const nested = await measureTree(`${path}/`, include);
        result.bytes += nested.bytes;
        result.count += nested.count;
      } else if (include(path)) {
        result.bytes += typeof info.size === "number" ? info.size : 0;
        result.count += 1;
      }
    } catch { /* An unavailable item is skipped; inaccessible data is never deleted. */ }
  }
  return result;
}
async function readUsage(): Promise<Usage> {
  const [docs, cache, downloads] = await Promise.all([
    measureTree(FileSystem.documentDirectory ?? ""),
    measureTree(FileSystem.cacheDirectory ?? ""),
    measureTree(DOWNLOADS_DIR),
  ]);
  const categories = Object.fromEntries(await Promise.all(CATEGORIES.map(async (category) => [
    category.key,
    await measureTree(FileSystem.documentDirectory ?? "", (path) => category.extensions.includes(path.split(".").pop()?.toLowerCase() ?? "")),
  ]))) as Record<string, Totals>;
  return { all: { bytes: docs.bytes + cache.bytes, count: docs.count + cache.count }, cache, downloads, categories };
}
export default function StorageManagementScreen() {
  const colors = useColors();
  const [usage, setUsage] = useState<Usage | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const refresh = useCallback(async () => {
    setBusy(true);
    try { setUsage(await readUsage()); } finally { setBusy(false); }
  }, []);
  useEffect(() => {
    const timer = setTimeout(() => { void refresh(); }, 0);
    return () => clearTimeout(timer);
  }, [refresh]);
  const chooseRoot = async () => {
    if (Platform.OS !== "android") {
      setNotice("Android folder access is available on Android devices only.");
      return;
    }
    try {
      const rootPermission = await FileSystem.StorageAccessFramework.requestDirectoryPermissionsAsync();
      if (!rootPermission.granted) return;
      const rootUri = rootPermission.directoryUri;
      const ariaUri = await FileSystem.StorageAccessFramework.makeDirectoryAsync(rootUri, "AriaChat");
      const folderResults: string[] = [];
      for (const category of CATEGORIES) {
        try {
          await FileSystem.StorageAccessFramework.makeDirectoryAsync(ariaUri, category.key);
          folderResults.push(category.key);
        } catch {
          // Existing folders may not be recreated. The selected SAF root remains user-controlled.
          folderResults.push(category.key);
        }
      }
      setNotice(`Selected folder access granted. AriaChat/${folderResults.join(", ")} is ready when supported. Files are never copied automatically.`);
    } catch {
      setNotice("Could not access that folder. No files were changed.");
    }
  };
  const clearCache = () => Alert.alert("Clear cache?", "Only temporary app cache files will be removed. Messages, account data, downloads and cloud data are not affected.", [
    { text: "Cancel", style: "cancel" },
    { text: "Clear cache", style: "destructive", onPress: async () => {
      setBusy(true);
      try {
        const before = await measureTree(FileSystem.cacheDirectory ?? "");
        if (FileSystem.cacheDirectory) await FileSystem.deleteAsync(FileSystem.cacheDirectory, { idempotent: true });
        const freed = before.bytes;
        setNotice(`Cache cleared. ${formatBytes(freed)} freed.`);
        await refresh();
      } catch { setNotice("Could not clear all cache files. Please try again."); setBusy(false); }
    } },
  ]);
  const deleteDownloads = () => Alert.alert("Delete local downloads?", "This permanently deletes files only inside this app’s dedicated local Downloads folder. It does not delete messages, account data, or anything on a server or cloud.", [
    { text: "Cancel", style: "cancel" },
    { text: "Delete downloads", style: "destructive", onPress: async () => {
      setBusy(true);
      try {
        const before = await measureTree(DOWNLOADS_DIR);
        await FileSystem.deleteAsync(DOWNLOADS_DIR, { idempotent: true });
        setNotice(`Local downloads deleted. ${formatBytes(before.bytes)} freed.`);
        await refresh();
      } catch { setNotice("Could not delete the local Downloads folder. Please try again."); setBusy(false); }
    } },
  ]);
  return <Page>
    <PageHeader eyebrow="DEVICE STORAGE" title="Storage Management" subtitle="Review files stored locally on this device." right={<Pressable accessibilityRole="button" onPress={() => router.back()} style={[styles.back, { backgroundColor: colors.surface }]}><Ionicons name="arrow-back" size={19} color={colors.tint} /></Pressable>} />
    <Surface style={styles.total}>
      <View style={[styles.bigIcon, { backgroundColor: colors.background }]}><Ionicons name="server-outline" size={25} color={colors.tint} /></View>
      <Text style={[styles.totalTitle, { color: colors.text }]}>App data, downloads & cache</Text>
      <Text style={[styles.totalSize, { color: colors.tint }]}>{usage ? formatBytes(usage.all.bytes) : "—"}</Text>
      <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{usage ? `${usage.all.count} local files` : "Calculating local usage…"}</Text>
      <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>Includes app document files and cache. The installed Android app/package size is not measurable from JavaScript here.</Text>
    </Surface>
    <Surface style={{ gap: 12 }}>
      <SectionTitle title="Local files by category" />
      {CATEGORIES.map((category) => {
        const total = usage?.categories[category.key] ?? emptyTotals();
        return <View key={category.key} style={[styles.row, { borderBottomColor: colors.border }]}><Ionicons name={category.icon} size={20} color={colors.tint} /><View style={{ flex: 1 }}><Text style={[styles.rowTitle, { color: colors.text }]}>{category.label}</Text><Text style={[ui.meta, { color: colors.icon }]}>{total.count} files · {formatBytes(total.bytes)}</Text></View></View>;
      })}
    </Surface>
    <Surface style={{ gap: 10 }}>
      <SectionTitle title="Save files to a folder" />
      <Text style={[ui.body, { color: colors.icon }]}>Choose an Android folder to grant access for AriaChat/Images, Videos, Files and Audio. This asks permission only when you tap below; choosing a folder does not copy or download anything.</Text>
      <PrimaryButton title="Choose Android folder" icon="folder-open-outline" onPress={chooseRoot} />
    </Surface>
    <Surface style={{ gap: 10 }}>
      <SectionTitle title="Downloads" />
      <Text style={[ui.body, { color: colors.icon }]}>Automatic downloads are off. This screen never starts automatic downloads.</Text>
      <Text style={[ui.meta, { color: colors.icon }]}>Local app Downloads folder: {usage?.downloads.count ?? 0} files · {formatBytes(usage?.downloads.bytes ?? 0)}</Text>
      <PrimaryButton title="Delete local downloads" icon="trash-outline" quiet onPress={deleteDownloads} />
    </Surface>
    <Surface style={{ gap: 10 }}>
      <SectionTitle title="Cache" />
      <Text style={[ui.meta, { color: colors.icon }]}>Temporary cache: {usage?.cache.count ?? 0} files · {formatBytes(usage?.cache.bytes ?? 0)}</Text>
      <PrimaryButton title="Clear cache" icon="trash-bin-outline" quiet onPress={clearCache} />
    </Surface>
    {notice ? <Surface><Text style={[ui.body, { color: colors.text }]}>{notice}</Text></Surface> : null}
    <PrimaryButton title={busy ? "Refreshing…" : "Refresh usage"} icon="refresh-outline" quiet disabled={busy} onPress={() => void refresh()} />
  </Page>;
}
const styles = StyleSheet.create({ back: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" }, total: { alignItems: "center", gap: 8 }, bigIcon: { width: 54, height: 54, borderRadius: 18, alignItems: "center", justifyContent: "center" }, totalTitle: { fontSize: 15, fontWeight: "800" }, totalSize: { fontSize: 30, fontWeight: "900" }, row: { flexDirection: "row-reverse", alignItems: "center", gap: 11, borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 9 }, rowTitle: { fontSize: 14, fontWeight: "700", textAlign: "right" } });
