import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useMemo } from "react";
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, View } from "react-native";
import { EmptyState, LoginGate, Page, PageHeader, Surface, ui } from "@/components/aria-ui";
import { UserIdentity } from "@/components/user-identity";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { trpc } from "@/lib/trpc";

export default function MessagesScreen() {
  const colors = useColors();
  const { locale, t, tExtra } = useLanguage();
  const { isAuthenticated, loading, error: authError, refresh } = useAuth();
  const inbox = trpc.messages.inbox.useQuery({ limit: 50 }, { enabled: isAuthenticated, refetchInterval: 5000 });
  const incomingInvites = trpc.roomInvites.incoming.useQuery(undefined, { enabled: isAuthenticated, refetchInterval: 5000 });
  const utils = trpc.useUtils();
  const respondInvite = trpc.roomInvites.respond.useMutation({ onSuccess: async (_result, variables) => { await Promise.all([incomingInvites.refetch(), utils.rooms.list.invalidate()]); if (variables.response === "accepted") router.push(`/room/${incomingInvites.data?.find(invite => invite.id === variables.invitationId)?.roomId}`); } });
  const inboxData = inbox.data;
  type InboxMessage = NonNullable<typeof inboxData>[number];
  const conversations = useMemo(() => {
    const map = new Map<number, InboxMessage>();
    for (const message of inboxData ?? []) {
      const otherAccountNumber = message.otherUser?.accountNumber;
      if (otherAccountNumber) map.set(otherAccountNumber, message);
    }
    return [...map.entries()].sort((a, b) => new Date(b[1].createdAt).getTime() - new Date(a[1].createdAt).getTime());
  }, [inboxData]);
  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={t("loginMessages")} authError={authError} onRetry={refresh} />;

  return (
    <Page>
      <PageHeader eyebrow={t("privateMessage")} title={t("messages")} subtitle={t("history")} />
      {incomingInvites.data?.length ? <Surface style={{ gap: 9 }}><Text style={[ui.body, { color: colors.text, textAlign: "right", fontWeight: "900" }]}>{t("invite")}</Text>
        {incomingInvites.data.map(invite => <View key={invite.id} style={[styles.card, { backgroundColor: colors.background, borderColor: colors.border }]}><View style={{ flex: 1, gap: 4 }}><Text style={[styles.name, { color: colors.text }]}>{invite.roomName}</Text><View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 4 }}><Text style={[ui.meta, { color: colors.icon }]}>از</Text><UserIdentity name={invite.inviterUsername || invite.inviterName || t("friend")} avatarEmoji={invite.inviterAvatarEmoji} badgeTitle={invite.inviterBadgeTitle} crownStyle={invite.inviterCrownStyle} role={invite.inviterRole} style={{ flex: 1 }} /></View><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>شمارهٔ حساب #{invite.accountNumber ?? "—"}</Text></View><Pressable disabled={respondInvite.isPending} onPress={() => respondInvite.mutate({ invitationId: invite.id, response: "accepted" })} style={[styles.inviteAction, { backgroundColor: colors.tint }]}><Text style={{ color: colors.background, fontWeight: "900" }}>{t("accept")}</Text></Pressable><Pressable disabled={respondInvite.isPending} onPress={() => respondInvite.mutate({ invitationId: invite.id, response: "declined" })} style={[styles.inviteAction, { backgroundColor: colors.error }]}><Text style={{ color: colors.background, fontWeight: "900" }}>{t("decline")}</Text></Pressable></View>)}
      </Surface> : null}
      {incomingInvites.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text></Surface> : null}
      {respondInvite.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
      {inbox.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
      {inbox.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text></Surface> : null}
      {!inbox.isLoading && !inbox.error && conversations.length === 0 ? <EmptyState icon="mail-open-outline" title={t("noResults")} detail={t("privateMessage")} /> : null}
      {conversations.map(([accountNumber, message]) => {
        const incoming = !message.isMine;
        return (
          <Pressable key={accountNumber} onPress={() => router.push(`/message/${accountNumber}`)} style={({ pressed }) => [styles.card, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && { opacity: 0.8 }]}>
            {message.otherUser?.avatarUrl ? <Image source={{ uri: message.otherUser.avatarUrl }} style={styles.avatar} /> : <View style={[styles.avatar, { backgroundColor: colors.background }]}><Ionicons name="person" size={21} color={colors.tint} /></View>}
            <View style={{ flex: 1, gap: 5 }}>
              <View style={ui.spread}><UserIdentity name={message.otherUser?.username || message.otherUser?.name || `کاربر #${accountNumber}`} avatarEmoji={message.otherUser?.avatarEmoji} badgeTitle={message.otherUser?.badgeTitle} crownStyle={message.otherUser?.crownStyle} role={message.otherUser?.role} style={{ flex: 1 }} nameStyle={[styles.name, { color: colors.text }]} /><Text style={[ui.meta, { color: colors.icon }]}>{new Date(message.createdAt).toLocaleDateString(locale)}</Text></View>
              <Text numberOfLines={1} style={[ui.body, { color: colors.icon }]}>{message.text || t("privateMessage")}</Text>
              {message.unreadCount > 0 ? <Text style={[ui.meta, { color: colors.warning, textAlign: "right", fontWeight: "900" }]}>{tExtra("unreadMessages", { count: message.unreadCount })}</Text> : null}
            </View>
            <Ionicons name="chevron-back" size={17} color={colors.icon} />
          </Pressable>
        );
      })}
    </Page>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: "row-reverse", alignItems: "center", gap: 11, borderRadius: 18, borderWidth: 1, padding: 13 },
  avatar: { width: 45, height: 45, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  name: { flex: 1, fontSize: 14, fontWeight: "800", textAlign: "right" },
  inviteAction: { paddingHorizontal: 10, paddingVertical: 8, borderRadius: 10 },
});
