import { Ionicons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { router } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, AppState, Image, Modal, Pressable, StyleSheet, Switch, Text, TextInput, View } from "react-native";
import { Chip, FloatingIcon, LoginGate, Page, PageHeader, PrimaryButton, SectionTitle, Surface, ui } from "@/components/aria-ui";
import { UserIdentity } from "@/components/user-identity";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { getChatRankProgress } from "@/lib/chat-ranks";
import { useThemeContext } from "@/lib/theme-provider";
import { useLanguage } from "@/hooks/use-language";
import { LOCALES } from "@/lib/locales";
import { isProfileAvatarEmoji, PROFILE_AVATAR_OPTIONS, type ProfileAvatarEmoji } from "@/lib/profile-avatars";
import { isProfileAvatarUrl } from "@/lib/profile-avatar-url";
import { trpc } from "@/lib/trpc";
import { translateProfileAvatars } from "@/lib/ui-locale-avatars";
import { MAX_IMAGE_UPLOAD_BYTES, MAX_UPLOAD_BASE64_CHARS } from "@/lib/media-limits";

function avatarErrorMessage(error: unknown, fallback: string, localizedMessages: string[]): string {
  const message = error instanceof Error ? error.message : "";
  if (!message) return fallback;
  if (localizedMessages.includes(message)) return message;
  try {
    const parsed: unknown = JSON.parse(message);
    if (Array.isArray(parsed) || (parsed !== null && typeof parsed === "object")) return fallback;
  } catch {
    // Keep plain, human-readable permission/network messages below.
  }
  if (/avatarUrl|invalid.*url|invalid_format/i.test(message)) return fallback;
  return message;
}

export default function ProfileSettingsScreen() {
  const colors = useColors();
  const { locale, setLocale, t, tExtra, isRTL } = useLanguage();
  const avatarCopy = useCallback((key: import("@/lib/ui-locale-avatars").ProfileAvatarLocaleKey) => translateProfileAvatars(locale, key), [locale]);
  const { setColorScheme, colorScheme } = useThemeContext();
  const { isAuthenticated, loading, error: authError, refresh, logout } = useAuth();
  const profile = trpc.profile.me.useQuery(undefined, { enabled: isAuthenticated });
  const update = trpc.profile.update.useMutation({ onSuccess: () => profile.refetch() });
  const avatarUpload = trpc.media.upload.useMutation();
  const updateAvatar = update.mutateAsync;
  const uploadAvatar = avatarUpload.mutateAsync;
  const pendingAssetHandler = useRef<(asset: ImagePicker.ImagePickerAsset) => Promise<void>>(async () => undefined);
  const passwordUpdate = trpc.profile.setPassword.useMutation({ onSuccess: async () => { setCurrentPassword(""); setNewPassword(""); setConfirmPassword(""); await profile.refetch(); } });
  const deleteAccount = trpc.profile.deleteAccount.useMutation();
  const hydrated = useRef(false);
  const [username, setUsername] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [avatarEmoji, setAvatarEmoji] = useState<ProfileAvatarEmoji | null>(null);
  const [avatarDisplayUrl, setAvatarDisplayUrl] = useState("");
  const [avatarError, setAvatarError] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState<"unspecified" | "male" | "female" | "nonbinary">("unspecified");
  const [city, setCity] = useState("");
  const [country, setCountry] = useState("");
  const [bio, setBio] = useState("");
  const [isPrivate, setIsPrivate] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordFormError, setPasswordFormError] = useState("");
  const [appearanceOpen, setAppearanceOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const processAvatarAsset = useCallback(async (asset: ImagePicker.ImagePickerAsset) => {
    try {
      if ((asset.fileSize !== undefined && asset.fileSize > MAX_IMAGE_UPLOAD_BYTES) || (asset.base64 && asset.base64.length > MAX_UPLOAD_BASE64_CHARS)) throw new Error(translateProfileAvatars(locale, "imageTooLarge"));
      if (!asset.base64) throw new Error(translateProfileAvatars(locale, "imageReadFailed"));
      const contentType = asset.mimeType?.toLowerCase().split(";")[0];
      if (!contentType || !["image/jpeg", "image/png", "image/webp"].includes(contentType)) throw new Error(translateProfileAvatars(locale, "imageTypeUnsupported"));
      const uploaded = await uploadAvatar({ fileName: asset.fileName || "profile-image", contentType, base64Data: asset.base64 });
      if (uploaded.kind !== "image" || !uploaded.stableUrl) throw new Error(translateProfileAvatars(locale, "imageUploadFailed"));
      await updateAvatar({ avatarUrl: uploaded.stableUrl });
      setAvatarUrl(uploaded.stableUrl);
      setAvatarDisplayUrl(uploaded.displayUrl || uploaded.stableUrl);
    } catch (error) {
      setAvatarError(avatarErrorMessage(error, avatarCopy("imageUploadFailed"), [avatarCopy("permissionDenied"), avatarCopy("imageTooLarge"), avatarCopy("imageReadFailed"), avatarCopy("imageTypeUnsupported")]));
    }
  }, [avatarCopy, locale, setAvatarDisplayUrl, setAvatarError, setAvatarUrl, updateAvatar, uploadAvatar]);
  useEffect(() => {
    pendingAssetHandler.current = processAvatarAsset;
  }, [processAvatarAsset]);
  useEffect(() => {
    const subscription = AppState.addEventListener("change", (state) => {
      if (state !== "active" || !ImagePicker.getPendingResultAsync) return;
      void ImagePicker.getPendingResultAsync().then((result) => {
        if (result && "assets" in result && !result.canceled && result.assets?.[0]) void pendingAssetHandler.current(result.assets[0]);
      }).catch(() => undefined);
    });
    return () => subscription.remove();
  }, []);
  useEffect(() => {
    const value = profile.data;
    if (!value || hydrated.current) return;
    hydrated.current = true;
    setUsername(value.username ?? ""); setAvatarUrl(value.avatarStorageUrl ?? value.avatarUrl ?? ""); setAvatarDisplayUrl(value.avatarUrl ?? ""); setAvatarEmoji(isProfileAvatarEmoji(value.avatarEmoji) ? value.avatarEmoji : null); setAge(value.age ? String(value.age) : ""); setGender(value.gender ?? "unspecified"); setIsPrivate(value.isPrivate ?? false);
    setCity(value.city ?? ""); setCountry(value.country ?? ""); setBio(value.bio ?? "");
    setColorScheme(value.darkMode ? "dark" : "light");
  }, [profile.data, setColorScheme]);
  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={t("loginProfile")} authError={authError} onRetry={refresh} />;
  const save = () => {
    const nextAvatarUrl = avatarUrl.trim();
    if (nextAvatarUrl && !isProfileAvatarUrl(nextAvatarUrl)) {
      setAvatarError(avatarCopy("imageUrlInvalid"));
      return;
    }
    setAvatarError("");
    update.mutate({ username: username.trim() || null, avatarUrl: nextAvatarUrl || null, avatarEmoji, age: age ? Number(age) : null, gender, city: city.trim() || null, country: country.trim() || null, bio: bio.trim() || null, isPrivate, language: locale, darkMode: colorScheme === "dark" });
  };
  const saveAppearance = () => update.mutate({ language: locale, darkMode: colorScheme === "dark" });
  const pickAvatar = async (source: "gallery" | "camera") => {
    setAvatarError("");
    try {
      if (source === "gallery") {
        const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (!permission.granted) throw new Error(avatarCopy("permissionDenied"));
      } else {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) throw new Error(avatarCopy("permissionDenied"));
      }
      const options: ImagePicker.ImagePickerOptions = { mediaTypes: ["images"], allowsEditing: true, aspect: [1, 1], quality: 0.82, base64: true };
      const result = source === "gallery"
        ? await ImagePicker.launchImageLibraryAsync(options)
        : await ImagePicker.launchCameraAsync({ ...options, cameraType: ImagePicker.CameraType.front });
      if (result.canceled) return;
      const asset = result.assets?.[0];
      if (asset) await processAvatarAsset(asset);
    } catch (error) {
      setAvatarError(avatarErrorMessage(error, avatarCopy("imageUploadFailed"), [avatarCopy("permissionDenied"), avatarCopy("imageTooLarge"), avatarCopy("imageReadFailed"), avatarCopy("imageTypeUnsupported")]));
    }
  };
  const savePassword = () => {
    if (newPassword !== confirmPassword) { setPasswordFormError("تکرار رمز عبور با رمز اصلی یکسان نیست."); return; }
    if (newPassword.length < 6) { setPasswordFormError("رمز عبور باید دست‌کم ۶ نویسه داشته باشد."); return; }
    setPasswordFormError("");
    passwordUpdate.mutate({ newPassword, ...(profile.data?.loginMethod === "password" ? { currentPassword } : {}) });
  };
  const signOut = async () => { await logout(); router.replace("/(tabs)"); };
  const messageCount = profile.data?.chatMessageCount ?? 0;
  const rankProgress = getChatRankProgress(messageCount);

  return (
    <Page>
      <PageHeader eyebrow={t("account")} title={profile.data ? <UserIdentity name={profile.data.username || profile.data.name || t("profileTitle")} avatarEmoji={profile.data.avatarEmoji} badgeTitle={profile.data.badgeTitle} crownStyle={profile.data.crownStyle} role={profile.data.role} fontSize={26} /> : t("profileTitle")} subtitle={t("profileSubtitle")} />
      {profile.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
      {profile.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text></Surface> : null}
      {profile.data ? <Surface style={{ gap: 10, alignItems: "center" }}>
        <View style={[ui.spread, { width: "100%" }]}><View style={ui.row}><FloatingIcon icon="person" size={42} label="شناسهٔ حساب" /><Text style={[ui.body, { color: colors.text, fontWeight: "900" }]}>شمارهٔ حساب #{profile.data.accountNumber}</Text></View><Text style={[ui.meta, { color: colors.icon }]}>قابل جست‌وجو</Text></View>
        <View style={[ui.row, { justifyContent: "center" }]}><FloatingIcon icon="ribbon" size={40} label="رتبهٔ چت" /><Text style={[ui.body, { color: colors.text, fontWeight: "900" }]}>رتبهٔ «{profile.data.rankTitle}»</Text></View>
        <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{profile.data.rankIsManual ? `رتبه با تنظیم مدیر تغییر کرده؛ پیشرفت خودکار: ${rankProgress.title}` : rankProgress.nextTitle ? `${messageCount} پیام سالم · ${rankProgress.remaining} پیام تا رتبهٔ ${rankProgress.nextTitle}` : `${messageCount} پیام سالم · بالاترین رتبهٔ خودکار`}</Text>
        <View style={{ width: "100%", height: 7, borderRadius: 8, backgroundColor: colors.border, overflow: "hidden" }}><View style={{ width: `${rankProgress.progress}%`, height: "100%", backgroundColor: colors.tint, borderRadius: 8 }} /></View>
      </Surface> : null}
      {profile.data?.accountNumber === 1 && (profile.data.role === "admin" || profile.data.role === "superadmin") ? <Surface style={{ gap: 10, borderColor: colors.warning }}>
        <View style={ui.row}><FloatingIcon icon="shield-checkmark" size={44} label="ابزارهای ویژهٔ Administrator" /><View style={{ flex: 1, gap: 3 }}><Text style={[ui.body, { color: colors.text, fontWeight: "900", textAlign: "right" }]}>گزینه‌های ویژهٔ Administrator</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>ویژهٔ حساب شمارهٔ ۱؛ دسترسی‌ها در سرور هم بررسی می‌شوند.</Text></View></View>
        <PrimaryButton title="ورود به پنل مدیریت" icon="shield-checkmark" onPress={() => router.push("/admin")} />
      </Surface> : null}
      <Surface style={styles.form}>
        <SectionTitle title={t("editProfile")} />
        <View style={styles.avatarRow}>{(avatarDisplayUrl || avatarUrl).trim() ? <Image source={{ uri: (avatarDisplayUrl || avatarUrl).trim() }} style={styles.avatarPreview} /> : <FloatingIcon icon="person" size={58} label="آواتار" />}<View style={{ flex: 1 }}><LabelInput label="نشانی عکس/آواتار" value={avatarUrl} onChangeText={(value) => { setAvatarUrl(value); setAvatarDisplayUrl(value); }} placeholder="https://…" /></View></View>
        <View style={ui.row}>
          <PrimaryButton title={avatarCopy("gallery")} icon="image-outline" quiet disabled={avatarUpload.isPending || update.isPending} onPress={() => { void pickAvatar("gallery"); }} />
          <PrimaryButton title={avatarCopy("selfie")} icon="camera-outline" quiet disabled={avatarUpload.isPending || update.isPending} onPress={() => { void pickAvatar("camera"); }} />
        </View>
        <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{avatarCopy("imageHint")}</Text>
        {avatarError ? <Text style={{ color: colors.error, textAlign: "right" }}>{avatarError}</Text> : null}
        <View style={{ gap: 8 }}>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right", fontWeight: "800" }]}>{avatarCopy("pickerTitle")}</Text>
          <View style={styles.avatarEmojiGrid}>
            {PROFILE_AVATAR_OPTIONS.map((emoji) => <Pressable key={emoji} accessibilityRole="button" accessibilityLabel={`${avatarCopy("pickerTitle")}: ${emoji}`} accessibilityState={{ selected: avatarEmoji === emoji }} onPress={() => setAvatarEmoji(emoji)} style={[styles.avatarEmojiOption, { backgroundColor: avatarEmoji === emoji ? colors.tint : colors.background, borderColor: avatarEmoji === emoji ? colors.warning : colors.border }]}><Text style={styles.avatarEmojiText}>{emoji}</Text></Pressable>)}
          </View>
          <PrimaryButton title={avatarCopy("clearAvatar")} icon="close-circle-outline" quiet disabled={!avatarEmoji || update.isPending} onPress={() => setAvatarEmoji(null)} />
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{avatarCopy("saveHint")}</Text>
        </View>
        <LabelInput label={t("username")} value={username} onChangeText={setUsername} placeholder="نام نمایشی یکتا" />
        <LabelInput label={t("age")} value={age} onChangeText={setAge} placeholder={t("age")} keyboardType="number-pad" />
        <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>جنسیت</Text>
        <View style={styles.chips}><Chip label={t("unspecified")} active={gender === "unspecified"} onPress={() => setGender("unspecified")} /><Chip label={t("female")} active={gender === "female"} onPress={() => setGender("female")} /><Chip label={t("male")} active={gender === "male"} onPress={() => setGender("male")} /><Chip label={t("other")} active={gender === "nonbinary"} onPress={() => setGender("nonbinary")} /></View>
        <LabelInput label={t("city")} value={city} onChangeText={setCity} placeholder={t("city")} />
        <LabelInput label={t("country")} value={country} onChangeText={setCountry} placeholder={t("country")} />
        <LabelInput label={t("bio")} value={bio} onChangeText={setBio} placeholder="چند خط از خودت بگو" multiline />
        <View style={styles.privacyRow}><View style={{ flex: 1, gap: 3 }}><Text style={[ui.body, { color: colors.text, fontWeight: "800", textAlign: "right" }]}>حساب خصوصی</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>پروفایل در جست‌وجوی عمومی دیده نمی‌شود؛ اطلاعات کامل فقط به دوستان نمایش داده می‌شود.</Text></View><Switch value={isPrivate} onValueChange={setIsPrivate} trackColor={{ false: colors.border, true: colors.tint }} thumbColor={colors.warning} accessibilityLabel={t("makePrivate")} /></View>
        <PrimaryButton title={update.isPending ? t("savePending") : "ذخیرهٔ پروفایل"} icon="checkmark" disabled={update.isPending} onPress={save} />
        {update.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
        {update.isSuccess ? <Text style={{ color: colors.success, textAlign: "right" }}>تغییرات ذخیره شد.</Text> : null}
      </Surface>
      {profile.data && profile.data.accountNumber >= 101 ? <Surface style={styles.form}>
        <SectionTitle title={t("security")} />
        <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{profile.data.loginMethod === "password" ? "برای تغییر رمز فعلی، رمز کنونی را وارد کن." : "برای ورود با نام کاربری و رمز، یک گذرواژه برای همین حساب تنظیم کن؛ شمارهٔ حساب و پیام‌هایت حفظ می‌شوند."}</Text>
        {profile.data.loginMethod === "password" ? <TextInput value={currentPassword} onChangeText={setCurrentPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="current-password" placeholder="رمز فعلی" placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} /> : null}
        <TextInput value={newPassword} onChangeText={setNewPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="new-password" placeholder="رمز جدید (حداقل ۶ نویسه)" placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
        <TextInput value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="new-password" placeholder="تکرار رمز جدید" placeholderTextColor={colors.icon} onSubmitEditing={savePassword} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
        <PrimaryButton title={passwordUpdate.isPending ? t("savePending") : "ذخیرهٔ رمز ورود"} icon="lock-closed" disabled={passwordUpdate.isPending || !newPassword || !confirmPassword || (profile.data.loginMethod === "password" && !currentPassword)} onPress={savePassword} />
        {passwordFormError ? <Text style={{ color: colors.error, textAlign: "right" }}>{passwordFormError}</Text> : null}
        {passwordUpdate.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
        {passwordUpdate.isSuccess ? <Text style={{ color: colors.success, textAlign: "right" }}>رمز ورود با موفقیت ذخیره شد.</Text> : null}
      </Surface> : null}
      <Surface style={styles.form}>
        <Pressable onPress={() => setAppearanceOpen((value) => !value)} style={ui.spread}><Text style={[ui.body, { color: colors.text, fontWeight: "800" }]}>{t("appearance")}</Text><View style={ui.row}><Text style={[ui.meta, { color: colors.icon }]}>{colorScheme === "dark" ? t("dark") : t("light")}</Text><Ionicons name={appearanceOpen ? "chevron-up" : "chevron-down"} size={17} color={colors.icon} /></View></Pressable>
        {appearanceOpen ? <View style={styles.form}>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{t("language")}</Text>
          <View style={[styles.chips, { flexDirection: isRTL ? "row-reverse" : "row" }]}>{LOCALES.map((item) => <Chip key={item.code} label={item.name} active={locale === item.code} onPress={() => setLocale(item.code)} />)}</View>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>تم</Text>
          <View style={styles.chips}><Chip label={t("dark")} active={colorScheme === "dark"} onPress={() => setColorScheme("dark")} /><Chip label={t("light")} active={colorScheme === "light"} onPress={() => setColorScheme("light")} /></View>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{t("paletteHelp")}</Text>
          <Pressable accessibilityRole="button" onPress={() => router.push("/shop")} style={[ui.spread, { paddingVertical: 8 }]}><View style={ui.row}><Ionicons name="storefront-outline" size={18} color={colors.tint} /><Text style={[ui.body, { color: colors.text }]}>رفتن به آرشاپ</Text></View><Ionicons name="chevron-back" size={17} color={colors.icon} /></Pressable>
          <PrimaryButton title="ذخیرهٔ ظاهر" icon="checkmark" disabled={update.isPending} onPress={saveAppearance} />
        </View> : null}
      </Surface>
      <Surface style={{ gap: 10 }}>
        <Pressable onPress={() => setSupportOpen((value) => !value)} style={ui.spread}><Text style={[ui.body, { color: colors.text, fontWeight: "800" }]}>راهنما و حریم خصوصی</Text><Ionicons name={supportOpen ? "chevron-up" : "chevron-down"} size={17} color={colors.icon} /></Pressable>
        {supportOpen ? <View style={styles.form}>
          <Text style={[ui.body, { color: colors.icon }]}>شناسهٔ نصب در جست‌وجوی کاربران نمایش داده نمی‌شود؛ شناسهٔ دائمی IMEI ذخیره نمی‌شود.</Text>
          <Pressable onPress={() => router.push("/help")} style={[ui.spread, { paddingVertical: 8 }]}><View style={ui.row}><Ionicons name="help-circle-outline" size={18} color={colors.tint} /><Text style={[ui.body, { color: colors.text }]}>راهنما و پرسش‌های متداول</Text></View><Ionicons name="chevron-back" size={17} color={colors.icon} /></Pressable>
          {profile.data?.accountNumber === 1 && (profile.data.role === "admin" || profile.data.role === "superadmin") ? <Pressable onPress={() => router.push("/admin")} style={[ui.spread, { paddingVertical: 8 }]}><View style={ui.row}><Ionicons name="shield-checkmark-outline" size={18} color={colors.tint} /><Text style={[ui.body, { color: colors.text }]}>پنل مدیریت Administrator</Text></View><Ionicons name="chevron-back" size={17} color={colors.icon} /></Pressable> : null}
          <Text style={[ui.body, { color: colors.icon }]}>ارتباط با مدیر: arialivechat@gmail.com</Text>
        </View> : null}
      </Surface>
      {profile.data && profile.data.accountNumber >= 101 && profile.data.role !== "admin" && profile.data.role !== "superadmin" ? <PrimaryButton title={tExtra("deleteAccount")} icon="trash-outline" quiet onPress={() => setDeleteConfirmOpen(true)} /> : null}
      <PrimaryButton title={t("safeSignOut")} icon="log-out-outline" quiet onPress={signOut} />
      <Modal visible={deleteConfirmOpen} transparent animationType="fade" onRequestClose={() => setDeleteConfirmOpen(false)}>
        <View style={{ flex: 1, backgroundColor: "rgba(4, 12, 25, 0.68)", alignItems: "center", justifyContent: "center", padding: 18 }}>
          <Surface style={{ width: "100%", maxWidth: 440, gap: 13, borderColor: colors.error }}>
            <Text style={[ui.body, { color: colors.text, fontWeight: "900", textAlign: "right" }]}>{tExtra("deleteAccount")}</Text>
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{tExtra("deleteAccountWarning")}</Text>
            {deleteAccount.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
            <PrimaryButton title={deleteAccount.isPending ? t("saving") : tExtra("confirmDeleteAccount")} icon="trash" disabled={deleteAccount.isPending} onPress={() => deleteAccount.mutate(undefined, { onSuccess: async () => { setDeleteConfirmOpen(false); await logout(); router.replace("/(tabs)"); } })} />
            <PrimaryButton title={t("cancel")} quiet onPress={() => setDeleteConfirmOpen(false)} />
          </Surface>
        </View>
      </Modal>
    </Page>
  );
}

function LabelInput(props: { label: string; value: string; onChangeText: (value: string) => void; placeholder: string; multiline?: boolean; keyboardType?: "default" | "number-pad" }) {
  const colors = useColors();
  return <View style={{ gap: 5 }}><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{props.label}</Text><TextInput value={props.value} onChangeText={props.onChangeText} placeholder={props.placeholder} placeholderTextColor={colors.icon} multiline={props.multiline} keyboardType={props.keyboardType} style={[ui.input, { minHeight: props.multiline ? 88 : 46, textAlignVertical: props.multiline ? "top" : "center", color: colors.text, borderColor: colors.border }]} /></View>;
}

const styles = StyleSheet.create({ form: { gap: 11 }, chips: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }, avatarRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, avatarPreview: { width: 58, height: 58, borderRadius: 19, alignItems: "center", justifyContent: "center" }, avatarEmojiGrid: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }, avatarEmojiOption: { width: 42, height: 42, borderWidth: 1, borderRadius: 13, alignItems: "center", justifyContent: "center" }, avatarEmojiText: { fontSize: 23 }, privacyRow: { flexDirection: "row-reverse", alignItems: "center", gap: 10, paddingVertical: 6 } });
