import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { useEffect, useRef, useState } from "react";
import { Platform, Pressable, Text, View } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { ActiveAdsTicker } from "@/components/active-ads-ticker";
import { useColors } from "@/hooks/use-colors";
import { useAuth } from "@/hooks/use-auth";
import { useSoundEffects } from "@/hooks/use-sound-effects";
import { useLanguage } from "@/hooks/use-language";
import { trpc } from "@/lib/trpc";
import { useRouter } from "expo-router";

export default function TabLayout() {
  const colors = useColors();
  const router = useRouter();
  const { t, locale, isRTL } = useLanguage();
  const insets = useSafeAreaInsets();
  const { isAuthenticated } = useAuth();
  const { playPrivateMessage } = useSoundEffects();
  const unread = trpc.messages.unreadCount.useQuery(undefined, { enabled: isAuthenticated, refetchInterval: 15_000 });
  const incoming = trpc.calls.incoming.useQuery(undefined, { enabled: isAuthenticated, refetchInterval: 3_000 });
  const respond = trpc.calls.respond.useMutation({ onSuccess: (_result, input) => { incoming.refetch(); if (input.response === "accepted") router.push((`/call/${input.callId}`) as any); } });
  const [now, setNow] = useState(() => new Date());
  const previousUnread = useRef<number | null>(null);
  const topPadding = Platform.OS === "web" ? 6 : Math.max(insets.top, 8);
  const unreadCount = isAuthenticated ? unread.data?.unreadCount ?? 0 : 0;

  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!isAuthenticated) {
      previousUnread.current = null;
      return;
    }
    if (unread.data === undefined) return;
    if (previousUnread.current !== null && unreadCount > previousUnread.current) playPrivateMessage();
    previousUnread.current = unreadCount;
  }, [isAuthenticated, unread.data, unreadCount, playPrivateMessage]);

  const clockText = now.toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit", hour12: false });
  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ paddingTop: topPadding, height: topPadding + 31, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 0.6, borderBottomColor: colors.border }}>
        <View style={{ flexDirection: isRTL ? "row-reverse" : "row", alignItems: "center", gap: 6 }}><Ionicons name="time-outline" color={colors.tint} size={16} /><Text accessibilityLabel={`${t("roomLive")} ${clockText}`} style={{ color: colors.text, fontVariant: ["tabular-nums"], fontSize: 13, fontWeight: "800" }}>{clockText}</Text></View>
        <View style={{ flexDirection: isRTL ? "row-reverse" : "row", alignItems: "center", gap: 8 }}>
          <Pressable accessibilityRole="button" accessibilityLabel={t("gameShop")} onPress={() => router.push("/shop" as any)} style={{ minHeight: 25, paddingHorizontal: 8, borderRadius: 10, backgroundColor: colors.surface, flexDirection: isRTL ? "row-reverse" : "row", alignItems: "center", gap: 4 }}>
            <Ionicons name="game-controller-outline" color={colors.tint} size={14} />
            <Text style={{ color: colors.text, fontSize: 9, fontWeight: "900" }}>{t("gameShop")}</Text>
          </Pressable>
          <Text style={{ color: colors.icon, fontSize: 10, fontWeight: "900", letterSpacing: 1 }}>ARIA CHAT</Text>
        </View>
      </View>
      <ActiveAdsTicker />
      {incoming.data?.[0] ? <View style={{ padding: 9, backgroundColor: colors.surface, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderColor: colors.border }}><Text style={{ color: colors.text, fontWeight: "800" }}>{t("roomLive")} {incoming.data[0].callerName}</Text><View style={{ flexDirection: "row-reverse", gap: 8 }}><Text onPress={() => respond.mutate({ callId: incoming.data![0].callId, response: "accepted" })} style={{ color: colors.success, fontWeight: "900", padding: 6 }}>{t("accept")}</Text><Text onPress={() => respond.mutate({ callId: incoming.data![0].callId, response: "declined" })} style={{ color: colors.error, fontWeight: "900", padding: 6 }}>{t("decline")}</Text></View></View> : null}
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarPosition: "top",
          tabBarButton: HapticTab,
          tabBarActiveTintColor: colors.tint,
          tabBarInactiveTintColor: colors.icon,
          tabBarLabelStyle: { fontSize: 9, fontWeight: "800", marginTop: 1 },
          tabBarItemStyle: { minHeight: 48, paddingVertical: 3 },
          tabBarStyle: { paddingTop: 4, paddingBottom: 5, height: 57, backgroundColor: colors.background, borderBottomColor: colors.border, borderBottomWidth: 0.6, borderTopWidth: 0 },
        }}
      >
        <Tabs.Screen name="index" options={{ title: t("roomsTab"), tabBarAccessibilityLabel: t("roomsTab"), tabBarIcon: ({ color, size }) => <Ionicons name="chatbubbles" color={color} size={size} /> }} />
        <Tabs.Screen name="users" options={{ title: t("userTab"), tabBarAccessibilityLabel: t("userTab"), tabBarIcon: ({ color, size }) => <Ionicons name="people" color={color} size={size} /> }} />
        <Tabs.Screen name="messages" options={{ title: t("messageTab"), tabBarAccessibilityLabel: t("messageTab"), tabBarBadge: unreadCount > 0 ? (unreadCount > 99 ? "99+" : unreadCount) : undefined, tabBarBadgeStyle: { backgroundColor: colors.warning, color: colors.background, fontSize: 9, fontWeight: "900" }, tabBarIcon: ({ color, size }) => <Ionicons name="mail" color={color} size={size} /> }} />
        <Tabs.Screen name="wallet" options={{ title: t("pointsTab"), tabBarAccessibilityLabel: t("pointsTab"), tabBarIcon: ({ color, size }) => <Ionicons name="sparkles" color={color} size={size} /> }} />
        <Tabs.Screen name="profile" options={{ title: t("profileTab"), tabBarAccessibilityLabel: t("profileTab"), tabBarIcon: ({ color, size }) => <Ionicons name="person-circle" color={color} size={size} /> }} />
      </Tabs>
    </View>
  );
}
