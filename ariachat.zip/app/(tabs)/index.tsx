import { Ionicons } from "@expo/vector-icons";
import { Link, router } from "expo-router";
import { useMemo, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Chip, EmptyState, FloatingIcon, LoginGate, Page, PageHeader, PrimaryButton, SectionTitle, Surface, ui } from "@/components/aria-ui";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { trpc } from "@/lib/trpc";
import { translateCoreScreen } from "@/lib/ui-locale-core-screens";
import { roomFavoriteText } from "@/lib/ui-locale-room-favorites";

export default function RoomsHomeScreen() {
  const colors = useColors();
  const { locale, t, tExtra } = useLanguage();
  const c = (key: import("@/lib/ui-locale-core-screens").CoreScreenLocaleKey) => translateCoreScreen(locale, key);
  const { isAuthenticated, loading, error: authError, refresh } = useAuth();
  const [search, setSearch] = useState("");
  const [kind, setKind] = useState<"public" | "private" | "country" | "official">("public");
  const [listKind, setListKind] = useState<"public" | "private" | "country" | "official" | "favorites">("public");
  const [createOpen, setCreateOpen] = useState(false);
  const [roomName, setRoomName] = useState("");
  const [roomDescription, setRoomDescription] = useState("");
  const [roomCountry, setRoomCountry] = useState("");
  const rooms = trpc.rooms.list.useQuery({ kind: listKind, limit: 30 }, { enabled: isAuthenticated, refetchInterval: 12000 });
  const wallet = trpc.wallet.me.useQuery(undefined, { enabled: isAuthenticated });
  const favoriteRoom = trpc.rooms.setFavorite.useMutation({ onSuccess: async () => { await rooms.refetch(); } });
  const createRoom = trpc.rooms.create.useMutation({ onSuccess: async () => { setCreateOpen(false); setRoomName(""); setRoomDescription(""); setRoomCountry(""); await rooms.refetch(); } });
  const filteredRooms = useMemo(() => {
    const items = rooms.data ?? [];
    const value = search.trim().toLocaleLowerCase();
    return value ? items.filter((room) => room.name.toLocaleLowerCase().includes(value)) : items;
  }, [rooms.data, search]);

  if (loading) return <Page scroll={false}><View style={styles.center}><ActivityIndicator color={colors.tint} /></View></Page>;
  if (!isAuthenticated) return <LoginGate title={`${t("rooms")} · ${t("join")}`} authError={authError} onRetry={refresh} />;

  return (
    <Page>
      <PageHeader
        eyebrow="ARIA CHAT"
        title={t("rooms")}
        subtitle={`${t("roomLive")} · ${t("roomManagement")}`}
        right={<View style={[styles.pointsBadge, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="sparkles" color={colors.tint} size={15} /><Text style={{ color: colors.text, fontWeight: "800" }}>{wallet.data?.balance ?? "—"}</Text></View>}
      />

      <Surface style={styles.hero}>
        <FloatingIcon icon="chatbubbles" size={44} label={t("rooms")} />
        <Text style={[styles.heroTitle, { color: colors.text }]}>{t("roomChat")}</Text>
        <Text style={[ui.body, { color: colors.icon }]}>{t("search")} · {t("room")}</Text>
        <View style={[ui.row, { marginTop: 4 }]}>
          <PrimaryButton title={t("start")} icon="add" onPress={() => setCreateOpen((open) => !open)} />
          <Link href="/(tabs)/users" asChild><Pressable style={StyleSheet.flatten([styles.secondaryButton, { borderColor: colors.border }])}><Ionicons name="people-outline" size={18} color={colors.tint} /><Text style={{ color: colors.text, fontWeight: "700" }}>{t("users")}</Text></Pressable></Link>
        </View>
        {createRoom.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
      </Surface>

      {createOpen ? <Surface style={styles.createCard}>
        <SectionTitle title={t("room")} />
        <TextInput value={roomName} onChangeText={setRoomName} placeholder={t("room")} placeholderTextColor={colors.icon} maxLength={120} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
        <TextInput value={roomDescription} onChangeText={setRoomDescription} placeholder={t("roomManagement")} placeholderTextColor={colors.icon} maxLength={1200} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
        <View style={styles.filters}>
          <Chip label={t("roomPublic")} active={kind === "public"} onPress={() => setKind("public")} />
          <Chip label={t("roomPrivateFilter")} active={kind === "private"} onPress={() => setKind("private")} />
          <Chip label={t("roomCountry")} active={kind === "country"} onPress={() => setKind("country")} />
        </View>
        {kind === "country" ? <TextInput value={roomCountry} onChangeText={setRoomCountry} placeholder={t("countryName")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} /> : null}
        <PrimaryButton title={createRoom.isPending ? t("saving") : t("save")} icon="checkmark" disabled={createRoom.isPending || roomName.trim().length < 2 || (kind === "country" && !roomCountry.trim())} onPress={() => createRoom.mutate({ name: roomName.trim(), kind, description: roomDescription.trim() || undefined, country: kind === "country" ? roomCountry.trim() : undefined })} />
      </Surface> : null}

      <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Ionicons name="search" size={19} color={colors.icon} />
        <TextInput value={search} onChangeText={setSearch} placeholder={`${t("search")} · ${t("rooms")}`} placeholderTextColor={colors.icon} style={[ui.input, { flex: 1, borderWidth: 0, color: colors.text }]} textAlign="right" returnKeyType="search" />
      </View>

      <View style={ui.spread}>
        <SectionTitle title={listKind === "public" ? t("roomTop") : listKind === "private" ? t("myPrivateRooms") : listKind === "country" ? c("countryRooms") : roomFavoriteText(locale, "favorites")} action={t("loading")} onAction={() => rooms.refetch()} />
      </View>
      <View style={styles.filters}>
        <Chip label={roomFavoriteText(locale, "favorites")} active={listKind === "favorites"} onPress={() => setListKind("favorites")} />
        <Chip label={t("roomPublic")} active={listKind === "public"} onPress={() => setListKind("public")} />
        <Chip label={t("roomPrivateFilter")} active={listKind === "private"} onPress={() => setListKind("private")} />
        <Chip label={t("roomCountry")} active={listKind === "country"} onPress={() => setListKind("country")} />
      </View>
      {rooms.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
      {rooms.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text><PrimaryButton title={t("retry")} icon="refresh" quiet onPress={() => rooms.refetch()} /></Surface> : null}
      {!rooms.isLoading && !rooms.error && filteredRooms.length === 0 ? <EmptyState icon="chatbubbles-outline" title={t("noResults")} detail={t("roomChat")} /> : null}
      {filteredRooms.map((room, index) => (
        <Pressable key={room.id} onPress={() => router.push(`/room/${room.id}`)} style={({ pressed }) => [styles.roomCard, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && { opacity: 0.82 }]}>
          <View style={[styles.rank, { backgroundColor: index === 0 ? colors.tint : colors.background }]}><Text style={{ color: index === 0 ? colors.background : colors.icon, fontWeight: "900" }}>{String(index + 1).padStart(2, "0")}</Text></View>
          <View style={{ flex: 1, gap: 4 }}>
            <View style={ui.spread}><Text numberOfLines={1} style={[styles.roomName, { color: colors.text }]}>{room.name}</Text><View style={styles.online}><View style={[styles.dot, { backgroundColor: colors.success }]} /><Text style={{ color: colors.icon, fontSize: 11 }}>{room.memberCount ?? 0}</Text></View></View>
            <Text numberOfLines={2} style={[ui.body, { color: colors.icon }]}>{room.description || t("roomDefaultDescription")}</Text>
            <View style={[ui.row, { justifyContent: "flex-start" }]}><Ionicons name="sparkles-outline" size={13} color={colors.tint} /><Text style={{ color: colors.tint, fontSize: 11, fontWeight: "700" }}>{room.points ?? 0} {tExtra("diamonds")}</Text><Text style={{ color: colors.icon, fontSize: 11 }}>· {room.kind === "public" ? t("roomPublic") : room.kind}</Text></View>
          </View>
          <Pressable accessibilityRole="button" accessibilityLabel={roomFavoriteText(locale, room.isFavorite ? "removeFavorite" : "favorite")} onPress={(event) => { event.stopPropagation(); favoriteRoom.mutate({ roomId: room.id, favorite: !room.isFavorite }); }}><Ionicons name={room.isFavorite ? "heart" : "heart-outline"} color={room.isFavorite ? colors.error : colors.icon} size={20} /></Pressable><Ionicons name="chevron-back" color={colors.icon} size={18} />
        </Pressable>
      ))}
      <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{t("rooms")} · {tExtra("diamonds")}</Text>
    </Page>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: "center", justifyContent: "center" },
  pointsBadge: { flexDirection: "row", alignItems: "center", gap: 6, borderRadius: 999, borderWidth: 1, paddingVertical: 8, paddingHorizontal: 11 },
  hero: { overflow: "hidden", gap: 9, padding: 18 },
  createCard: { gap: 10 },
  heroOrb: { width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  heroTitle: { fontSize: 17, textAlign: "right", fontWeight: "800" },
  secondaryButton: { minHeight: 48, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, paddingHorizontal: 14, borderWidth: 1, borderRadius: 15 },
  filters: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  searchBox: { flexDirection: "row-reverse", alignItems: "center", borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, gap: 8 },
  roomCard: { borderWidth: 1, borderRadius: 20, padding: 13, flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  rank: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  roomName: { flex: 1, fontWeight: "800", fontSize: 15, textAlign: "right" },
  online: { flexDirection: "row", alignItems: "center", gap: 5 },
  dot: { width: 7, height: 7, borderRadius: 4 },
});
