import { Ionicons } from "@expo/vector-icons";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useState } from "react";
import { ActivityIndicator, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { EmptyState, FloatingIcon, LoginGate, Page, PageHeader, PrimaryButton, SectionTitle, Surface, ui } from "@/components/aria-ui";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { diamondBalanceLabel, isWalletSnapshotReady } from "@/lib/diamond-balance";
import { trpc } from "@/lib/trpc";
import { roomFavoriteText } from "@/lib/ui-locale-room-favorites";
import { translateDiamondGift } from "@/lib/ui-locale-gifts";

const giftPresets = [
  { key: "rose", emoji: "🌹", amount: 25 },
  { key: "star", emoji: "⭐", amount: 50 },
  { key: "present", emoji: "🎁", amount: 100 },
  { key: "heart", emoji: "💖", amount: 250 },
] as const;

export default function WalletScreen() {
  const colors = useColors();
  const { t, tExtra, locale } = useLanguage();
  const { isAuthenticated, loading, error: authError, refresh } = useAuth();
  const [recipient, setRecipient] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const wallet = trpc.wallet.me.useQuery(undefined, { enabled: isAuthenticated });
  const refetchWallet = wallet.refetch;
  useFocusEffect(useCallback(() => {
    if (isAuthenticated) void refetchWallet();
  }, [isAuthenticated, refetchWallet]));
  const walletReady = isWalletSnapshotReady(Boolean(wallet.data), wallet.isFetching, Boolean(wallet.error));
  const walletTransactions = walletReady ? wallet.data?.transactions ?? [] : [];
  const transfer = trpc.wallet.transfer.useMutation({ onSuccess: async () => { setRecipient(""); setAmount(""); setNote(""); await wallet.refetch(); } });
  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={t("loginWallet")} authError={authError} onRetry={refresh} />;
  const submit = () => { const toAccountNumber = Number(recipient); const diamonds = Number(amount); if (walletReady && Number.isSafeInteger(toAccountNumber) && toAccountNumber > 0 && Number.isSafeInteger(diamonds) && diamonds > 0) transfer.mutate({ toAccountNumber, amount: diamonds, note: note.trim() || undefined }); };

  return (
    <Page>
      <PageHeader eyebrow={`${t("gameShop")} · ${t("walletTitle")}`} title={t("walletTitle")} subtitle={`${t("balance")} · #${walletReady ? wallet.data?.accountNumber ?? "—" : "—"}`} />
      {wallet.isFetching ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
      {wallet.error ? <Surface style={{ gap: 8 }}><Text style={{ color: colors.error, textAlign: "right" }}>{wallet.error.message}</Text><PrimaryButton title={t("retry")} icon="refresh" quiet disabled={wallet.isFetching} onPress={() => void wallet.refetch()} /></Surface> : null}
      <Surface style={styles.balanceCard}>
        <View style={styles.balanceHeader}><FloatingIcon icon="sparkles" size={38} /><Text style={[ui.meta, { color: colors.icon }]}>{t("balance")}</Text></View>
        <Text style={[styles.balance, { color: colors.text }]}>{walletReady ? diamondBalanceLabel(wallet.data?.balance, wallet.data?.isUnlimited === true) : "—"}</Text>
        <Text style={[ui.meta, { color: colors.icon }]}>{roomFavoriteText(locale, "account")} #{walletReady ? wallet.data?.accountNumber ?? "—" : "—"} · {tExtra("diamonds")}</Text>
      </Surface>
      <Surface style={styles.form}>
        <SectionTitle title={t("transferToUser")} />
        <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{t("transferHelp")}</Text>
        <TextInput value={recipient} onChangeText={setRecipient} placeholder={t("recipientAccount")} placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
        <TextInput value={amount} onChangeText={setAmount} placeholder={`${tExtra("diamonds")} · ${t("transfer")}`} placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
        <TextInput value={note} onChangeText={setNote} placeholder={t("optionalNote")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} maxLength={500} />
        <Surface style={giftStyles.wrapper}>
          <SectionTitle title={translateDiamondGift(locale, "title")} />
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{translateDiamondGift(locale, "hint")}</Text>
          <View style={giftStyles.list}>
            {giftPresets.map((gift) => (
              <Pressable
                key={gift.key}
                accessibilityRole="button"
                accessibilityLabel={`${gift.emoji} ${translateDiamondGift(locale, gift.key)} · ${gift.amount} ${tExtra("diamonds")}`}
                style={[giftStyles.button, { backgroundColor: colors.background, borderColor: colors.border }]}
                onPress={() => {
                  setAmount(String(gift.amount));
                  setNote(`${gift.emoji} ${translateDiamondGift(locale, gift.key)}`);
                }}
              >
                <Text style={giftStyles.icon}>{gift.emoji}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={[giftStyles.label, { color: colors.text }]}>{translateDiamondGift(locale, gift.key)}</Text>
                  <Text style={[ui.meta, { color: colors.icon }]}>{gift.amount} {tExtra("diamonds")}</Text>
                </View>
              </Pressable>
            ))}
          </View>
        </Surface>
        <PrimaryButton title={transfer.isPending ? t("recording") : t("registerTransfer")} icon="arrow-forward" disabled={!walletReady || transfer.isPending || !recipient || !amount} onPress={submit} />
        {transfer.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{transfer.error.message}</Text> : null}
        {transfer.isSuccess ? <Text style={{ color: colors.success, textAlign: "right" }}>{t("transferSuccess")}</Text> : null}
      </Surface>
      <View style={ui.spread}><SectionTitle title={t("transactions")} action={t("refresh")} onAction={() => void wallet.refetch()} /><Text style={[ui.meta, { color: colors.icon }]}>{walletTransactions.length} {t("transactions")}</Text></View>
      {walletReady && walletTransactions.length === 0 ? <EmptyState icon="receipt-outline" title={t("noResults")} detail={t("history")} /> : null}
      {walletTransactions.map((item) => {
        const positive = item.direction === "credit";
        return (
          <View key={item.id} style={[styles.transaction, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={[styles.txIcon, { backgroundColor: colors.background }]}><Ionicons name={positive ? "arrow-down" : "arrow-up"} size={17} color={positive ? colors.success : colors.warning} /></View>
            <View style={{ flex: 1, gap: 3 }}>
              <Text style={[styles.txTitle, { color: colors.text }]}>{item.note || (item.type === "transfer" ? `${t("transfer")} ${tExtra("diamonds")}` : item.type === "admin_adjustment" ? `${t("adjustment")} ${tExtra("diamonds")}` : item.type)}</Text>
              {item.type === "transfer" && item.counterpartyAccountNumber != null ? (
                <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>
                  {(item.direction === "debit" ? roomFavoriteText(locale, "recipient") : roomFavoriteText(locale, "sender"))}: {item.counterpartyName || "—"}{item.counterpartyUsername ? ` (@${item.counterpartyUsername})` : ""} · #{item.counterpartyAccountNumber}
                </Text>
              ) : null}
              {item.type === "admin_adjustment" ? (
                <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>
                  {roomFavoriteText(locale, "adminActor")}: {item.actorName || (item.actorAccountNumber === 1 ? "Administrator" : "—")} · #{item.actorAccountNumber ?? "—"} · {roomFavoriteText(locale, "target")}: {item.accountName || "—"}{item.accountUsername ? ` (@${item.accountUsername})` : ""} · #{item.accountNumber ?? "—"}
                </Text>
              ) : null}
              <Text style={[ui.meta, { color: colors.icon }]}>{new Date(item.createdAt).toLocaleString(locale)}</Text>
            </View>
            <Text style={[styles.amount, { color: positive ? colors.success : colors.warning }]}>{positive ? "+" : "−"}{item.amount}</Text>
          </View>
        );
      })}
      <Pressable accessibilityRole="button" style={[styles.shop, { borderColor: colors.border, backgroundColor: colors.surface }]} onPress={() => router.push("/shop")}><FloatingIcon icon="storefront-outline" size={38} /><View style={{ flex: 1 }}><Text style={[styles.txTitle, { color: colors.text }]}>{t("gameShop")}</Text><Text style={[ui.meta, { color: colors.icon }]}>{t("games")} · {tExtra("diamonds")}</Text></View><Ionicons name="chevron-back" color={colors.icon} size={17} /></Pressable>
    </Page>
  );
}

const styles = StyleSheet.create({ balanceCard: { alignItems: "center", gap: 6, paddingVertical: 21 }, balanceHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 8 }, spark: { width: 38, height: 38, borderRadius: 13, alignItems: "center", justifyContent: "center" }, balance: { fontSize: 39, fontWeight: "900", lineHeight: 46 }, form: { gap: 11 }, transaction: { flexDirection: "row-reverse", alignItems: "center", gap: 10, borderRadius: 17, borderWidth: 1, padding: 12 }, txIcon: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" }, txTitle: { textAlign: "right", fontSize: 14, fontWeight: "800" }, amount: { fontSize: 14, fontWeight: "900" }, shop: { flexDirection: "row-reverse", alignItems: "center", gap: 10, borderRadius: 18, borderWidth: 1, padding: 12 } });


const giftStyles = StyleSheet.create({
  wrapper: { gap: 8, paddingVertical: 10 },
  list: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  button: { minWidth: "46%", flexGrow: 1, flexDirection: "row-reverse", alignItems: "center", gap: 8, paddingVertical: 9, paddingHorizontal: 10, borderRadius: 13, borderWidth: 1 },
  icon: { fontSize: 21 },
  label: { textAlign: "right", fontSize: 13, fontWeight: "800" },
});
