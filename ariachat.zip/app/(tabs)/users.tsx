import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { Chip, EmptyState, LoginGate, Page, PageHeader, Surface, ui } from "@/components/aria-ui";
import { UserIdentity } from "@/components/user-identity";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { formatLastSeen } from "@/lib/last-seen";
import { trpc } from "@/lib/trpc";
import { translateFriendsCalls, type FriendsCallsKey } from "@/lib/ui-locale-friends-calls";

export default function UsersScreen() {
  const colors = useColors();
  const { isRTL, locale, t, tExtra } = useLanguage();
  const { isAuthenticated, loading, error: authError, refresh } = useAuth();
  const [query, setQuery] = useState("");
  const [view, setView] = useState<"search" | "friends">("search");
  const [gender, setGender] = useState<"any" | "male" | "female" | "nonbinary">("any");
  const [ageMin, setAgeMin] = useState("");
  const [ageMax, setAgeMax] = useState("");
  const [city, setCity] = useState("");
  const [country, setCountry] = useState("");
  const [onlineOnly, setOnlineOnly] = useState(false);
  const [hasPhotoOnly, setHasPhotoOnly] = useState(false);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const friendText = (key: FriendsCallsKey) => translateFriendsCalls(locale, key);
  const search = trpc.users.search.useQuery({ query: query.trim() || undefined, gender: gender === "any" ? undefined : gender, ageMin: ageMin && Number.isInteger(Number(ageMin)) ? Number(ageMin) : undefined, ageMax: ageMax && Number.isInteger(Number(ageMax)) ? Number(ageMax) : undefined, city: city.trim() || undefined, country: country.trim() || undefined, onlineOnly, hasPhotoOnly, limit: 30 }, { enabled: isAuthenticated, refetchInterval: 18000 });
  const friends = trpc.friends.list.useQuery(undefined, { enabled: isAuthenticated, refetchInterval: 30000 });
  const toggleFriend = trpc.users.toggleFriend.useMutation({ onSuccess: async () => { await Promise.all([search.refetch(), friends.refetch()]); } });

  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={t("loginUsers")} authError={authError} onRetry={refresh} />;

  return (
    <Page>
      <PageHeader eyebrow="ARIA CHAT" title={t("users")} subtitle={`${t("search")} · ${t("profile")}`} />
      <View style={styles.filters}>
        <Chip label={friendText("searchTab")} active={view === "search"} onPress={() => setView("search")} />
        <Chip label={friendText("friendsTab")} active={view === "friends"} onPress={() => setView("friends")} />
      </View>
      {view === "search" ? <>
      <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <Ionicons name="search" size={18} color={colors.icon} />
        <TextInput value={query} onChangeText={setQuery} placeholder={`${t("search")} · ${t("username")}`} placeholderTextColor={colors.icon} style={[ui.input, { flex: 1, borderWidth: 0, color: colors.text, textAlign: isRTL ? "right" : "left" }]} returnKeyType="search" keyboardType={/^\d+$/.test(query) ? "number-pad" : "default"} />
        {query ? <Pressable onPress={() => setQuery("")}><Ionicons name="close-circle" size={18} color={colors.icon} /></Pressable> : null}
      </View>
      <View style={styles.filters}>
        <Chip label={t("online")} active={onlineOnly} onPress={() => setOnlineOnly((value) => !value)} />
        <Chip label={t("photo")} active={hasPhotoOnly} onPress={() => setHasPhotoOnly((value) => !value)} />
        <Pressable accessibilityRole="button" onPress={() => setAdvancedOpen((value) => !value)} style={[styles.advancedToggle, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name={advancedOpen ? "chevron-up" : "options-outline"} size={15} color={colors.tint} /><Text style={[ui.meta, { color: colors.text, fontWeight: "700" }]}>{advancedOpen ? t("closeFilters") : t("moreFilters")}</Text></Pressable>
      </View>
      {advancedOpen ? <Surface style={{ gap: 9 }}>
        <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{t("gender")}</Text>
        <View style={styles.filters}><Chip label={t("all")} active={gender === "any"} onPress={() => setGender("any")} /><Chip label={t("female")} active={gender === "female"} onPress={() => setGender("female")} /><Chip label={t("male")} active={gender === "male"} onPress={() => setGender("male")} /><Chip label={t("other")} active={gender === "nonbinary"} onPress={() => setGender("nonbinary")} /></View>
        <View style={styles.locationFields}>
          <TextInput value={ageMin} onChangeText={setAgeMin} placeholder={t("ageFrom")} placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, styles.filterInput, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={ageMax} onChangeText={setAgeMax} placeholder={t("ageTo")} placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, styles.filterInput, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={city} onChangeText={setCity} placeholder={t("city")} placeholderTextColor={colors.icon} style={[ui.input, styles.filterInput, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={country} onChangeText={setCountry} placeholder={t("country")} placeholderTextColor={colors.icon} style={[ui.input, styles.filterInput, { color: colors.text, borderColor: colors.border }]} />
        </View>
      </Surface> : null}
      <Surface style={styles.privacyNote}>
        <Ionicons name="shield-checkmark-outline" size={18} color={colors.tint} />
        <Text style={[ui.meta, { flex: 1, color: colors.icon, textAlign: "right" }]}>{t("privateSearchNote")}</Text>
      </Surface>
      <View style={ui.spread}><Text style={[styles.count, { color: colors.text }]}>{t("users")}</Text><Text style={[ui.meta, { color: colors.icon }]}>{search.data?.length ?? 0}</Text></View>
      {search.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
      {search.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text></Surface> : null}
      {!search.isLoading && !search.error && (search.data?.length ?? 0) === 0 ? <EmptyState icon="people-outline" title={t("noResults")} detail={query ? t("checkSpelling") : t("usersEmpty")} /> : null}
      {(search.data ?? []).map((user) => (
        <Pressable key={user.accountNumber ?? user.username ?? user.name ?? "unknown"} onPress={() => user.accountNumber ? router.push(`/user/${user.accountNumber}`) : undefined} style={({ pressed }) => [styles.userCard, { backgroundColor: colors.surface, borderColor: colors.border, flexDirection: isRTL ? "row-reverse" : "row" }, pressed && { opacity: 0.82 }]}>
          {user.avatarUrl ? <Image source={{ uri: user.avatarUrl }} style={styles.avatar} /> : <View style={[styles.avatar, { backgroundColor: colors.background }]}><Ionicons name="person" size={20} color={colors.tint} /></View>}
          <View style={{ flex: 1, gap: 3 }}>
            <View style={ui.spread}><UserIdentity name={user.username || user.name || `#${user.accountNumber ?? "—"}`} avatarEmoji={user.avatarEmoji} badgeTitle={user.badgeTitle} crownStyle={user.crownStyle} role={user.role} style={{ flex: 1 }} nameStyle={[styles.username, { textAlign: isRTL ? "right" : "left" }]} /><View style={styles.online}><View style={[styles.dot, { backgroundColor: user.isOnline ? colors.success : colors.icon }]} /><Text style={[ui.meta, { color: colors.icon }]}>{user.isOnline ? t("online") : t("offline")}</Text></View></View>
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{[`حساب #${user.accountNumber ?? "—"}`, user.age ? `${user.age} ساله` : null, user.gender === "female" ? t("female") : user.gender === "male" ? t("male") : null, user.city, user.country].filter(Boolean).join(" · ")}</Text>
            <Text style={[ui.meta, { color: colors.icon, textAlign: isRTL ? "right" : "left" }]}>{tExtra("lastSeen")}: {formatLastSeen(user.lastSeenAt, user.isOnline, locale, tExtra)}</Text>
            {user.bio ? <Text numberOfLines={1} style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{user.bio}</Text> : null}
          </View>
          {(() => { const isFriend = Boolean(user.accountNumber && friends.data?.some((friend) => friend.accountNumber === user.accountNumber)); return <Pressable accessibilityRole="button" accessibilityLabel={friendText(isFriend ? "removeFriend" : "addFriend")} disabled={toggleFriend.isPending || !user.accountNumber} onPress={(event) => { event.stopPropagation(); if (user.accountNumber) toggleFriend.mutate({ accountNumber: user.accountNumber }); }} style={[styles.addButton, { backgroundColor: colors.background }]}><Ionicons name={isFriend ? "person-remove-outline" : "person-add-outline"} size={17} color={colors.tint} /></Pressable>; })()}
        </Pressable>
      ))}
      </> : <>
        {friends.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {friends.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text></Surface> : null}
        {!friends.isLoading && !friends.error && (friends.data?.length ?? 0) === 0 ? <EmptyState icon="people-outline" title={friendText("emptyFriendsTitle")} detail={friendText("emptyFriendsDetail")} /> : null}
        {(friends.data ?? []).map((friend) => (
          <View key={friend.accountNumber} style={[styles.userCard, { backgroundColor: colors.surface, borderColor: colors.border, flexDirection: isRTL ? "row-reverse" : "row" }]}>
            <Pressable accessibilityRole="button" onPress={() => router.push(`/message/${friend.accountNumber}`)} style={{ flex: 1, flexDirection: isRTL ? "row-reverse" : "row", alignItems: "center", gap: 11 }}>
              {friend.avatarUrl ? <Image source={{ uri: friend.avatarUrl }} style={styles.avatar} /> : <View style={[styles.avatar, { backgroundColor: colors.background }]}><Ionicons name="person" size={20} color={colors.tint} /></View>}
              <View style={{ flex: 1, gap: 3 }}><UserIdentity name={friend.username || friend.name || `#${friend.accountNumber}`} avatarEmoji={friend.avatarEmoji} badgeTitle={friend.badgeTitle} crownStyle={friend.crownStyle} role={friend.role} style={{ flex: 1 }} nameStyle={[styles.username, { textAlign: isRTL ? "right" : "left" }]} /><Text style={[ui.meta, { color: colors.icon, textAlign: isRTL ? "right" : "left" }]}>#{friend.accountNumber} · {friendText("messageFriend")}</Text></View>
            </Pressable>
            <Pressable accessibilityRole="button" accessibilityLabel={friendText("removeFriend")} disabled={toggleFriend.isPending || friend.accountNumber === null} onPress={() => { if (friend.accountNumber !== null) toggleFriend.mutate({ accountNumber: friend.accountNumber }); }} style={[styles.addButton, { backgroundColor: colors.background }]}><Ionicons name="person-remove-outline" size={17} color={colors.error} /></Pressable>
          </View>
        ))}
      </>}
      {toggleFriend.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
    </Page>
  );
}

const styles = StyleSheet.create({
  searchBox: { flexDirection: "row-reverse", alignItems: "center", borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, gap: 8 },
  filters: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 },
  locationFields: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 },
  filterInput: { flexGrow: 1, minWidth: "45%" },
  advancedToggle: { minHeight: 36, flexDirection: "row-reverse", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 99, paddingHorizontal: 11 },
  privacyNote: { flexDirection: "row-reverse", alignItems: "center", gap: 9, padding: 12 },
  count: { fontSize: 15, fontWeight: "800" },
  userCard: { borderRadius: 18, borderWidth: 1, padding: 12, flexDirection: "row-reverse", alignItems: "center", gap: 11 },
  avatar: { width: 46, height: 46, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  username: { fontSize: 14, fontWeight: "800", textAlign: "right", flex: 1 },
  online: { flexDirection: "row", alignItems: "center", gap: 4 },
  dot: { width: 7, height: 7, borderRadius: 4 },
  addButton: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" },
});
