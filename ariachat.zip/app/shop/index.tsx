import { Ionicons } from "@expo/vector-icons";
import { router, useFocusEffect } from "expo-router";
import { useCallback, useState } from "react";
import { DiceDisplay, DiamondMiniGames, Wheel } from "@/components/shop-games";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { Chip, EmptyState, LoginGate, Page, PageHeader, PrimaryButton, Surface, ui } from "@/components/aria-ui";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { useSoundEffects } from "@/hooks/use-sound-effects";
import { canSpendDiamonds, diamondBalanceLabel, isWalletSnapshotReady } from "@/lib/diamond-balance";
import { trpc } from "@/lib/trpc";
import { roomFavoriteText } from "@/lib/ui-locale-room-favorites";
import { createGameRequestId, type DiamondMiniGameResult } from "@/lib/diamond-games";
import { translateShop, type ShopLocaleKey } from "@/lib/ui-locale-shop";
import { translateGameExtra, type GameExtraKey } from "@/lib/ui-locale-game-extra";

const AD_COST = 100;
type ShopSection = "games" | "ads" | "agents" | "perks";
type Hand = "rock" | "paper" | "scissors";
const hands: { key: Hand; labelKey: ShopLocaleKey; icon: keyof typeof Ionicons.glyphMap }[] = [
  { key: "rock", labelKey: "rock", icon: "radio-button-on" },
  { key: "paper", labelKey: "paper", icon: "document-outline" },
  { key: "scissors", labelKey: "scissors", icon: "cut-outline" },
];

export default function ShopScreen() {
  const colors = useColors();
  const { locale, t, tExtra } = useLanguage();
  const lotteryText = (key: string) => tExtra(key as Parameters<typeof tExtra>[0]);
  const shopText = (key: ShopLocaleKey, values?: Record<string, string | number>) => translateShop(locale, key, values);
  const gameText = (key: GameExtraKey) => translateGameExtra(locale, key);
  const { isAuthenticated, loading } = useAuth();
  const { playGameWin, playGameLoss } = useSoundEffects();
  const [section, setSection] = useState<ShopSection>("games");
  const [bet, setBet] = useState("10");
  const [choice, setChoice] = useState<Hand>("rock");
  const [diceChoice, setDiceChoice] = useState<"odd" | "even">("even");
  const [wheelSector, setWheelSector] = useState<number | null>(null);
  const [wheelResultKey, setWheelResultKey] = useState(0);
  const [wheelAnimating, setWheelAnimating] = useState(false);
  const [diceResultKey, setDiceResultKey] = useState(0);
  const [diceAnimating, setDiceAnimating] = useState(false);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [targetUrl, setTargetUrl] = useState("");
  const [feedback, setFeedback] = useState("");
  const [lotteryAmount, setLotteryAmount] = useState("1");
  const wallet = trpc.wallet.me.useQuery(undefined, { enabled: isAuthenticated });
  const refetchWallet = wallet.refetch;
  useFocusEffect(useCallback(() => {
    if (isAuthenticated) void refetchWallet();
  }, [isAuthenticated, refetchWallet]));
  const walletReady = isWalletSnapshotReady(Boolean(wallet.data), wallet.isFetching, Boolean(wallet.error));
  const walletBalance = wallet.data?.balance ?? 0;
  const isUnlimited = wallet.data?.isUnlimited === true;
  const showBalance = (value: number | null | undefined = wallet.data?.balance) => walletReady ? diamondBalanceLabel(value, isUnlimited) : "—";
  const canSpend = (value: number) => walletReady && canSpendDiamonds(value, walletBalance, isUnlimited);
  const history = trpc.games.history.useQuery({ limit: 10 }, { enabled: isAuthenticated && section === "games" });
  const spin = trpc.games.spin.useMutation({ onSuccess: async (result) => { setWheelSector(result.sector); setWheelResultKey((current) => current + 1); const outcome = result.outcome === "win" ? t("win") : t("loss"); if (result.outcome === "win") playGameWin(); else playGameLoss(); setFeedback(`${t("games")}: ${outcome} · ${result.bet} ${tExtra("diamonds")} · ${t("balance")} ${showBalance(result.balance)} ${tExtra("diamonds")}`); await Promise.all([wallet.refetch(), history.refetch()]); } });
  const dice = trpc.games.dice.useMutation({ onSuccess: async (result) => { setDiceResultKey((current) => current + 1); if (result.outcome === "win") playGameWin(); else playGameLoss(); setFeedback(`${shopText("diceTitle")}: ${gameText("yourChoice")} ${gameText(result.choice)} · ${gameText("rolled")} ${result.face} · ${result.outcome === "win" ? shopText("win") : shopText("loss")} · ${result.payout} ${tExtra("diamonds")}`); await Promise.all([wallet.refetch(), history.refetch()]); } });
  const rps = trpc.games.rockPaperScissors.useMutation({ onSuccess: async (result) => { const outcome = result.outcome === "win" ? t("win") : result.outcome === "tie" ? t("draw") : t("loss"); if (result.outcome === "win") playGameWin(); else if (result.outcome === "loss") playGameLoss(); setFeedback(`${t("games")}: ${outcome} · ${result.bet} ${tExtra("diamonds")} · ${t("balance")} ${showBalance(result.balance)} ${tExtra("diamonds")}`); await Promise.all([wallet.refetch(), history.refetch()]); } });
  const ads = trpc.ads.activeList.useQuery({ limit: 30 }, { enabled: isAuthenticated });
  const agents = trpc.sales.listAgents.useQuery(undefined, { enabled: isAuthenticated });
  const catalog = trpc.shop.catalog.useQuery(undefined, { enabled: isAuthenticated && section === "perks" });
  const profile = trpc.profile.me.useQuery(undefined, { enabled: isAuthenticated && section === "perks" });
  const lottery = trpc.lottery.current.useQuery(undefined, { enabled: isAuthenticated, refetchInterval: 30_000 });
  const lotteryHistory = trpc.lottery.history.useQuery({ limit: 8 }, { enabled: isAuthenticated });
  const enterLottery = trpc.lottery.enter.useMutation({ onSuccess: async (result) => { setFeedback(`${lotteryText("lotteryEnterSuccess")} · ${result.amount} ${tExtra("diamonds")}`); setLotteryAmount("1"); await Promise.all([lottery.refetch(), wallet.refetch()]); } });
  const createAd = trpc.ads.create.useMutation({ onSuccess: async (result) => { setFeedback(`${shopText("adsCreated")} · ${result.pointsCharged} ${tExtra("diamonds")}`); setTitle(""); setBody(""); setTargetUrl(""); await ads.refetch(); await wallet.refetch(); } });
  const buyProduct = trpc.shop.purchase.useMutation({ onSuccess: async (result) => { const ending = result.invisibleUntil ? ` · ${new Date(result.invisibleUntil).toLocaleTimeString(locale)}` : ""; setFeedback(`${result.title} · ${result.pointsCharged} ${tExtra("diamonds")} · ${t("balance")} ${showBalance(result.balance)}${ending}`); await Promise.all([wallet.refetch(), catalog.refetch(), profile.refetch()]); } });
  if (loading) return <Page scroll={false}><ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={shopText("login")} />;
  const wager = Number(bet);
  const hasValidWager = walletReady && canSpendDiamonds(wager, walletBalance, isUnlimited, Math.floor(Number.MAX_SAFE_INTEGER / 10));
  const runSpin = () => { if (hasValidWager && !spin.isPending && !wheelAnimating) { setWheelSector(null); setFeedback(""); spin.reset(); spin.mutate({ bet: wager, requestId: createGameRequestId() }); } };
  const runRps = () => { if (hasValidWager && !rps.isPending) { setFeedback(""); rps.reset(); rps.mutate({ bet: wager, choice, requestId: createGameRequestId() }); } };
  const runDice = () => { if (hasValidWager && !dice.isPending && !diceAnimating) { setFeedback(""); dice.reset(); dice.mutate({ bet: wager, choice: diceChoice, requestId: createGameRequestId() }); } };

  const miniText = (key: string) => {
    if (key === "balance") return t("balance");
    if (key === "win" || key === "loss" || key === "payout") return shopText(key);
    return gameText(key as GameExtraKey);
  };
  const onMiniResult = async (result: DiamondMiniGameResult) => {
    const labels: Record<DiamondMiniGameResult["gameType"], GameExtraKey> = {
      tic_tac_toe: "ticTacToe", memory_match: "memoryMatch", guess_number: "guessNumber", treasure_hunt: "treasureHunt",
    };
    if (result.outcome === "win") playGameWin(); else playGameLoss();
    setFeedback(`${gameText(labels[result.gameType])}: ${result.outcome === "win" ? t("win") : t("loss")} · ${result.payout} ${tExtra("diamonds")} · ${t("balance")} ${showBalance(result.balance)} ${tExtra("diamonds")}`);
    await Promise.all([wallet.refetch(), history.refetch()]);
  };
  const gameHistoryLabel = (gameType: string) => {
    if (gameType === "spin") return shopText("spinGame");
    if (gameType === "rock_paper_scissors") return shopText("rpsGame");
    if (gameType === "dice_odd_even") return shopText("diceTitle");
    if (gameType === "tic_tac_toe") return gameText("ticTacToe");
    if (gameType === "memory_match") return gameText("memoryMatch");
    if (gameType === "guess_number") return gameText("guessNumber");
    if (gameType === "treasure_hunt") return gameText("treasureHunt");
    return shopText("spinGame");
  };

  return (
    <Page>
      <PageHeader eyebrow="ARShop" title={t("gameShop")} subtitle={`${t("balance")} ${showBalance()} ${tExtra("diamonds")} · ${roomFavoriteText(locale, "account")} #${walletReady ? wallet.data?.accountNumber ?? "—" : "—"}`} />
      {wallet.isFetching ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
      {wallet.error ? <Surface style={{ gap: 8 }}><Text style={{ color: colors.error, textAlign: "right" }}>{wallet.error.message}</Text><PrimaryButton title={t("retry")} icon="refresh" quiet disabled={wallet.isFetching} onPress={() => void wallet.refetch()} /></Surface> : null}
      {feedback ? <Text accessibilityLiveRegion="polite" style={{ color: colors.tint, textAlign: "center", fontWeight: "800" }}>{feedback}</Text> : null}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.navigation}>
        <ShopTab label={t("games")} active={section === "games"} icon="game-controller-outline" onPress={() => setSection("games")} />
        <ShopTab label={shopText("adsTab")} active={section === "ads"} icon="megaphone-outline" onPress={() => setSection("ads")} />
        <ShopTab label={t("agents")} active={section === "agents"} icon="storefront-outline" onPress={() => setSection("agents")} />
        <ShopTab label={shopText("appearanceTab")} active={section === "perks"} icon="color-palette-outline" onPress={() => setSection("perks")} />
      </ScrollView>
      {section === "games" ? <>
        <Surface style={styles.gameCard}>
          <View style={[styles.gameIcon, { backgroundColor: colors.background }]}><Ionicons name="ticket-outline" color={colors.tint} size={24} /></View>
          <Text style={[styles.gameTitle, { color: colors.text }]}>{lotteryText("lotteryTitle")}</Text>
          {lottery.isLoading ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
          {lottery.data ? <>
            <Text style={[ui.body, { color: colors.icon, textAlign: "right" }]}>{lotteryText("lotteryRoundEnds")}: {new Date(lottery.data.round.endAt).toLocaleString(locale)} · {lotteryText("lotteryDrawAfter")} {Math.floor(lottery.data.round.countdownMs / 3_600_000)}:{String(Math.floor(lottery.data.round.countdownMs / 60_000) % 60).padStart(2, "0")}:{String(Math.floor(lottery.data.round.countdownMs / 1000) % 60).padStart(2, "0")}</Text>
            <Text style={[ui.body, { color: colors.text, textAlign: "right" }]}>{lotteryText("lotteryPool")}: {lottery.data.round.grossPool} {tExtra("diamonds")} · {lotteryText("lotteryFee")}: 10% · {lotteryText("lotteryPrize")}: {lottery.data.round.grossPool - Math.floor(lottery.data.round.grossPool / 10)}</Text>
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{lotteryText("lotteryContribution")}: {lottery.data.myContribution} {tExtra("diamonds")} · {lotteryText("lotteryOdds")}: {lottery.data.round.grossPool ? `${((lottery.data.myContribution / lottery.data.round.grossPool) * 100).toFixed(2)}%` : "0%"}</Text>
            <TextInput value={lotteryAmount} onChangeText={setLotteryAmount} keyboardType="number-pad" placeholder={lotteryText("lotteryAmount")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
            <PrimaryButton title={enterLottery.isPending ? "…" : lotteryText("lotteryParticipate")} icon="ticket" disabled={enterLottery.isPending || !canSpend(Number(lotteryAmount))} onPress={() => enterLottery.mutate({ amount: Number(lotteryAmount) })} />
            {enterLottery.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{enterLottery.error.message}</Text> : null}
          </> : null}
          {lottery.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{lottery.error.message}</Text> : null}
          <Text style={[styles.gameTitle, { color: colors.text }]}>{lotteryText("lotteryHistory")}</Text>
          {lotteryHistory.isLoading ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
          {(lotteryHistory.data ?? []).length === 0 && !lotteryHistory.isLoading ? <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{lotteryText("lotteryEmpty")}</Text> : null}
          {(lotteryHistory.data ?? []).map((item) => <Text key={item.id} style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{new Date(item.startAt).toLocaleDateString(locale)} · {item.winner?.name ?? lotteryText("lotteryEmpty")} · {lotteryText("lotteryWinner")}: {item.prize} {tExtra("diamonds")}</Text>)}
          {lotteryHistory.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{lotteryHistory.error.message}</Text> : null}
        </Surface>
        <Surface style={styles.gameCard}>
          <View style={[styles.gameIcon, { backgroundColor: colors.background }]}><Ionicons name="sync-circle-outline" color={colors.tint} size={24} /></View>
          <Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("spinTitle")}</Text>
          <Text style={[ui.body, { color: colors.icon }]}>{shopText("spinDescription")}</Text>
          <Wheel result={wheelSector} resultKey={wheelResultKey} spinning={spin.isPending} onAnimationStateChange={setWheelAnimating} label={shopText("wheelResult")} textColor={colors.text} successColor={colors.success} />
          <TextInput value={bet} onChangeText={setBet} keyboardType="number-pad" placeholder={shopText("wagerPlaceholder")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={spin.isPending || wheelAnimating ? shopText("spinning") : shopText("spinAction")} icon="sync" disabled={spin.isPending || wheelAnimating || !hasValidWager} onPress={runSpin} />
        </Surface>
        <Surface style={styles.gameCard}>
          <View style={[styles.gameIcon, { backgroundColor: colors.background }]}><Ionicons name="hand-left-outline" color={colors.tint} size={24} /></View>
          <Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("rpsTitle")}</Text>
          <Text style={[ui.body, { color: colors.icon }]}>{shopText("rpsDescription")}</Text>
          {rps.data && !rps.isPending ? <View style={{ gap: 5, alignItems: "center", padding: 11, borderRadius: 14, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border }}>
            <Text style={[ui.body, { color: colors.text, textAlign: "center", fontWeight: "800" }]}>{gameText("yourChoice")}: {rps.data.choice === "rock" ? "✊" : rps.data.choice === "paper" ? "✋" : "✌️"} {shopText(rps.data.choice as ShopLocaleKey)}</Text>
            <Text style={[ui.body, { color: colors.text, textAlign: "center", fontWeight: "800" }]}>{shopText("opponent")}: {rps.data.opponentChoice === "rock" ? "✊" : rps.data.opponentChoice === "paper" ? "✋" : "✌️"} {shopText(rps.data.opponentChoice as ShopLocaleKey)}</Text>
            <Text style={[ui.body, { color: rps.data.outcome === "win" ? colors.success : rps.data.outcome === "loss" ? colors.error : colors.tint, textAlign: "center", fontWeight: "900" }]}>{rps.data.outcome === "win" ? shopText("win") : rps.data.outcome === "tie" ? shopText("draw") : shopText("loss")}</Text>
          </View> : null}
          <View style={styles.handRow}>{hands.map((hand) => <Chip key={hand.key} label={shopText(hand.labelKey)} active={choice === hand.key} onPress={() => setChoice(hand.key)} />)}</View>
          <TextInput value={bet} onChangeText={setBet} keyboardType="number-pad" placeholder={shopText("wagerPlaceholder")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={rps.isPending ? shopText("playing") : shopText("playAction")} icon="play" disabled={rps.isPending || !hasValidWager} onPress={runRps} />
        </Surface>
        <Surface style={styles.gameCard}>
          <Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("diceTitle")}</Text>
          <Text style={[ui.body, { color: colors.icon, textAlign: "center" }]}>{gameText("chooseParity")}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{shopText("diceRules")}</Text>
          <View style={styles.handRow}><Chip label={gameText("even")} active={diceChoice === "even"} onPress={() => setDiceChoice("even")} /><Chip label={gameText("odd")} active={diceChoice === "odd"} onPress={() => setDiceChoice("odd")} /></View>
          <DiceDisplay face={dice.data?.face ?? null} resultKey={diceResultKey} rolling={dice.isPending} onAnimationStateChange={setDiceAnimating} textColor={colors.text} pipColor={colors.tint} surfaceColor={colors.surface} borderColor={colors.border} />
          {dice.data && !dice.isPending ? <View style={{ gap: 4, alignItems: "center", padding: 10, borderRadius: 14, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border }}>
            <Text style={[ui.body, { color: colors.text, textAlign: "center", fontWeight: "800" }]}>{gameText("yourChoice")}: {gameText(dice.data.choice)} · {gameText("rolled")}: {dice.data.face} ({gameText(dice.data.parity)})</Text>
            <Text style={[ui.body, { color: dice.data.outcome === "win" ? colors.success : colors.error, textAlign: "center", fontWeight: "900" }]}>{dice.data.outcome === "win" ? shopText("youWin") : shopText("youLose")} · {shopText("payout")}: {dice.data.payout} {tExtra("diamonds")}</Text>
          </View> : null}
          <TextInput value={bet} onChangeText={setBet} keyboardType="number-pad" placeholder={shopText("wagerPlaceholder")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={dice.isPending || diceAnimating ? shopText("playing") : shopText("playAction")} disabled={dice.isPending || diceAnimating || !hasValidWager} onPress={runDice} />
        </Surface>
        <DiamondMiniGames
          t={miniText}
          amount={bet}
          onAmountChange={setBet}
          balance={walletReady ? walletBalance : null}
          walletReady={walletReady}
          isUnlimited={isUnlimited}
          diamondLabel={tExtra("diamonds")}
          textColor={colors.text}
          mutedColor={colors.icon}
          accentColor={colors.tint}
          successColor={colors.success}
          errorColor={colors.error}
          surfaceColor={colors.surface}
          backgroundColor={colors.background}
          borderColor={colors.border}
          onResult={onMiniResult}
        />
        <Surface style={{ gap: 9 }}>
          <Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("paymentRules")}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{shopText("spinRules")} {shopText("rpsRules")}</Text>
          {history.isLoading ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
          {(history.data ?? []).length === 0 && !history.isLoading ? <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{shopText("noGames")}</Text> : null}
          {(history.data ?? []).map((item) => <View key={item.id} style={{ flexDirection: "row-reverse", justifyContent: "space-between", gap: 8, borderTopWidth: 1, borderColor: colors.border, paddingTop: 8 }}>
            <View style={{ flex: 1, gap: 3 }}>
              <Text style={{ color: colors.text, textAlign: "right", fontWeight: "800" }}>{gameHistoryLabel(item.gameType)} · {item.outcome === "win" ? shopText("win") : item.outcome === "tie" ? shopText("draw") : shopText("loss")}</Text>
              <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{new Date(item.playedAt).toLocaleString(locale)} · {shopText("wager")} {item.bet} {tExtra("diamonds")} · {shopText("payout")} {item.payout} {tExtra("diamonds")}</Text>
            </View>
            <Text style={{ color: item.netChange >= 0 ? colors.success : colors.error, fontWeight: "900", alignSelf: "center" }}>{item.netChange >= 0 ? "+" : ""}{item.netChange}</Text>
          </View>)}
          {history.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{history.error.message}</Text> : null}
        </Surface>
        {(spin.error || rps.error || dice.error) ? <Text style={{ color: colors.error, textAlign: "right" }}>{spin.error?.message || rps.error?.message || dice.error?.message}</Text> : null}
      </> : null}
      {section === "ads" ? <>
        <Surface style={styles.adCard}>
          <Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("adTitle")}</Text>
          <Text style={[ui.body, { color: colors.icon }]}>{shopText("adCost", { cost: AD_COST })}</Text>
          <TextInput value={title} onChangeText={setTitle} placeholder={shopText("adTitlePlaceholder")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} maxLength={160} />
          <TextInput value={body} onChangeText={setBody} placeholder={shopText("adBodyPlaceholder")} placeholderTextColor={colors.icon} style={[ui.input, { minHeight: 85, color: colors.text, borderColor: colors.border, textAlignVertical: "top" }]} multiline maxLength={2000} />
          <TextInput value={targetUrl} onChangeText={setTargetUrl} placeholder={shopText("adUrlPlaceholder")} placeholderTextColor={colors.icon} keyboardType="url" autoCapitalize="none" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={createAd.isPending ? shopText("submitting") : shopText("submitReview")} icon="megaphone" disabled={!walletReady || createAd.isPending || title.trim().length < 3} onPress={() => { if (walletReady) createAd.mutate({ title: title.trim(), body: body.trim() || undefined, targetUrl: targetUrl.trim() || undefined }); }} />
          {createAd.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{createAd.error.message}</Text> : null}
        </Surface>
        <Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("activeAds")}</Text>
        {ads.isLoading ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
        {ads.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{ads.error.message}</Text> : null}
        {(ads.data ?? []).length === 0 && !ads.isLoading ? <EmptyState icon="megaphone-outline" title={shopText("noActiveAds")} detail={shopText("adsApprovedHint")} /> : null}
        {(ads.data ?? []).map((ad) => <Surface key={ad.id} style={styles.adLine}><Ionicons name="sparkles-outline" color={colors.tint} size={19} /><View style={{ flex: 1, gap: 3 }}><Text style={[styles.gameTitle, { color: colors.text }]}>{ad.title}</Text>{ad.body ? <Text style={[ui.meta, { color: colors.icon }]}>{ad.body}</Text> : null}</View></Surface>)}
      </> : null}
      {section === "agents" ? <>
        <Surface><Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("salesTitle")}</Text><Text style={[ui.body, { color: colors.icon }]}>{shopText("salesDescription")}</Text></Surface>
        {agents.isLoading ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
        {agents.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{agents.error.message}</Text> : null}
        {(agents.data ?? []).length === 0 && !agents.isLoading ? <EmptyState icon="storefront-outline" title={shopText("noSalesAgents")} detail={shopText("salesAgentHint")} /> : null}
        {(agents.data ?? []).map((agent) => <Pressable key={agent.id} accessibilityRole="button" accessibilityLabel={`${agent.username || shopText("agentFallback", { id: agent.id })} · ${agent.accountNumber ? t("contactAgent") : shopText("messagingUnavailable")}`} disabled={!agent.accountNumber} onPress={() => { if (agent.accountNumber) router.push(`/message/${agent.accountNumber}`); }} style={({ pressed }) => [styles.agent, { backgroundColor: colors.surface, borderColor: colors.border, opacity: pressed ? 0.75 : agent.accountNumber ? 1 : 0.6 }]}><View style={[styles.gameIcon, { backgroundColor: colors.background }]}><Ionicons name="person-outline" color={colors.tint} size={19} /></View><View style={{ flex: 1, gap: 3 }}><Text style={[styles.gameTitle, { color: colors.text }]}>{agent.username || shopText("agentFallback", { id: agent.id })}</Text><Text style={[ui.meta, { color: colors.icon }]}>{shopText("agentCode", { code: agent.code })} · {shopText("agentDiscount", { discount: Number(agent.discountBps) / 100 })}</Text><Text style={[ui.meta, { color: colors.tint }]}>{agent.accountNumber ? t("contactAgent") : shopText("messagingUnavailable")}</Text></View><Ionicons name="chatbubble-ellipses-outline" color={colors.tint} size={18} /></Pressable>)}
      </> : null}
      {section === "perks" ? <>
      </> : null}
      {section === "perks" ? <>
        <Surface style={{ gap: 8 }}><Text style={[styles.gameTitle, { color: colors.text }]}>{shopText("appearanceTitle")}</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{shopText("appearanceDescription")}</Text>{catalog.data?.invisibleActive && catalog.data.invisibleUntil ? <Text style={{ color: colors.success, textAlign: "right", fontWeight: "800" }}>{shopText("invisibleUntil", { time: new Date(catalog.data.invisibleUntil).toLocaleString(locale) })}</Text> : null}</Surface>
        {catalog.isLoading ? <ActivityIndicator accessibilityLabel={t("loading")} color={colors.tint} /> : null}
        {catalog.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{catalog.error.message}</Text> : null}
        {(catalog.data?.products ?? []).map((product) => {
          const isColor = "bubbleColor" in product;
          const bubbleColor = "bubbleColor" in product ? product.bubbleColor : colors.surface;
          const textColor = "textColor" in product ? product.textColor : colors.text;
          const currentColor = Boolean(isColor && product.isCurrent);
          const activeInvisibility = Boolean(!isColor && product.isCurrent);
          const accountUnlimited = isUnlimited || catalog.data?.isUnlimited === true;
          const insufficient = !walletReady || (!accountUnlimited && (wallet.data?.balance ?? 0) < product.price);
          return <Surface key={product.id} style={styles.perkCard}>
            {isColor ? <View style={[styles.colorPreview, { backgroundColor: bubbleColor }]}><Text style={{ color: textColor, fontWeight: "900" }}>Aa</Text></View> : <View style={[styles.gameIcon, { backgroundColor: colors.background }]}><Ionicons name="eye-off-outline" color={colors.tint} size={23} /></View>}
            <View style={{ flex: 1, gap: 4 }}><Text style={[styles.gameTitle, { color: colors.text }]}>{product.title}</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{isColor ? shopText("bubbleColor") : activeInvisibility ? shopText("extendInvisibility") : shopText("invisibilityDuration")} · {product.price} {tExtra("diamonds")}</Text>{currentColor ? <Text style={{ color: colors.success, textAlign: "right" }}>{shopText("paletteActive")}</Text> : null}</View>
            <PrimaryButton title={buyProduct.isPending ? shopText("buying") : currentColor ? shopText("active") : activeInvisibility ? shopText("extend") : shopText("buy")} icon={currentColor ? "checkmark" : "sparkles"} quiet disabled={buyProduct.isPending || currentColor || insufficient} onPress={() => buyProduct.mutate({ productId: product.id as "message_sapphire" | "message_gold" | "message_rose" | "invisibility_60m" })} />
          </Surface>;
        })}
        {buyProduct.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{buyProduct.error.message}</Text> : null}
      </> : null}
      {feedback ? <Surface style={styles.feedback}><Ionicons name="checkmark-circle-outline" color={colors.success} size={19} /><Text style={[ui.body, { flex: 1, color: colors.success }]}>{feedback}</Text></Surface> : null}
      <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{shopText("balanceUnitNotice")}</Text>
    </Page>
  );
}

function ShopTab({ label, icon, active, onPress }: { label: string; icon: keyof typeof Ionicons.glyphMap; active: boolean; onPress: () => void }) {
  const colors = useColors();
  return <Pressable onPress={onPress} accessibilityRole="tab" accessibilityLabel={label} accessibilityState={{ selected: active }} style={[styles.tab, { backgroundColor: active ? colors.tint : colors.surface, borderColor: active ? colors.tint : colors.border }]}><Ionicons name={icon} color={active ? colors.background : colors.icon} size={16} /><Text style={{ color: active ? colors.background : colors.text, fontSize: 12, fontWeight: "800" }}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({ navigation: { flexDirection: "row-reverse", gap: 8, paddingVertical: 2 }, tab: { flexDirection: "row-reverse", alignItems: "center", gap: 6, borderWidth: 1, borderRadius: 999, paddingVertical: 9, paddingHorizontal: 13 }, gameCard: { gap: 10 }, gameIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, gameTitle: { textAlign: "right", fontSize: 15, fontWeight: "800" }, handRow: { flexDirection: "row-reverse", justifyContent: "flex-start", gap: 7 }, adCard: { gap: 11 }, adLine: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, agent: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, feedback: { flexDirection: "row-reverse", alignItems: "center", gap: 8 }, perkCard: { flexDirection: "row-reverse", alignItems: "center", gap: 10 }, colorPreview: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" } });
