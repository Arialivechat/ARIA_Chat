import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ActivityIndicator, PermissionsAndroid, Platform, Pressable, StyleSheet, Text, View } from "react-native";
import { requestRecordingPermissionsAsync } from "expo-audio";
import { Page, PageHeader, PrimaryButton, Surface, ui } from "@/components/aria-ui";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { trpc } from "@/lib/trpc";
import { translateCoreScreen } from "@/lib/ui-locale-core-screens";
import { callAudioText, type CallAudioKey } from "@/lib/ui-locale-call-audio";

let liveKitGlobalsRegistered = false;

function requiresBluetoothConnectPermission() {
  return Platform.OS === "android" && Number(Platform.Version) >= 31;
}

export default function CallScreen() {
  const colors = useColors();
  const { locale } = useLanguage();
  const c = (key: import("@/lib/ui-locale-core-screens").CoreScreenLocaleKey) => translateCoreScreen(locale, key);
  const a = useCallback((key: CallAudioKey) => callAudioText(locale, key), [locale]);
  const router = useRouter();
  const { callId } = useLocalSearchParams<{ callId: string }>();
  const [token, setToken] = useState<string>();
  const [url, setUrl] = useState("");
  const [nativeRoom, setNativeRoom] = useState<any>();
  const [muted, setMuted] = useState(false);
  const [error, setError] = useState("");
  const [liveConnected, setLiveConnected] = useState(false);
  const [bluetoothAllowed, setBluetoothAllowed] = useState(!requiresBluetoothConnectPermission());
  const initializedCallRef = useRef<string | null>(null);
  const stopAudioSessionRef = useRef<(() => Promise<void>) | null>(null);
  const status = trpc.calls.status.useQuery({ callId }, { refetchInterval: 2_000, enabled: Boolean(callId) });
  const mint = trpc.calls.token.useMutation();
  const mintCallToken = mint.mutateAsync;
  const end = trpc.calls.end.useMutation();

  useEffect(() => {
    if (status.data?.status !== "accepted" || !callId || token || error || Platform.OS === "web") return;
    if (initializedCallRef.current === callId) return;
    initializedCallRef.current = callId;
    let alive = true;
    let sessionStarted = false;
    (async () => {
      try {
        const microphonePermission = await requestRecordingPermissionsAsync();
        if (!microphonePermission.granted) throw new Error(a("permissionDenied"));

        // Bluetooth routing is optional: a denied permission must not block the call.
        let canUseBluetooth = !requiresBluetoothConnectPermission();
        if (requiresBluetoothConnectPermission()) {
          try {
            const permission = PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT;
            const result = await PermissionsAndroid.request(permission);
            canUseBluetooth = result === PermissionsAndroid.RESULTS.GRANTED;
          } catch {
            canUseBluetooth = false;
          }
        }
        if (alive) setBluetoothAllowed(canUseBluetooth);

        const livekit = await import("@livekit/react-native");
        // The SDK wrapper installs WebRTC globals, LiveKit client shims and URL polyfills.
        // Calling registerGlobals from react-native-webrtc alone skips those setup steps.
        if (!liveKitGlobalsRegistered) {
          livekit.registerGlobals();
          liveKitGlobalsRegistered = true;
        }

        await livekit.AudioSession.configureAudio({
          android: {
            preferredOutputList: canUseBluetooth
              ? ["bluetooth", "headset", "speaker", "earpiece"]
              : ["headset", "speaker", "earpiece"],
            audioTypeOptions: livekit.AndroidAudioTypePresets.communication,
          },
          ios: { defaultOutput: "speaker" },
        });
        await livekit.AudioSession.startAudioSession();
        sessionStarted = true;
        const stopSession = () => livekit.AudioSession.stopAudioSession();
        stopAudioSessionRef.current = stopSession;

        if (!alive) {
          await stopSession();
          stopAudioSessionRef.current = null;
          return;
        }

        const result = await mintCallToken({ callId });
        if (!alive) {
          await stopSession();
          stopAudioSessionRef.current = null;
          return;
        }
        setUrl(result.url);
        setToken(result.token);
        setNativeRoom(() => livekit.LiveKitRoom);
      } catch (e) {
        if (sessionStarted && stopAudioSessionRef.current) {
          const stopSession = stopAudioSessionRef.current;
          stopAudioSessionRef.current = null;
          try { await stopSession(); } catch (stopError) { console.error("Failed to stop LiveKit audio after setup error", stopError); }
        }
        if (alive) setError(e instanceof Error ? e.message : a("audioInitFailed"));
      }
    })();
    return () => { alive = false; };
  }, [status.data?.status, token, error, callId, a, mintCallToken]);

  useEffect(() => () => {
    const stopSession = stopAudioSessionRef.current;
    stopAudioSessionRef.current = null;
    if (stopSession) void stopSession().catch((e) => console.error("Failed to stop LiveKit audio session", e));
  }, []);

  const finish = async () => {
    try { await end.mutateAsync({ callId }); } finally { router.back(); }
  };
  if (Platform.OS === "web") return <Page><PageHeader eyebrow={c("callTitle")} title={c("webCallTitle")} /><Surface><Text style={[ui.body, { color: colors.text, textAlign: "right" }]}>{c("webCallHelp")}</Text></Surface><PrimaryButton title={c("back")} icon="arrow-back" onPress={() => router.back()} /></Page>;
  const state = status.data?.status;
  const title = state === "pending" ? c("callPending") : state === "accepted" ? (liveConnected ? a("connected") : a("connecting")) : state === "declined" ? c("callDeclined") : c("callEnded");
  return <Page><PageHeader eyebrow={c("callTitle")} title={title} />
    <Surface style={styles.card}>
      <View style={[styles.icon, { backgroundColor: colors.surface }]}><Ionicons name="call" size={32} color={colors.tint} /></View>
      <Text style={[ui.body, { color: colors.text, textAlign: "center" }]}>{c("audioOnly")}</Text>
      {status.isLoading || mint.isPending ? <ActivityIndicator color={colors.tint} /> : null}
      {error || status.error?.message ? <Text style={{ color: colors.error, textAlign: "center" }}>{error || status.error?.message}</Text> : null}
      {state === "accepted" ? <Text style={[ui.meta, { color: liveConnected ? colors.tint : colors.icon, textAlign: "center" }]}>{liveConnected ? a("connected") : nativeRoom ? a("connecting") : a("disconnected")}</Text> : null}
      {state === "accepted" && nativeRoom && token ? <CallRoom Room={nativeRoom} url={url} token={token} muted={muted} onMuted={setMuted} localeText={a} onConnected={setLiveConnected} onError={setError} bluetoothAllowed={bluetoothAllowed} /> : null}
      {state === "accepted" ? <View style={styles.actions}><PrimaryButton title={muted ? c("micOn") : c("mute")} icon={muted ? "mic" : "mic-off"} quiet onPress={() => setMuted((v) => !v)} /><PrimaryButton title={c("endCall")} icon="call" onPress={finish} /></View> : null}
      {state && state !== "accepted" && state !== "pending" ? <PrimaryButton title={c("back")} icon="arrow-back" onPress={() => router.back()} /> : null}
      {state === "pending" ? <PrimaryButton title={c("cancelCall")} icon="close" quiet onPress={finish} /> : null}
    </Surface></Page>;
}

function CallRoom({ Room, url, token, muted, onMuted, localeText, onConnected, onError, bluetoothAllowed }: any) {
  const [connected, setConnected] = useState(false);
  const [outputs, setOutputs] = useState<string[]>([]);
  const [selected, setSelected] = useState("");
  const [remoteAudio, setRemoteAudio] = useState(0);
  const [micPublished, setMicPublished] = useState(false);
  const [routeError, setRouteError] = useState("");
  const visibleOutputs = requiresBluetoothConnectPermission() && !bluetoothAllowed ? ["headset", "speaker", "earpiece"] : outputs;
  useEffect(() => { onConnected(connected); }, [connected, onConnected]);
  useEffect(() => {
    if (!connected || (requiresBluetoothConnectPermission() && !bluetoothAllowed)) return;
    let alive = true;
    (async () => {
      try {
        const { AudioSession } = await import("@livekit/react-native");
        const available = await AudioSession.getAudioOutputs();
        if (alive) setOutputs(available);
      } catch (e) {
        if (alive) onError(e instanceof Error ? e.message : localeText("routingFailed"));
      }
    })();
    return () => { alive = false; };
  }, [connected, localeText, onError, bluetoothAllowed]);
  return <Room serverUrl={url} token={token} connect audio={false} video={false} options={{ adaptiveStream: false, dynacast: false }} onConnected={() => setConnected(true)} onDisconnected={() => { setConnected(false); setMicPublished(false); }} onError={(e: Error) => onError(e.message || localeText("disconnected"))}>
    <RoomControls muted={muted} connected={connected} setMicPublished={setMicPublished} onError={onError} setRemoteAudio={setRemoteAudio} />
    <View style={styles.audioInfo}>
      <Text style={[ui.meta, { color: micPublished ? "#168a55" : "#b7791f", textAlign: "center" }]}>{micPublished ? localeText("micPublished") : localeText("micOff")}</Text>
      <Text style={[ui.meta, { color: remoteAudio > 0 ? "#168a55" : "#b7791f", textAlign: "center" }]}>{remoteAudio > 0 ? localeText("remoteAudio") : localeText("remoteWaiting")}</Text>
      <Text style={[ui.meta, { color: "#555", textAlign: "center", fontWeight: "700" }]}>{localeText("output")}: {selected ? outputLabel(selected, localeText) : localeText("defaultOutput")}</Text>
      <View style={styles.outputChoices}>{visibleOutputs.map((output) => <Pressable key={output} onPress={async () => {
        try { const { AudioSession } = await import("@livekit/react-native"); await AudioSession.selectAudioOutput(output); setSelected(output); setRouteError(""); }
        catch (e) { const message = e instanceof Error ? e.message : localeText("routingFailed"); setRouteError(message); onError(message); }
      }} style={[styles.outputOption, selected === output && styles.outputSelected]}><Text style={styles.outputText}>{outputLabel(output, localeText)}</Text></Pressable>)}</View>
      {Platform.OS === "ios" ? <Pressable style={styles.picker} onPress={async () => { try { const { AudioSession } = await import("@livekit/react-native"); await AudioSession.showAudioRoutePicker(); } catch (e) { const message = e instanceof Error ? e.message : localeText("routingFailed"); setRouteError(message); onError(message); } }}><Text style={styles.outputText}>{localeText("systemPicker")}</Text></Pressable> : null}
      {routeError ? <Text style={{ color: "#b42318", textAlign: "center" }}>{routeError}</Text> : null}
    </View>
  </Room>;
}

function RoomControls({ muted, connected, setMicPublished, onError, setRemoteAudio }: any) {
  // Keep LiveKit native hooks dynamically loaded so Expo Web does not import WebRTC modules.
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { useLocalParticipant, useRoomContext, RoomEvent, Track } = require("@livekit/react-native");
  const { localParticipant } = useLocalParticipant();
  const room = useRoomContext();
  useEffect(() => {
    let alive = true;
    if (!connected || !localParticipant) { setMicPublished(false); return; }
    (async () => {
      try {
        await localParticipant.setMicrophoneEnabled(!muted);
        if (alive) setMicPublished(!muted);
      } catch (e) {
        if (alive) { setMicPublished(false); onError(e instanceof Error ? e.message : "Could not enable microphone"); }
      }
    })();
    return () => { alive = false; };
  }, [connected, muted, localParticipant, onError, setMicPublished]);
  useEffect(() => {
    if (!room) return;
    const update = () => {
      const count = room.remoteParticipants ? Array.from(room.remoteParticipants.values()).reduce((n: number, participant: any) => n + participant.audioTrackPublications.filter((pub: any) => pub.track && !pub.isMuted).length, 0) : 0;
      setRemoteAudio(count);
    };
    const subscribed = (track: any) => { if (track.kind === Track.Kind.Audio) update(); };
    const unsubscribed = (track: any) => { if (track.kind === Track.Kind.Audio) update(); };
    room.on(RoomEvent.TrackSubscribed, subscribed);
    room.on(RoomEvent.TrackUnsubscribed, unsubscribed);
    room.on(RoomEvent.ParticipantConnected, update);
    room.on(RoomEvent.ParticipantDisconnected, update);
    update();
    return () => {
      room.off(RoomEvent.TrackSubscribed, subscribed);
      room.off(RoomEvent.TrackUnsubscribed, unsubscribed);
      room.off(RoomEvent.ParticipantConnected, update);
      room.off(RoomEvent.ParticipantDisconnected, update);
    };
  }, [room, RoomEvent, Track, setRemoteAudio]);
  return null;
}

function outputLabel(output: string, text: (key: CallAudioKey) => string) {
  const keys: Record<string, CallAudioKey> = { default: "defaultOutput", force_speaker: "forceSpeaker", speaker: "speaker", earpiece: "earpiece", headset: "headset", bluetooth: "bluetooth" };
  return keys[output] ? text(keys[output]) : output;
}

const styles = StyleSheet.create({
  card: { alignItems: "center", gap: 18, paddingVertical: 28 },
  icon: { width: 78, height: 78, borderRadius: 39, alignItems: "center", justifyContent: "center" },
  actions: { flexDirection: "row-reverse", gap: 10, width: "100%" },
  audioInfo: { width: "100%", gap: 9 },
  outputChoices: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 8 },
  outputOption: { borderWidth: 1, borderColor: "#aab3bf", borderRadius: 18, paddingVertical: 8, paddingHorizontal: 12 },
  outputSelected: { borderColor: "#3b82f6", backgroundColor: "#eaf2ff" },
  outputText: { color: "#182230", fontSize: 13, fontWeight: "600" },
  picker: { alignSelf: "center", paddingVertical: 7, paddingHorizontal: 12 },
});
