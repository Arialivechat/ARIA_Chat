import { Redirect } from "expo-router";

/** Kept only as a route compatibility redirect; all roles now use the shared login form. */
export default function SpecialLoginRedirect() {
  return <Redirect href="/(tabs)" />;
}
