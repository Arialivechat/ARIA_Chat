import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Alert, Image, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { EmptyState, LoginGate, Page, PageHeader, PrimaryButton, Surface, ui } from "@/components/aria-ui";
import { UserIdentity } from "@/components/user-identity";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import * as Auth from "@/lib/_core/auth";
import { logout as logoutSession } from "@/lib/_core/api";
import { adminText } from "@/lib/ui-locale-admin";
import { ADMIN_BLOCK_DURATIONS_HOURS } from "@/lib/account-suspensions";
import { adminBlockText } from "@/lib/ui-locale-admin-blocks";
import { PROFILE_BADGE_TITLES, PROFILE_CROWN_STYLES, isProfileBadgeTitle, isProfileCrownStyle, type ProfileBadgeTitle, type ProfileCrownStyle } from "@/lib/profile-badges";
import { profileBadgeText, profileBadgeTitleLabel, profileCrownLabel } from "@/lib/ui-locale-profile-badges";
import { trpc } from "@/lib/trpc";
import { roomFavoriteText } from "@/lib/ui-locale-room-favorites";
import { getLedgerTransferParties } from "@/lib/ledger-parties";
import { canSpendDiamonds, diamondBalanceLabel } from "@/lib/diamond-balance";
type AdminSection = "overview" | "users" | "special" | "security" | "notices" | "rooms" | "reports" | "ads" | "agents" | "audit";
type AppRole = "user" | "admin" | "superadmin" | "moderator" | "support" | "sales_agent";
const roleOptions: { value: AppRole; label: string }[] = [
  { value: "user", label: "کاربر عادی" },
  { value: "moderator", label: "ناظر محتوا" },
  { value: "support", label: "پشتیبانی" },
  { value: "sales_agent", label: "نمایندهٔ فروش" },
  { value: "admin", label: "ادمین" },
  { value: "superadmin", label: "سوپرادمین" },
];
const blockDurationLabels = { 1: "oneHour", 24: "oneDay", 168: "sevenDays", 720: "thirtyDays" } as const;
const rankOptions = [
  { value: 0, label: "سرباز" },
  { value: 1, label: "لورد" },
  { value: 2, label: "دوک" },
  { value: 3, label: "کینگ" },
  { value: 4, label: "امپراتور" },
  { value: 5, label: "افسانه" },
];

export default function AdminPanelScreen() {
  const colors = useColors();
  const { locale } = useLanguage();
  const tAdmin = (key: Parameters<typeof adminText>[1]) => adminText(locale, key);
  const tBlock = (key: Parameters<typeof adminBlockText>[1]) => adminBlockText(locale, key);
  const utils = trpc.useUtils();
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const authorized = me.data?.role === "admin" || me.data?.role === "superadmin";
  const ownProfile = trpc.profile.me.useQuery(undefined, { enabled: authorized });
  const mayManageRoles = authorized && me.data?.role === "admin" && ownProfile.data?.accountNumber === 1;
  const [section, setSection] = useState<AdminSection>("overview");
  const [search, setSearch] = useState("");
  const [targetId, setTargetId] = useState("");
  const [adjustment, setAdjustment] = useState("");
  const [reason, setReason] = useState("");
  const [diamondTransferTarget, setDiamondTransferTarget] = useState("");
  const [diamondTransferAmount, setDiamondTransferAmount] = useState("");
  const [diamondTransferNote, setDiamondTransferNote] = useState("");
  const [agentSearch, setAgentSearch] = useState("");
  const [selectedAgentCandidate, setSelectedAgentCandidate] = useState<{ id: number; username: string | null; name: string | null; accountNumber: number | null } | null>(null);
  const [agentCode, setAgentCode] = useState("");
  const [agentDiscount, setAgentDiscount] = useState("10");
  const [agentEnabled, setAgentEnabled] = useState(true);
  const [feedback, setFeedback] = useState("");
  const [specialAccountNumber, setSpecialAccountNumber] = useState("");
  const [specialAccountUsername, setSpecialAccountUsername] = useState("");
  const [specialAccountPassword, setSpecialAccountPassword] = useState("");
  const [noticeTitle, setNoticeTitle] = useState("");
  const [noticeBody, setNoticeBody] = useState("");
  const [noticeTargetNumber, setNoticeTargetNumber] = useState("");
  const [noticeDurationDays, setNoticeDurationDays] = useState("7");
  const [roleTarget, setRoleTarget] = useState<{ userId: number; label: string; role: AppRole } | null>(null);
  const [selectedRole, setSelectedRole] = useState<AppRole>("user");
  const [roleReason, setRoleReason] = useState("");
  const [selectedBadgeTitle, setSelectedBadgeTitle] = useState<ProfileBadgeTitle>("none");
  const [selectedCrownStyle, setSelectedCrownStyle] = useState<ProfileCrownStyle | null>(null);
  const [badgeReason, setBadgeReason] = useState("");
  const [confirmRoleRemoval, setConfirmRoleRemoval] = useState(false);
  const [numberDrafts, setNumberDrafts] = useState<Record<number, string>>({});
  const [countryDrafts, setCountryDrafts] = useState<Record<number, string>>({});
  const [rankTarget, setRatingTarget] = useState<{ userId: number; label: string; rankLevel: number } | null>(null);
  const [rankValue, setRatingValue] = useState("");
  const [rankReason, setRatingReason] = useState("");
  const [accountActionTarget, setAccountActionTarget] = useState<{ userId: number; label: string; action: "delete" | "restore" } | null>(null);
  const [accountActionReason, setAccountActionReason] = useState("");
  const [passwordTarget, setPasswordTarget] = useState<{ userId: number; accountNumber: number; label: string } | null>(null);
  const [newUserPassword, setNewUserPassword] = useState("");
  const [showNewUserPassword, setShowNewUserPassword] = useState(false);
  const [blockTarget, setBlockTarget] = useState<{ userId: number; label: string } | null>(null);
  const [blockDuration, setBlockDuration] = useState<number | null>(24);
  const [blockReason, setBlockReason] = useState("");
  const summary = trpc.admin.summary.useQuery(undefined, { enabled: authorized });
  const users = trpc.admin.users.useQuery({ query: search.trim() || undefined, limit: 60 }, { enabled: authorized });
  const adminWallet = trpc.wallet.me.useQuery(undefined, { enabled: authorized && section === "users" });
  const rooms = trpc.rooms.list.useQuery({ limit: 100 }, { enabled: authorized });
  const countryRequests = trpc.admin.countryRoomRequests.useQuery(undefined, { enabled: authorized && section === "rooms" });
  const decideCountryRequest = trpc.admin.decideCountryRoomRequest.useMutation({ onSuccess: async () => { await countryRequests.refetch(); await rooms.refetch(); setFeedback("درخواست روم کشوری بررسی شد."); } });
  const specialAccounts = trpc.admin.specialAccounts.useQuery(undefined, { enabled: authorized && section === "special" });
  const securityEvents = trpc.admin.securityEvents.useQuery({ limit: 50 }, { enabled: authorized && section === "security" });
  const notices = trpc.admin.notices.useQuery({ limit: 50 }, { enabled: authorized && section === "notices" });
  const audit = trpc.admin.audit.useQuery({ limit: 30 }, { enabled: authorized && section === "audit" });
  const diamondTransactions = trpc.admin.diamondTransactions.useQuery({ limit: 50 }, { enabled: authorized && section === "audit" });
  const reports = trpc.admin.reports.useQuery({ status: "open", limit: 50 }, { enabled: authorized && section === "reports" });
  const ads = trpc.admin.ads.useQuery({ limit: 50 }, { enabled: authorized && section === "ads" });
  const agents = trpc.sales.listAgents.useQuery(undefined, { enabled: authorized && section === "agents" });
  const agentCandidates = trpc.admin.searchSalesAgentCandidates.useQuery({ query: agentSearch.trim(), limit: 20 }, { enabled: authorized && section === "agents" && agentSearch.trim().length >= 2 });
  const adjust = trpc.admin.adjustPoints.useMutation({ onSuccess: async () => { setFeedback("تغییر الماس در دفترکل ثبت شد."); setAdjustment(""); setReason(""); await Promise.all([users.refetch(), summary.refetch()]); } });
  const transferDiamonds = trpc.wallet.transfer.useMutation({ onSuccess: async (_result, variables) => { setFeedback(`انتقال ${variables.amount} الماس به حساب #${variables.toAccountNumber} ثبت شد.`); setDiamondTransferTarget(""); setDiamondTransferAmount(""); setDiamondTransferNote(""); await Promise.all([adminWallet.refetch(), users.refetch(), summary.refetch()]); } });
  const setRole = trpc.admin.setRole.useMutation({ onSuccess: async (_result, input) => { setFeedback("نقش کاربر به‌روز شد."); setRoleTarget((current) => current?.userId === input.userId ? { ...current, role: input.role } : current); setConfirmRoleRemoval(false); setRoleReason(""); await Promise.all([users.refetch(), audit.refetch()]); } });
  const setUserBadge = trpc.admin.setUserBadge.useMutation({ onSuccess: async () => { setFeedback("عنوان نمایشی و تاج ذخیره شد."); setBadgeReason(""); await Promise.all([users.refetch(), audit.refetch()]); } });
  const changeNumber = trpc.admin.changeAccountNumber.useMutation({ onSuccess: async () => { setFeedback("شمارهٔ حساب تغییر کرد."); await users.refetch(); } });
  const setUserRank = trpc.admin.setUserRank.useMutation({ onSuccess: async () => { setFeedback("عنوان رتبه ذخیره شد."); setRatingTarget(null); setRatingValue(""); setRatingReason(""); await users.refetch(); } });
  const moderate = trpc.admin.moderateUser.useMutation({ onSuccess: async (_result, input) => { setFeedback(input.action === "restore" ? tBlock("restoreRecorded") : "اقدام مدیریتی ثبت شد."); await users.refetch(); await summary.refetch(); } });
  const blockUser = trpc.admin.blockUser.useMutation({ onSuccess: async () => { setFeedback(tBlock("blockRecorded")); setBlockTarget(null); setBlockReason(""); await Promise.all([users.refetch(), summary.refetch()]); } });
  const deleteAccount = trpc.admin.deleteAccount.useMutation({ onSuccess: async () => { setFeedback("حساب به‌صورت نرم حذف شد؛ سوابق مالی حفظ شدند."); setAccountActionTarget(null); setAccountActionReason(""); await users.refetch(); } });
  const restoreDeletedAccount = trpc.admin.restoreDeletedAccount.useMutation({ onSuccess: async () => { setFeedback("حساب بازیابی شد."); setAccountActionTarget(null); setAccountActionReason(""); await users.refetch(); } });
  const resetUserPassword = trpc.admin.resetUserPassword.useMutation({ onSuccess: async () => { setFeedback(`رمز حساب #${passwordTarget?.accountNumber} بازنشانی شد. رمز تازه را امن به صاحب حساب بده؛ رمز قبلی قابل مشاهده نیست.`); await users.refetch(); } });
  const updateRoom = trpc.admin.updateRoom.useMutation({ onSuccess: async () => { setFeedback("وضعیت روم ذخیره شد."); await rooms.refetch(); } });
  const resolveReport = trpc.admin.resolveReport.useMutation({ onSuccess: async () => { setFeedback("گزارش بررسی و ثبت شد."); await reports.refetch(); await summary.refetch(); } });
  const updateAd = trpc.admin.updateAd.useMutation({ onSuccess: async () => { setFeedback("وضعیت آگهی به‌روز شد."); await ads.refetch(); } });
  const configureAgent = trpc.admin.configureSalesAgent.useMutation({ onSuccess: async () => { setFeedback("تخفیف نماینده ذخیره شد."); setSelectedAgentCandidate(null); setAgentSearch(""); setAgentCode(""); await agents.refetch(); } });
  const removeAgent = trpc.admin.removeSalesAgent.useMutation({ onSuccess: async (result) => { setFeedback(`نمایندهٔ فروش #${result.accountNumber ?? "—"} غیرفعال شد؛ حساب و سوابق مالی حفظ شدند.`); await Promise.all([agents.refetch(), users.refetch(), audit.refetch()]); } });
  const createSpecialAccount = trpc.admin.createSpecialAccount.useMutation({ onSuccess: async (result) => { setFeedback(`حساب ویژهٔ شمارهٔ ${result.accountNumber} ساخته شد.`); setSpecialAccountPassword(""); await Promise.all([specialAccounts.refetch(), users.refetch(), summary.refetch()]); } });
  const reviewSecurityEvent = trpc.admin.reviewSecurityEvent.useMutation({ onSuccess: async () => { setFeedback("رسیدگی به هشدار امنیتی ثبت شد."); await Promise.all([securityEvents.refetch(), audit.refetch()]); } });
  const createNotice = trpc.admin.createNotice.useMutation({ onSuccess: async () => { setFeedback("اعلان شناور منتشر شد."); setNoticeTitle(""); setNoticeBody(""); setNoticeTargetNumber(""); await notices.refetch(); } });
  const archiveNotice = trpc.admin.archiveNotice.useMutation({ onSuccess: async () => { setFeedback("اعلان بایگانی شد."); await notices.refetch(); } });
  const signOut = async () => {
    try { await logoutSession(); } catch { /* نشست کلاینت را در هر صورت پاک می‌کنیم. */ }
    await Auth.removeSessionToken();
    await Auth.clearUserInfo();
    await utils.invalidate();
    router.replace("/(tabs)");
  };

  if (me.isLoading && !authorized) return <Page scroll={false}><View style={styles.center}><ActivityIndicator color={colors.tint} /></View></Page>;
  if (!authorized) {
    if (me.data) return <Page><PageHeader eyebrow={tAdmin("deniedEyebrow")} title={tAdmin("deniedTitle")} subtitle={tAdmin("deniedSubtitle")} right={<Pressable accessibilityLabel={tAdmin("close")} onPress={() => router.back()} style={[styles.iconButton, { backgroundColor: colors.surface }]}><Ionicons name="arrow-forward" color={colors.tint} size={19} /></Pressable>} /><EmptyState icon="shield-outline" title={tAdmin("deniedEmpty")} detail={tAdmin("deniedDetail")} /></Page>;
    return (
      <LoginGate title={tAdmin("login")} redirectTo="/admin" />
    );
  }

  const submitAdjustment = () => {
    const accountNumber = Number(targetId);
    const amount = Number(adjustment);
    if (Number.isInteger(accountNumber) && accountNumber > 0 && Number.isInteger(amount) && amount !== 0 && reason.trim().length >= 3) {
      adjust.mutate({ accountNumber, amount, note: reason.trim() });
    }
  };
  const submitDiamondTransfer = () => {
    const toAccountNumber = Number(diamondTransferTarget);
    const amount = Number(diamondTransferAmount);
    if (!Number.isSafeInteger(toAccountNumber) || toAccountNumber < 1 || !canSpendDiamonds(amount, adminWallet.data?.balance, adminWallet.data?.isUnlimited === true)) return;
    transferDiamonds.mutate({ toAccountNumber, amount, note: diamondTransferNote.trim() || undefined });
  };
  const canSubmitDiamondTransfer = canSpendDiamonds(Number(diamondTransferAmount), adminWallet.data?.balance, adminWallet.data?.isUnlimited === true);

  const submitBadge = () => {
    if (!roleTarget || badgeReason.trim().length < 3) return;
    setUserBadge.mutate({ userId: roleTarget.userId, badgeTitle: selectedBadgeTitle, crownStyle: selectedCrownStyle, reason: badgeReason.trim() });
  };

  const submitRank = () => {
    if (!rankTarget || rankReason.trim().length < 3) return;
    const rankOverride = rankValue.trim() === "" ? null : Number(rankValue);
    if (rankOverride !== null && (!Number.isInteger(rankOverride) || rankOverride < 0 || rankOverride > 5)) return;
    setUserRank.mutate({ userId: rankTarget.userId, rankOverride, note: rankReason.trim() });
  };
  const submitBlock = () => {
    if (!blockTarget || blockReason.trim().length < 3) return;
    const perform = () => blockUser.mutate({ userId: blockTarget.userId, durationHours: blockDuration, reason: blockReason.trim() });
    const details = `${tBlock("confirmBlockDetails")}\n${blockTarget.label}`;
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(`${tBlock("confirmBlock")}\n\n${details}`)) perform();
      return;
    }
    Alert.alert(tBlock("confirmBlock"), details, [
      { text: tAdmin("cancel"), style: "cancel" },
      { text: tBlock("blockUser"), style: "destructive", onPress: perform },
    ]);
  };
  const requestRestoreBlock = (userId: number, label: string) => {
    const perform = () => moderate.mutate({ userId, action: "restore", reason: "رفع مسدودسازی از پنل مدیریت" });
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(`${tBlock("confirmRestore")}\n${label}`)) perform();
      return;
    }
    Alert.alert(tBlock("restoreAccess"), `${tBlock("confirmRestore")}\n${label}`, [
      { text: tAdmin("cancel"), style: "cancel" },
      { text: tBlock("restoreAccess"), onPress: perform },
    ]);
  };
  const requestRemoveAgent = (discountId: number, accountNumber: number | null) => {
    const message = `نمایندهٔ فروش #${accountNumber ?? "—"} از فهرست فعال خارج می‌شود؛ حساب، پیام‌ها و سوابق مالی حذف نمی‌شوند.`;
    const perform = () => removeAgent.mutate({ discountId });
    if (Platform.OS === "web") {
      if (typeof window !== "undefined" && window.confirm(message)) perform();
      return;
    }
    Alert.alert("حذف نمایندهٔ فروش", message, [
      { text: tAdmin("cancel"), style: "cancel" },
      { text: "حذف نمایندگی", style: "destructive", onPress: perform },
    ]);
  };

  return (
    <Page>
      <PageHeader eyebrow={tAdmin("eyebrow")} title={tAdmin("title")} subtitle={tAdmin("subtitle")} right={<Pressable accessibilityLabel={locale === "fa" ? "خروج از حساب" : "Sign out"} onPress={signOut} style={[styles.iconButton, { backgroundColor: colors.surface }]}><Ionicons name="log-out-outline" color={colors.tint} size={19} /></Pressable>} />
      <View style={styles.nav}>
        <AdminTab label={tAdmin("overview")} icon="grid-outline" active={section === "overview"} onPress={() => setSection("overview")} />
        <AdminTab label={tAdmin("users")} icon="people-outline" active={section === "users"} onPress={() => setSection("users")} />
        <AdminTab label={tAdmin("special")} icon="key-outline" active={section === "special"} onPress={() => setSection("special")} />
        <AdminTab label={tAdmin("security")} icon="shield-checkmark-outline" active={section === "security"} onPress={() => setSection("security")} />
        <AdminTab label={tAdmin("notices")} icon="megaphone-outline" active={section === "notices"} onPress={() => setSection("notices")} />
        <AdminTab label={tAdmin("rooms")} icon="chatbubbles-outline" active={section === "rooms"} onPress={() => setSection("rooms")} />
        <AdminTab label={tAdmin("reports")} icon="flag-outline" active={section === "reports"} onPress={() => setSection("reports")} />
        <AdminTab label={tAdmin("ads")} icon="megaphone-outline" active={section === "ads"} onPress={() => setSection("ads")} />
        <AdminTab label={tAdmin("agents")} icon="storefront-outline" active={section === "agents"} onPress={() => setSection("agents")} />
        <AdminTab label={tAdmin("audit")} icon="receipt-outline" active={section === "audit"} onPress={() => setSection("audit")} />
      </View>
      {summary.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
      {summary.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{tAdmin("error")}</Text></Surface> : null}
      {section === "overview" ? <>
        <View style={styles.stats}>
          <Metric title="کاربران" value={summary.data?.users} icon="people-outline" />
          <Metric title="روم‌ها" value={summary.data?.rooms} icon="chatbubbles-outline" />
          <Metric title="گزارش باز" value={summary.data?.openReports} icon="flag-outline" />
          <Metric title="کل الماس" value={summary.data?.points} icon="sparkles-outline" />
        </View>
        <Surface style={{ gap: 9 }}><Text style={[styles.cardTitle, { color: colors.text }]}>دسترسی‌های مدیریتی</Text><Text style={[ui.body, { color: colors.icon }]}>تغییر نقش‌ها و الماس‌ها از API محافظت‌شده انجام می‌شوند و در audit log ثبت می‌گردند. افزودن/حذف مدیر فقط در اختیار Administrator شمارهٔ ۱ است.</Text><PrimaryButton title="مدیریت کاربران" icon="people" onPress={() => setSection("users")} /></Surface>
        <Surface style={{ gap: 8 }}><Text style={[styles.cardTitle, { color: colors.text }]}>رتبهٔ گفت‌وگو</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>سرباز، لورد، دوک، کینگ، امپراتور و افسانه با آستانه‌های پیام سالم تعیین می‌شوند؛ ادمین می‌تواند عنوان را با دلیل تغییر دهد یا خودکار کند.</Text></Surface>
      </> : null}
      {section === "special" ? <>
        <Surface style={styles.adjustCard}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>ساخت حساب ویژهٔ مالک</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>فقط شماره‌های آزاد ۲ تا ۱۰۰. رمز حداقل ۱۲ نویسه دارد و سرور فقط hash امن آن را ذخیره می‌کند؛ رمز پس از ساخت دوباره نمایش داده نمی‌شود.</Text>
          <TextInput value={specialAccountNumber} onChangeText={setSpecialAccountNumber} placeholder="شمارهٔ حساب ۲ تا ۱۰۰" placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={specialAccountUsername} onChangeText={setSpecialAccountUsername} placeholder="نام کاربری یکتا" placeholderTextColor={colors.icon} autoCapitalize="none" autoCorrect={false} maxLength={32} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={specialAccountPassword} onChangeText={setSpecialAccountPassword} placeholder="رمز اولیه (حداقل ۱۲ نویسه)" placeholderTextColor={colors.icon} secureTextEntry autoCapitalize="none" autoCorrect={false} maxLength={256} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={createSpecialAccount.isPending ? "در حال ساخت…" : "ساخت حساب رزروی"} icon="key" disabled={createSpecialAccount.isPending || !Number.isInteger(Number(specialAccountNumber)) || Number(specialAccountNumber) < 2 || Number(specialAccountNumber) > 100 || specialAccountUsername.trim().length < 3 || specialAccountPassword.length < 12} onPress={() => createSpecialAccount.mutate({ accountNumber: Number(specialAccountNumber), username: specialAccountUsername.trim(), password: specialAccountPassword })} />
          {createSpecialAccount.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{"خطا"}</Text> : null}
        </Surface>
        <Surface style={{ gap: 10 }}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>جایگاه‌های شمارهٔ ۲ تا ۱۰۰</Text>
          {specialAccounts.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
          <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }}>
            {(specialAccounts.data ?? []).map((slot) => (
              <Pressable key={slot.accountNumber} disabled={slot.status !== "available"} onPress={() => setSpecialAccountNumber(String(slot.accountNumber))} style={{ minWidth: 82, paddingHorizontal: 9, paddingVertical: 8, borderRadius: 13, borderWidth: 1, borderColor: slot.status === "available" ? colors.border : colors.tint, backgroundColor: slot.status === "available" ? colors.background : colors.tint, opacity: slot.status === "available" ? 1 : 0.88 }}>
                <Text style={{ color: slot.status === "available" ? colors.text : colors.background, fontSize: 12, fontWeight: "800", textAlign: "center" }}>#{slot.accountNumber}</Text>
                <Text numberOfLines={1} style={{ color: slot.status === "available" ? colors.icon : colors.background, fontSize: 10, textAlign: "center" }}>{slot.status === "available" ? "آزاد" : slot.username || "واگذار شده"}</Text>
              </Pressable>
            ))}
          </View>
          {specialAccounts.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{"خطا"}</Text> : null}
        </Surface>
      </> : null}
      {section === "security" ? <>
        <Surface style={{ gap: 9 }}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>هشدارهای ربات محافظ</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>پیام‌های تکراری و سیل ارسال پیام در سرور متوقف می‌شوند؛ متن کامل پیام‌ها در این صف ذخیره نمی‌شود.</Text>
        </Surface>
        {securityEvents.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {(securityEvents.data ?? []).length === 0 && !securityEvents.isLoading ? <EmptyState icon="shield-checkmark-outline" title="هشدار بازی نداریم" detail="هشدارهای ضداسپم و پیام تکراری اینجا برای بررسی مدیر ظاهر می‌شوند." /> : null}
        {(securityEvents.data ?? []).map((event) => <Surface key={event.id} style={styles.auditRow}>
          <Text style={[styles.cardTitle, { color: event.severity === "high" ? colors.warning : colors.text }]}>{event.eventType === "message_flood" ? "ارسال پرتعداد پیام" : "پیام تکراری"} · {event.severity === "high" ? "اولویت بالا" : "هشدار"}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>کاربر {event.username || event.name || "—"} · شمارهٔ حساب #{event.accountNumber ?? "—"}</Text>
          <Text style={[ui.body, { color: colors.text }]}>{event.summary}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{new Date(event.createdAt).toLocaleString("fa-IR")} · وضعیت {event.status}</Text>
          {event.status === "open" ? <View style={styles.actions}>
            <PrimaryButton title="بررسی شد" icon="checkmark-circle-outline" quiet disabled={reviewSecurityEvent.isPending} onPress={() => reviewSecurityEvent.mutate({ eventId: event.id, status: "reviewed" })} />
            <PrimaryButton title="نادیده‌گرفتن" icon="close-circle-outline" quiet disabled={reviewSecurityEvent.isPending} onPress={() => reviewSecurityEvent.mutate({ eventId: event.id, status: "dismissed" })} />
          </View> : null}
        </Surface>)}
        {securityEvents.error || reviewSecurityEvent.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{securityEvents.error?.message || reviewSecurityEvent.error?.message}</Text> : null}
      </> : null}
      {section === "users" ? <>
        <TextInput value={search} onChangeText={setSearch} placeholder={tAdmin("search")} placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border, backgroundColor: colors.surface }]} />
        <Surface style={styles.adjustCard}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>افزایش یا کسر الماس کاربر</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>حساب Administrator شمارهٔ ۱ الماس نامحدود دارد و شارژشدنی نیست؛ برای افزایش یا کسر، شمارهٔ حساب عمومی کاربر دیگری را وارد کن.</Text>
          <TextInput value={targetId} onChangeText={setTargetId} placeholder="شمارهٔ حساب عمومی کاربر" placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={adjustment} onChangeText={setAdjustment} placeholder="مقدار؛ منفی برای کسر" placeholderTextColor={colors.icon} keyboardType="numbers-and-punctuation" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={reason} onChangeText={setReason} placeholder="دلیل ثبت در دفترکل" placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={adjust.isPending ? "در حال ثبت…" : "ثبت تغییر الماس کیف"} icon="sparkles" disabled={adjust.isPending || !targetId || !adjustment || reason.trim().length < 3} onPress={submitAdjustment} />
          {adjust.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{adjust.error.message}</Text> : null}
        </Surface>
        <Surface style={styles.adjustCard}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>انتقال مستقیم الماس از Administrator</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>موجودی شما: {diamondBalanceLabel(adminWallet.data?.balance, adminWallet.data?.isUnlimited === true)} الماس</Text>
          <TextInput value={diamondTransferTarget} onChangeText={setDiamondTransferTarget} placeholder="شمارهٔ حساب عمومی گیرنده" placeholderTextColor={colors.icon} keyboardType="number-pad" maxLength={10} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={diamondTransferAmount} onChangeText={setDiamondTransferAmount} placeholder="مقدار الماس" placeholderTextColor={colors.icon} keyboardType="number-pad" maxLength={16} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={diamondTransferNote} onChangeText={setDiamondTransferNote} placeholder="یادداشت اختیاری" placeholderTextColor={colors.icon} maxLength={500} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={transferDiamonds.isPending ? "در حال انتقال…" : "انتقال الماس"} icon="send-outline" disabled={transferDiamonds.isPending || !diamondTransferTarget || !canSubmitDiamondTransfer} onPress={submitDiamondTransfer} />
          {adminWallet.error || transferDiamonds.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{adminWallet.error?.message || transferDiamonds.error?.message}</Text> : null}
        </Surface>
        {passwordTarget ? <Surface style={styles.adjustCard}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>بازنشانی رمز · {passwordTarget.label} · #{passwordTarget.accountNumber}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>رمز فعلی عمداً قابل مشاهده نیست. رمز تازه را وارد کن و پس از موفقیت به‌شکل امن به صاحب حساب تحویل بده؛ سرور فقط hash آن را نگه می‌دارد و مقدار رمز را در سوابق ثبت نمی‌کند.</Text>
          <TextInput value={newUserPassword} onChangeText={setNewUserPassword} placeholder="رمز تازه (۶ تا ۲۵۶ بایت)" placeholderTextColor={colors.icon} secureTextEntry={!showNewUserPassword} autoCapitalize="none" autoCorrect={false} maxLength={256} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <View style={styles.actions}>
            <Pressable onPress={() => setShowNewUserPassword((value) => !value)} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name={showNewUserPassword ? "eye-off-outline" : "eye-outline"} color={colors.tint} size={17} /><Text style={[ui.meta, { color: colors.text }]}>{showNewUserPassword ? "پنهان" : "نمایش"}</Text></Pressable>
            <PrimaryButton title={resetUserPassword.isPending ? "در حال بازنشانی…" : "تأیید و بازنشانی رمز"} icon="key-outline" disabled={resetUserPassword.isPending || newUserPassword.length < 6} onPress={() => resetUserPassword.mutate({ userId: passwordTarget.userId, newPassword: newUserPassword })} />
            <PrimaryButton title="بستن" quiet onPress={() => { setPasswordTarget(null); setNewUserPassword(""); setShowNewUserPassword(false); resetUserPassword.reset(); }} />
          </View>
          {resetUserPassword.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{"خطا"}</Text> : null}
        </Surface> : null}
        {rankTarget ? <Surface style={styles.adjustCard}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>تغییر رتبهٔ {rankTarget.label} · فعلی {rankOptions.find((item) => item.value === rankTarget.rankLevel)?.label}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>رتبهٔ خودکار با پیام سالم: سرباز زیر ۱٬۰۰۰، لورد از ۱٬۰۰۰، دوک از ۲۰٬۰۰۰، کینگ از ۱۰۰٬۰۰۰، امپراتور از ۳۰۰٬۰۰۰ و افسانه از ۷۰۰٬۰۰۰ پیام.</Text>
          <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }}>{rankOptions.map((item) => <Pressable key={item.value} onPress={() => setRatingValue(String(item.value))} style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: rankValue === String(item.value) ? colors.tint : colors.border, backgroundColor: rankValue === String(item.value) ? colors.tint : colors.background }}><Text style={{ color: rankValue === String(item.value) ? colors.background : colors.text, fontWeight: "800" }}>{item.label}</Text></Pressable>)}<Pressable onPress={() => setRatingValue("")} style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: rankValue === "" ? colors.tint : colors.border, backgroundColor: rankValue === "" ? colors.tint : colors.background }}><Text style={{ color: rankValue === "" ? colors.background : colors.text, fontWeight: "800" }}>خودکار</Text></Pressable></View>
          <TextInput value={rankReason} onChangeText={setRatingReason} placeholder="دلیل تغییر/بازنشانی رتبه" placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={setUserRank.isPending ? "در حال ذخیره…" : "ذخیرهٔ رتبه"} icon="ribbon-outline" disabled={setUserRank.isPending || rankReason.trim().length < 3} onPress={submitRank} />
          {setUserRank.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{"خطا"}</Text> : null}
        </Surface> : null}
        {users.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {(users.data ?? []).length === 0 && !users.isLoading ? <EmptyState icon="people-outline" title={tAdmin("noUsers")} detail={locale === "fa" ? "عبارت جستجو را تغییر بده." : "Try changing your search."} /> : null}
        {(users.data ?? []).map((user) => <View key={user.id} style={[styles.userRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          {user.avatarUrl ? <Image source={{ uri: user.avatarUrl }} style={styles.avatar} /> : <View style={[styles.avatar, { backgroundColor: colors.background }]}><Ionicons name="person" size={18} color={colors.tint} /></View>}
          <View style={{ flex: 1, gap: 6 }}>
            <UserIdentity name={user.username || user.name || `کاربر #${user.accountNumber ?? "—"}`} avatarEmoji={user.avatarEmoji} badgeTitle={user.badgeTitle} crownStyle={user.crownStyle} role={user.role} nameStyle={[styles.userName, { color: colors.text }]} />
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>شمارهٔ حساب #{user.accountNumber ?? "—"} · {roleOptions.find((item) => item.value === user.role)?.label || user.role} · {user.accountStatus === "suspended" ? (user.suspendedUntil ? `${tBlock("blockedUntil")} ${new Date(String(user.suspendedUntil)).toLocaleString(locale)}` : tBlock("permanentlyBlocked")) : (user.accountStatus || "active")}</Text>
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{user.accountNumber === 1 && user.role === "admin" ? "∞" : user.points} الماس کیف · رتبهٔ {user.rankTitle}{user.rankIsManual ? " (دستی)" : ""} · {user.chatMessageCount} پیام سالم</Text>
            <View style={styles.actions}>
              {mayManageRoles && user.accountNumber !== 1 ? <Pressable accessibilityLabel="افزودن یا حذف سمت مدیریتی" onPress={() => { const label = user.username || user.name || `کاربر #${user.accountNumber ?? "—"}`; setRoleTarget({ userId: user.id, label, role: user.role }); setSelectedRole(user.role); setSelectedBadgeTitle(isProfileBadgeTitle(user.badgeTitle) ? user.badgeTitle : "none"); setSelectedCrownStyle(isProfileCrownStyle(user.crownStyle) ? user.crownStyle : null); setRoleReason(""); setBadgeReason(""); setUserBadge.reset(); setConfirmRoleRemoval(false); }} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="shield-outline" size={16} color={colors.tint} /></Pressable> : null}
              {user.accountNumber !== 1 && user.accountNumber != null ? <Pressable accessibilityLabel={`بازنشانی رمز حساب ${user.accountNumber}`} onPress={() => { setPasswordTarget({ userId: user.id, accountNumber: user.accountNumber!, label: user.username || user.name || `کاربر #${user.accountNumber}` }); setNewUserPassword(""); setShowNewUserPassword(false); resetUserPassword.reset(); }} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="key-outline" size={16} color={colors.tint} /></Pressable> : null}
              <Pressable onPress={() => { const label = user.username || user.name || `کاربر #${user.accountNumber ?? "—"}`; setRatingTarget({ userId: user.id, label, rankLevel: user.rankLevel }); setRatingValue(String(user.rankLevel)); setRatingReason(""); }} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="ribbon-outline" size={16} color={colors.tint} /></Pressable>
              {user.accountStatus === "suspended" ? <Pressable accessibilityLabel={tBlock("restoreAccess")} onPress={() => requestRestoreBlock(user.id, user.username || user.name || `کاربر #${user.accountNumber ?? "—"}`)} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="checkmark-circle-outline" size={16} color={colors.success} /></Pressable> : user.accountStatus !== "deleted" ? <Pressable accessibilityLabel="ثبت اخطار" onPress={() => moderate.mutate({ userId: user.id, action: "warn", reason: "اخطار از پنل مدیریت" })} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="warning-outline" size={16} color={colors.warning} /></Pressable> : null}
              {user.accountNumber !== 1 && user.role !== "admin" && user.role !== "superadmin" && user.accountStatus !== "deleted" && user.accountStatus !== "suspended" ? <Pressable accessibilityLabel={tBlock("blockUser")} onPress={() => { setBlockTarget({ userId: user.id, label: user.username || user.name || `کاربر #${user.accountNumber ?? "—"}` }); setBlockDuration(24); setBlockReason(""); blockUser.reset(); }} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="ban-outline" size={16} color={colors.error} /></Pressable> : null}
              {user.accountNumber !== 1 && user.role !== "admin" && user.role !== "superadmin" ? <Pressable accessibilityLabel={user.accountStatus === "deleted" ? "بازیابی حساب" : "حذف حساب"} onPress={() => { setAccountActionTarget({ userId: user.id, label: user.username || user.name || `کاربر #${user.accountNumber ?? "—"}`, action: user.accountStatus === "deleted" ? "restore" : "delete" }); setAccountActionReason(""); }} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name={user.accountStatus === "deleted" ? "refresh-outline" : "trash-outline"} size={16} color={user.accountStatus === "deleted" ? colors.success : colors.error} /></Pressable> : null}
            </View>
            {user.accountNumber !== 1 && (user.accountNumber ?? 0) >= 101 ? <View style={styles.actions}>
              <TextInput value={numberDrafts[user.id] ?? ""} onChangeText={(value) => setNumberDrafts((current) => ({ ...current, [user.id]: value }))} placeholder="شمارهٔ آزاد ۱۰۱+" placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, { flex: 1, minHeight: 38, color: colors.text, borderColor: colors.border }]} />
              <Pressable disabled={changeNumber.isPending || !Number.isInteger(Number(numberDrafts[user.id])) || Number(numberDrafts[user.id]) < 101 || Number(numberDrafts[user.id]) === user.accountNumber} onPress={() => changeNumber.mutate({ userId: user.id, accountNumber: Number(numberDrafts[user.id]) })} style={[styles.smallAction, { backgroundColor: colors.background, opacity: changeNumber.isPending ? 0.5 : 1 }]}><Ionicons name="swap-horizontal-outline" size={17} color={colors.tint} /></Pressable>
            </View> : <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>شمارهٔ ویژه؛ تغییر مستقیم ندارد.</Text>}
          </View>
        </View>)}
        {(setRole.error || moderate.error || blockUser.error || changeNumber.error || deleteAccount.error || restoreDeletedAccount.error) ? <Text style={{ color: colors.error, textAlign: "right" }}>{setRole.error?.message || moderate.error?.message || blockUser.error?.message || changeNumber.error?.message || deleteAccount.error?.message || restoreDeletedAccount.error?.message}</Text> : null}
      </> : null}
      {section === "notices" ? <>
        <Surface style={styles.adjustCard}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>اعلان شفاف و شناور در مرکز صفحه</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>شمارهٔ حساب را خالی بگذار تا همهٔ کاربران، حتی حساب‌های خصوصی، اعلان را ببینند. اعلان هدفمند فقط برای حساب واگذارشده ارسال می‌شود.</Text>
          <TextInput value={noticeTitle} onChangeText={setNoticeTitle} placeholder="عنوان اعلان" placeholderTextColor={colors.icon} maxLength={160} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={noticeBody} onChangeText={setNoticeBody} placeholder="متن اعلان" placeholderTextColor={colors.icon} maxLength={4000} multiline style={[ui.input, { minHeight: 90, color: colors.text, borderColor: colors.border, textAlignVertical: "top" }]} />
          <TextInput value={noticeTargetNumber} onChangeText={setNoticeTargetNumber} placeholder="شمارهٔ حساب هدف (خالی = همه)" placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={noticeDurationDays} onChangeText={setNoticeDurationDays} placeholder="مدت اعتبار به روز (۱ تا ۳۰)" placeholderTextColor={colors.icon} keyboardType="number-pad" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <PrimaryButton title={createNotice.isPending ? "در حال انتشار…" : "انتشار اعلان"} icon="megaphone" disabled={createNotice.isPending || noticeTitle.trim().length < 2 || noticeBody.trim().length < 1 || !Number.isInteger(Number(noticeDurationDays)) || Number(noticeDurationDays) < 1 || Number(noticeDurationDays) > 30 || (noticeTargetNumber !== "" && (!Number.isInteger(Number(noticeTargetNumber)) || Number(noticeTargetNumber) < 1))} onPress={() => createNotice.mutate({ title: noticeTitle.trim(), body: noticeBody.trim(), targetAccountNumber: noticeTargetNumber ? Number(noticeTargetNumber) : undefined, durationDays: Number(noticeDurationDays) })} />
          {createNotice.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{"خطا"}</Text> : null}
        </Surface>
        {notices.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {(notices.data ?? []).length === 0 && !notices.isLoading ? <EmptyState icon="megaphone-outline" title="اعلانی ثبت نشده" detail="اعلان سراسری یا هدفمند را از فرم بالا منتشر کن." /> : null}
        {(notices.data ?? []).map((notice) => <Surface key={notice.id} style={styles.auditRow}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>{notice.title}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>#{notice.id} · {notice.status} · {notice.targetAccountNumber ? `حساب #${notice.targetAccountNumber}` : "همهٔ کاربران"} · پایان {notice.expiresAt ? new Date(notice.expiresAt).toLocaleDateString("fa-IR") : "بدون تاریخ"}</Text>
          <Text style={[ui.body, { color: colors.text }]}>{notice.body}</Text>
          {notice.status === "active" ? <PrimaryButton title={archiveNotice.isPending ? "در حال بایگانی…" : "بایگانی اعلان"} icon="archive-outline" quiet disabled={archiveNotice.isPending} onPress={() => archiveNotice.mutate({ noticeId: notice.id })} /> : null}
        </Surface>)}
        {notices.error || archiveNotice.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{notices.error?.message || archiveNotice.error?.message}</Text> : null}
      </> : null}
      {section === "rooms" ? <>
        {mayManageRoles ? <><Text style={[styles.cardTitle, { color: colors.text, textAlign: "right" }]}>درخواست‌های روم کشوری</Text>
        {(countryRequests.data ?? []).map((request) => <Surface key={request.id} style={styles.auditRow}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>#{request.roomId} {request.roomName} · {request.country}</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>درخواست‌کننده #{request.requesterUserId} · {request.fee} الماس</Text>
          <TextInput value={reason} onChangeText={setReason} placeholder="دلیل تصمیم (الزامی)" placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border, textAlign: "right" }]} />
          <View style={styles.actions}>
            <PrimaryButton title="تأیید" icon="checkmark-circle-outline" disabled={decideCountryRequest.isPending || reason.trim().length < 3} onPress={() => decideCountryRequest.mutate({ requestId: request.id, decision: "approved", reason: reason.trim() })} />
            <PrimaryButton title="رد و بازپرداخت" icon="close-circle-outline" quiet disabled={decideCountryRequest.isPending || reason.trim().length < 3} onPress={() => decideCountryRequest.mutate({ requestId: request.id, decision: "rejected", reason: reason.trim() })} />
          </View>
        </Surface>)}
        {decideCountryRequest.error || countryRequests.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{decideCountryRequest.error?.message || countryRequests.error?.message}</Text> : null}</> : null}
        {rooms.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {(rooms.data ?? []).length === 0 && !rooms.isLoading ? <EmptyState icon="chatbubbles-outline" title="رومی در دسترس نیست" detail="روم‌های قابل‌مدیریت پس از افزودن اعضا نمایش داده می‌شوند." /> : null}
        {(rooms.data ?? []).map((room) => {
          const country = countryDrafts[room.id] ?? room.country ?? "IRAN";
          return <View key={room.id} style={[styles.roomRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={{ flex: 1, gap: 4 }}>
              <Text style={[styles.userName, { color: colors.text }]}>{room.name}</Text>
              <Text style={[ui.meta, { color: colors.icon }]}>{room.kind} · {room.memberCount ?? 0} عضو · {room.points ?? 0} امتیاز</Text>
              {mayManageRoles && room.kind === "public" ? <View style={styles.actions}>
                <TextInput value={country} onChangeText={(value) => setCountryDrafts((current) => ({ ...current, [room.id]: value }))} placeholder="نام کشور" placeholderTextColor={colors.icon} style={[ui.input, { flex: 1, minHeight: 38, color: colors.text, borderColor: colors.border }]} />
                <PrimaryButton title={updateRoom.isPending ? "در حال تغییر…" : "تبدیل به کشوری"} icon="earth-outline" disabled={updateRoom.isPending || !country.trim()} onPress={() => updateRoom.mutate({ roomId: room.id, kind: "country", country: country.trim() })} />
              </View> : null}
            </View>
            <Pressable accessibilityLabel="قفل‌کردن روم" onPress={() => updateRoom.mutate({ roomId: room.id, status: "locked" })} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="lock-closed-outline" color={colors.warning} size={16} /></Pressable>
            <Pressable accessibilityLabel="بازکردن روم" onPress={() => updateRoom.mutate({ roomId: room.id, status: "active" })} style={[styles.smallAction, { backgroundColor: colors.background }]}><Ionicons name="lock-open-outline" color={colors.success} size={16} /></Pressable>
          </View>;
        })}
        {updateRoom.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{"خطا"}</Text> : null}
      </> : null}
      {section === "reports" ? <>
        {reports.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {(reports.data ?? []).length === 0 && !reports.isLoading ? <EmptyState icon="shield-checkmark-outline" title="گزارش بازی نداریم" detail="گزارش‌های تازه برای بازبینی اینجا می‌آیند." /> : null}
        {(reports.data ?? []).map((report) => <Surface key={report.id} style={styles.auditRow}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>گزارش #{report.id} · کاربر {report.reportedUserId}</Text>
          <Text style={[ui.meta, { color: colors.icon }]}>از کاربر {report.reporterUserId} · {new Date(report.createdAt).toLocaleString("fa-IR")}</Text>
          <Text style={[ui.body, { color: colors.text }]}>{report.reason}</Text>
          {report.details ? <Text style={[ui.meta, { color: colors.icon }]}>{report.details}</Text> : null}
          <View style={styles.actions}>
            <PrimaryButton title="اخطار و بستن" icon="warning-outline" quiet disabled={moderate.isPending} onPress={() => moderate.mutate({ userId: report.reportedUserId, action: "warn", reason: report.reason, reportId: report.id })} />
            <PrimaryButton title="رد گزارش" icon="close-circle-outline" quiet disabled={resolveReport.isPending} onPress={() => resolveReport.mutate({ reportId: report.id, status: "dismissed" })} />
          </View>
        </Surface>)}
        {reports.error || resolveReport.error || moderate.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{reports.error?.message || resolveReport.error?.message || moderate.error?.message}</Text> : null}
      </> : null}
      {section === "ads" ? <>
        {ads.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {(ads.data ?? []).length === 0 && !ads.isLoading ? <EmptyState icon="megaphone-outline" title="آگهی‌ای ثبت نشده" detail="آگهی‌های کاربر پس از ارسال برای بازبینی اینجا ظاهر می‌شوند." /> : null}
        {(ads.data ?? []).map((ad) => <Surface key={ad.id} style={styles.auditRow}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>{ad.title}</Text>
          <Text style={[ui.meta, { color: colors.icon }]}>آگهی #{ad.id} · سازنده {ad.createdByUserId} · {ad.status}</Text>
          {ad.body ? <Text style={[ui.body, { color: colors.icon }]}>{ad.body}</Text> : null}
          <View style={styles.actions}>
            <PrimaryButton title="فعال" icon="checkmark-circle-outline" quiet disabled={updateAd.isPending || ad.status === "active"} onPress={() => updateAd.mutate({ adId: ad.id, status: "active" })} />
            <PrimaryButton title="مکث" icon="pause-circle-outline" quiet disabled={updateAd.isPending || ad.status === "paused"} onPress={() => updateAd.mutate({ adId: ad.id, status: "paused" })} />
            <PrimaryButton title="بایگانی" icon="archive-outline" quiet disabled={updateAd.isPending || ad.status === "archived"} onPress={() => updateAd.mutate({ adId: ad.id, status: "archived" })} />
          </View>
        </Surface>)}
        {ads.error || updateAd.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{ads.error?.message || updateAd.error?.message}</Text> : null}
      </> : null}
      {section === "agents" ? <>
        <Surface style={styles.adjustCard}>
          <Text style={[styles.cardTitle, { color: colors.text }]}>تعریف / ویرایش نماینده</Text>
          <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>امتیاز واقعی فروخته یا شارژ نمی‌شود؛ اینجا فقط کد تخفیف ثبت می‌شود.</Text>
          <TextInput value={agentSearch} onChangeText={(value) => { setAgentSearch(value); setSelectedAgentCandidate(null); }} placeholder="جستجو با نام کاربری، نام یا شمارهٔ حساب" placeholderTextColor={colors.icon} autoCapitalize="none" autoCorrect={false} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          {selectedAgentCandidate ? <View style={[styles.userRow, { backgroundColor: colors.background, borderColor: colors.tint }]}><View style={{ flex: 1, gap: 3 }}><Text style={[styles.userName, { color: colors.text }]}>نمایندهٔ انتخاب‌شده: {selectedAgentCandidate.username || selectedAgentCandidate.name || `کاربر #${selectedAgentCandidate.accountNumber ?? "—"}`}</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>شمارهٔ حساب عمومی #{selectedAgentCandidate.accountNumber ?? "—"}</Text></View><Ionicons name="checkmark-circle" color={colors.success} size={20} /></View> : null}
          {!selectedAgentCandidate && agentSearch.trim().length >= 2 ? <View style={{ gap: 6 }}>
            {agentCandidates.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
            {(agentCandidates.data ?? []).map((candidate) => <Pressable key={candidate.id} accessibilityRole="button" onPress={() => setSelectedAgentCandidate(candidate)} style={[styles.userRow, { backgroundColor: colors.background, borderColor: colors.border }]}><View style={{ flex: 1, gap: 3 }}><Text style={[styles.userName, { color: colors.text }]}>{candidate.username || candidate.name || `کاربر #${candidate.accountNumber ?? "—"}`}</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{candidate.username ? `@${candidate.username} · ` : ""}{candidate.name || "بدون نام نمایشی"} · حساب عمومی #{candidate.accountNumber ?? "—"}</Text></View><Ionicons name="person-add-outline" color={colors.tint} size={19} /></Pressable>)}
            {agentCandidates.data?.length === 0 && !agentCandidates.isLoading ? <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>کاربری پیدا نشد.</Text> : null}
            {agentCandidates.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{agentCandidates.error.message}</Text> : null}
          </View> : null}
          <TextInput value={agentCode} onChangeText={setAgentCode} placeholder="کد فروشنده" placeholderTextColor={colors.icon} autoCapitalize="characters" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <TextInput value={agentDiscount} onChangeText={setAgentDiscount} placeholder="درصد تخفیف (۰ تا ۱۰۰)" placeholderTextColor={colors.icon} keyboardType="decimal-pad" style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
          <Pressable onPress={() => setAgentEnabled((value) => !value)} style={styles.actions}><Ionicons name={agentEnabled ? "checkmark-circle" : "ellipse-outline"} color={agentEnabled ? colors.success : colors.icon} size={19} /><Text style={[ui.body, { color: colors.text }]}>{agentEnabled ? "نمایندگی فعال" : "نمایندگی غیرفعال"}</Text></Pressable>
          <PrimaryButton title={configureAgent.isPending ? "در حال ذخیره…" : "ذخیرهٔ نمایندگی"} icon="save-outline" disabled={configureAgent.isPending || !selectedAgentCandidate || agentCode.trim().length < 3 || !Number.isFinite(Number(agentDiscount)) || Number(agentDiscount) < 0 || Number(agentDiscount) > 100} onPress={() => { if (selectedAgentCandidate) configureAgent.mutate({ agentUserId: selectedAgentCandidate.id, code: agentCode.trim(), discountBps: Math.round(Number(agentDiscount) * 100), isActive: agentEnabled }); }} />
          {configureAgent.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{configureAgent.error.message}</Text> : null}
        </Surface>
        {(agents.data ?? []).map((agent) => <View key={agent.id} style={[styles.userRow, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={{ flex: 1, gap: 3 }}><Text style={[styles.userName, { color: colors.text }]}>{agent.username || agent.publicName}</Text><Text style={[ui.meta, { color: colors.icon }]}>{agent.code} · {agent.discountBps / 100}% · #{agent.accountNumber ?? "—"}</Text></View><Ionicons name="storefront-outline" color={colors.tint} size={19} /><Pressable accessibilityLabel="حذف نمایندهٔ فروش" disabled={removeAgent.isPending} onPress={() => requestRemoveAgent(agent.id, agent.accountNumber)} style={[styles.smallAction, { backgroundColor: colors.background, opacity: removeAgent.isPending ? 0.5 : 1 }]}><Ionicons name="trash-outline" color={colors.error} size={17} /></Pressable></View>)}
        {agents.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {(agents.data ?? []).length === 0 && !agents.isLoading ? <EmptyState icon="storefront-outline" title="نمایندهٔ فعالی نیست" detail="برای معرفی نماینده، نام یا شمارهٔ حساب عمومی را جستجو و یک نتیجه را انتخاب کن." /> : null}
        {agents.error || removeAgent.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{agents.error?.message || removeAgent.error?.message}</Text> : null}
      </> : null}
      {section === "audit" ? <>
        {audit.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        <Text style={[styles.cardTitle, { color: colors.text }]}>{roomFavoriteText(locale, "recentDiamondTransactions")}</Text>
        {(diamondTransactions.data ?? []).map((item) => {
          const account = { name: item.userName, username: item.username, accountNumber: item.accountNumber };
          const counterparty = { name: item.counterpartyName, username: item.counterpartyUsername, accountNumber: item.counterpartyAccountNumber };
          const { sender, recipient } = getLedgerTransferParties(item.direction, account, counterparty);
          const accountLabel = item.type === "admin_adjustment" ? roomFavoriteText(locale, "target") : roomFavoriteText(locale, "account");
          return (
            <Surface key={`diamond-${item.id}`} style={styles.auditRow}>
              <Text style={[styles.cardTitle, { color: colors.text }]}>{item.type} · {item.direction === "credit" ? "+" : "−"}{item.amount} {roomFavoriteText(locale, "diamonds")}</Text>
              <Text style={[ui.meta, { color: colors.icon }]}>{accountLabel}: {item.userName || "—"}{item.username ? ` (@${item.username})` : ""} · #{item.accountNumber ?? "—"}</Text>
              {item.type === "transfer" ? (
                <Text style={[ui.meta, { color: colors.icon }]}>
                  {roomFavoriteText(locale, "sender")}: {sender.name || "—"}{sender.username ? ` (@${sender.username})` : ""} · #{sender.accountNumber ?? "—"} · {roomFavoriteText(locale, "recipient")}: {recipient.name || "—"}{recipient.username ? ` (@${recipient.username})` : ""} · #{recipient.accountNumber ?? "—"}
                </Text>
              ) : null}
              {item.type === "admin_adjustment" ? (
                <Text style={[ui.meta, { color: colors.icon }]}>
                  {roomFavoriteText(locale, "adminActor")}: {item.actorName || (item.actorAccountNumber === 1 ? "Administrator" : "—")}{item.actorUsername ? ` (@${item.actorUsername})` : ""} · #{item.actorAccountNumber ?? "—"}
                </Text>
              ) : null}
              <Text style={[ui.meta, { color: colors.icon }]}>{new Date(item.createdAt).toLocaleString(locale)}</Text>
            </Surface>
          );
        })}
        {diamondTransactions.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{tAdmin("error")}</Text> : null}
        {(audit.data ?? []).length === 0 && !audit.isLoading ? <EmptyState icon="receipt-outline" title="سابقه‌ای ثبت نشده" detail="تغییرات حساس مدیر در این بخش نمایش داده می‌شوند." /> : null}
        {(audit.data ?? []).map((item) => <Surface key={item.id} style={styles.auditRow}><Text style={[styles.cardTitle, { color: colors.text }]}>{item.action}</Text><Text style={[ui.meta, { color: colors.icon }]}>مدیر {item.actorName || "—"} · حساب #{item.actorAccountNumber ?? "—"} · کاربر هدف {item.targetName || "—"} · حساب #{item.targetAccountNumber ?? "—"}</Text><Text style={[ui.meta, { color: colors.icon }]}>{new Date(item.createdAt).toLocaleString("fa-IR")}</Text></Surface>)}
        {audit.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{"خطا"}</Text> : null}
      </> : null}
      <Modal visible={Boolean(roleTarget && mayManageRoles)} transparent animationType="fade" onRequestClose={() => setRoleTarget(null)}>
        <View style={{ flex: 1, backgroundColor: "rgba(4, 12, 25, 0.62)", alignItems: "center", justifyContent: "center", padding: 18 }}>
          <Surface style={{ width: "100%", maxWidth: 460, maxHeight: "90%" }}>
            <ScrollView keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator contentContainerStyle={{ gap: 12 }}>
              <Text style={[styles.cardTitle, { color: colors.text }]}>مدیریت سمت و تاج · {roleTarget?.label}</Text>
              <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>سمت امنیتی فقط دسترسی برنامه را تعیین می‌کند؛ عنوان نمایشی به‌تنهایی هیچ مجوز مدیریتی نمی‌دهد. تغییرات با دلیل در سابقه ثبت می‌شوند.</Text>
              <Text style={[ui.meta, { color: colors.text, textAlign: "right", fontWeight: "800" }]}>سمت امنیتی</Text>
              <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }}>{roleOptions.map((item) => <Pressable key={item.value} accessibilityRole="button" accessibilityState={{ selected: selectedRole === item.value }} onPress={() => setSelectedRole(item.value)} style={{ paddingHorizontal: 12, paddingVertical: 9, borderWidth: 1, borderRadius: 999, borderColor: selectedRole === item.value ? colors.tint : colors.border, backgroundColor: selectedRole === item.value ? colors.tint : colors.background }}><Text style={{ color: selectedRole === item.value ? colors.background : colors.text, fontWeight: "800" }}>{item.label}</Text></Pressable>)}</View>
              <TextInput value={roleReason} onChangeText={setRoleReason} placeholder="دلیل تغییر سمت امنیتی (حداقل ۳ نویسه)" placeholderTextColor={colors.icon} maxLength={500} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
              <PrimaryButton title={setRole.isPending ? "در حال ذخیره…" : "ثبت سمت امنیتی"} icon="shield-checkmark-outline" disabled={setRole.isPending || !roleTarget || roleReason.trim().length < 3} onPress={() => { if (roleTarget) setRole.mutate({ userId: roleTarget.userId, role: selectedRole, reason: roleReason.trim() }); }} />
              {roleTarget && roleTarget.role !== "user" && roleTarget.userId !== me.data?.id ? (confirmRoleRemoval ? <View style={{ gap: 8 }}>
                <Text style={[ui.meta, { color: colors.warning, textAlign: "right" }]}>این کار فقط سمت امنیتی را به «کاربر عادی» برمی‌گرداند؛ خود حساب، پیام‌ها و سوابق مالی حذف نمی‌شوند.</Text>
                <PrimaryButton title={setRole.isPending ? "در حال انجام…" : "تأیید حذف سمت"} icon="person-remove-outline" disabled={setRole.isPending} onPress={() => setRole.mutate({ userId: roleTarget.userId, role: "user", reason: roleReason.trim() })} />
                <PrimaryButton title="لغو حذف سمت" quiet onPress={() => setConfirmRoleRemoval(false)} />
              </View> : <PrimaryButton title="حذف سمت امنیتی" icon="person-remove-outline" quiet disabled={setRole.isPending} onPress={() => setConfirmRoleRemoval(true)} />) : null}
              <Text style={[ui.meta, { color: colors.text, textAlign: "right", fontWeight: "800" }]}>{profileBadgeText(locale, "displayTitle")}</Text>
              <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }}>{PROFILE_BADGE_TITLES.map((title) => {
                const selected = selectedBadgeTitle === title;
                const label = title === "none" ? profileBadgeText(locale, "clearTitle") : profileBadgeTitleLabel(locale, title) || title;
                return <Pressable key={title} accessibilityRole="button" accessibilityState={{ selected }} onPress={() => setSelectedBadgeTitle(title)} style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? colors.tint : colors.background }}><Text style={{ color: selected ? colors.background : colors.text, fontWeight: "800" }}>{label}</Text></Pressable>;
              })}</View>
              <Text style={[ui.meta, { color: colors.text, textAlign: "right", fontWeight: "800" }]}>{profileBadgeText(locale, "crownStyle")}</Text>
              <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }}>
                <Pressable accessibilityRole="button" accessibilityState={{ selected: selectedCrownStyle === null }} onPress={() => setSelectedCrownStyle(null)} style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: selectedCrownStyle === null ? colors.tint : colors.border, backgroundColor: selectedCrownStyle === null ? colors.tint : colors.background }}><Text style={{ color: selectedCrownStyle === null ? colors.background : colors.text, fontWeight: "800" }}>{profileBadgeText(locale, "noCrown")}</Text></Pressable>
                {PROFILE_CROWN_STYLES.map((style) => {
                  const selected = selectedCrownStyle === style;
                  return <Pressable key={style} accessibilityRole="button" accessibilityState={{ selected }} onPress={() => setSelectedCrownStyle(style)} style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? colors.tint : colors.background }}><Text style={{ color: selected ? colors.background : colors.text, fontWeight: "800" }}>{profileCrownLabel(locale, style)}</Text></Pressable>;
                })}
              </View>
              {roleTarget ? <UserIdentity name={roleTarget.label} role={selectedRole} badgeTitle={selectedBadgeTitle} crownStyle={selectedCrownStyle} /> : null}
              <TextInput value={badgeReason} onChangeText={setBadgeReason} placeholder={`${profileBadgeText(locale, "auditReason")} · ${profileBadgeText(locale, "reasonHint")}`} placeholderTextColor={colors.icon} maxLength={500} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
              <PrimaryButton title={setUserBadge.isPending ? tAdmin("saving") : profileBadgeText(locale, "savePresentation")} icon="ribbon-outline" disabled={setUserBadge.isPending || !roleTarget || badgeReason.trim().length < 3} onPress={submitBadge} />
              {setUserBadge.isSuccess ? <Text style={{ color: colors.success, textAlign: "right" }}>{profileBadgeText(locale, "saved")}</Text> : null}
              {setRole.error || setUserBadge.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{setRole.error?.message || setUserBadge.error?.message}</Text> : null}
              <PrimaryButton title="انصراف" quiet onPress={() => setRoleTarget(null)} />
            </ScrollView>
          </Surface>
        </View>
      </Modal>
      <Modal visible={Boolean(accountActionTarget)} transparent animationType="fade" onRequestClose={() => setAccountActionTarget(null)}>
        <View style={{ flex: 1, backgroundColor: "rgba(4, 12, 25, 0.68)", alignItems: "center", justifyContent: "center", padding: 18 }}>
          <Surface style={{ width: "100%", maxWidth: 460, gap: 12, borderColor: accountActionTarget?.action === "delete" ? colors.error : colors.success }}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>{accountActionTarget?.action === "delete" ? `حذف نرم حساب ${accountActionTarget?.label}` : `بازیابی حساب ${accountActionTarget?.label}`}</Text>
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{accountActionTarget?.action === "delete" ? "حساب از ورود و جست‌وجوی عمومی خارج می‌شود؛ سوابق مالی و audit پاک نمی‌شوند و شمارهٔ حساب آزاد نمی‌شود." : "حساب حذف‌شده دوباره فعال و قابل ورود خواهد شد. سوابق قبلی حفظ می‌شوند."}</Text>
            <TextInput value={accountActionReason} onChangeText={setAccountActionReason} placeholder="علت اقدام (حداقل ۳ نویسه)" placeholderTextColor={colors.icon} maxLength={500} style={[ui.input, { color: colors.text, borderColor: colors.border }]} />
            {(deleteAccount.error || restoreDeletedAccount.error) ? <Text style={{ color: colors.error, textAlign: "right" }}>{deleteAccount.error?.message || restoreDeletedAccount.error?.message}</Text> : null}
            <PrimaryButton title={accountActionTarget?.action === "delete" ? (deleteAccount.isPending ? "در حال حذف نرم…" : "تأیید حذف نرم") : (restoreDeletedAccount.isPending ? "در حال بازیابی…" : "تأیید بازیابی")} icon={accountActionTarget?.action === "delete" ? "trash-outline" : "refresh-outline"} disabled={!accountActionTarget || accountActionReason.trim().length < 3 || deleteAccount.isPending || restoreDeletedAccount.isPending} onPress={() => { if (!accountActionTarget) return; const input = { userId: accountActionTarget.userId, reason: accountActionReason.trim() }; if (accountActionTarget.action === "delete") deleteAccount.mutate(input); else restoreDeletedAccount.mutate(input); }} />
            <PrimaryButton title="انصراف" quiet onPress={() => setAccountActionTarget(null)} />
          </Surface>
        </View>
      </Modal>
      <Modal visible={Boolean(blockTarget)} transparent animationType="fade" onRequestClose={() => setBlockTarget(null)}>
        <View style={{ flex: 1, backgroundColor: "rgba(4, 12, 25, 0.68)", alignItems: "center", justifyContent: "center", padding: 18 }}>
          <Surface style={{ width: "100%", maxWidth: 460, gap: 12, borderColor: colors.error }}>
            <Text style={[styles.cardTitle, { color: colors.text }]}>{tBlock("blockUser")} · {blockTarget?.label}</Text>
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{tBlock("confirmBlockDetails")}</Text>
            <Text style={[ui.meta, { color: colors.text, textAlign: "right", fontWeight: "800" }]}>{tBlock("duration")}</Text>
            <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }}>
              {ADMIN_BLOCK_DURATIONS_HOURS.map((hours) => {
                const selected = blockDuration === hours;
                return <Pressable key={hours} accessibilityRole="button" accessibilityState={{ selected }} onPress={() => setBlockDuration(hours)} style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: selected ? colors.tint : colors.border, backgroundColor: selected ? colors.tint : colors.background }}><Text style={{ color: selected ? colors.background : colors.text, fontWeight: "800" }}>{tBlock(blockDurationLabels[hours])}</Text></Pressable>;
              })}
              <Pressable accessibilityRole="button" accessibilityState={{ selected: blockDuration === null }} onPress={() => setBlockDuration(null)} style={{ paddingHorizontal: 11, paddingVertical: 8, borderRadius: 999, borderWidth: 1, borderColor: blockDuration === null ? colors.error : colors.border, backgroundColor: blockDuration === null ? colors.error : colors.background }}><Text style={{ color: blockDuration === null ? "#FFFFFF" : colors.text, fontWeight: "800" }}>{tBlock("permanent")}</Text></Pressable>
            </View>
            <TextInput value={blockReason} onChangeText={setBlockReason} placeholder={`${tBlock("reason")} · ${tBlock("reasonHint")}`} placeholderTextColor={colors.icon} maxLength={500} multiline style={[ui.input, { color: colors.text, borderColor: colors.border, minHeight: 74, textAlignVertical: "top" }]} />
            {blockUser.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{blockUser.error.message}</Text> : null}
            <PrimaryButton title={blockUser.isPending ? tAdmin("saving") : tBlock("confirmBlock")} icon="ban-outline" disabled={blockUser.isPending || blockReason.trim().length < 3} onPress={submitBlock} />
            <PrimaryButton title={tAdmin("cancel")} quiet onPress={() => setBlockTarget(null)} />
          </Surface>
        </View>
      </Modal>
      {feedback ? <Text style={{ color: colors.success, textAlign: "right", fontWeight: "700" }}>{feedback}</Text> : null}
    </Page>
  );
}

function Metric({ title, value, icon }: { title: string; value?: number; icon: keyof typeof Ionicons.glyphMap }) {
  const colors = useColors();
  return <Surface style={styles.metric}><Ionicons name={icon} color={colors.tint} size={18} /><Text style={[styles.metricValue, { color: colors.text }]}>{value ?? "—"}</Text><Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{title}</Text></Surface>;
}
function AdminTab({ label, icon, active, onPress }: { label: string; icon: keyof typeof Ionicons.glyphMap; active: boolean; onPress: () => void }) {
  const colors = useColors();
  return <Pressable onPress={onPress} style={[styles.tab, { backgroundColor: active ? colors.tint : colors.surface, borderColor: active ? colors.tint : colors.border }]}><Ionicons name={icon} size={16} color={active ? colors.background : colors.icon} /><Text style={{ color: active ? colors.background : colors.text, fontSize: 11, fontWeight: "800" }}>{label}</Text></Pressable>;
}

const styles = StyleSheet.create({ center: { flex: 1, alignItems: "center", justifyContent: "center" }, iconButton: { width: 41, height: 41, borderRadius: 14, alignItems: "center", justifyContent: "center" }, loginCard: { alignItems: "center", gap: 12, paddingVertical: 22 }, lockMark: { width: 53, height: 53, borderRadius: 18, alignItems: "center", justifyContent: "center" }, loginTitle: { fontSize: 18, fontWeight: "900" }, nav: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 7 }, tab: { flexDirection: "row-reverse", alignItems: "center", gap: 5, borderWidth: 1, borderRadius: 999, paddingVertical: 8, paddingHorizontal: 10 }, stats: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }, metric: { width: "48%", flexGrow: 1, alignItems: "center", gap: 7 }, metricValue: { fontSize: 22, fontWeight: "900" }, cardTitle: { textAlign: "right", fontWeight: "800", fontSize: 14 }, adjustCard: { gap: 9 }, userRow: { borderWidth: 1, borderRadius: 17, padding: 11, flexDirection: "row-reverse", alignItems: "center", gap: 9 }, avatar: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" }, userName: { textAlign: "right", fontWeight: "800", fontSize: 13 }, actions: { flexDirection: "row", alignItems: "center", gap: 5 }, smallAction: { width: 32, height: 32, borderRadius: 11, alignItems: "center", justifyContent: "center" }, roomRow: { borderWidth: 1, borderRadius: 17, padding: 12, flexDirection: "row-reverse", alignItems: "center", gap: 8 }, auditRow: { gap: 5 } });
