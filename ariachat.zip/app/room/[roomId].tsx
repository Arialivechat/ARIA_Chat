import { Ionicons } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Image, KeyboardAvoidingView, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { EmptyState, LoginGate, Page, PageHeader, PrimaryButton, Surface, ui } from "@/components/aria-ui";
import { UserIdentity } from "@/components/user-identity";
import { ActiveAdsTicker } from "@/components/active-ads-ticker";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { trpc } from "@/lib/trpc";
import { translateCoreScreen } from "@/lib/ui-locale-core-screens";
import { MAX_IMAGE_UPLOAD_BYTES, MAX_NON_IMAGE_UPLOAD_BYTES } from "@/lib/media-limits";
import { translateProfileAvatars } from "@/lib/ui-locale-avatars";
import { AttachmentReadError, AttachmentTooLargeError, readPickerAssetBase64 } from "@/lib/chat-media-picker";

const ALLOWED_CHAT_TYPES = ["image/jpeg", "image/png", "image/webp", "audio/mpeg", "audio/mp4", "audio/aac", "application/pdf"];
export default function RoomChatScreen() {
  const colors = useColors();
  const { locale, t } = useLanguage();
  const c = (key: import("@/lib/ui-locale-core-screens").CoreScreenLocaleKey) => translateCoreScreen(locale, key);
  const router = useRouter();
  const params = useLocalSearchParams<{ roomId: string }>();
  const roomId = Number(params.roomId);
  const validRoomId = Number.isInteger(roomId) && roomId > 0;
  const { isAuthenticated, loading } = useAuth();
  const utils = trpc.useUtils();
  const join = trpc.rooms.join.useMutation({ onSuccess: () => { void utils.rooms.list.invalidate(); } });
  const joinStarted = useRef(false);
  const [draft, setDraft] = useState("");
  const [pendingAttachment, setPendingAttachment] = useState<{ id: number; fileName: string; kind: "image" | "audio" | "asset"; sizeBytes: number } | null>(null);
  const [localError, setLocalError] = useState("");
  const [manageOpen, setManageOpen] = useState(false);
  const [invitePickerOpen, setInvitePickerOpen] = useState(false);
  const [announcementDraft, setAnnouncementDraft] = useState<string | null>(null);
  const [kickArmed, setKickArmed] = useState<number | null>(null);
  const [clearArmed, setClearArmed] = useState(false);
  const [countryDraft, setCountryDraft] = useState("ایران");
  const listRef = useRef<ScrollView>(null);
  const friends = trpc.friends.list.useQuery(undefined, { enabled: isAuthenticated && validRoomId });
  const inviteFriend = trpc.roomInvites.send.useMutation({ onSuccess: async () => { await friends.refetch(); setLocalError(c("inviteSent")); } });
  const myProfile = trpc.profile.me.useQuery(undefined, { enabled: isAuthenticated });
  const rooms = trpc.rooms.list.useQuery({ limit: 100 }, { enabled: isAuthenticated && validRoomId });
  const room = useMemo(() => rooms.data?.find((item) => item.id === roomId), [rooms.data, roomId]);
  const countryRequest = trpc.rooms.countryRequest.useQuery({ roomId }, { enabled: isAuthenticated && validRoomId });
  const requestCountry = trpc.rooms.requestCountry.useMutation({ onSuccess: async () => { await countryRequest.refetch(); await rooms.refetch(); } });
  const chat = trpc.rooms.messages.useQuery({ roomId, limit: 80 }, { enabled: isAuthenticated && validRoomId && join.isSuccess, refetchInterval: 2500 });
  const send = trpc.rooms.sendMessage.useMutation({ onSuccess: async () => { setDraft(""); setPendingAttachment(null); setLocalError(""); await chat.refetch(); listRef.current?.scrollToEnd({ animated: true }); } });
  const upload = trpc.media.upload.useMutation();
  const isGlobalAdmin = myProfile.data?.role === "admin" || myProfile.data?.role === "superadmin";
  const isRoomOwner = room?.membershipRole === "owner" || Number(room?.creatorAccountNumber) === myProfile.data?.accountNumber;
  const isRoomManager = isGlobalAdmin || isRoomOwner || room?.membershipRole === "moderator";
  const canSetRoomRole = isGlobalAdmin || isRoomOwner;
  const members = trpc.rooms.members.useQuery({ roomId }, { enabled: isAuthenticated && validRoomId && Boolean(isRoomManager) });
  const refreshRoomState = async () => { await Promise.all([rooms.refetch(), members.refetch(), chat.refetch()]); };
  const kickMember = trpc.rooms.kickMember.useMutation({ onSuccess: refreshRoomState });
  const muteMember = trpc.rooms.muteMember.useMutation({ onSuccess: refreshRoomState });
  const setModerator = trpc.rooms.setModerator.useMutation({ onSuccess: refreshRoomState });
  const setAnnouncement = trpc.rooms.announcement.useMutation({ onSuccess: async () => { setAnnouncementDraft(null); await refreshRoomState(); } });
  const setStatus = trpc.rooms.setStatus.useMutation({ onSuccess: refreshRoomState });
  const clearMessages = trpc.rooms.clearMessages.useMutation({ onSuccess: async () => { setClearArmed(false); await refreshRoomState(); } });
  useEffect(() => {
    if (isAuthenticated && validRoomId && !joinStarted.current) {
      joinStarted.current = true;
      join.mutate({ roomId });
    }
  }, [isAuthenticated, validRoomId, roomId, join]);
  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={t("loginRoom")} />;
  if (!validRoomId) return <Page><EmptyState icon="alert-circle-outline" title={t("invalidRoom")} detail={t("chooseRoomAgain")} /></Page>;
  const currentAnnouncement = announcementDraft ?? room?.announcement ?? "";
  const submit = () => {
    const text = draft.trim();
    if ((!pendingAttachment && text.length < 2) || send.isPending) return;
    send.mutate({ roomId, text: text || undefined, type: pendingAttachment?.kind, assetId: pendingAttachment?.id });
  };
  const pickAttachment = async () => {
    setLocalError("");
    let isImageAttachment = false;
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: ALLOWED_CHAT_TYPES, copyToCacheDirectory: true, base64: true });
      if (result.canceled) return;
      const asset = result.assets?.[0];
      if (!asset) throw new Error(t("fileReadError"));
      const contentType = asset.mimeType?.toLowerCase().split(";")[0];
      if (!contentType || !ALLOWED_CHAT_TYPES.includes(contentType)) throw new Error(t("fileTypes"));
      isImageAttachment = contentType.startsWith("image/");
      const maxBytes = contentType.startsWith("image/") ? MAX_IMAGE_UPLOAD_BYTES : MAX_NON_IMAGE_UPLOAD_BYTES;
      const { base64Data } = await readPickerAssetBase64(asset, maxBytes);
      const uploaded = await upload.mutateAsync({ fileName: asset.name || "attachment", contentType, base64Data });
      setPendingAttachment({ id: uploaded.id, fileName: uploaded.fileName, kind: uploaded.kind, sizeBytes: uploaded.sizeBytes });
    } catch (error) {
      if (error instanceof AttachmentTooLargeError) setLocalError(isImageAttachment ? translateProfileAvatars(locale, "imageTooLarge") : t("fileTooLarge"));
      else if (error instanceof AttachmentReadError) setLocalError(t("fileReadError"));
      else setLocalError(error instanceof Error ? error.message : t("uploadFailed"));
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.background }} behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}>
      <Page scroll={false} bottomSafeArea>
        <PageHeader eyebrow={room?.kind === "private" ? t("roomPrivate") : t("roomLiveHeader")} title={room?.name || t("roomChatTitle")} subtitle={room?.description || (room ? `${room.memberCount ?? 0} عضو · ${room.points ?? 0} امتیاز` : t("loadingRoom"))} right={<Pressable onPress={() => router.back()} style={[styles.back, { backgroundColor: colors.surface }]}><Ionicons name="arrow-forward" size={19} color={colors.tint} /></Pressable>} />
        <ActiveAdsTicker />
        {room?.status === "active" && join.isSuccess ? <Surface style={{ gap: 8 }}>
          <PrimaryButton title={invitePickerOpen ? t("closeFriends") : t("inviteToRoom")} icon="person-add-outline" quiet onPress={() => setInvitePickerOpen(value => !value)} />
          {invitePickerOpen ? friends.isLoading ? <ActivityIndicator color={colors.tint} /> : (friends.data ?? []).length === 0 ? <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{c("noFriends")}</Text> : (friends.data ?? []).filter(friend => friend.accountNumber !== null).map(friend => <Pressable key={friend.accountNumber} disabled={inviteFriend.isPending} onPress={() => inviteFriend.mutate({ roomId, accountNumber: friend.accountNumber! })} style={[styles.memberRow, { backgroundColor: colors.background, borderColor: colors.border }]}><UserIdentity name={`${friend.username || friend.name || t("friend")} · #${friend.accountNumber}`} avatarEmoji={friend.avatarEmoji} badgeTitle={friend.badgeTitle} crownStyle={friend.crownStyle} role={friend.role} style={{ flex: 1 }} /><Ionicons name="send-outline" size={18} color={colors.tint} /></Pressable>) : null}
          {inviteFriend.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
        </Surface> : null}
        {room && (countryRequest.data?.canRequest || countryRequest.data?.request) ? <Surface style={{ gap: 8 }}>
          {countryRequest.data.request ? <Text style={[ui.meta, { color: colors.tint, textAlign: "right" }]}>درخواست روم کشوری: {countryRequest.data.request.status === "pending" ? "در انتظار بررسی" : countryRequest.data.request.status === "approved" ? "تأیید شد" : `رد شد · ${countryRequest.data.request.reason || ""}`}</Text> : null}
          {countryRequest.data.request?.status !== "pending" ? <>
            <TextInput value={countryDraft} onChangeText={setCountryDraft} placeholder="نام کشور" placeholderTextColor={colors.icon} style={[ui.input, { color: colors.text, borderColor: colors.border, textAlign: "right" }]} />
            <PrimaryButton title={requestCountry.isPending ? "در حال ثبت…" : "درخواست روم کشوری · ۲۰٬۰۰۰ الماس"} icon="earth-outline" disabled={requestCountry.isPending || countryDraft.trim().length < 1} onPress={() => requestCountry.mutate({ roomId, country: countryDraft.trim() })} />
          </> : null}
          {requestCountry.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{requestCountry.error.message}</Text> : null}
        </Surface> : null}
        {room?.announcement ? <Surface style={[styles.announcement, { backgroundColor: colors.surface, borderColor: colors.warning }]}><View style={ui.row}><Ionicons name="megaphone" size={18} color={colors.warning} /><Text style={[ui.meta, { color: colors.warning, fontWeight: "900" }]}>{c("roomAnnouncement")}</Text></View><Text style={[ui.body, { color: colors.text, textAlign: "right" }]}>{room.announcement}</Text></Surface> : null}
        {join.error ? <Surface><Text style={{ textAlign: "right", color: colors.error }}>{t("retry")}</Text><PrimaryButton title={t("backRooms")} quiet onPress={() => router.replace("/(tabs)")} /></Surface> : null}
        {isRoomManager ? <Surface style={styles.managePanel}>
          <Pressable accessibilityRole="button" onPress={() => setManageOpen((value) => !value)} style={ui.spread}><View style={ui.row}><Ionicons name="settings-outline" size={19} color={colors.tint} /><Text style={[ui.body, { color: colors.text, fontWeight: "900" }]}>{c("manageRoom")}</Text></View><Ionicons name={manageOpen ? "chevron-up" : "chevron-down"} size={17} color={colors.icon} /></Pressable>
          {manageOpen ? <View style={{ gap: 10 }}>
            <TextInput value={currentAnnouncement} onChangeText={setAnnouncementDraft} multiline maxLength={1000} placeholder={t("shortAnnouncement")} placeholderTextColor={colors.icon} style={[ui.input, styles.announcementInput, { color: colors.text, borderColor: colors.border }]} />
            <PrimaryButton title={setAnnouncement.isPending ? t("savePending") : currentAnnouncement.trim() ? t("publishAnnouncement") : t("clearAnnouncement")} icon="megaphone-outline" quiet disabled={setAnnouncement.isPending} onPress={() => setAnnouncement.mutate({ roomId, text: currentAnnouncement.trim() || null })} />
            {canSetRoomRole ? <>
              <PrimaryButton title={room?.status === "active" ? t("lockRoom") : t("activateRoom")} icon={room?.status === "active" ? "lock-closed-outline" : "lock-open-outline"} quiet disabled={setStatus.isPending} onPress={() => setStatus.mutate({ roomId, status: room?.status === "active" ? "locked" : "active" })} />
              <PrimaryButton title={clearArmed ? t("confirmClear") : t("clearRoomMessages")} icon="trash-outline" quiet disabled={clearMessages.isPending} onPress={() => { if (clearArmed) clearMessages.mutate({ roomId }); else setClearArmed(true); }} />
            </> : null}
            {members.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
            {members.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
            <Text style={[ui.meta, { color: colors.icon, textAlign: "right", fontWeight: "800" }]}>{t("roomMembers")} ({members.data?.length ?? 0})</Text>
            <ScrollView style={{ maxHeight: 190 }} nestedScrollEnabled showsVerticalScrollIndicator contentContainerStyle={{ gap: 7 }}>
              {(members.data ?? []).map((member, index) => {
                const accountNumber = member.accountNumber;
                const hasAccountNumber = typeof accountNumber === "number";
                const canModerateMember = hasAccountNumber && !member.isMe && member.role !== "owner" && (canSetRoomRole || member.role === "member");
                const muted = member.isMuted;
                return <View key={accountNumber ?? index} style={[styles.memberRow, { backgroundColor: colors.background, borderColor: colors.border }]}>
                  <View style={{ flex: 1, gap: 2 }}><UserIdentity name={`${member.username || member.name || t("member")} · #${accountNumber ?? "—"}`} avatarEmoji={member.avatarEmoji} badgeTitle={member.badgeTitle} crownStyle={member.crownStyle} role={member.appRole} roomRole={member.role} style={{ flex: 1 }} nameStyle={{ color: colors.text }} /><Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{member.role === "owner" ? t("owner") : member.role === "moderator" ? t("moderator") : t("member")}{muted ? ` · ${c("muted")}` : ""}</Text></View>
                  {canModerateMember && hasAccountNumber ? <View style={styles.memberActions}>
                    <Pressable style={[styles.managerAction, { backgroundColor: colors.error }]} onPress={() => { if (kickArmed === accountNumber) { kickMember.mutate({ roomId, accountNumber }); setKickArmed(null); } else setKickArmed(accountNumber); }}><Text style={{ color: colors.background, fontSize: 11, fontWeight: "900" }}>{kickArmed === accountNumber ? t("confirmKick") : t("kick")}</Text></Pressable>
                    <Pressable style={[styles.managerAction, { backgroundColor: colors.warning }]} onPress={() => muteMember.mutate({ roomId, accountNumber, durationMinutes: muted ? 0 : 10 })}><Text style={{ color: colors.background, fontSize: 11, fontWeight: "900" }}>{muted ? t("unmute") : t("muteTen")}</Text></Pressable>
                    {canSetRoomRole ? <Pressable style={[styles.managerAction, { backgroundColor: colors.tint }]} onPress={() => setModerator.mutate({ roomId, accountNumber, moderator: member.role !== "moderator" })}><Text style={{ color: colors.background, fontSize: 11, fontWeight: "900" }}>{member.role === "moderator" ? t("removeRole") : t("makeModerator")}</Text></Pressable> : null}
                  </View> : null}
                </View>;
              })}
            </ScrollView>
            {[kickMember.error, muteMember.error, setModerator.error, setAnnouncement.error, setStatus.error, clearMessages.error].filter(Boolean).map((error, index) => <Text key={index} style={{ color: colors.error, textAlign: "right" }}>{error?.message}</Text>)}
          </View> : null}
        </Surface> : null}
        {chat.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {chat.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text></Surface> : null}
        {!chat.isLoading && !chat.error && (chat.data?.length ?? 0) === 0 ? <EmptyState icon="chatbubble-ellipses-outline" title={t("startConversation")} detail={t("firstMessage")} /> : null}
        <ScrollView ref={listRef} style={{ flex: 1 }} contentContainerStyle={{ paddingVertical: 8, gap: 9 }} showsVerticalScrollIndicator={false} onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}>
          {(chat.data ?? []).map((message) => {
            const mine = message.isMine;
            return (
              <View key={message.id} style={[styles.messageRow, mine ? { justifyContent: "flex-start" } : { justifyContent: "flex-end" }]}>
                <View style={[styles.bubble, { backgroundColor: mine ? myProfile.data?.messageBubbleColor || colors.tint : colors.surface, borderColor: colors.border }]}>
                  {!mine && message.sender ? <UserIdentity name={message.sender.username || message.sender.name || t("member")} avatarEmoji={message.sender.avatarEmoji} badgeTitle={message.sender.badgeTitle} crownStyle={message.sender.crownStyle} role={message.sender.role} roomRole={message.sender.roomRole} style={{ alignSelf: "flex-start" }} nameStyle={[ui.meta, { color: colors.tint, textAlign: "right", fontWeight: "800" }]} /> : null}
                  {message.sender?.avatarUrl && !mine ? <Image source={{ uri: message.sender.avatarUrl }} style={styles.tinyAvatar} /> : null}
                  {message.type === "image" && message.assetUrl ? <Image source={{ uri: message.assetUrl }} resizeMode="cover" style={styles.chatImage} /> : null}
                  {(message.type === "audio" || message.type === "asset") && message.assetUrl ? <Pressable accessibilityRole="button" onPress={() => { void Linking.openURL(message.assetUrl!).catch(() => setLocalError(t("openAttachmentError"))); }} style={[styles.attachmentLink, { backgroundColor: colors.background }]}><Ionicons name={message.type === "audio" ? "play-circle" : "document-text"} size={19} color={colors.tint} /><Text style={[ui.meta, { color: colors.tint, fontWeight: "800" }]}>{message.type === "audio" ? t("playAudio") : t("openAttachment")}</Text></Pressable> : null}
                  <Text style={[ui.body, { color: mine ? myProfile.data?.messageTextColor || colors.background : colors.text }]}>{message.text || (message.type === "image" ? t("image") : t("media"))}</Text>
                  <Text style={[ui.meta, { color: mine ? myProfile.data?.messageTextColor || colors.background : colors.icon, opacity: 0.8, textAlign: "left" }]}>{new Date(message.createdAt).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })}</Text>
                </View>
              </View>
            );
          })}
        </ScrollView>
        {pendingAttachment ? <Surface style={[styles.pendingFile, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name={pendingAttachment.kind === "image" ? "image" : pendingAttachment.kind === "audio" ? "musical-notes" : "document-text"} size={18} color={colors.tint} /><Text style={[ui.meta, { color: colors.text, flex: 1, textAlign: "right" }]} numberOfLines={1}>{pendingAttachment.fileName} · {(pendingAttachment.sizeBytes / 1024).toFixed(0)} KB</Text><Pressable accessibilityLabel={t("removeAttachment")} onPress={() => setPendingAttachment(null)}><Ionicons name="close-circle" size={20} color={colors.error} /></Pressable></Surface> : null}
        {localError ? <Text style={{ color: colors.error, textAlign: "right" }}>{localError}</Text> : null}
        <View style={[styles.composer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable accessibilityRole="button" accessibilityLabel={t("addPhotoFile")} disabled={upload.isPending || send.isPending} onPress={() => { void pickAttachment(); }} style={[styles.send, { backgroundColor: colors.background }]}><Ionicons name={upload.isPending ? "hourglass" : "attach"} size={19} color={colors.tint} /></Pressable>
          <TextInput value={draft} onChangeText={setDraft} placeholder={t("writeMessage")} placeholderTextColor={colors.icon} style={[ui.input, styles.messageInput, { color: colors.text, borderColor: colors.border }]} multiline maxLength={4000} returnKeyType="send" onSubmitEditing={submit} />
          <Pressable disabled={(!draft.trim() && !pendingAttachment) || send.isPending || upload.isPending} onPress={submit} style={[styles.send, { backgroundColor: draft.trim() || pendingAttachment ? colors.tint : colors.border }]}><Ionicons name="send" size={18} color={colors.background} /></Pressable>
        </View>
        {upload.isPending ? <ActivityIndicator color={colors.tint} /> : null}
        {send.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text> : null}
      </Page>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  back: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  messageRow: { flexDirection: "row", alignItems: "flex-end" },
  bubble: { maxWidth: "86%", minWidth: 72, padding: 11, borderWidth: 1, borderRadius: 17, gap: 4 },
  tinyAvatar: { width: 24, height: 24, borderRadius: 12 },
  chatImage: { width: 224, height: 168, borderRadius: 12, alignSelf: "flex-end" },
  attachmentLink: { flexDirection: "row-reverse", alignItems: "center", gap: 7, borderRadius: 12, padding: 8, alignSelf: "flex-end" },
  pendingFile: { flexDirection: "row-reverse", alignItems: "center", gap: 7, borderWidth: 1, padding: 9 },
  announcement: { borderWidth: 1, padding: 11, gap: 7 },
  managePanel: { gap: 10, padding: 10 },
  announcementInput: { minHeight: 42, maxHeight: 88, textAlign: "right", textAlignVertical: "top" },
  memberRow: { flexDirection: "row-reverse", alignItems: "center", gap: 8, borderWidth: 1, borderRadius: 12, padding: 7 },
  memberActions: { flexDirection: "row-reverse", flexWrap: "wrap", gap: 5, justifyContent: "flex-start" },
  managerAction: { paddingHorizontal: 8, paddingVertical: 6, borderRadius: 10, alignItems: "center" },
  composer: { flexDirection: "row-reverse", alignItems: "flex-end", gap: 8, borderWidth: 1, borderRadius: 17, padding: 6 },
  messageInput: { flex: 1, minHeight: 44, maxHeight: 120, borderWidth: 0, paddingVertical: 9 },
  send: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
});
