import { Ionicons } from "@expo/vector-icons";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Image, Pressable, StyleSheet, Text, View } from "react-native";
import { LoginGate, Page, PageHeader, PrimaryButton, SectionTitle, Surface, ui } from "@/components/aria-ui";
import { UserIdentity } from "@/components/user-identity";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { formatLastSeen } from "@/lib/last-seen";
import { trpc } from "@/lib/trpc";
import { translateCoreScreen } from "@/lib/ui-locale-core-screens";

export default function PublicUserProfileScreen() {
  const colors = useColors();
  const { locale, t, tExtra } = useLanguage();
  const c = (key: import("@/lib/ui-locale-core-screens").CoreScreenLocaleKey) => translateCoreScreen(locale, key);
  const router = useRouter();
  const params = useLocalSearchParams<{ userId: string }>();
  const accountNumber = Number(params.userId);
  const { isAuthenticated, loading } = useAuth();
  const profile = trpc.users.get.useQuery({ accountNumber }, { enabled: isAuthenticated && Number.isInteger(accountNumber) && accountNumber > 0 });
  const friend = trpc.users.toggleFriend.useMutation({ onSuccess: () => profile.refetch() });
  const block = trpc.users.toggleBlock.useMutation({ onSuccess: () => profile.refetch() });
  const report = trpc.users.report.useMutation();
  const startCall = trpc.calls.start.useMutation({ onSuccess: ({ callId }) => router.push((`/call/${callId}`) as any) });
  const [confirmBlock, setConfirmBlock] = useState(false);
  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate />;
  const person = profile.data;
  const toggleBlock = () => { block.mutate({ accountNumber }, { onSuccess: () => setConfirmBlock(false) }); };

  return (
    <Page>
      <PageHeader eyebrow={t("profileTitle")} title={t("profile")} subtitle={t("helpPrivacy")} right={<Pressable onPress={() => router.back()} style={[styles.back, { backgroundColor: colors.surface }]}><Ionicons name="arrow-forward" color={colors.tint} size={18} /></Pressable>} />
      {profile.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
      {profile.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("retry")}</Text></Surface> : null}
      {person ? <>
        <Surface style={styles.hero}>
          {person.avatarUrl ? <Image source={{ uri: person.avatarUrl }} style={styles.avatar} /> : <View style={[styles.avatar, { backgroundColor: colors.background }]}><Ionicons name="person" size={35} color={colors.tint} /></View>}
          <UserIdentity name={person.username || person.name || `کاربر #${person.accountNumber ?? "—"}`} avatarEmoji={person.avatarEmoji} badgeTitle={person.badgeTitle} crownStyle={person.crownStyle} role={person.role} fontSize={22} style={{ justifyContent: "center" }} nameStyle={[styles.name, { color: colors.text }]} />
          <View style={[ui.row, { justifyContent: "center" }]}><View style={[styles.dot, { backgroundColor: person.isOnline ? colors.success : colors.icon }]} /><Text style={[ui.meta, { color: colors.icon }]}>{formatLastSeen(person.lastSeenAt, person.isOnline, locale, tExtra)}</Text></View>
          <Text style={[ui.body, { color: colors.icon, textAlign: "center" }]}>{[person.age ? `${person.age} ساله` : null, person.gender !== "unspecified" ? person.gender : null, person.city, person.country].filter(Boolean).join(" · ") || "عضو آریا چت"}</Text>
          {person.bio ? <Text style={[ui.body, { color: colors.text, textAlign: "center" }]}>{person.bio}</Text> : <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>این کاربر هنوز دربارهٔ خودش چیزی ننوشته.</Text>}
          <View style={styles.actions}>
            <PrimaryButton title={t("privateMessage")} icon="chatbubble-ellipses" onPress={() => person.accountNumber && router.push(`/message/${person.accountNumber}`)} />
            <PrimaryButton title="تماس صوتی" icon="call" disabled={startCall.isPending || person.isBlocked} onPress={() => startCall.mutate({ accountNumber })} />
            <PrimaryButton title={person.isFriend ? "حذف دوست" : "افزودن دوست"} icon={person.isFriend ? "person-remove" : "person-add"} quiet disabled={friend.isPending} onPress={() => friend.mutate({ accountNumber })} />
          </View>
          <View style={styles.actions}>
            <PrimaryButton title={person.isBlocked ? "رفع مسدودسازی" : "مسدود کردن"} icon="ban-outline" quiet onPress={() => setConfirmBlock(true)} />
            <PrimaryButton title="گزارش کاربر" icon="flag-outline" quiet disabled={report.isPending} onPress={() => report.mutate({ accountNumber, reason: "گزارش از صفحهٔ پروفایل" })} />
          </View>
        </Surface>
        {confirmBlock ? <Surface style={styles.confirm}><Text style={[styles.confirmTitle, { color: colors.text }]}>{person.isBlocked ? "مسدودسازی این کاربر برداشته شود؟" : "این کاربر مسدود شود؟"}</Text><Text style={[ui.meta, { color: colors.icon }]}>در صورت مسدودسازی، پیام خصوصی میان دو طرف محدود می‌شود.</Text><View style={styles.actions}><PrimaryButton title="تأیید" icon="checkmark" onPress={toggleBlock} disabled={block.isPending} /><PrimaryButton title="انصراف" quiet onPress={() => setConfirmBlock(false)} /></View></Surface> : null}
        {(friend.error || block.error || report.error || startCall.error) ? <Text style={{ color: colors.error, textAlign: "right" }}>{friend.error?.message || block.error?.message || report.error?.message || startCall.error?.message}</Text> : null}
        {(friend.isSuccess || report.isSuccess) ? <Text style={{ color: colors.success, textAlign: "right" }}>{friend.isSuccess ? "فهرست دوستان به‌روز شد." : "گزارش ثبت شد."}</Text> : null}
        <SectionTitle title="اطلاعات عمومی" />
        <Surface>
          <InfoRow icon="person-circle-outline" label="شمارهٔ حساب" value={`#${person.accountNumber ?? "—"}`} />
          <InfoRow icon="ribbon-outline" label="رتبهٔ چت" value={person.rankTitle} />
          <InfoRow icon="time-outline" label={tExtra("lastSeen")} value={formatLastSeen(person.lastSeenAt, person.isOnline, locale, tExtra)} />
          <InfoRow icon="location-outline" label="موقعیت" value={[person.city, person.country].filter(Boolean).join("، ") || "نمایش داده نشده"} />
          <InfoRow icon="people-outline" label="روم‌های عضو" value={String(person.membershipCount ?? 0)} />
        </Surface>
      </> : null}
    </Page>
  );
}

function InfoRow({ icon, label, value }: { icon: keyof typeof Ionicons.glyphMap; label: string; value: string }) {
  const colors = useColors();
  return <View style={[ui.spread, { paddingVertical: 5 }]}><View style={ui.row}><Ionicons name={icon} size={18} color={colors.tint} /><Text style={[ui.meta, { color: colors.icon }]}>{label}</Text></View><Text style={[ui.body, { color: colors.text }]}>{value}</Text></View>;
}

const styles = StyleSheet.create({ back: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" }, hero: { alignItems: "center", gap: 12, paddingVertical: 22 }, avatar: { width: 88, height: 88, borderRadius: 29, alignItems: "center", justifyContent: "center" }, name: { fontSize: 22, fontWeight: "900", textAlign: "center" }, dot: { width: 8, height: 8, borderRadius: 4 }, actions: { flexDirection: "row-reverse", alignItems: "center", gap: 8, width: "100%" }, confirm: { gap: 10 }, confirmTitle: { textAlign: "right", fontSize: 15, fontWeight: "800" } });
