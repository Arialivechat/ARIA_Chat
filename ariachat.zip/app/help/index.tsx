import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Linking, Pressable, StyleSheet, Text, View } from "react-native";
import { EmptyState, LoginGate, Page, PageHeader, PrimaryButton, SectionTitle, Surface, ui } from "@/components/aria-ui";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/hooks/use-language";
import { uiLocale } from "@/lib/ui-locale-help-message";

const SUPPORT_EMAIL = "arialivechat@gmail.com";
export default function HelpScreen() {
  const colors = useColors();
  const { locale } = useLanguage();
  const t = (key: Parameters<typeof uiLocale>[1], values?: Record<string, string | number>) => uiLocale(locale, key, values);
  const { isAuthenticated, loading } = useAuth();
  const adminSearch = trpc.users.search.useQuery({ query: "Administrator", limit: 5 }, { enabled: isAuthenticated });
  const [feedback, setFeedback] = useState("");
  const admin = adminSearch.data?.find((user) => user.name === "Administrator" || user.username === "Administrator");
  const openEmail = async (subject: string) => {
    const url = `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(subject)}`;
    try {
      const supported = await Linking.canOpenURL(url);
      if (!supported) { setFeedback(t("emailFallback")); return; }
      await Linking.openURL(url);
    } catch { setFeedback(t("emailCatch", { email: SUPPORT_EMAIL })); }
  };
  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={t("helpLogin")} />;

  return (
    <Page>
      <PageHeader eyebrow={t("helpEyebrow")} title={t("helpTitle")} subtitle={t("helpSubtitle")} right={<Pressable onPress={() => router.back()} style={[styles.back, { backgroundColor: colors.surface }]}><Ionicons name="arrow-forward" size={19} color={colors.tint} /></Pressable>} />
      <Surface style={styles.about}>
        <View style={[styles.icon, { backgroundColor: colors.background }]}><Ionicons name="chatbubbles-outline" size={23} color={colors.tint} /></View>
        <Text style={[styles.title, { color: colors.text }]}>{t("aboutTitle")}</Text>
        <Text style={[ui.body, { color: colors.icon }]}>{t("about")}</Text>
      </Surface>
      <SectionTitle title={t("faqTitle")} />
      {([1,2,3,4] as const).map((n) => <Surface key={n} style={styles.faq}><Text style={[styles.title, { color: colors.text }]}>{t(`faq${n}q` as Parameters<typeof uiLocale>[1])}</Text><Text style={[ui.body, { color: colors.icon }]}>{t(`faq${n}a` as Parameters<typeof uiLocale>[1])}</Text></Surface>)}
      <Surface style={{ gap: 9 }}>
        <SectionTitle title={t("rulesTitle")} />
        <Rule text={t("rule1")} />
        <Rule text={t("rule2")} />
        <Rule text={t("rule3")} />
        <Rule text={t("rule4")} />
        <Rule text={t("rule5")} />
      </Surface>
      <Surface style={{ gap: 10 }}>
        <SectionTitle title={t("contactTitle")} />
        <Text style={[ui.body, { color: colors.icon }]}>{t("contactCopy")}</Text>
        {admin ? <PrimaryButton title={t("adminMessage")} icon="chatbubble-ellipses" onPress={() => router.push(`/message/${admin.accountNumber}`)} /> : <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{adminSearch.isLoading ? t("adminSearching") : t("adminUnavailable")}</Text>}
        <PrimaryButton title={t("emailSupport")} icon="mail-outline" quiet onPress={() => openEmail(t("emailSupport"))} />
        <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{SUPPORT_EMAIL}</Text>
      </Surface>
      <Surface style={{ gap: 10 }}>
        <SectionTitle title={t("collaborationTitle")} />
        <Text style={[ui.body, { color: colors.icon }]}>{t("collaborationCopy")}</Text>
        <View style={styles.actions}><PrimaryButton title={t("collaboration")} icon="people-outline" onPress={() => openEmail(t("collaboration"))} /><PrimaryButton title={t("representation")} icon="storefront-outline" quiet onPress={() => openEmail(t("representation"))} /></View>
      </Surface>
      {feedback ? <Surface><Text style={{ textAlign: "right", color: colors.warning }}>{feedback}</Text></Surface> : null}
      {adminSearch.error ? <EmptyState icon="information-circle-outline" title={t("helpErrorTitle")} detail={t("helpErrorDetail")} /> : null}
    </Page>
  );
}

function Rule({ text }: { text: string }) {
  const colors = useColors();
  return <View style={styles.rule}><Ionicons name="checkmark-circle-outline" size={18} color={colors.tint} /><Text style={[ui.body, { color: colors.text, flex: 1 }]}>{text}</Text></View>;
}

const styles = StyleSheet.create({ back: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" }, about: { gap: 11, alignItems: "center" }, icon: { width: 50, height: 50, borderRadius: 17, alignItems: "center", justifyContent: "center" }, title: { fontSize: 14, fontWeight: "800", textAlign: "right" }, faq: { gap: 6 }, rule: { flexDirection: "row-reverse", alignItems: "flex-start", gap: 8 }, actions: { flexDirection: "row-reverse", gap: 8 } });
