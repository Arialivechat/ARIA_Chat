import { Ionicons } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useState } from "react";
import { ActivityIndicator, Image, KeyboardAvoidingView, Linking, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { LoginGate, Page, PageHeader, PrimaryButton, Surface, ui } from "@/components/aria-ui";
import { ActiveAdsTicker } from "@/components/active-ads-ticker";
import { UserIdentity } from "@/components/user-identity";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { getPrivateMessageRank } from "@/lib/chat-ranks";
import { trpc } from "@/lib/trpc";
import { useLanguage } from "@/hooks/use-language";
import { uiLocale } from "@/lib/ui-locale-help-message";
import { translateFriendsCalls, type FriendsCallsKey } from "@/lib/ui-locale-friends-calls";
import { MAX_IMAGE_UPLOAD_BYTES, MAX_NON_IMAGE_UPLOAD_BYTES } from "@/lib/media-limits";
import { translateProfileAvatars } from "@/lib/ui-locale-avatars";
import { AttachmentReadError, AttachmentTooLargeError, readPickerAssetBase64 } from "@/lib/chat-media-picker";

const ALLOWED_CHAT_TYPES = ["image/jpeg", "image/png", "image/webp", "audio/mpeg", "audio/mp4", "audio/aac", "application/pdf"];

export default function PrivateThreadScreen() {
  const colors = useColors();
  const { locale } = useLanguage();
  const t = (key: Parameters<typeof uiLocale>[1], values?: Record<string, string | number>) => uiLocale(locale, key, values);
  const callText = (key: FriendsCallsKey) => translateFriendsCalls(locale, key);
  const router = useRouter();
  const params = useLocalSearchParams<{ userId: string }>();
  // The path carries the public account number; internal database IDs never enter navigation.
  const accountNumber = Number(params.userId);
  const validAccountNumber = Number.isInteger(accountNumber) && accountNumber > 0;
  const { isAuthenticated, loading } = useAuth();
  const myProfile = trpc.profile.me.useQuery(undefined, { enabled: isAuthenticated });
  const person = trpc.users.get.useQuery({ accountNumber }, { enabled: isAuthenticated && validAccountNumber });
  const friends = trpc.friends.list.useQuery(undefined, { enabled: isAuthenticated && validAccountNumber });
  const thread = trpc.messages.privateThread.useQuery({ accountNumber, limit: 80 }, { enabled: isAuthenticated && validAccountNumber, refetchInterval: 3500 });
  const utils = trpc.useUtils();
  const [draft, setDraft] = useState("");
  const [replyPrefix, setReplyPrefix] = useState("");
  const [dismissedMessageIds, setDismissedMessageIds] = useState<Set<number>>(() => new Set());
  const [deleteTarget, setDeleteTarget] = useState<{ messageId: number; isMine: boolean; isDeleted: boolean } | null>(null);
  const [pendingAttachment, setPendingAttachment] = useState<{ id: number; fileName: string; kind: "image" | "audio" | "asset"; sizeBytes: number } | null>(null);
  const [localError, setLocalError] = useState("");
  const startCall = trpc.calls.start.useMutation({ onSuccess: ({ callId }) => router.push((`/call/${callId}`) as any), onError: (error) => setLocalError(error.message) });
  const send = trpc.messages.sendPrivate.useMutation({
    onSuccess: async () => {
      setDraft("");
      setReplyPrefix("");
      setPendingAttachment(null);
      setLocalError("");
      await thread.refetch();
    },
  });
  const upload = trpc.media.upload.useMutation();
  const deleteMessage = trpc.messages.deletePrivate.useMutation({
    onSuccess: async () => {
      setDeleteTarget(null);
      await Promise.all([thread.refetch(), utils.messages.inbox.invalidate()]);
    },
  });

  const isMutualFriend = Boolean(friends.data?.some((friend) => friend.accountNumber === accountNumber));
  const isDesignatedAdmin = myProfile.data?.accountNumber === 1 && myProfile.data?.role === "admin";
  const canCall = validAccountNumber && accountNumber !== myProfile.data?.accountNumber && (isMutualFriend || isDesignatedAdmin);

  if (loading) return <Page scroll={false}><ActivityIndicator color={colors.tint} /></Page>;
  if (!isAuthenticated) return <LoginGate title={t("messageLogin")} />;

  const submit = () => {
    const text = draft.trim();
    if ((!pendingAttachment && text.length < 2) || !validAccountNumber || send.isPending) return;
    send.mutate({
      accountNumber,
      text: text || undefined,
      type: pendingAttachment?.kind,
      assetId: pendingAttachment?.id,
    });
  };

  const pickAttachment = async () => {
    setLocalError("");
    let isImageAttachment = false;
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ALLOWED_CHAT_TYPES,
        copyToCacheDirectory: true,
        base64: true,
      });
      if (result.canceled) return;
      const asset = result.assets?.[0];
      if (!asset) throw new Error(t("fileRead"));
      const contentType = asset.mimeType?.toLowerCase().split(";")[0];
      if (!contentType || !ALLOWED_CHAT_TYPES.includes(contentType)) {
        throw new Error(t("fileTypes"));
      }
      isImageAttachment = contentType.startsWith("image/");
      const maxBytes = contentType.startsWith("image/") ? MAX_IMAGE_UPLOAD_BYTES : MAX_NON_IMAGE_UPLOAD_BYTES;
      const { base64Data } = await readPickerAssetBase64(asset, maxBytes);
      const uploaded = await upload.mutateAsync({
        fileName: asset.name || "attachment",
        contentType,
        base64Data,
      });
      setPendingAttachment({ id: uploaded.id, fileName: uploaded.fileName, kind: uploaded.kind, sizeBytes: uploaded.sizeBytes });
    } catch (error) {
      if (error instanceof AttachmentTooLargeError) setLocalError(isImageAttachment ? translateProfileAvatars(locale, "imageTooLarge") : t("fileSize"));
      else if (error instanceof AttachmentReadError) setLocalError(t("fileRead"));
      else setLocalError(error instanceof Error ? error.message : t("uploadFailed"));
    }
  };

  const beginReply = (message: NonNullable<typeof thread.data>[number]) => {
    const senderName = message.sender?.username || message.sender?.name || "عضو";
    const quote = (message.text || (message.type === "image" ? t("image") : t("attachment") )).replace(/\s+/g, " ").slice(0, 220);
    const prefix = `> ${senderName}: ${quote}\n`;
    setReplyPrefix(prefix);
    setDraft(prefix);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: colors.background }} behavior={Platform.OS === "ios" ? "padding" : "height"} keyboardVerticalOffset={0}>
      <Page scroll={false} bottomSafeArea>
        <PageHeader eyebrow={t("privateEyebrow")} title={person.data ? <UserIdentity name={person.data.username || person.data.name || `حساب #${accountNumber}`} avatarEmoji={person.data.avatarEmoji} badgeTitle={person.data.badgeTitle} crownStyle={person.data.crownStyle} role={person.data.role} fontSize={21} /> : `حساب #${accountNumber}`} subtitle={t("privateSubtitle")} right={<View style={{ flexDirection: "row", alignItems: "center", gap: 7 }}>
          {canCall ? <Pressable accessibilityRole="button" accessibilityLabel={callText("voiceCall")} disabled={startCall.isPending} onPress={() => startCall.mutate({ accountNumber })} style={{ minHeight: 38, flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, borderRadius: 12, backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border, opacity: startCall.isPending ? 0.65 : 1 }}><Ionicons name="call-outline" color={colors.tint} size={17} /><Text style={{ color: colors.tint, fontSize: 11, fontWeight: "800" }}>{startCall.isPending ? callText("callStarting") : callText("voiceCall")}</Text></Pressable> : null}
          <Pressable onPress={() => router.back()} style={[styles.back, { backgroundColor: colors.surface }]}><Ionicons name="arrow-forward" color={colors.tint} size={19} /></Pressable>
        </View>} />
        <ActiveAdsTicker />
        {!canCall && person.data && accountNumber !== myProfile.data?.accountNumber ? <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{callText("friendsOnlyCall")}</Text> : null}
        {person.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("error")}</Text></Surface> : null}
        {thread.isLoading ? <ActivityIndicator color={colors.tint} /> : null}
        {thread.error ? <Surface><Text style={{ color: colors.error, textAlign: "right" }}>{t("error")}</Text></Surface> : null}
        <ScrollView style={{ flex: 1 }} contentContainerStyle={{ paddingVertical: 8, gap: 11, flexGrow: 1 }} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          {(thread.data ?? []).filter((message) => !dismissedMessageIds.has(message.id)).map((message) => {
            const mine = message.isMine;
            const gender = mine ? myProfile.data?.gender ?? "unspecified" : message.sender?.gender ?? "unspecified";
            const count = mine ? myProfile.data?.chatMessageCount ?? 0 : message.sender?.chatMessageCount ?? 0;
            const rankOverride = mine ? myProfile.data?.rankLevel : message.sender?.rankLevel;
            const role = mine ? myProfile.data?.role : message.sender?.role;
            const rank = getPrivateMessageRank(
              count,
              gender,
              mine ? myProfile.data?.messageBubbleColor || colors.tint : message.sender?.messageBubbleColor || colors.surface,
              mine ? myProfile.data?.messageTextColor || colors.background : message.sender?.messageTextColor || colors.text,
              rankOverride,
              role,
            );
            const senderName = mine
              ? myProfile.data?.username || myProfile.data?.name || t("me")
              : message.sender?.username || message.sender?.name || t("member");
            const senderAccountNumber = message.sender?.accountNumber ?? (mine ? myProfile.data?.accountNumber : person.data?.accountNumber);
            const attachmentName = getAttachmentName(message.assetMetadata, t("attachment"));
            return (
              <View key={message.id} style={[styles.messageRow, { justifyContent: mine ? "flex-start" : "flex-end" }]}>
                <View style={[styles.card, { backgroundColor: rank.bodyColor, borderColor: rank.borderColor, shadowColor: rank.headerColor }]}>
                  <View style={[styles.cardHeader, { backgroundColor: rank.headerColor }]}>
                    {message.sender?.avatarUrl || (mine && myProfile.data?.avatarUrl)
                      ? <Image source={{ uri: mine ? myProfile.data?.avatarUrl || message.sender?.avatarUrl || "" : message.sender?.avatarUrl || "" }} style={styles.avatar} />
                      : <View style={[styles.avatar, { backgroundColor: "rgba(255,255,255,0.22)" }]}><Ionicons name="person" size={16} color={rank.headerTextColor} /></View>}
                    <View style={{ flex: 1, gap: 2 }}>
                      <UserIdentity name={senderName} avatarEmoji={mine ? myProfile.data?.avatarEmoji : message.sender?.avatarEmoji} badgeTitle={mine ? myProfile.data?.badgeTitle : message.sender?.badgeTitle} crownStyle={mine ? myProfile.data?.crownStyle : message.sender?.crownStyle} role={role} style={{ flex: 1 }} nameStyle={[styles.senderName, { color: rank.headerTextColor }]} />
                      <View style={styles.badges}>
                        <Text style={[styles.rankBadge, { color: rank.headerTextColor, borderColor: rank.headerTextColor }]}>{t("account", { number: senderAccountNumber ?? "—" })}</Text>
                        <Text style={[styles.rankBadge, { color: rank.headerTextColor, borderColor: rank.headerTextColor }]}>{rank.rankLabel}</Text>
                        {rank.isSpecialRole ? <Text style={[styles.rankBadge, { color: rank.headerTextColor, borderColor: rank.headerTextColor }]}>{rank.label}</Text> : null}
                      </View>
                    </View>
                    <Pressable accessibilityRole="button" accessibilityLabel={t("closeCard")} onPress={() => setDismissedMessageIds((current) => new Set(current).add(message.id))} style={styles.closeButton}><Ionicons name="close" size={16} color={rank.headerTextColor} /></Pressable>
                  </View>
                  <View style={styles.cardBody}>
                    {message.text ? <Text style={[ui.body, { color: rank.bodyTextColor, textAlign: "right" }]}>{message.text}</Text> : null}
                    {message.type === "image" && message.assetUrl
                      ? <Image source={{ uri: message.assetUrl }} resizeMode="cover" style={styles.imageAttachment} />
                      : message.assetUrl
                        ? <Pressable onPress={() => { void Linking.openURL(message.assetUrl!).catch(() => setLocalError(t("openFile"))); }} style={[styles.fileAttachment, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name={message.type === "audio" ? "musical-notes" : "document-attach-outline"} size={19} color={rank.headerColor} /><Text numberOfLines={1} style={{ flex: 1, color: colors.text, textAlign: "right" }}>{attachmentName}</Text><Ionicons name="open-outline" size={16} color={colors.icon} /></Pressable>
                        : null}
                    <Text style={[ui.meta, { color: rank.bodyTextColor, opacity: 0.72, textAlign: "left" }]}>{new Date(message.createdAt).toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" })}</Text>
                    <View style={[styles.actions, { borderTopColor: colors.border }]}>
                      {!message.deleted ? <Pressable accessibilityRole="button" onPress={() => beginReply(message)} style={[styles.actionButton, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="return-down-back" size={14} color={rank.headerColor} /><Text style={[styles.actionText, { color: colors.text }]}>{t("reply")}</Text></Pressable> : null}
                      {senderAccountNumber ? <Pressable accessibilityRole="button" onPress={() => router.push(`/user/${senderAccountNumber}`)} style={[styles.actionButton, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="person-circle-outline" size={15} color={rank.headerColor} /><Text style={[styles.actionText, { color: colors.text }]}>{t("aboutUser")}</Text></Pressable> : null}
                      <Pressable accessibilityRole="button" accessibilityLabel={t("deleteMessage")} onPress={() => { deleteMessage.reset(); setDeleteTarget({ messageId: message.id, isMine: mine, isDeleted: message.deleted }); }} style={[styles.actionButton, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name="trash-outline" size={14} color={colors.error} /><Text style={[styles.actionText, { color: colors.error }]}>{t("delete")}</Text></Pressable>
                    </View>
                  </View>
                </View>
              </View>
            );
          })}
        </ScrollView>
        {replyPrefix ? <View style={[styles.replyPreview, { backgroundColor: colors.surface, borderColor: colors.border }]}><View style={{ flex: 1 }}><Text style={[ui.meta, { color: colors.tint, fontWeight: "800", textAlign: "right" }]}>{t("replyDraft")}</Text><Text numberOfLines={1} style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{replyPrefix.trim()}</Text></View><Pressable accessibilityRole="button" accessibilityLabel={t("cancelQuote")} onPress={() => { setDraft((current) => current.startsWith(replyPrefix) ? current.slice(replyPrefix.length) : current); setReplyPrefix(""); }}><Ionicons name="close-circle" color={colors.icon} size={20} /></Pressable></View> : null}
        {pendingAttachment ? <View style={[styles.replyPreview, { backgroundColor: colors.surface, borderColor: colors.border }]}><Ionicons name={pendingAttachment.kind === "image" ? "image-outline" : pendingAttachment.kind === "audio" ? "musical-notes-outline" : "document-attach-outline"} size={18} color={colors.tint} /><Text numberOfLines={1} style={[ui.meta, { color: colors.text, flex: 1, textAlign: "right" }]}>{pendingAttachment.fileName} · {(pendingAttachment.sizeBytes / 1024 / 1024).toFixed(1)} MB</Text><Pressable accessibilityRole="button" accessibilityLabel={t("removeDraftAttachment")} onPress={() => setPendingAttachment(null)}><Ionicons name="close-circle" color={colors.icon} size={20} /></Pressable></View> : null}
        <View style={[styles.composer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Pressable accessibilityRole="button" accessibilityLabel={t("addFile")} disabled={upload.isPending || send.isPending} onPress={() => { void pickAttachment(); }} style={[styles.attachButton, { backgroundColor: colors.background }]}><Ionicons name={upload.isPending ? "hourglass-outline" : "attach-outline"} size={20} color={colors.tint} /></Pressable>
          <TextInput value={draft} onChangeText={setDraft} placeholder={t("compose")} placeholderTextColor={colors.icon} style={[ui.input, styles.input, { color: colors.text }]} multiline maxLength={4000} returnKeyType="send" blurOnSubmit onSubmitEditing={submit} />
          <Pressable disabled={(!draft.trim() || draft.trim().length < 2) && !pendingAttachment || send.isPending || upload.isPending} onPress={submit} style={[styles.send, { backgroundColor: ((draft.trim().length >= 2 || pendingAttachment) && !send.isPending && !upload.isPending) ? colors.tint : colors.border }]}><Ionicons name={send.isPending ? "hourglass-outline" : "send"} size={18} color={colors.background} /></Pressable>
        </View>
        {upload.isPending ? <Text style={[ui.meta, { color: colors.icon, textAlign: "right" }]}>{t("uploadProgress")}</Text> : null}
        {upload.error || send.error || localError ? <Text style={{ color: colors.error, textAlign: "right" }}>{localError || upload.error?.message || send.error?.message}</Text> : null}
        <Modal visible={Boolean(deleteTarget)} transparent animationType="fade" onRequestClose={() => { if (!deleteMessage.isPending) setDeleteTarget(null); }}>
          <View style={styles.modalBackdrop}>
            <View style={[styles.deleteDialog, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.senderName, { color: colors.text, fontSize: 16 }]}>{t("deleteMessage")}</Text>
              <Text style={[ui.meta, { color: colors.icon, textAlign: "right", lineHeight: 21 }]}>{t("deleteExplanation")}</Text>
              {deleteMessage.error ? <Text style={{ color: colors.error, textAlign: "right" }}>{t("error")}</Text> : null}
              <PrimaryButton title={t("deleteForMe")} icon="eye-off-outline" onPress={() => { if (deleteTarget) deleteMessage.mutate({ messageId: deleteTarget.messageId, scope: "me" }); }} disabled={deleteMessage.isPending} />
              {deleteTarget?.isMine && !deleteTarget.isDeleted ? <PrimaryButton title={t("deleteForEveryone")} icon="trash-outline" onPress={() => { if (deleteTarget) deleteMessage.mutate({ messageId: deleteTarget.messageId, scope: "everyone" }); }} disabled={deleteMessage.isPending} quiet /> : null}
              <PrimaryButton title={t("cancel")} onPress={() => setDeleteTarget(null)} disabled={deleteMessage.isPending} quiet />
            </View>
          </View>
        </Modal>
      </Page>
    </KeyboardAvoidingView>
  );
}

function getAttachmentName(value?: string | null, fallback = "Attachment") {
  if (!value) return fallback;
  try {
    const parsed = JSON.parse(value) as { fileName?: unknown };
    return typeof parsed.fileName === "string" ? parsed.fileName : fallback;
  } catch {
    return fallback;
  }
}

const styles = StyleSheet.create({
  back: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  messageRow: { flexDirection: "row", alignItems: "flex-end" },
  card: { width: "92%", overflow: "hidden", borderRadius: 19, borderWidth: 1, elevation: 4, shadowOpacity: 0.15, shadowRadius: 12, shadowOffset: { width: 0, height: 5 } },
  cardHeader: { flexDirection: "row-reverse", alignItems: "center", gap: 9, paddingHorizontal: 11, paddingVertical: 10 },
  avatar: { width: 34, height: 34, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  senderName: { fontSize: 13, fontWeight: "900", textAlign: "right" },
  badges: { flexDirection: "row-reverse", flexWrap: "wrap", alignItems: "center", gap: 4 },
  rankBadge: { borderWidth: 1, borderRadius: 99, paddingHorizontal: 6, paddingVertical: 1, fontSize: 9, fontWeight: "800", overflow: "hidden" },
  closeButton: { width: 29, height: 29, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.14)" },
  cardBody: { padding: 11, gap: 8 },
  imageAttachment: { width: "100%", height: 170, borderRadius: 12, backgroundColor: "#E6EAF0" },
  fileAttachment: { flexDirection: "row-reverse", alignItems: "center", gap: 8, minHeight: 42, paddingHorizontal: 10, borderWidth: 1, borderRadius: 12 },
  actions: { flexDirection: "row-reverse", alignItems: "center", gap: 7, paddingTop: 8, borderTopWidth: StyleSheet.hairlineWidth },
  actionButton: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 5, minHeight: 34, paddingHorizontal: 10, borderWidth: 1, borderRadius: 11 },
  actionText: { fontSize: 11, fontWeight: "800" },
  modalBackdrop: { flex: 1, backgroundColor: "rgba(8,13,28,0.62)", justifyContent: "center", alignItems: "center", padding: 18 },
  deleteDialog: { width: "100%", maxWidth: 420, gap: 12, padding: 17, borderRadius: 20, borderWidth: 1 },
  replyPreview: { flexDirection: "row-reverse", alignItems: "center", gap: 9, padding: 9, borderWidth: 1, borderRadius: 13 },
  composer: { flexDirection: "row-reverse", alignItems: "flex-end", gap: 7, borderWidth: 1, borderRadius: 17, padding: 6 },
  input: { flex: 1, minHeight: 44, maxHeight: 120, borderWidth: 0, paddingVertical: 9 },
  attachButton: { width: 40, height: 40, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  send: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" },
});
