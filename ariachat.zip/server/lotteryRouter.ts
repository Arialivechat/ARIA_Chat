import { z } from "zod";
import { protectedProcedure, router } from "./_core/trpc";
import { enterLottery, getLotteryCurrent } from "./lottery";
import { and, desc, eq } from "drizzle-orm";
import { lotteryRounds, lotteryEntries, profiles, users } from "../drizzle/schema";
import { getDb } from "./db";

export const lotteryRouter = router({
  current: protectedProcedure.query(({ ctx }) => getLotteryCurrent(ctx.user.id)),
  enter: protectedProcedure.input(z.object({ amount: z.number().int().min(1).max(Number.MAX_SAFE_INTEGER) }).strict()).mutation(async ({ ctx, input }) => {
    try { return await enterLottery(ctx.user.id, input.amount); }
    catch (error) { throw new Error(error instanceof Error ? error.message : "Lottery entry failed."); }
  }),
  history: protectedProcedure.input(z.object({ limit: z.number().int().min(1).max(50).optional() }).optional()).query(async ({ input }) => {
    const db = await getDb(); if (!db) throw new Error("Database unavailable.");
    const rounds = await db.select().from(lotteryRounds).where(eq(lotteryRounds.status, "settled")).orderBy(desc(lotteryRounds.startAt)).limit(input?.limit ?? 10);
    return Promise.all(rounds.map(async (round) => {
      const [winner] = round.winnerUserId ? await db.select({ userId: users.id, name: profiles.username }).from(users).leftJoin(profiles, eq(profiles.userId, users.id)).where(eq(users.id, round.winnerUserId)).limit(1) : [];
      return { id: round.id, startAt: round.startAt, endAt: round.endAt, grossPool: round.grossPool, fee: round.fee, prize: round.prize, settledAt: round.settledAt, winner: winner ?? null };
    }));
  }),
});
