import { randomInt } from "node:crypto";
import type { DiamondMiniGameType, DiamondMiniGameOutcome } from "../lib/diamond-games";

type RandomInt = (min: number, max: number) => number;

export interface DiamondMiniOutcome {
  outcome: DiamondMiniGameOutcome;
  choice?: number;
  board?: Array<"X" | "O" | null>;
  memoryDeck?: number[];
  matchedCards?: number[];
  matchedPairs?: number;
  winningNumbers?: number[];
  treasureSpots?: number[];
}

function pickThreeNumbers(rng: RandomInt): number[] {
  const values = Array.from({ length: 10 }, (_, index) => index + 1);
  for (let index = values.length - 1; index > 0; index -= 1) {
    const target = rng(0, index + 1);
    [values[index], values[target]] = [values[target], values[index]];
  }
  return values.slice(0, 3).sort((a, b) => a - b);
}

function makeMemoryDeck(rng: RandomInt): number[] {
  const deck = Array.from({ length: 8 }, (_, index) => index % 4);
  for (let index = deck.length - 1; index > 0; index -= 1) {
    const target = rng(0, index + 1);
    [deck[index], deck[target]] = [deck[target], deck[index]];
  }
  return deck;
}

function foundCardIndices(deck: number[], pairCount: number): number[] {
  const selected = new Set<number>();
  const pairs: number[][] = [];
  const byValue = new Map<number, number[]>();
  deck.forEach((value, index) => byValue.set(value, [...(byValue.get(value) ?? []), index]));
  for (const indexes of byValue.values()) pairs.push(indexes);
  pairs.slice(0, pairCount).forEach((pair) => pair.forEach((index) => selected.add(index)));
  return [...selected].sort((a, b) => a - b);
}

function makeTicTacToeBoard(won: boolean): Array<"X" | "O" | null> {
  return won
    ? ["X", "X", "X", "O", null, "O", null, null, null]
    : ["O", "O", "O", "X", null, "X", null, null, null];
}

export type RockPaperScissorsChoice = "rock" | "paper" | "scissors";

export function createRockPaperScissorsOutcome(
  choice: RockPaperScissorsChoice,
  rng: RandomInt = randomInt,
): { outcome: "win" | "tie" | "loss"; opponentChoice: RockPaperScissorsChoice; roll: number } {
  const roll = rng(0, 10);
  const outcome = roll < 3 ? "win" : roll < 6 ? "tie" : "loss";
  const beats: Record<RockPaperScissorsChoice, RockPaperScissorsChoice> = { rock: "scissors", paper: "rock", scissors: "paper" };
  const losesTo: Record<RockPaperScissorsChoice, RockPaperScissorsChoice> = { rock: "paper", paper: "scissors", scissors: "rock" };
  const opponentChoice = outcome === "win" ? beats[choice] : outcome === "tie" ? choice : losesTo[choice];
  return { outcome, opponentChoice, roll };
}

export function createDiamondMiniOutcome(
  gameType: DiamondMiniGameType,
  choice: number | undefined,
  rng: RandomInt = randomInt,
): DiamondMiniOutcome {
  if (gameType === "guess_number" || gameType === "treasure_hunt") {
    if (!Number.isSafeInteger(choice) || choice! < 1 || choice! > 10) {
      throw new Error("A choice from 1 to 10 is required for this game.");
    }
    const winningNumbers = pickThreeNumbers(rng);
    return {
      outcome: winningNumbers.includes(choice!) ? "win" : "loss",
      choice,
      ...(gameType === "guess_number" ? { winningNumbers } : { treasureSpots: winningNumbers }),
    };
  }

  const won = rng(0, 10) < 3;
  if (gameType === "tic_tac_toe") {
    return { outcome: won ? "win" : "loss", board: makeTicTacToeBoard(won) };
  }

  const memoryDeck = makeMemoryDeck(rng);
  const matchedPairs = won ? 4 : rng(0, 4);
  return {
    outcome: won ? "win" : "loss",
    memoryDeck,
    matchedPairs,
    matchedCards: foundCardIndices(memoryDeck, matchedPairs),
  };
}

export function diamondMiniPayout(amount: number, outcome: DiamondMiniGameOutcome): number {
  if (!Number.isSafeInteger(amount) || amount < 1 || amount > Math.floor(Number.MAX_SAFE_INTEGER / 10)) {
    throw new Error("The game amount is outside the supported range.");
  }
  return outcome === "win" ? amount * 3 : 0;
}
