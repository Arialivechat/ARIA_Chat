import { z } from "zod";
import { DIAMOND_MINI_GAME_TYPES } from "../lib/diamond-games";
import { APP_ROLES } from "../drizzle/schema";
import { PROFILE_BADGE_TITLES, PROFILE_CROWN_STYLES } from "../lib/profile-badges";
import { isProfileAvatarEmoji } from "../lib/profile-avatars";
import { isProfileAvatarUrl } from "../lib/profile-avatar-url";
import { isAdminBlockDurationHours } from "../lib/account-suspensions";
import { adminProcedure, moderatorProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  adminCountryRoomRequests, adminDecideCountryRoomRequest,
  adminChangeAccountNumber,
  adminArchiveNotice,
  adminBlockUser,
  adminAds,
  adminAdjustPoints,
  adminAudit,
  setRoomFavorite,
  adminDiamondTransactions,
  adminConfigureSalesAgent,
  adminSearchSalesAgentCandidates,
  adminRemoveSalesAgent,
  adminCreateNotice,
  adminDeleteAccount,
  adminCreateSpecialAccount,
  adminListSpecialAccounts,
  adminListNotices,
  adminModerateUser,
  adminReviewSecurityEvent,
  adminReports,
  adminRestoreDeletedAccount,
  adminResetUserPassword,
  adminSecurityEvents,
  adminResolveReport,
  adminSetRole,
  adminSetUserBadge,
  adminSetUserRank,
  adminSummary,
  adminUpdateAd,
  adminUpdateRoom,
  adminUsers,
  getCountryRoomRequest, requestCountryRoom,
  createAd,
  createReport,
  createRoom,
  deletePrivateMessage,
  clearRoomMessages,
  countUnreadPrivateMessages,
  getMyProfile,
  getPublicUser,
  getWallet,
  joinRoom,
  leaveRoom,
  roomMembers,
  listActiveAds,
  listPrivateThread,
  listRoomMessages,
  listRooms,
  listSalesAgents,
  listWalletHistory,
  listGameHistory,
  latestAdminNotice,
  privateInbox,
  rockPaperScissorsGame,
  diceGame,
  searchUsers,
  kickRoomMember,
  muteRoomMember,
  setRoomAnnouncement,
  setRoomModerator,
  setRoomStatus,
  setMyPassword,
  sendPrivateMessage,
  sendRoomMessage,
  tipRoom,
  toggleBlock,
  toggleFriend,
  listFriends, sendRoomInvite, listIncomingRoomInvites, respondRoomInvite,
  transferPoints,
  updateMyProfile,
  uploadChatMedia,
  spinGame,
  playDiamondMiniGame,
  shopCatalog,
  purchaseShopProduct,
  requestAccountDeletion,
} from "./socialDb";
import { MAX_CHAT_MEDIA_BASE64_CHARS } from "./media-validation";

const paginationInput = z.object({
  limit: z.number().int().min(1).max(100).optional(),
  offset: z.number().int().min(0).max(10_000).optional(),
});

const genderInput = z.enum(["unspecified", "male", "female", "nonbinary"]);
const roomKindInput = z.enum(["public", "private", "country", "official"]);
const roomListKindInput = z.enum(["public", "private", "country", "official", "favorites"]);
const roomStatusInput = z.enum(["active", "locked", "archived"]);
const adStatusInput = z.enum(["draft", "active", "paused", "archived"]);
const adUpdateStatusInput = z.enum(["active", "paused", "archived"]);
const reportStatusInput = z.enum(["open", "reviewed", "resolved", "dismissed"]);
const reportResolutionStatusInput = z.enum(["reviewed", "resolved", "dismissed"]);
const accountNumberInput = z.object({ accountNumber: z.number().int().min(1).max(2_000_000_000) });
const messageText = z.string().trim().min(1).max(4_000);
const optionalNullableString = (max: number) => z.string().trim().max(max).nullable().optional();
// Game payouts can reach 10x the wager; keep arithmetic within JS safe integers,
// but do not impose the former business cap of 1,000 diamonds.
const MAX_GAME_BET = Math.floor(Number.MAX_SAFE_INTEGER / 10);
const gameBetInput = z.object({ bet: z.number().int().min(1).max(MAX_GAME_BET), requestId: z.string().uuid() });
const salesCodeInput = z
  .string()
  .trim()
  .min(3)
  .max(64)
  .regex(/^[A-Za-z0-9_-]+$/, "کد فروشنده فقط می‌تواند شامل حروف انگلیسی، اعداد، خط تیره و زیرخط باشد.")
  .transform((value) => value.toUpperCase());

const profileUpdateInput = z
  .object({
    username: z
      .string()
      .trim()
      .min(3)
      .max(32)
      .regex(/^[\p{L}\p{N}_.-]+$/u, "نام کاربری فقط می‌تواند شامل حروف، اعداد، نقطه، خط تیره و زیرخط باشد.")
      .nullable()
      .optional(),
    avatarUrl: z.string().trim().max(2_048).nullable().optional().refine((value) => value === undefined || value === null || isProfileAvatarUrl(value), "نشانی عکس یا آواتار معتبر نیست."),
    avatarEmoji: z.string().max(32).nullable().optional().refine((value) => value === undefined || value === null || isProfileAvatarEmoji(value), "آواتار انتخاب‌شده معتبر نیست."),
    age: z.number().int().min(13).max(120).nullable().optional(),
    gender: genderInput.optional(),
    city: optionalNullableString(120),
    country: optionalNullableString(120),
    bio: optionalNullableString(2_000),
    isPrivate: z.boolean().optional(),
    privateId: optionalNullableString(128),
    language: z.enum(["fa", "en", "ar", "de", "tg", "ps", "ur", "sw", "es", "it", "tr", "hi"]).optional(),
    darkMode: z.boolean().optional(),
    // A random UUID installation identifier only. There is deliberately no IMEI field.
    installId: z.string().uuid().nullable().optional(),
  })
  .strict()
  .refine((value) => Object.keys(value).length > 0, "حداقل یک فیلد باید به‌روزرسانی شود.");

const mediaMessageInput = z
  .object({
    roomId: z.number().int().positive(),
    text: z.string().trim().min(1).max(4_000).optional(),
    type: z.enum(["text", "image", "audio", "asset"]).optional(),
    assetId: z.number().int().positive().optional(),
  })
  .superRefine((value, ctx) => {
    if (!value.text && !value.assetId) {
      ctx.addIssue({ code: "custom", message: "متن یا فایل پیام الزامی است.", path: ["text"] });
    }
    if (value.type && value.type !== "text" && !value.assetId) {
      ctx.addIssue({ code: "custom", message: "برای پیام رسانه‌ای فایل معتبر لازم است.", path: ["assetId"] });
    }
  });

/** ARIA Chat feature routers. Protected endpoints require a valid application session; roles are server-checked. */
export const socialRouter = router({
  profile: router({
    me: protectedProcedure.query(({ ctx }) => getMyProfile(ctx.user.id)),
    update: protectedProcedure.input(profileUpdateInput).mutation(({ ctx, input }) => updateMyProfile(ctx.user.id, input)),
    setPassword: protectedProcedure.input(z.object({ currentPassword: z.string().max(256).optional(), newPassword: z.string().min(1).max(256) })).mutation(({ ctx, input }) => setMyPassword(ctx.user.id, input)),
    deleteAccount: protectedProcedure.mutation(({ ctx }) => requestAccountDeletion(ctx.user.id)),
  }),

  notices: router({
    latest: protectedProcedure.query(({ ctx }) => latestAdminNotice(ctx.user.id)),
  }),

  media: router({
    upload: protectedProcedure
      .input(z.object({
        fileName: z.string().trim().min(1).max(180),
        contentType: z.string().trim().min(3).max(127),
        base64Data: z.string().min(8).max(MAX_CHAT_MEDIA_BASE64_CHARS),
      }))
      .mutation(({ ctx, input }) => uploadChatMedia(ctx.user.id, input)),
  }),

  users: router({
    search: protectedProcedure
      .input(
        paginationInput.extend({
          query: z.string().trim().min(1).max(100).optional(),
          gender: genderInput.optional(),
          ageMin: z.number().int().min(13).max(120).optional(),
          ageMax: z.number().int().min(13).max(120).optional(),
          city: z.string().trim().min(1).max(120).optional(),
          country: z.string().trim().min(1).max(120).optional(),
          onlineOnly: z.boolean().optional(),
          hasPhotoOnly: z.boolean().optional(),
        }).refine((value) => value.ageMin === undefined || value.ageMax === undefined || value.ageMin <= value.ageMax, {
          message: "حداقل سن نباید از حداکثر سن بیشتر باشد.",
          path: ["ageMin"],
        }),
      )
      .query(({ ctx, input }) => searchUsers(ctx.user.id, input)),
    get: protectedProcedure.input(accountNumberInput).query(({ ctx, input }) => getPublicUser(ctx.user.id, input.accountNumber)),
    toggleFriend: protectedProcedure
      .input(accountNumberInput)
      .mutation(({ ctx, input }) => toggleFriend(ctx.user.id, input.accountNumber)),
    toggleBlock: protectedProcedure
      .input(accountNumberInput)
      .mutation(({ ctx, input }) => toggleBlock(ctx.user.id, input.accountNumber)),
    report: protectedProcedure
      .input(
        z.object({
          accountNumber: z.number().int().min(1).max(2_000_000_000),
          reason: z.string().trim().min(3).max(500),
          details: z.string().trim().max(4_000).optional(),
          roomId: z.number().int().positive().optional(),
          messageId: z.number().int().positive().optional(),
        }),
      )
      .mutation(({ ctx, input }) => createReport(ctx.user.id, input)),
  }),

  friends: router({ list: protectedProcedure.query(({ ctx }) => listFriends(ctx.user.id)) }),
  roomInvites: router({
    incoming: protectedProcedure.query(({ ctx }) => listIncomingRoomInvites(ctx.user.id)),
    send: protectedProcedure.input(z.object({ roomId: z.number().int().positive(), accountNumber: z.number().int().min(1).max(2_000_000_000) })).mutation(({ ctx, input }) => sendRoomInvite(ctx.user.id, input.roomId, input.accountNumber)),
    respond: protectedProcedure.input(z.object({ invitationId: z.number().int().positive(), response: z.enum(["accepted", "declined"]) })).mutation(({ ctx, input }) => respondRoomInvite(ctx.user.id, input.invitationId, input.response)),
  }),
  rooms: router({
    list: protectedProcedure
      .input(paginationInput.extend({ kind: roomListKindInput.optional() }).optional())
      .query(({ ctx, input }) => listRooms(ctx.user.id, input ?? {})),
    setFavorite: protectedProcedure.input(z.object({ roomId: z.number().int().positive(), favorite: z.boolean() }))
      .mutation(({ ctx, input }) => setRoomFavorite(ctx.user.id, input.roomId, input.favorite)),
    create: protectedProcedure
      .input(
        z
          .object({
            name: z.string().trim().min(2).max(120),
            description: z.string().trim().max(4_000).optional(),
            kind: roomKindInput,
            country: z.string().trim().min(1).max(120).optional(),
            invitedUserIds: z.array(z.number().int().positive()).max(20).optional(),
          })
          .superRefine((value, ctx) => {
            if (value.kind === "country" && !value.country) {
              ctx.addIssue({ code: "custom", message: "کشور روم الزامی است.", path: ["country"] });
            }
          }),
      )
      .mutation(({ ctx, input }) => createRoom(ctx.user.id, input)),
    countryRequest: protectedProcedure.input(z.object({ roomId: z.number().int().positive() })).query(({ctx,input})=>getCountryRoomRequest(ctx.user.id,input.roomId)),
    requestCountry: protectedProcedure.input(z.object({roomId:z.number().int().positive(),country:z.string().trim().min(1).max(120)})).mutation(({ctx,input})=>requestCountryRoom(ctx.user.id,input)),
    join: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive() }))
      .mutation(({ ctx, input }) => joinRoom(ctx.user.id, input.roomId)),
    leave: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive() }))
      .mutation(({ ctx, input }) => leaveRoom(ctx.user.id, input.roomId)),
    members: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive() }))
      .query(({ ctx, input }) => roomMembers(ctx.user.id, input.roomId)),
    kickMember: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive(), accountNumber: z.number().int().min(1).max(2_000_000_000) }))
      .mutation(({ ctx, input }) => kickRoomMember(ctx.user.id, input.roomId, input.accountNumber)),
    muteMember: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive(), accountNumber: z.number().int().min(1).max(2_000_000_000), durationMinutes: z.number().int().min(0).max(1440) }))
      .mutation(({ ctx, input }) => muteRoomMember(ctx.user.id, input.roomId, input.accountNumber, input.durationMinutes)),
    setModerator: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive(), accountNumber: z.number().int().min(1).max(2_000_000_000), moderator: z.boolean() }))
      .mutation(({ ctx, input }) => setRoomModerator(ctx.user.id, input.roomId, input.accountNumber, input.moderator)),
    announcement: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive(), text: z.string().trim().max(1000).nullable().optional() }))
      .mutation(({ ctx, input }) => setRoomAnnouncement(ctx.user.id, input.roomId, input.text)),
    setStatus: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive(), status: roomStatusInput }))
      .mutation(({ ctx, input }) => setRoomStatus(ctx.user.id, input.roomId, input.status)),
    clearMessages: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive() }))
      .mutation(({ ctx, input }) => clearRoomMessages(ctx.user.id, input.roomId)),
    messages: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive(), limit: z.number().int().min(1).max(100).optional(), offset: z.number().int().min(0).max(10_000).optional() }))
      .query(({ ctx, input }) => listRoomMessages(ctx.user.id, input.roomId, input)),
    sendMessage: protectedProcedure.input(mediaMessageInput).mutation(({ ctx, input }) => sendRoomMessage(ctx.user.id, input)),
    tip: protectedProcedure
      .input(z.object({ roomId: z.number().int().positive(), amount: z.number().int().positive().max(1_000_000) }))
      .mutation(({ ctx, input }) => tipRoom(ctx.user.id, input.roomId, input.amount)),
  }),

  messages: router({
    unreadCount: protectedProcedure.query(({ ctx }) => countUnreadPrivateMessages(ctx.user.id)),
    inbox: protectedProcedure
      .input(paginationInput.optional())
      .query(({ ctx, input }) => privateInbox(ctx.user.id, input ?? {})),
    privateThread: protectedProcedure
      .input(z.object({ accountNumber: z.number().int().min(1).max(2_000_000_000), limit: z.number().int().min(1).max(100).optional(), offset: z.number().int().min(0).max(10_000).optional() }))
      .query(({ ctx, input }) => listPrivateThread(ctx.user.id, input.accountNumber, input)),
    sendPrivate: protectedProcedure
      .input(z.object({
        accountNumber: z.number().int().min(1).max(2_000_000_000),
        text: messageText.optional(),
        type: z.enum(["text", "image", "audio", "asset"]).optional(),
        assetId: z.number().int().positive().optional(),
      }).superRefine((value, ctx) => {
        if (!value.text && !value.assetId) ctx.addIssue({ code: "custom", message: "متن یا فایل پیام الزامی است.", path: ["text"] });
        if (value.type && value.type !== "text" && !value.assetId) ctx.addIssue({ code: "custom", message: "برای پیام رسانه‌ای فایل معتبر لازم است.", path: ["assetId"] });
      }))
      .mutation(({ ctx, input }) => sendPrivateMessage(ctx.user.id, input.accountNumber, input)),
    deletePrivate: protectedProcedure
      .input(z.object({ messageId: z.number().int().positive(), scope: z.enum(["me", "everyone"]) }))
      .mutation(({ ctx, input }) => deletePrivateMessage(ctx.user.id, input.messageId, input.scope)),
  }),

  wallet: router({
    me: protectedProcedure.query(({ ctx }) => getWallet(ctx.user.id)),
    transfer: protectedProcedure
      .input(z.object({ toAccountNumber: z.number().int().min(1).max(2_000_000_000), amount: z.number().int().positive().max(Number.MAX_SAFE_INTEGER), note: z.string().trim().max(500).optional() }))
      .mutation(({ ctx, input }) => transferPoints(ctx.user.id, input.toAccountNumber, input.amount, input.note)),
    history: protectedProcedure
      .input(paginationInput.optional())
      .query(({ ctx, input }) => listWalletHistory(ctx.user.id, input ?? {})),
  }),

  shop: router({
    catalog: protectedProcedure.query(({ ctx }) => shopCatalog(ctx.user.id)),
    purchase: protectedProcedure
      .input(z.object({ productId: z.enum(["message_sapphire", "message_gold", "message_rose", "invisibility_60m"]) }))
      .mutation(({ ctx, input }) => purchaseShopProduct(ctx.user.id, input.productId)),
  }),

  games: router({
    history: protectedProcedure
      .input(paginationInput.optional())
      .query(({ ctx, input }) => listGameHistory(ctx.user.id, input ?? {})),
    spin: protectedProcedure
      .input(gameBetInput)
      .mutation(({ ctx, input }) => spinGame(ctx.user.id, input.bet, input.requestId)),
    dice: protectedProcedure
      .input(gameBetInput.extend({ choice: z.enum(["odd", "even"]) }))
      .mutation(({ ctx, input }) => diceGame(ctx.user.id, input.bet, input.choice, input.requestId)),
    rockPaperScissors: protectedProcedure
      .input(gameBetInput.extend({ choice: z.enum(["rock", "paper", "scissors"]) }))
      .mutation(({ ctx, input }) => rockPaperScissorsGame(ctx.user.id, input.bet, input.choice, input.requestId)),
    mini: protectedProcedure
      .input(gameBetInput.extend({
        gameType: z.enum(DIAMOND_MINI_GAME_TYPES),
        choice: z.number().int().min(1).max(10).optional(),
      }).superRefine((input, ctx) => {
        const requiresChoice = input.gameType === "guess_number" || input.gameType === "treasure_hunt";
        if (requiresChoice && input.choice === undefined) {
          ctx.addIssue({ code: "custom", message: "برای این بازی یک انتخاب از ۱ تا ۱۰ لازم است.", path: ["choice"] });
        }
        if (!requiresChoice && input.choice !== undefined) {
          ctx.addIssue({ code: "custom", message: "این بازی انتخاب عددی نمی‌پذیرد.", path: ["choice"] });
        }
      }))
      .mutation(({ ctx, input }) => playDiamondMiniGame(ctx.user.id, input)),
  }),

  ads: router({
    activeList: protectedProcedure
      .input(z.object({ limit: z.number().int().min(1).max(100).optional() }).optional())
      .query(({ input }) => listActiveAds(input ?? {})),
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().trim().min(2).max(160),
          body: z.string().trim().min(1).max(4_000).optional(),
          targetUrl: z.string().url().max(2_048).optional(),
        }),
      )
      .mutation(({ ctx, input }) => createAd(ctx.user.id, input)),
  }),

  sales: router({
    listAgents: protectedProcedure.query(() => listSalesAgents()),
  }),

  admin: router({
    specialAccounts: adminProcedure.query(() => adminListSpecialAccounts()),
    createSpecialAccount: adminProcedure
      .input(z.object({
        accountNumber: z.number().int().min(2).max(100),
        username: z.string().trim().min(3).max(32).regex(/^[\p{L}\p{N}_.-]+$/u),
        password: z.string().min(6).max(256),
      }))
      .mutation(({ ctx, input }) => adminCreateSpecialAccount(ctx.user.id, input)),
    securityEvents: adminProcedure
      .input(paginationInput.optional())
      .query(({ input }) => adminSecurityEvents(input ?? {})),
    reviewSecurityEvent: adminProcedure
      .input(z.object({ eventId: z.number().int().positive(), status: z.enum(["reviewed", "dismissed"]) }))
      .mutation(({ ctx, input }) => adminReviewSecurityEvent(ctx.user.id, input.eventId, input.status)),
    summary: adminProcedure.query(({ ctx }) => adminSummary(ctx.user.id)),
    users: adminProcedure
      .input(paginationInput.extend({ query: z.string().trim().min(1).max(100).optional(), role: z.enum(APP_ROLES).optional() }).optional())
      .query(({ input }) => adminUsers(input ?? {})),
    deleteAccount: adminProcedure
      .input(z.object({ userId: z.number().int().positive(), reason: z.string().trim().min(3).max(500) }))
      .mutation(({ ctx, input }) => adminDeleteAccount(ctx.user.id, input.userId, input.reason)),
    restoreDeletedAccount: adminProcedure
      .input(z.object({ userId: z.number().int().positive(), reason: z.string().trim().min(3).max(500) }))
      .mutation(({ ctx, input }) => adminRestoreDeletedAccount(ctx.user.id, input.userId, input.reason)),
    resetUserPassword: adminProcedure
      .input(z.object({ userId: z.number().int().positive(), newPassword: z.string().min(6).max(256) }))
      .mutation(({ ctx, input }) => adminResetUserPassword(ctx.user.id, input)),
    setRole: adminProcedure
      .input(z.object({ userId: z.number().int().positive(), role: z.enum(APP_ROLES), reason: z.string().trim().min(3).max(500) }))
      .mutation(({ ctx, input }) => adminSetRole(ctx.user.id, input.userId, input.role, input.reason)),
    setUserBadge: adminProcedure
      .input(z.object({
        userId: z.number().int().positive(),
        badgeTitle: z.enum(PROFILE_BADGE_TITLES),
        crownStyle: z.enum(PROFILE_CROWN_STYLES).nullable(),
        reason: z.string().trim().min(3).max(500),
      }))
      .mutation(({ ctx, input }) => adminSetUserBadge(ctx.user.id, input.userId, input.badgeTitle, input.crownStyle, input.reason)),
    changeAccountNumber: adminProcedure
      .input(z.object({ userId: z.number().int().positive(), accountNumber: z.number().int().min(101).max(2_000_000_000) }))
      .mutation(({ ctx, input }) => adminChangeAccountNumber(ctx.user.id, input.userId, input.accountNumber)),
    setUserRank: adminProcedure
      .input(z.object({ userId: z.number().int().positive(), rankOverride: z.number().int().min(0).max(5).nullable(), note: z.string().trim().min(3).max(500) }))
      .mutation(({ ctx, input }) => adminSetUserRank(ctx.user.id, input.userId, input.rankOverride, input.note)),
    adjustPoints: adminProcedure
      .input(z.object({ accountNumber: z.number().int().positive(), amount: z.number().int().min(-Number.MAX_SAFE_INTEGER).max(Number.MAX_SAFE_INTEGER).refine((value) => value !== 0), note: z.string().trim().min(3).max(500) }))
      .mutation(({ ctx, input }) => adminAdjustPoints(ctx.user.id, input)),
    moderateUser: moderatorProcedure
      .input(
        z.object({
          userId: z.number().int().positive(),
          action: z.enum(["warn", "mute", "suspend", "restore"]),
          reason: z.string().trim().min(3).max(500),
          until: z.coerce.date().optional(),
          reportId: z.number().int().positive().optional(),
        }).superRefine((value, ctx) => {
          if ((value.action === "mute" || value.action === "suspend") && value.until && value.until <= new Date()) {
            ctx.addIssue({ code: "custom", message: "زمان محدودیت باید در آینده باشد.", path: ["until"] });
          }
        }),
      )
      .mutation(({ ctx, input }) => adminModerateUser(ctx.user.id, input)),
    blockUser: adminProcedure
      .input(z.object({
        userId: z.number().int().positive(),
        durationHours: z.number().int().nullable().refine((value) => value === null || isAdminBlockDurationHours(value), "مدت مسدودسازی معتبر نیست."),
        reason: z.string().trim().min(3).max(500),
      }))
      .mutation(({ ctx, input }) => adminBlockUser(ctx.user.id, input)),
    countryRoomRequests: adminProcedure.query(()=>adminCountryRoomRequests()),
    decideCountryRoomRequest: adminProcedure.input(z.object({requestId:z.number().int().positive(),decision:z.enum(["approved","rejected"]),reason:z.string().trim().min(3).max(500)})).mutation(({ctx,input})=>adminDecideCountryRoomRequest(ctx.user.id,input)),
    updateRoom: adminProcedure
      .input(
        z
          .object({
            roomId: z.number().int().positive(),
            name: z.string().trim().min(2).max(120).optional(),
            description: z.string().trim().max(4_000).nullable().optional(),
            status: roomStatusInput.optional(),
            kind: roomKindInput.optional(),
            country: z.string().trim().min(1).max(120).nullable().optional(),
          })
          .refine((value) => Object.keys(value).some((key) => key !== "roomId"), "حداقل یک فیلد روم باید به‌روزرسانی شود."),
      )
      .mutation(({ ctx, input }) => adminUpdateRoom(ctx.user.id, input)),
    ads: adminProcedure
      .input(paginationInput.extend({ status: adStatusInput.optional() }).optional())
      .query(({ input }) => adminAds(input ?? {})),
    updateAd: adminProcedure
      .input(z.object({ adId: z.number().int().positive(), status: adUpdateStatusInput }))
      .mutation(({ ctx, input }) => adminUpdateAd(ctx.user.id, input.adId, input.status)),
    configureSalesAgent: adminProcedure
      .input(
        z.object({
          agentUserId: z.number().int().positive(),
          code: salesCodeInput,
          discountBps: z.number().int().min(0).max(10_000),
          isActive: z.boolean(),
        }),
      )
      .mutation(({ ctx, input }) => adminConfigureSalesAgent(ctx.user.id, input)),
    searchSalesAgentCandidates: adminProcedure
      .input(z.object({ query: z.string().trim().min(2).max(100), limit: z.number().int().min(1).max(20).optional() }))
      .query(({ input }) => adminSearchSalesAgentCandidates(input.query, input.limit ?? 20)),
    removeSalesAgent: adminProcedure
      .input(z.object({ discountId: z.number().int().positive() }))
      .mutation(({ ctx, input }) => adminRemoveSalesAgent(ctx.user.id, input.discountId)),
    notices: adminProcedure
      .input(paginationInput.optional())
      .query(({ input }) => adminListNotices(input ?? {})),
    createNotice: adminProcedure
      .input(z.object({
        title: z.string().trim().min(2).max(160),
        body: z.string().trim().min(1).max(4_000),
        targetAccountNumber: z.number().int().min(1).max(2_000_000_000).optional(),
        durationDays: z.number().int().min(1).max(30).default(7),
      }))
      .mutation(({ ctx, input }) => adminCreateNotice(ctx.user.id, input)),
    archiveNotice: adminProcedure
      .input(z.object({ noticeId: z.number().int().positive() }))
      .mutation(({ ctx, input }) => adminArchiveNotice(ctx.user.id, input.noticeId)),
    reports: moderatorProcedure
      .input(paginationInput.extend({ status: reportStatusInput.optional() }).optional())
      .query(({ input }) => adminReports(input ?? {})),
    resolveReport: moderatorProcedure
      .input(z.object({ reportId: z.number().int().positive(), status: reportResolutionStatusInput }))
      .mutation(({ ctx, input }) => adminResolveReport(ctx.user.id, input.reportId, input.status)),
    audit: adminProcedure
      .input(paginationInput.extend({ actorUserId: z.number().int().positive().optional(), targetUserId: z.number().int().positive().optional(), action: z.string().trim().min(1).max(100).optional() }).optional())
      .query(({ input }) => adminAudit(input ?? {})),
    diamondTransactions: adminProcedure.input(paginationInput.optional()).query(({ input }) => adminDiamondTransactions(input ?? {})),
  }),
});
