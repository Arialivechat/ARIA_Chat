import { TRPCError } from "@trpc/server";
import { and, eq, lte } from "drizzle-orm";
import { profiles } from "../../drizzle/schema";
import { isSuspensionExpired } from "../../lib/account-suspensions";
import { getDb } from "../db";

/** Deny protected application actions while an account is suspended or deleted. */
export async function assertAccountNotBlocked(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "پایگاه‌داده در دسترس نیست." });
  }

  const [profile] = await db
    .select({
      accountStatus: profiles.accountStatus,
      deletedAt: profiles.deletedAt,
      suspendedUntil: profiles.suspendedUntil,
    })
    .from(profiles)
    .where(eq(profiles.userId, userId))
    .limit(1);

  if (!profile) return;
  if (profile.accountStatus === "deleted" || profile.deletedAt) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "این حساب حذف شده است و برای استفاده باید توسط Administrator بازیابی شود.",
    });
  }

  const now = new Date();
  if (isSuspensionExpired(profile.accountStatus, profile.suspendedUntil, now)) {
    await db
      .update(profiles)
      .set({ accountStatus: "active", suspendedUntil: null })
      .where(
        and(
          eq(profiles.userId, userId),
          eq(profiles.accountStatus, "suspended"),
          lte(profiles.suspendedUntil, now),
        ),
      );
    return;
  }

  if (profile.accountStatus === "suspended") {
    const candidate = profile.suspendedUntil ? new Date(String(profile.suspendedUntil)) : null;
    const until = candidate && Number.isFinite(candidate.getTime()) ? candidate.toISOString() : null;
    throw new TRPCError({
      code: "FORBIDDEN",
      message: until
        ? `این حساب تا ${until} به‌طور موقت مسدود است.`
        : "این حساب به‌طور دائم مسدود است؛ برای رفع مسدودی با Administrator تماس بگیرید.",
    });
  }
}
