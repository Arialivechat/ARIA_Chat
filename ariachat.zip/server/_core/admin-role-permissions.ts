export type RoleSubject = {
  userId: number;
  accountNumber: number | null;
  role: string;
};

/** Only public account #1 with the Administrator role may change another account's role. */
export function mayChangeAccountRole(actor: RoleSubject, target: RoleSubject): boolean {
  return actor.accountNumber === 1
    && actor.role === "admin"
    && actor.userId !== target.userId
    && target.accountNumber !== 1;
}
