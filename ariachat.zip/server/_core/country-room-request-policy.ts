export type CountryRoomDecision = "approved" | "rejected";

export function mayDecideCountryRoomRequest(identity: { accountNumber: number | null | undefined; role: string | null | undefined }): boolean {
  return identity.accountNumber === 1 && identity.role === "admin";
}

export function maySettleCountryRoomRequest(status: string): boolean {
  return status === "pending";
}

export function countryRoomDecisionRefunds(decision: CountryRoomDecision): boolean {
  return decision === "rejected";
}
