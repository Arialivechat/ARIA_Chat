export type VoiceCallPermissionInput = {
  callerUserId: number;
  targetUserId: number;
  callerAccountNumber: number | null;
  callerRole: string | null;
  mutualFriendship: boolean;
  blocked: boolean;
};

/** Friendship rows are undirected canonical pairs, so one row means both users are friends. */
export function canInitiateVoiceCall(input: VoiceCallPermissionInput): boolean {
  if (input.callerUserId === input.targetUserId || input.blocked) return false;
  const isDesignatedAdministrator = input.callerAccountNumber === 1 && input.callerRole === "admin";
  return isDesignatedAdministrator || input.mutualFriendship;
}
