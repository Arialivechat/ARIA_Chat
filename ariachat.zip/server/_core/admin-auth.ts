import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
import express, {
  type Express,
  type Request,
  type RequestHandler,
  type Response,
} from "express";
import { and, eq, gte, lte, sql } from "drizzle-orm";
import { accountNumbers, passwordCredentials, pointAccounts, profiles, specialAccountCredentials, users } from "../../drizzle/schema";
import { getDb, getUserByOpenId, upsertUser } from "../db";
import {
  getSessionCookieName,
  getSessionCookieOptions,
} from "./cookies";
import { sdk } from "./sdk";
import { hashLocalPassword, validateLocalPassword, verifyLocalPassword } from "./password-hash";

const ADMIN_USERNAME = "Administrator";
const ADMIN_OPEN_ID = "aria_chat_admin_account";
const ADMIN_LOGIN_METHOD = "admin-password";
const ADMIN_SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const LOGIN_BODY_LIMIT = "4kb";
const MAX_USERNAME_LENGTH = 64;
const MAX_PASSWORD_LENGTH = 1024;
const MAX_FAILED_ATTEMPTS = 5;
const FAILED_ATTEMPT_WINDOW_MS = 15 * 60 * 1000;
const MAX_TRACKED_REQUESTERS = 1_000;
const SUPPORTED_LANGUAGES = ["fa", "en", "ar", "de", "tg", "ps", "ur", "sw", "es", "it", "tr", "hi"] as const;
type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number];

type AdminLoginPayload = {
  username: string;
  password: string;
  language?: SupportedLanguage;
};

type FailedAttempt = {
  count: number;
  expiresAt: number;
  blockedUntil: number;
};

const failedAttempts = new Map<string, FailedAttempt>();
const loginBodyParser = express.json({ limit: LOGIN_BODY_LIMIT, strict: true });

function requesterKey(req: Request): string {
  return req.ip || req.socket.remoteAddress || "unknown";
}

function pruneExpiredAttempts(now: number): void {
  for (const [key, attempt] of failedAttempts) {
    if (attempt.expiresAt <= now) {
      failedAttempts.delete(key);
    }
  }
}

function discardOldestAttempt(): void {
  let oldestKey: string | undefined;
  let oldestExpiry = Number.POSITIVE_INFINITY;

  for (const [key, attempt] of failedAttempts) {
    if (attempt.expiresAt < oldestExpiry) {
      oldestKey = key;
      oldestExpiry = attempt.expiresAt;
    }
  }

  if (oldestKey) {
    failedAttempts.delete(oldestKey);
  }
}

function isRateLimited(key: string, now: number): boolean {
  pruneExpiredAttempts(now);
  const attempt = failedAttempts.get(key);
  return Boolean(attempt && attempt.blockedUntil > now);
}

function recordFailedAttempt(key: string, now: number): void {
  pruneExpiredAttempts(now);
  let attempt = failedAttempts.get(key);

  if (!attempt) {
    if (failedAttempts.size >= MAX_TRACKED_REQUESTERS) {
      discardOldestAttempt();
    }
    attempt = {
      count: 0,
      expiresAt: now + FAILED_ATTEMPT_WINDOW_MS,
      blockedUntil: 0,
    };
    failedAttempts.set(key, attempt);
  }

  attempt.count += 1;
  if (attempt.count >= MAX_FAILED_ATTEMPTS) {
    attempt.blockedUntil = now + FAILED_ATTEMPT_WINDOW_MS;
  }
}

function isAdminLoginPayload(value: unknown): value is AdminLoginPayload {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    return false;
  }

  const payload = value as Record<string, unknown>;
  const keys = Object.keys(payload);
  if (
    keys.length < 2 ||
    keys.length > 3 ||
    keys.some((key) => !["username", "password", "language"].includes(key)) ||
    !keys.includes("username") ||
    !keys.includes("password") ||
    typeof payload.username !== "string" ||
    typeof payload.password !== "string"
  ) {
    return false;
  }

  if (payload.language !== undefined && !SUPPORTED_LANGUAGES.includes(payload.language as SupportedLanguage)) {
    return false;
  }

  return (
    payload.username.length > 0 &&
    payload.username.length <= MAX_USERNAME_LENGTH &&
    payload.password.length > 0 &&
    payload.password.length <= MAX_PASSWORD_LENGTH
  );
}

function isExpectedUsername(username: string): boolean {
  return username.toLowerCase() === ADMIN_USERNAME.toLowerCase();
}

function digestPassword(password: string): Buffer {
  return createHash("sha256").update(password, "utf8").digest();
}

function passwordMatches(submittedPassword: string, configuredPassword: string | undefined): boolean {
  const submittedDigest = digestPassword(submittedPassword);
  const configuredDigest = digestPassword(configuredPassword ?? "");
  const hasConfiguredPassword =
    typeof configuredPassword === "string" && configuredPassword.trim().length > 0;

  return hasConfiguredPassword && timingSafeEqual(submittedDigest, configuredDigest);
}

const parseAdminLoginBody: RequestHandler = (req, res, next) => {
  loginBodyParser(req, res, (error?: unknown) => {
    if (error) {
      recordFailedAttempt(requesterKey(req), Date.now());
      res.status(400).json({ error: "Invalid login request" });
      return;
    }
    next();
  });
};

function buildUserResponse(user: NonNullable<Awaited<ReturnType<typeof getUserByOpenId>>>) {
  return {
    id: user.id,
    openId: user.openId,
    name: user.name,
    email: user.email,
    loginMethod: user.loginMethod,
    lastSignedIn: user.lastSignedIn.toISOString(),
  };
}

async function handleAdminLogin(req: Request, res: Response): Promise<void> {
  const now = Date.now();
  const requester = requesterKey(req);

  if (isRateLimited(requester, now)) {
    res.status(429).json({ error: "Too many login attempts" });
    return;
  }

  if (!isAdminLoginPayload(req.body)) {
    recordFailedAttempt(requester, now);
    res.status(400).json({ error: "Invalid login request" });
    return;
  }

  const { username, password } = req.body;
  const configuredPassword = process.env.ARIA_ADMIN_PASSWORD;
  const validPassword = passwordMatches(password, configuredPassword);
  const validUsername = isExpectedUsername(username);

  if (!validUsername || !validPassword) {
    recordFailedAttempt(requester, now);
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }

  try {
    const lastSignedIn = new Date();
    await upsertUser({
      openId: ADMIN_OPEN_ID,
      name: ADMIN_USERNAME,
      email: null,
      loginMethod: ADMIN_LOGIN_METHOD,
      role: "admin",
      lastSignedIn,
    });

    const user = await getUserByOpenId(ADMIN_OPEN_ID);
    if (!user) {
      throw new Error("Admin account is unavailable");
    }

    const sessionToken = await sdk.createSessionToken(ADMIN_OPEN_ID, {
      name: ADMIN_USERNAME,
      expiresInMs: ADMIN_SESSION_TTL_MS,
    });
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(getSessionCookieName(req), sessionToken, {
      ...cookieOptions,
      maxAge: ADMIN_SESSION_TTL_MS,
    });

    failedAttempts.delete(requester);
    res.json({
      sessionToken,
      user: buildUserResponse(user),
    });
  } catch {
    console.error("[AdminAuth] Login setup failed");
    res.status(500).json({ error: "Unable to complete login" });
  }
}

export function registerAdminAuthRoutes(app: Express): void {
  app.post("/api/auth/login", parseAdminLoginBody, (req, res) => {
    if (typeof req.body?.username === "string" && isExpectedUsername(req.body.username.trim())) {
      void handleAdminLogin(req, res);
      return;
    }
    void handlePasswordAccountLogin(req, res);
  });
  app.post("/api/auth/register", parseAdminLoginBody, handlePublicRegistration);
  app.post("/api/admin/login", parseAdminLoginBody, handleAdminLogin);
  app.post("/api/special/login", parseAdminLoginBody, handleSpecialAccountLogin);
}


const DUMMY_SPECIAL_PASSWORD_HASH = `scrypt$16384$8$1$${"0".repeat(32)}$${"0".repeat(128)}`;

async function handleSpecialAccountLogin(req: Request, res: Response): Promise<void> {
  const now = Date.now();
  const requester = requesterKey(req);
  if (isRateLimited(requester, now)) {
    res.status(429).json({ error: "Too many login attempts" });
    return;
  }
  if (!isAdminLoginPayload(req.body)) {
    recordFailedAttempt(requester, now);
    res.status(400).json({ error: "Invalid login request" });
    return;
  }

  const username = req.body.username.normalize("NFKC").trim().toLocaleLowerCase("fa-IR");
  const { password } = req.body;
  try {
    const db = await getDb();
    if (!db) {
      res.status(503).json({ error: "Authentication is temporarily unavailable" });
      return;
    }

    const [account] = await db
      .select({
        openId: users.openId,
        passwordHash: specialAccountCredentials.passwordHash,
        username: specialAccountCredentials.username,
        accountNumber: specialAccountCredentials.accountNumber,
      })
      .from(specialAccountCredentials)
      .innerJoin(users, eq(users.id, specialAccountCredentials.userId))
      .innerJoin(accountNumbers, eq(accountNumbers.accountNumber, specialAccountCredentials.accountNumber))
      .where(and(
        eq(specialAccountCredentials.username, username),
        eq(accountNumbers.userId, users.id),
        eq(accountNumbers.isReserved, true),
        gte(accountNumbers.accountNumber, 2),
        lte(accountNumbers.accountNumber, 100),
      ))
      .limit(1);

    const passwordMatchesAccount = await verifyLocalPassword(
      password,
      account?.passwordHash ?? DUMMY_SPECIAL_PASSWORD_HASH,
    );
    if (!account || !passwordMatchesAccount) {
      recordFailedAttempt(requester, now);
      res.status(401).json({ error: "Invalid credentials" });
      return;
    }

    const lastSignedIn = new Date();
    await db.update(users).set({ lastSignedIn }).where(eq(users.openId, account.openId));
    const user = await getUserByOpenId(account.openId);
    if (!user) throw new Error("Reserved account is unavailable");

    const sessionToken = await sdk.createSessionToken(account.openId, {
      name: account.username,
      expiresInMs: ADMIN_SESSION_TTL_MS,
    });
    const cookieOptions = getSessionCookieOptions(req);
    res.cookie(getSessionCookieName(req), sessionToken, {
      ...cookieOptions,
      maxAge: ADMIN_SESSION_TTL_MS,
    });

    failedAttempts.delete(requester);
    res.json({ sessionToken, user: buildUserResponse(user) });
  } catch {
    console.error("[SpecialAuth] Login setup failed");
    res.status(500).json({ error: "Unable to complete login" });
  }
}

const REGISTRATION_WINDOW_MS = 60 * 60 * 1000;
const MAX_REGISTRATIONS_PER_WINDOW = 5;
const registrationAttempts = new Map<string, { count: number; resetAt: number }>();
const PUBLIC_SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

function isValidPublicUsername(username: string): boolean {
  return username.length >= 3 && username.length <= 32 && /^[\p{L}\p{N}_.-]+$/u.test(username);
}

function normalizedUsername(username: string): string {
  return username.normalize("NFKC").trim().toLocaleLowerCase("fa-IR");
}

function allowRegistration(requester: string, now: number): boolean {
  for (const [key, value] of registrationAttempts) {
    if (value.resetAt <= now) registrationAttempts.delete(key);
  }
  const existing = registrationAttempts.get(requester);
  if (existing && existing.count >= MAX_REGISTRATIONS_PER_WINDOW) return false;
  if (registrationAttempts.size >= MAX_TRACKED_REQUESTERS && !existing) {
    registrationAttempts.delete(registrationAttempts.keys().next().value ?? "");
  }
  const attempt = existing ?? { count: 0, resetAt: now + REGISTRATION_WINDOW_MS };
  attempt.count += 1;
  registrationAttempts.set(requester, attempt);
  return true;
}

async function handlePasswordAccountLogin(req: Request, res: Response): Promise<void> {
  const now = Date.now();
  const requester = requesterKey(req);
  if (isRateLimited(requester, now)) {
    res.status(429).json({ error: "Too many login attempts" });
    return;
  }
  if (!isAdminLoginPayload(req.body)) {
    recordFailedAttempt(requester, now);
    res.status(400).json({ error: "Invalid login request" });
    return;
  }

  const username = normalizedUsername(req.body.username);
  const password = req.body.password;
  try {
    const db = await getDb();
    if (!db) {
      res.status(503).json({ error: "Authentication is temporarily unavailable" });
      return;
    }

    let account: { openId: string; username: string; passwordHash: string; loginMethod: string | null } | undefined;
    const [publicAccount] = await db.select({
      openId: users.openId,
      username: passwordCredentials.username,
      passwordHash: passwordCredentials.passwordHash,
      loginMethod: users.loginMethod,
    }).from(passwordCredentials)
      .innerJoin(users, eq(users.id, passwordCredentials.userId))
      .innerJoin(accountNumbers, eq(accountNumbers.userId, users.id))
      .where(and(
        eq(passwordCredentials.username, username),
        eq(accountNumbers.isReserved, false),
        gte(accountNumbers.accountNumber, 101),
      )).limit(1);

    if (publicAccount) {
      account = publicAccount;
    } else {
      const [reservedAccount] = await db.select({
        openId: users.openId,
        username: specialAccountCredentials.username,
        passwordHash: specialAccountCredentials.passwordHash,
        loginMethod: users.loginMethod,
      }).from(specialAccountCredentials)
        .innerJoin(users, eq(users.id, specialAccountCredentials.userId))
        .innerJoin(accountNumbers, eq(accountNumbers.accountNumber, specialAccountCredentials.accountNumber))
        .where(and(
          eq(specialAccountCredentials.username, username),
          eq(accountNumbers.userId, users.id),
          eq(accountNumbers.isReserved, true),
          gte(accountNumbers.accountNumber, 2),
          lte(accountNumbers.accountNumber, 100),
        )).limit(1);
      account = reservedAccount;
    }

    const passwordIsValid = await verifyLocalPassword(password, account?.passwordHash ?? DUMMY_SPECIAL_PASSWORD_HASH);
    if (!account || !passwordIsValid) {
      recordFailedAttempt(requester, now);
      res.status(401).json({ error: "Invalid username or password" });
      return;
    }

    const lastSignedIn = new Date();
    await db.update(users).set({ lastSignedIn }).where(eq(users.openId, account.openId));
    const user = await getUserByOpenId(account.openId);
    if (!user) throw new Error("Password account is unavailable");

    const expiresInMs = account.loginMethod === "password" ? PUBLIC_SESSION_TTL_MS : ADMIN_SESSION_TTL_MS;
    const sessionToken = await sdk.createSessionToken(account.openId, { name: account.username, expiresInMs });
    res.cookie(getSessionCookieName(req), sessionToken, { ...getSessionCookieOptions(req), maxAge: expiresInMs });
    failedAttempts.delete(requester);
    res.json({ sessionToken, user: buildUserResponse(user) });
  } catch {
    console.error("[PasswordAuth] Login failed");
    res.status(500).json({ error: "Unable to complete login" });
  }
}

async function handlePublicRegistration(req: Request, res: Response): Promise<void> {
  const now = Date.now();
  const requester = requesterKey(req);
  if (!allowRegistration(requester, now)) {
    res.status(429).json({ error: "Too many registration attempts" });
    return;
  }
  if (!isAdminLoginPayload(req.body)) {
    res.status(400).json({ error: "Invalid registration request" });
    return;
  }

  const username = req.body.username.normalize("NFKC").trim();
  const normalized = normalizedUsername(username);
  const password = req.body.password;
  const language = req.body.language ?? "fa";
  if (!isValidPublicUsername(username) || normalized === ADMIN_USERNAME.toLocaleLowerCase("en-US")) {
    res.status(400).json({ error: "نام کاربری باید ۳ تا ۳۲ نویسهٔ معتبر باشد و نام Administrator رزرو است." });
    return;
  }
  if (!validateLocalPassword(password)) {
    res.status(400).json({ error: "رمز عبور باید بین ۶ تا ۲۵۶ بایت باشد." });
    return;
  }

  try {
    const passwordHash = await hashLocalPassword(password);
    const db = await getDb();
    if (!db) {
      res.status(503).json({ error: "Registration is temporarily unavailable" });
      return;
    }
    const openId = `aria_password_${randomUUID()}`;
    const nowDate = new Date();
    const created = await db.transaction(async (tx) => {
      await tx.insert(accountNumbers).values(Array.from({ length: 100 }, (_, index) => ({
        accountNumber: index + 1,
        isReserved: true,
      }))).onDuplicateKeyUpdate({ set: { accountNumber: sql`${accountNumbers.accountNumber}` } });

      const [publicCredentialOwner] = await tx.select({ userId: passwordCredentials.userId }).from(passwordCredentials)
        .where(eq(passwordCredentials.username, normalized)).limit(1);
      const [specialCredentialOwner] = await tx.select({ userId: specialAccountCredentials.userId }).from(specialAccountCredentials)
        .where(eq(specialAccountCredentials.username, normalized)).limit(1);
      const [profileOwner] = await tx.select({ userId: profiles.userId }).from(profiles)
        .where(sql`LOWER(${profiles.username}) = ${normalized}`).limit(1);
      if (publicCredentialOwner || specialCredentialOwner || profileOwner) {
        throw new Error("USERNAME_TAKEN");
      }

      const inserted = await tx.insert(users).values({
        openId,
        name: username,
        email: null,
        loginMethod: "password",
        role: "user",
        lastSignedIn: nowDate,
      });
      const userId = Number(inserted[0].insertId);
      if (!Number.isInteger(userId) || userId < 1) throw new Error("ACCOUNT_CREATE_FAILED");
      await tx.insert(profiles).values({ userId, username, language, lastSeenAt: nowDate });
      await tx.insert(passwordCredentials).values({ userId, username: normalized, passwordHash });
      const accountInsert = await tx.insert(accountNumbers).values({ userId, isReserved: false, claimedAt: nowDate });
      const accountNumber = Number(accountInsert[0].insertId);
      if (!Number.isInteger(accountNumber) || accountNumber < 101) throw new Error("ACCOUNT_NUMBER_FAILED");
      await tx.insert(pointAccounts).values({ userId, balance: 0 });
      return { userId, accountNumber };
    });
    const user = await getUserByOpenId(openId);
    if (!user) throw new Error("ACCOUNT_CREATE_FAILED");
    const sessionToken = await sdk.createSessionToken(openId, { name: username, expiresInMs: PUBLIC_SESSION_TTL_MS });
    res.cookie(getSessionCookieName(req), sessionToken, { ...getSessionCookieOptions(req), maxAge: PUBLIC_SESSION_TTL_MS });
    failedAttempts.delete(requester);
    res.status(201).json({ sessionToken, accountNumber: created.accountNumber, user: buildUserResponse(user) });
  } catch (error) {
    if (error instanceof Error && error.message === "USERNAME_TAKEN") {
      res.status(409).json({ error: "این نام کاربری قبلاً استفاده شده است." });
      return;
    }
    console.error("[PasswordAuth] Registration failed");
    res.status(500).json({ error: "Unable to complete registration" });
  }
}
