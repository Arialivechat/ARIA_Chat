import { eq } from "drizzle-orm";
import { profiles } from "../../drizzle/schema";
import { getDb } from "../db";

const LAST_SEEN_WRITE_INTERVAL_MS = 60_000;

/** Rejects soft-deleted accounts and records activity at most once per minute. */
export async function refreshAccountActivity(userId: number): Promise<boolean> {
  const db = await getDb();
  if (!db) return true;

  const [profile] = await db
    .select({ accountStatus: profiles.accountStatus, deletedAt: profiles.deletedAt, lastSeenAt: profiles.lastSeenAt })
    .from(profiles)
    .where(eq(profiles.userId, userId))
    .limit(1);

  if (profile?.accountStatus === "deleted" || profile?.deletedAt) return false;
  if (!profile) return true;

  const now = new Date();
  if (!profile.lastSeenAt || now.getTime() - profile.lastSeenAt.getTime() >= LAST_SEEN_WRITE_INTERVAL_MS) {
    await db.update(profiles).set({ lastSeenAt: now }).where(eq(profiles.userId, userId));
  }
  return true;
}
