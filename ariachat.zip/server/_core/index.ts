import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { createCorsMiddleware } from "./cors";
import { clearLegacySessionCookie } from "./cookies";
import { registerAdminAuthRoutes } from "./admin-auth";
import { RetentionCallbackError, messageRetentionCallbackPath, runScheduledMessageRetention } from "../retention";
import { runLotterySettlement } from "../lottery";

async function startServer() {
  const app = express();
  const server = createServer(app);

  app.use(createCorsMiddleware());
  app.use(clearLegacySessionCookie());

  // Register the credential endpoint before the broader parsers so it keeps its small body limit.
  registerAdminAuthRoutes(app);

  app.use((req, res, next) => {
    const procedures = req.path.startsWith("/api/trpc/")
      ? req.path.slice("/api/trpc/".length).split(",")
      : [];
    if (req.method === "POST" && procedures.includes("media.upload")) {
      return express.json({ limit: "40mb" })(req, res, next);
    }
    return next();
  });
  app.use(express.json({ limit: "15mb" }));
  app.use(express.urlencoded({ limit: "100kb", extended: true }));

  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.post(messageRetentionCallbackPath, async (req, res) => {
    try {
      const result = await runScheduledMessageRetention(req.headers.cookie);
      res.status(200).json(result);
    } catch (error) {
      const statusCode = error instanceof RetentionCallbackError ? error.statusCode : 500;
      const message = error instanceof RetentionCallbackError ? error.message : "Message retention failed; retry is safe.";
      res.status(statusCode).json({ error: message });
    }
  });

  app.post("/api/scheduled/lottery-settlement", async (req, res) => {
    try {
      const result = await runLotterySettlement(req.headers.cookie);
      res.status(200).json(result);
    } catch (error) {
      const statusCode = error instanceof RetentionCallbackError ? error.statusCode : 500;
      res.status(statusCode).json({ error: error instanceof RetentionCallbackError ? error.message : "Lottery settlement failed; retry is safe." });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const port = parseInt(process.env.PORT || "3000");
  server.listen(port, () => {
    console.log("[api] server listening");
  });
}

startServer().catch(() => {
  console.error("[api] server failed to start");
});
