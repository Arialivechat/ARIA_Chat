import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { sdk } from "./sdk";
import { refreshAccountActivity } from "./user-activity";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(opts: CreateExpressContextOptions): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch (error) {
    // Authentication is optional for public procedures.
    user = null;
  }

  if (user) {
    try {
      if (!await refreshAccountActivity(user.id)) user = null;
    } catch {
      // Keep the session usable during a transient database outage; protected
      // data operations will still report their own database availability.
      console.warn("[auth] Account activity check unavailable");
    }
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
