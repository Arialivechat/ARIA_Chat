import { jwtVerify } from "jose";
import { and, asc, eq, inArray, lte, notExists } from "drizzle-orm";
import { parse as parseCookieHeader } from "cookie";
import { mediaAssets, messages, scheduledMaintenance } from "../drizzle/schema";
import { getDb } from "./db";
import { ENV } from "./_core/env";

const JOB_KEY = "message-retention";
const JOB_COOKIE = "app_session_id";
const CALLBACK_PATH = "/api/scheduled/message-retention";
const RETENTION_MS = 4 * 24 * 60 * 60 * 1000;
const BATCH_SIZE = 500;

export class RetentionCallbackError extends Error {
  constructor(readonly statusCode: number, message: string) {
    super(message);
    this.name = "RetentionCallbackError";
  }
}

type PlatformTaskIdentity = {
  openId?: unknown;
  projectId?: unknown;
  taskUid?: unknown;
};

export function getPlatformTicket(cookieHeader: string | undefined): string {
  if (!cookieHeader) throw new RetentionCallbackError(401, "Scheduled callback authentication is required.");
  const token = parseCookieHeader(cookieHeader)[JOB_COOKIE];
  if (!token) throw new RetentionCallbackError(401, "Scheduled callback authentication is required.");
  return token;
}

export async function resolveAuthorizedTaskUid(token: string): Promise<string> {
  if (!ENV.cookieSecret || !ENV.appId || !ENV.oAuthServerUrl) {
    throw new RetentionCallbackError(503, "Scheduled callback authentication is not configured.");
  }

  let payload: Record<string, unknown>;
  try {
    const verified = await jwtVerify(token, new TextEncoder().encode(ENV.cookieSecret), {
      algorithms: ["HS256"],
    });
    payload = verified.payload as Record<string, unknown>;
  } catch {
    throw new RetentionCallbackError(401, "Scheduled callback authentication failed.");
  }

  if ((payload.projectId ?? payload.appId) !== ENV.appId || typeof payload.openId !== "string" || !payload.openId.startsWith("cron_")) {
    throw new RetentionCallbackError(403, "Scheduled callback identity is not authorized for this project.");
  }

  const base = ENV.oAuthServerUrl.endsWith("/") ? ENV.oAuthServerUrl : `${ENV.oAuthServerUrl}/`;
  const identityUrl = new URL("webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt", base);
  let response: Response;
  try {
    response = await fetch(identityUrl, {
      method: "POST",
      headers: { "content-type": "application/json", accept: "application/json" },
      body: JSON.stringify({ jwt_token: token, project_id: ENV.appId }),
    });
  } catch {
    throw new RetentionCallbackError(503, "Scheduled callback identity could not be resolved.");
  }
  if (!response.ok) throw new RetentionCallbackError(401, "Scheduled callback identity could not be resolved.");

  let identity: PlatformTaskIdentity;
  try {
    identity = (await response.json()) as PlatformTaskIdentity;
  } catch {
    throw new RetentionCallbackError(401, "Scheduled callback identity could not be resolved.");
  }
  if (
    identity.openId !== payload.openId ||
    identity.projectId !== ENV.appId ||
    typeof identity.taskUid !== "string" ||
    identity.taskUid.length < 1
  ) {
    throw new RetentionCallbackError(403, "Scheduled callback task identity is not valid.");
  }
  return identity.taskUid;
}

async function purgeExpiredMessages(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, cutoff: Date) {
  let deletedMessages = 0;
  for (;;) {
    const batch = await db
      .select({ id: messages.id, assetUrl: messages.assetUrl })
      .from(messages)
      .where(lte(messages.createdAt, cutoff))
      .orderBy(asc(messages.id))
      .limit(BATCH_SIZE);
    if (!batch.length) break;

    const ids = batch.map((message) => message.id);
    const stableAssetUrls = [...new Set(
      batch
        .map((message) => message.assetUrl)
        .filter((url): url is string => typeof url === "string" && url.startsWith("/manus-storage/")),
    )];

    const removed = await db.transaction(async (tx) => {
      const result = await tx.delete(messages).where(inArray(messages.id, ids));
      if (stableAssetUrls.length) {
        // Runtime storage can remove only the database index; the managed object bytes
        // require the separate owner/operator storage-delete surface.
        await tx.delete(mediaAssets).where(and(
          inArray(mediaAssets.stableUrl, stableAssetUrls),
          notExists(tx.select({ id: messages.id }).from(messages).where(eq(messages.assetUrl, mediaAssets.stableUrl))),
        ));
      }
      return Number(result[0]?.affectedRows ?? 0);
    });

    deletedMessages += removed;
    if (removed === 0) break;
  }
  return deletedMessages;
}

/** The request body is deliberately ignored: only the signed platform task UID selects the job. */
export async function runScheduledMessageRetention(cookieHeader: string | undefined) {
  const token = getPlatformTicket(cookieHeader);
  const taskUid = await resolveAuthorizedTaskUid(token);
  const db = await getDb();
  if (!db) throw new RetentionCallbackError(503, "Database is not available.");

  const [job] = await db.select({ id: scheduledMaintenance.id })
    .from(scheduledMaintenance)
    .where(and(
      eq(scheduledMaintenance.jobKey, JOB_KEY),
      eq(scheduledMaintenance.taskUid, taskUid),
      eq(scheduledMaintenance.enabled, true),
    ))
    .limit(1);
  if (!job) throw new RetentionCallbackError(403, "This scheduled task is not registered for message retention.");

  const startedAt = new Date();
  const cutoff = new Date(startedAt.getTime() - RETENTION_MS);
  try {
    const deletedMessages = await purgeExpiredMessages(db, cutoff);
    await db.update(scheduledMaintenance).set({
      lastRunAt: new Date(),
      lastDeletedMessages: deletedMessages,
      lastError: null,
    }).where(eq(scheduledMaintenance.id, job.id));
    return { success: true, deletedMessages, cutoff, storageBytesNote: "Expired message rows and unreferenced media indexes were removed; object bytes require the owner/operator storage-delete surface." };
  } catch {
    await db.update(scheduledMaintenance).set({ lastError: "Retention run failed; the job may retry safely." })
      .where(eq(scheduledMaintenance.id, job.id))
      .catch(() => undefined);
    throw new RetentionCallbackError(500, "Message retention failed; retry is safe.");
  }
}

export const messageRetentionCallbackPath = CALLBACK_PATH;
