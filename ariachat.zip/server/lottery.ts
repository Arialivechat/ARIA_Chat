import { randomBytes } from "node:crypto";
import { and, eq, sql } from "drizzle-orm";
import { pointAccounts, pointTransactions, lotteryEntries, lotteryRounds, profiles, scheduledMaintenance, users } from "../drizzle/schema";
import { getDb } from "./db";
import { RetentionCallbackError, getPlatformTicket, resolveAuthorizedTaskUid } from "./retention";
import { ensureAccountFor, isUnlimitedDiamondAdmin } from "./socialDb";

const DAY_MS = 86_400_000;
const JOB_KEY = "diamond-lottery-settlement";
const MAX = Number.MAX_SAFE_INTEGER;
const safe = (n: unknown) => { const value = Number(n ?? 0); if (!Number.isSafeInteger(value) || value < 0) throw new Error("Lottery amount exceeds safe integer bounds."); return value; };

function secureIndex(total: number): number {
  if (!Number.isSafeInteger(total) || total < 1) throw new Error("Invalid lottery pool.");
  const range = BigInt(total), space = 1n << 64n, limit = space - (space % range);
  for (;;) { const bytes = randomBytes(8); let n = 0n; for (const b of bytes) n = (n << 8n) | BigInt(b); if (n < limit) return Number(n % range); }
}

export async function ensureLotteryRound(now = new Date()) {
  const db = await getDb(); if (!db) throw new Error("Database unavailable.");
  const startMs = Math.floor(now.getTime() / DAY_MS) * DAY_MS;
  const startAt = new Date(startMs), endAt = new Date(startMs + DAY_MS);
  await db.insert(lotteryRounds).values({ startAt, endAt, status: "open", grossPool: 0 }).onDuplicateKeyUpdate({ set: { startAt: sql`${lotteryRounds.startAt}` } });
  const [round] = await db.select().from(lotteryRounds).where(eq(lotteryRounds.startAt, startAt)).limit(1);
  if (!round) throw new Error("Could not initialize lottery round.");
  return round;
}

export async function getLotteryCurrent(userId: number) {
  const db = await getDb(); if (!db) throw new Error("Database unavailable.");
  const now = new Date(), round = await ensureLotteryRound(now);
  const [mine] = await db.select({ amount: sql<number>`COALESCE(SUM(${lotteryEntries.amount}), 0)` }).from(lotteryEntries).where(and(eq(lotteryEntries.roundId, round.id), eq(lotteryEntries.userId, userId)));
  const [prior] = await db.select().from(lotteryRounds).where(eq(lotteryRounds.status, "settled")).orderBy(sql`${lotteryRounds.startAt} DESC`).limit(1);
  let winner: { userId: number; name: string | null } | null = null;
  if (prior?.winnerUserId) { const [u] = await db.select({ userId: users.id, name: profiles.username }).from(users).leftJoin(profiles, eq(profiles.userId, users.id)).where(eq(users.id, prior.winnerUserId)).limit(1); if (u) winner = u; }
  return { round: { id: round.id, startAt: round.startAt, endAt: round.endAt, status: round.status, grossPool: safe(round.grossPool), countdownMs: Math.max(0, round.endAt.getTime() - now.getTime()) }, myContribution: safe(mine?.amount), prior: prior ? { id: prior.id, startAt: prior.startAt, endAt: prior.endAt, grossPool: safe(prior.grossPool), fee: safe(prior.fee), prize: safe(prior.prize), settledAt: prior.settledAt, winner } : null };
}

export async function enterLottery(userId: number, amount: number) {
  if (!Number.isSafeInteger(amount) || amount <= 0 || amount > MAX) throw new Error("Contribution must be a positive safe integer.");
  const db = await getDb(); if (!db) throw new Error("Database unavailable.");
  await ensureAccountFor(db, userId);
  const unlimited = await isUnlimitedDiamondAdmin(db, userId);
  const now = new Date();
  return db.transaction(async (tx) => {
    const round = await ensureLotteryRound(now);
    const [locked] = await tx.select().from(lotteryRounds).where(eq(lotteryRounds.id, round.id)).for("update").limit(1);
    if (!locked || locked.status !== "open" || locked.endAt.getTime() <= now.getTime()) throw new Error("This lottery round has closed.");
    const [account] = await tx.select().from(pointAccounts).where(eq(pointAccounts.userId, userId)).for("update").limit(1);
    if (!account) throw new Error("Wallet unavailable.");
    const balance = unlimited ? MAX : safe(account.balance); if (amount > balance) throw new Error("Insufficient spendable diamonds.");
    const newPool = safe(locked.grossPool) + amount; if (!Number.isSafeInteger(newPool)) throw new Error("Lottery pool exceeds safe integer bounds.");
    const nextBalance = unlimited ? MAX : balance - amount;
    await tx.update(pointAccounts).set({ balance: nextBalance }).where(eq(pointAccounts.userId, userId));
    await tx.insert(pointTransactions).values({ accountUserId: userId, type: "lottery_entry", direction: "debit", amount, balanceAfter: nextBalance, note: `Lottery round ${locked.id}` });
    await tx.insert(lotteryEntries).values({ roundId: locked.id, userId, amount });
    await tx.update(lotteryRounds).set({ grossPool: newPool }).where(eq(lotteryRounds.id, locked.id));
    return { success: true, amount, balance: nextBalance, grossPool: newPool };
  });
}

export async function settleLotteryRound(roundId: number) {
  const db = await getDb(); if (!db) throw new Error("Database unavailable.");
  return db.transaction(async (tx) => {
    const [round] = await tx.select().from(lotteryRounds).where(eq(lotteryRounds.id, roundId)).for("update").limit(1);
    if (!round) throw new Error("Lottery round not found.");
    if (round.status === "settled") return round;
    const now = new Date(); if (round.endAt > now) throw new Error("Lottery round is not closed.");
    const gross = safe(round.grossPool);
    const entries = await tx.select({ userId: lotteryEntries.userId, amount: sql<number>`SUM(${lotteryEntries.amount})` }).from(lotteryEntries).where(eq(lotteryEntries.roundId, round.id)).groupBy(lotteryEntries.userId);
    let winnerUserId: number | null = null, fee = 0, prize = 0;
    if (gross > 0 && entries.length) {
      const total = entries.reduce((sum, row) => { const next = sum + safe(row.amount); if (!Number.isSafeInteger(next)) throw new Error("Lottery pool exceeds safe integer bounds."); return next; }, 0);
      if (total !== gross) throw new Error("Lottery audit totals do not match round pool.");
      let pick = secureIndex(total);
      for (const row of entries) { const amount = safe(row.amount); if (pick < amount) { winnerUserId = row.userId; break; } pick -= amount; }
      if (!winnerUserId) throw new Error("Could not choose lottery winner.");
      fee = Math.floor(gross / 10); prize = gross - fee;
      const [account] = await tx.select().from(pointAccounts).where(eq(pointAccounts.userId, winnerUserId)).for("update").limit(1);
      if (!account) throw new Error("Winner wallet unavailable.");
      const balance = safe(account.balance), next = balance + prize;
      if (!Number.isSafeInteger(next)) throw new Error("Winner balance exceeds safe integer bounds.");
      await tx.update(pointAccounts).set({ balance: next }).where(eq(pointAccounts.userId, winnerUserId));
      await tx.insert(pointTransactions).values({ accountUserId: winnerUserId, type: "lottery_prize", direction: "credit", amount: prize, balanceAfter: next, note: `Lottery round ${round.id}` });
    }
    await tx.update(lotteryRounds).set({ status: "settled", winnerUserId, grossPool: gross, fee, prize, settledAt: now }).where(eq(lotteryRounds.id, round.id));
    return { ...round, status: "settled" as const, winnerUserId, grossPool: gross, fee, prize, settledAt: now };
  });
}

export async function runLotterySettlement(cookieHeader: string | undefined) {
  const taskUid = await resolveAuthorizedTaskUid(getPlatformTicket(cookieHeader));
  const db = await getDb(); if (!db) throw new RetentionCallbackError(503, "Database unavailable.");
  const [job] = await db.select({ id: scheduledMaintenance.id }).from(scheduledMaintenance).where(and(eq(scheduledMaintenance.jobKey, JOB_KEY), eq(scheduledMaintenance.taskUid, taskUid), eq(scheduledMaintenance.enabled, true))).limit(1);
  if (!job) throw new RetentionCallbackError(403, "Scheduled task is not registered for lottery settlement.");
  const [due] = await db.select({ id: lotteryRounds.id }).from(lotteryRounds).where(and(eq(lotteryRounds.status, "open"), sql`${lotteryRounds.endAt} <= UTC_TIMESTAMP()`)).orderBy(lotteryRounds.startAt).limit(1);
  if (due) await settleLotteryRound(due.id);
  await db.update(scheduledMaintenance).set({ lastRunAt: new Date(), lastError: null }).where(eq(scheduledMaintenance.id, job.id));
  return { success: true, settledRoundId: due?.id ?? null };
}
