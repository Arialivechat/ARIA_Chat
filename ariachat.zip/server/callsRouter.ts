import { AccessToken } from "livekit-server-sdk";
import { TrackSource } from "@livekit/protocol";
import { randomBytes, randomUUID } from "node:crypto";
import { and, desc, eq, gt, or } from "drizzle-orm";
import { z } from "zod";
import { accountNumbers, blockedUsers, callSessions, friendships, profiles, users } from "../drizzle/schema";
import { getDb } from "./db";
import { protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { canInitiateVoiceCall } from "./_core/call-permissions";

const ACTIVE_WINDOW_MS = 60_000;
const CALL_TIMEOUT_MS = 45_000;
const TERMINAL_RETENTION_MS = 24 * 60 * 60_000;
function dbOrFail(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "پایگاه داده در دسترس نیست." });
  return db;
}
async function getLiveKitConfig() {
  const url = process.env.LIVEKIT_URL;
  const key = process.env.LIVEKIT_API_KEY;
  const secret = process.env.LIVEKIT_API_SECRET;
  if (!url || !key || !secret) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "سرویس تماس هنوز پیکربندی نشده است." });
  return { url, key, secret };
}
async function expireIfNeeded(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, row: typeof callSessions.$inferSelect) {
  const now = Date.now();
  if (row.status === "pending" && row.createdAt.getTime() + CALL_TIMEOUT_MS <= now) {
    await db.update(callSessions).set({ status: "expired", updatedAt: new Date() }).where(and(eq(callSessions.id, row.id), eq(callSessions.status, "pending")));
    return "expired" as const;
  }
  if (row.status === "accepted" && row.updatedAt.getTime() + ACTIVE_WINDOW_MS <= now) {
    await db.update(callSessions).set({ status: "ended", updatedAt: new Date() }).where(and(eq(callSessions.id, row.id), eq(callSessions.status, "accepted")));
    return "ended" as const;
  }
  return row.status;
}
async function authorizedPair(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, callerId: number, targetId: number) {
  if (callerId === targetId) throw new TRPCError({ code: "BAD_REQUEST", message: "نمی‌توانید با خودتان تماس بگیرید." });
  const [rows, blocks] = await Promise.all([
    db.select({ id: users.id, status: profiles.accountStatus }).from(users).innerJoin(profiles, eq(users.id, profiles.userId)).where(or(eq(users.id, callerId), eq(users.id, targetId))),
    db.select({ id: blockedUsers.id }).from(blockedUsers).where(or(and(eq(blockedUsers.blockerUserId, callerId), eq(blockedUsers.blockedUserId, targetId)), and(eq(blockedUsers.blockerUserId, targetId), eq(blockedUsers.blockedUserId, callerId)))),
  ]);
  if (rows.length !== 2 || rows.some((r) => r.status !== "active") || blocks.length) throw new TRPCError({ code: "FORBIDDEN", message: "امکان تماس با این کاربر وجود ندارد." });
}
async function assertCallPermission(db: NonNullable<Awaited<ReturnType<typeof getDb>>>, callerId: number, targetId: number) {
  await authorizedPair(db, callerId, targetId);
  const [caller, friend] = await Promise.all([
    db.select({ accountNumber: accountNumbers.accountNumber, role: users.role })
      .from(users).innerJoin(accountNumbers, eq(accountNumbers.userId, users.id))
      .where(eq(users.id, callerId)).limit(1),
    db.select({ id: friendships.id }).from(friendships)
      .where(and(eq(friendships.userId, Math.min(callerId, targetId)), eq(friendships.friendUserId, Math.max(callerId, targetId))))
      .limit(1),
  ]);
  if (!canInitiateVoiceCall({
    callerUserId: callerId,
    targetUserId: targetId,
    callerAccountNumber: caller[0]?.accountNumber ?? null,
    callerRole: caller[0]?.role ?? null,
    mutualFriendship: friend.length > 0,
    blocked: false,
  })) {
    throw new TRPCError({ code: "FORBIDDEN", message: "تماس صوتی فقط بین دوستان دوطرفه مجاز است؛ فقط Administrator شمارهٔ ۱ می‌تواند تماس با غیردوست را آغاز کند." });
  }
}
export const callsRouter = router({
  start: protectedProcedure.input(z.object({ accountNumber: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
    const db = dbOrFail(await getDb());
    const [target] = await db.select({ userId: accountNumbers.userId }).from(accountNumbers).innerJoin(users, eq(accountNumbers.userId, users.id)).innerJoin(profiles, eq(users.id, profiles.userId)).where(and(eq(accountNumbers.accountNumber, input.accountNumber), eq(profiles.accountStatus, "active"))).limit(1);
    if (!target?.userId) throw new TRPCError({ code: "NOT_FOUND", message: "کاربر پیدا نشد یا حساب فعال نیست." });
    await assertCallPermission(db, ctx.user.id, target.userId);
    const now = new Date();
    const [pending] = await db.select({ id: callSessions.id }).from(callSessions).where(and(eq(callSessions.callerUserId, ctx.user.id), eq(callSessions.calleeUserId, target.userId), eq(callSessions.status, "pending"))).limit(1);
    if (pending) throw new TRPCError({ code: "CONFLICT", message: "برای این کاربر تماس در انتظار وجود دارد." });
    const id = randomUUID();
    const roomName = `aria-${randomBytes(24).toString("hex")}`;
    await db.insert(callSessions).values({ id, callerUserId: ctx.user.id, calleeUserId: target.userId, roomName, status: "pending", createdAt: now, updatedAt: now });
    return { callId: id };
  }),
  incoming: protectedProcedure.query(async ({ ctx }) => {
    const db = dbOrFail(await getDb());
    const rows = await db.select({ call: callSessions, name: profiles.username, displayName: users.name }).from(callSessions).innerJoin(users, eq(callSessions.callerUserId, users.id)).innerJoin(profiles, eq(users.id, profiles.userId)).where(and(eq(callSessions.calleeUserId, ctx.user.id), eq(callSessions.status, "pending"))).orderBy(desc(callSessions.createdAt)).limit(5);
    const result = [];
    for (const r of rows) if (await expireIfNeeded(db, r.call) === "pending") result.push({ callId: r.call.id, callerName: r.name || r.displayName || "کاربر", createdAt: r.call.createdAt });
    return result;
  }),
  status: protectedProcedure.input(z.object({ callId: z.string().uuid() })).query(async ({ ctx, input }) => {
    const db = dbOrFail(await getDb());
    const [row] = await db.select().from(callSessions).where(eq(callSessions.id, input.callId)).limit(1);
    if (!row || (row.callerUserId !== ctx.user.id && row.calleeUserId !== ctx.user.id)) throw new TRPCError({ code: "NOT_FOUND", message: "تماس پیدا نشد." });
    const current = await expireIfNeeded(db, row);
    if (current === "accepted") await db.update(callSessions).set({ updatedAt: new Date() }).where(and(eq(callSessions.id, row.id), eq(callSessions.status, "accepted")));
    return { status: current };
  }),
  respond: protectedProcedure.input(z.object({ callId: z.string().uuid(), response: z.enum(["accepted", "declined"]) })).mutation(async ({ ctx, input }) => {
    const db = dbOrFail(await getDb());
    const [row] = await db.select().from(callSessions).where(eq(callSessions.id, input.callId)).limit(1);
    if (!row || row.calleeUserId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND", message: "تماس پیدا نشد." });
    if (await expireIfNeeded(db, row) !== "pending") throw new TRPCError({ code: "CONFLICT", message: "این تماس دیگر در انتظار نیست." });
    if (input.response === "accepted") await assertCallPermission(db, row.callerUserId, row.calleeUserId);
    else await authorizedPair(db, row.callerUserId, row.calleeUserId);
    const status = input.response === "accepted" ? "accepted" : "declined";
    const changed = await db.update(callSessions).set({ status, updatedAt: new Date() }).where(and(eq(callSessions.id, row.id), eq(callSessions.status, "pending")));
    if (!changed[0].affectedRows) throw new TRPCError({ code: "CONFLICT", message: "تماس قبلاً پاسخ داده شده است." });
    return { status };
  }),
  token: protectedProcedure.input(z.object({ callId: z.string().uuid() })).mutation(async ({ ctx, input }) => {
    const db = dbOrFail(await getDb());
    const [row] = await db.select().from(callSessions).where(eq(callSessions.id, input.callId)).limit(1);
    if (!row || (row.callerUserId !== ctx.user.id && row.calleeUserId !== ctx.user.id)) throw new TRPCError({ code: "NOT_FOUND", message: "تماس پیدا نشد." });
    if (await expireIfNeeded(db, row) !== "accepted") throw new TRPCError({ code: "PRECONDITION_FAILED", message: "تماس هنوز پذیرفته نشده یا پایان یافته است." });
    await assertCallPermission(db, row.callerUserId, row.calleeUserId);
    const { url, key, secret } = await getLiveKitConfig();
    const access = new AccessToken(key, secret, { identity: `u-${ctx.user.id}`, ttl: "5m" });
    access.addGrant({ roomJoin: true, room: row.roomName, canPublish: true, canSubscribe: true, canPublishSources: [TrackSource.MICROPHONE] });
    return { url, token: await access.toJwt() };
  }),
  end: protectedProcedure.input(z.object({ callId: z.string().uuid() })).mutation(async ({ ctx, input }) => {
    const db = dbOrFail(await getDb());
    const [row] = await db.select().from(callSessions).where(eq(callSessions.id, input.callId)).limit(1);
    if (!row || (row.callerUserId !== ctx.user.id && row.calleeUserId !== ctx.user.id)) throw new TRPCError({ code: "NOT_FOUND", message: "تماس پیدا نشد." });
    if (["pending", "accepted"].includes(row.status)) await db.update(callSessions).set({ status: "ended", updatedAt: new Date() }).where(and(eq(callSessions.id, row.id), or(eq(callSessions.status, "pending"), eq(callSessions.status, "accepted"))));
    return { success: true };
  }),
});
