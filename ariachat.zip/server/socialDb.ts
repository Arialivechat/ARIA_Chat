// Recovered from the successful pre-overwrite server bundle; retain explicit exports below.
// @ts-nocheck
import { randomInt, randomUUID } from "node:crypto";
import { TRPCError as TRPCError3 } from "@trpc/server";
import { and, asc, desc, eq as eq2, groupBy, gte, inArray, isNull, isNotNull, like, lte, notExists, or, sql } from "drizzle-orm";
import {
  adminNotices, accountNumbers, ads, auditLogs, blockedUsers, countryRoomRequests, friendships,
  gameRecords, mediaAssets, messages, messageHides, moderationReports, moderationWarnings, pointAccounts, securityEvents,
  pointTransactions, profiles, rooms, favoriteRooms, roomMemberships, roomInvitations, salesAgentDiscounts, specialAccountCredentials, passwordCredentials, users,
} from "../drizzle/schema";
import { getDb } from "./db";
import { hashLocalPassword, validateLocalPassword, verifyLocalPassword } from "./_core/password-hash";
import { mayChangeAccountRole } from "./_core/admin-role-permissions";
import { countryRoomDecisionRefunds, mayDecideCountryRoomRequest, maySettleCountryRoomRequest } from "./_core/country-room-request-policy";
import { storageGetSignedUrl, storagePut } from "./storage";
import { validateChatMedia } from "./media-validation";
import { canViewPrivateProfile } from "../lib/profile-visibility";
import { isAdminBlockDurationHours, isSuspensionExpired } from "../lib/account-suspensions";
import { createDiamondMiniOutcome, createRockPaperScissorsOutcome, diamondMiniPayout } from "./diamond-game-rules";
import { AD_VISIBILITY_WINDOW_MS } from "../lib/ad-schedule";
import { isSafeDiamondAmount } from "../lib/diamond-balance";

var ONLINE_WINDOW_MS = 5 * 60 * 1e3;
var MAX_LIMIT = 100;
var PRIVILEGED_ROOM_LEAVE_SCORE_PENALTY = 10;
var AD_CREATION_COST_POINTS = 100;
var MAX_SAFE_DIAMONDS = Number.MAX_SAFE_INTEGER;
function clampLimit(limit, fallback = 30) {
  return Math.min(Math.max(limit ?? fallback, 1), MAX_LIMIT);
}
function clampOffset(offset) {
  return Math.max(offset ?? 0, 0);
}
function unavailable() {
  throw new TRPCError3({
    code: "INTERNAL_SERVER_ERROR",
    message: "\u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647 \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A."
  });
}
function fail(code, message) {
  throw new TRPCError3({ code, message });
}
async function requireDb() {
  const db = await getDb();
  if (!db) unavailable();
  return db;
}
function asNumber(value) {
  return Number(value ?? 0);
}
function chatRankLevel(messageCount) {
  const count = asNumber(messageCount);
  if (count >= 7e5) return 5;
  if (count >= 3e5) return 4;
  if (count >= 1e5) return 3;
  if (count >= 2e4) return 2;
  if (count >= 1e3) return 1;
  return 0;
}
var CHAT_RANK_TITLES = ["\u0633\u0631\u0628\u0627\u0632", "\u0644\u0648\u0631\u062F", "\u062F\u0648\u06A9", "\u06A9\u06CC\u0646\u06AF", "\u0627\u0645\u067E\u0631\u0627\u062A\u0648\u0631", "\u0627\u0641\u0633\u0627\u0646\u0647"];
function chatRankTitle(level) {
  return CHAT_RANK_TITLES[Math.max(0, Math.min(5, Math.trunc(level)))];
}
function publicUser(row) {
  const now = new Date();
  const invisible = Boolean(row.invisibleUntil && row.invisibleUntil > now);
  return {
    accountNumber: row.accountNumber,
    name: row.name,
    username: row.username,
    avatarUrl: row.avatarUrl,
    avatarEmoji: row.avatarEmoji ?? null,
    badgeTitle: row.badgeTitle ?? null,
    crownStyle: row.crownStyle ?? null,
    role: row.role ?? "user",
    rankLevel: row.rankLevel ?? 0,
    rankTitle: chatRankTitle(row.rankLevel ?? 0),
    age: row.age,
    gender: row.gender,
    city: row.city,
    country: row.country,
    bio: row.bio,
    lastSeenAt: row.lastSeenAt ?? null,
    isOnline: !invisible && Boolean(row.lastSeenAt && row.lastSeenAt >= new Date(now.getTime() - ONLINE_WINDOW_MS)),
    membershipCount: asNumber(row.membershipCount)
  };
}
function messageView(row, viewerUserId) {
  const senderChatMessageCount = asNumber(row.senderChatMessageCount ?? 0);
  const senderRankLevel = row.senderRankOverride ?? chatRankLevel(senderChatMessageCount);
  const deleted = Boolean(row.deletedAt);
  const canViewSenderProfile = canViewPrivateProfile(row.senderIsPrivate, row.senderIsFriend, row.senderId === viewerUserId);
  return {
    id: row.id,
    roomId: row.roomId,
    isMine: viewerUserId !== void 0 && row.senderId === viewerUserId,
    type: deleted ? "text" : row.type,
    text: deleted ? "این پیام حذف شده است." : row.body,
    deleted,
    assetUrl: deleted ? null : row.assetUrl,
    assetMetadata: deleted ? null : row.assetMetadata,
    createdAt: row.createdAt,
    editedAt: row.editedAt,
    sender: row.senderName === void 0 ? void 0 : {
      accountNumber: row.senderAccountNumber ?? null,
      name: canViewSenderProfile ? row.senderName : "حساب خصوصی",
      username: canViewSenderProfile ? row.senderUsername ?? null : null,
      avatarUrl: canViewSenderProfile ? row.senderAvatarUrl ?? null : null,
      avatarEmoji: canViewSenderProfile ? row.senderAvatarEmoji ?? null : null,
      badgeTitle: canViewSenderProfile ? row.senderBadgeTitle ?? null : null,
      crownStyle: canViewSenderProfile ? row.senderCrownStyle ?? null : null,
      gender: canViewSenderProfile ? row.senderGender ?? "unspecified" : "unspecified",
      role: row.senderRole ?? "user",
      roomRole: row.senderRoomRole ?? null,
      chatMessageCount: canViewSenderProfile ? senderChatMessageCount : 0,
      rankLevel: canViewSenderProfile ? senderRankLevel : 0,
      rankTitle: canViewSenderProfile ? chatRankTitle(senderRankLevel) : "حساب خصوصی",
      messageBubbleColor: canViewSenderProfile ? row.senderMessageBubbleColor ?? null : null,
      messageTextColor: canViewSenderProfile ? row.senderMessageTextColor ?? null : null
    }
  };
}
const signedMediaUrlCache = new Map();
async function getSignedMediaUrl(storageKey) {
  const cached = signedMediaUrlCache.get(storageKey);
  if (cached && cached.expiresAt > Date.now() + 60_000) return cached.url;
  try {
    const url = await storageGetSignedUrl(storageKey);
    signedMediaUrlCache.set(storageKey, { url, expiresAt: Date.now() + 50 * 60_000 });
    return url;
  } catch {
    return null;
  }
}
async function resolveProfileAvatar(db, avatarUrl) {
  if (typeof avatarUrl !== "string" || !avatarUrl.startsWith("/manus-storage/")) return avatarUrl;
  const [asset] = await db.select({ storageKey: mediaAssets.storageKey }).from(mediaAssets)
    .where(eq2(mediaAssets.stableUrl, avatarUrl)).limit(1);
  return asset ? await getSignedMediaUrl(asset.storageKey) : null;
}
async function resolveMessageViews(db, rows, viewerUserId) {
  const stableUrls = [...new Set(rows.filter((row) => !row.deletedAt).map((row) => row.assetUrl).filter((url) => typeof url === "string" && url.startsWith("/manus-storage/")))];
  const assets = stableUrls.length ? await db.select({ stableUrl: mediaAssets.stableUrl, storageKey: mediaAssets.storageKey })
    .from(mediaAssets).where(inArray(mediaAssets.stableUrl, stableUrls)) : [];
  const assetByUrl = new Map(assets.map((asset) => [asset.stableUrl, asset]));
  return Promise.all(rows.map(async (row) => {
    const view = messageView(row, viewerUserId);
    const asset = row.deletedAt ? undefined : assetByUrl.get(row.assetUrl);
    const sender = view.sender ? { ...view.sender, avatarUrl: await resolveProfileAvatar(db, view.sender.avatarUrl) } : view.sender;
    return { ...view, sender, assetUrl: asset ? await getSignedMediaUrl(asset.storageKey) : null };
  }));
}
async function uploadChatMedia(userId, input) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  let file;
  try {
    file = validateChatMedia(input);
  } catch (error) {
    fail("BAD_REQUEST", error instanceof Error ? error.message : "فایل معتبر نیست.");
  }
  const extensionByType = {
    "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp",
    "audio/mpeg": "mp3", "audio/mp4": "m4a", "audio/aac": "aac", "application/pdf": "pdf",
  };
  const requestedKey = `aria-chat/${userId}/${randomUUID()}.${extensionByType[file.contentType]}`;
  let stored;
  try {
    stored = await storagePut(requestedKey, file.bytes, file.contentType);
  } catch {
    fail("INTERNAL_SERVER_ERROR", "بارگذاری فایل انجام نشد؛ دوباره تلاش کن.");
  }
  const result = await db.insert(mediaAssets).values({
    ownerUserId: userId,
    storageKey: stored.key,
    stableUrl: stored.url,
    fileName: file.fileName,
    contentType: file.contentType,
    sizeBytes: file.sizeBytes,
  });
  return {
    id: Number(result[0].insertId),
    fileName: file.fileName,
    contentType: file.contentType,
    kind: file.kind,
    sizeBytes: file.sizeBytes,
    stableUrl: stored.url,
    displayUrl: await getSignedMediaUrl(stored.key),
  };
}
async function getOwnedChatMedia(db, userId, mediaId) {
  if (!mediaId) return null;
  const [asset] = await db.select().from(mediaAssets).where(and(
    eq2(mediaAssets.id, mediaId), eq2(mediaAssets.ownerUserId, userId),
  )).limit(1);
  if (!asset) fail("NOT_FOUND", "فایل پیوست‌شده پیدا نشد یا متعلق به حساب شما نیست.");
  return asset;
}
var reservedAccountSlotsSeeded = false;
async function ensureReservedAccountSlots(db) {
  if (reservedAccountSlotsSeeded) return;
  const slots = Array.from({ length: 100 }, (_, index2) => ({ accountNumber: index2 + 1, isReserved: true }));
  await db.insert(accountNumbers).values(slots).onDuplicateKeyUpdate({
    set: { isReserved: sql`${accountNumbers.isReserved}` }
  });
  reservedAccountSlotsSeeded = true;
}
async function ensureAccountNumberFor(db, userId) {
  await ensureReservedAccountSlots(db);
  const [identity] = await db.select({ loginMethod: users.loginMethod }).from(users).where(eq2(users.id, userId)).limit(1);
  const [existing] = await db.select({ accountNumber: accountNumbers.accountNumber }).from(accountNumbers).where(eq2(accountNumbers.userId, userId)).limit(1);
  if (identity?.loginMethod === "admin-password") {
    const [ownerSlot] = await db.select({ userId: accountNumbers.userId }).from(accountNumbers).where(eq2(accountNumbers.accountNumber, 1)).limit(1);
    if (ownerSlot?.userId && ownerSlot.userId !== userId) fail("CONFLICT", "\u0634\u0645\u0627\u0631\u0647\u0654 \u06F1 \u0628\u0631\u0627\u06CC Administrator \u0631\u0632\u0631\u0648 \u0634\u062F\u0647 \u0627\u0633\u062A.");
    if (existing?.accountNumber === 1) return 1;
    await db.transaction(async (tx) => {
      if (existing) await tx.update(accountNumbers).set({ userId: null }).where(eq2(accountNumbers.accountNumber, existing.accountNumber));
      await tx.update(accountNumbers).set({ userId, isReserved: true, claimedAt: /* @__PURE__ */ new Date() }).where(eq2(accountNumbers.accountNumber, 1));
    });
    return 1;
  }
  if (existing) return existing.accountNumber;
  try {
    await db.insert(accountNumbers).values({ userId, isReserved: false, claimedAt: /* @__PURE__ */ new Date() });
  } catch (error) {
    if (error.code !== "ER_DUP_ENTRY") throw error;
  }
  const [created] = await db.select({ accountNumber: accountNumbers.accountNumber }).from(accountNumbers).where(eq2(accountNumbers.userId, userId)).limit(1);
  if (!created) unavailable();
  return created.accountNumber;
}
async function ensureProfileFor(db, userId) {
  await db.insert(profiles).values({ userId, lastSeenAt: /* @__PURE__ */ new Date() }).onDuplicateKeyUpdate({ set: { userId: sql`${profiles.userId}` } });
  const [profile] = await db.select().from(profiles).where(eq2(profiles.userId, userId)).limit(1);
  if (!profile) unavailable();
  await ensureAccountNumberFor(db, userId);
  return profile;
}
async function isUnlimitedDiamondAdmin(db, userId) {
  await ensureAccountNumberFor(db, userId);
  const [identity] = await db.select({ accountNumber: accountNumbers.accountNumber, role: users.role })
    .from(users).innerJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(eq2(users.id, userId)).limit(1);
  return mayDecideCountryRoomRequest(identity);
}
async function ensureAccountFor(db, userId) {
  const unlimited = await isUnlimitedDiamondAdmin(db, userId);
  await db.insert(pointAccounts).values({ userId, balance: unlimited ? MAX_SAFE_DIAMONDS : 0 }).onDuplicateKeyUpdate({
    set: unlimited ? { balance: MAX_SAFE_DIAMONDS } : { userId: sql`${pointAccounts.userId}` }
  });
  const [account] = await db.select().from(pointAccounts).where(eq2(pointAccounts.userId, userId)).limit(1);
  if (!account) unavailable();
  return account;
}
async function userExists(db, userId) {
  const [found] = await db.select({ id: users.id }).from(users).where(eq2(users.id, userId)).limit(1);
  return Boolean(found);
}
async function assertCanParticipate(db, userId) {
  const profile = await ensureProfileFor(db, userId);
  const now = /* @__PURE__ */ new Date();
  if (profile.accountStatus === "deleted" || profile.deletedAt) {
    fail("UNAUTHORIZED", "این حساب حذف شده است و برای استفاده باید توسط Administrator بازیابی شود.");
  }
  if (isSuspensionExpired(profile.accountStatus, profile.suspendedUntil, now)) {
    await db.update(profiles).set({ accountStatus: "active", suspendedUntil: null })
      .where(and(eq2(profiles.userId, userId), eq2(profiles.accountStatus, "suspended"), lte(profiles.suspendedUntil, now)));
    profile.accountStatus = "active";
    profile.suspendedUntil = null;
  }
  const muted = profile.accountStatus === "muted" && (!profile.mutedUntil || profile.mutedUntil > now);
  const suspended = profile.accountStatus === "suspended" && (!profile.suspendedUntil || profile.suspendedUntil > now);
  if (muted || suspended) {
    fail("FORBIDDEN", "\u062F\u0633\u062A\u0631\u0633\u06CC \u062D\u0633\u0627\u0628 \u0634\u0645\u0627 \u062A\u0648\u0633\u0637 \u0645\u062F\u06CC\u0631\u06CC\u062A \u0645\u062D\u062F\u0648\u062F \u0634\u062F\u0647 \u0627\u0633\u062A.");
  }
  return profile;
}
async function assertNotBlocked(db, firstUserId, secondUserId) {
  const [block] = await db.select({ id: blockedUsers.id }).from(blockedUsers).where(
    or(
      and(eq2(blockedUsers.blockerUserId, firstUserId), eq2(blockedUsers.blockedUserId, secondUserId)),
      and(eq2(blockedUsers.blockerUserId, secondUserId), eq2(blockedUsers.blockedUserId, firstUserId))
    )
  ).limit(1);
  if (block) fail("FORBIDDEN", "\u0627\u06CC\u0646 \u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0647\u200C\u062F\u0644\u06CC\u0644 \u0628\u0644\u0627\u06A9\u200C\u0644\u06CC\u0633\u062A \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A.");
}
async function getRoom(db, roomId) {
  const [room] = await db.select().from(rooms).where(eq2(rooms.id, roomId)).limit(1);
  if (!room) fail("NOT_FOUND", "\u0631\u0648\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  return room;
}
async function membershipFor(db, roomId, userId) {
  const [membership] = await db.select().from(roomMemberships).where(and(eq2(roomMemberships.roomId, roomId), eq2(roomMemberships.userId, userId))).limit(1);
  return membership;
}
async function assertRoomAccess(db, roomId, userId, writing = false) {
  const room = await getRoom(db, roomId);
  if (writing && room.status !== "active") {
    fail("FORBIDDEN", "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645 \u0628\u0647 \u0627\u06CC\u0646 \u0631\u0648\u0645 \u0645\u0645\u06A9\u0646 \u0646\u06CC\u0633\u062A.");
  }
  const membership = await membershipFor(db, roomId, userId);
  if (room.type === "private" && !membership) {
    fail("FORBIDDEN", "\u0639\u0636\u0648\u06CC\u062A \u062F\u0631 \u0631\u0648\u0645 \u062E\u0635\u0648\u0635\u06CC \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A.");
  }
  return { room, membership };
}
async function getMyProfile(userId) {
  const db = await requireDb();
  const profile = await ensureProfileFor(db, userId);
  const [user] = await db.select({ id: users.id, name: users.name, role: users.role, loginMethod: users.loginMethod }).from(users).where(eq2(users.id, userId)).limit(1);
  if (!user) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  await db.update(profiles).set({ lastSeenAt: /* @__PURE__ */ new Date() }).where(eq2(profiles.userId, userId));
  return {
    accountNumber: await ensureAccountNumberFor(db, userId),
    name: user.name,
    role: user.role,
    loginMethod: user.loginMethod,
    username: profile.username,
    avatarUrl: await resolveProfileAvatar(db, profile.avatarUrl),
    avatarEmoji: profile.avatarEmoji ?? null,
    badgeTitle: profile.badgeTitle ?? null,
    crownStyle: profile.crownStyle ?? null,
    avatarStorageUrl: profile.avatarUrl,
    rankLevel: profile.rankOverride ?? chatRankLevel(profile.chatMessageCount),
    rankTitle: chatRankTitle(profile.rankOverride ?? chatRankLevel(profile.chatMessageCount)),
    chatMessageCount: profile.chatMessageCount,
    rankIsManual: profile.rankOverride !== null,
    isPrivate: profile.isPrivate,
    age: profile.age,
    gender: profile.gender,
    city: profile.city,
    country: profile.country,
    bio: profile.bio,
    privateId: profile.privateId,
    language: profile.language,
    darkMode: profile.darkMode,
    messageBubbleColor: profile.messageBubbleColor,
    messageTextColor: profile.messageTextColor,
    invisibleUntil: profile.invisibleUntil,
    isInvisible: Boolean(profile.invisibleUntil && profile.invisibleUntil > new Date()),
    installId: profile.installId,
    lastSeenAt: new Date(),
    isOnline: true,
    accountStatus: profile.accountStatus
  };
}
async function updateMyProfile(userId, input) {
  const db = await requireDb();
  await ensureProfileFor(db, userId);
  if (typeof input.avatarUrl === "string" && input.avatarUrl.startsWith("/manus-storage/")) {
    const [asset] = await db.select({ ownerUserId: mediaAssets.ownerUserId, contentType: mediaAssets.contentType })
      .from(mediaAssets).where(eq2(mediaAssets.stableUrl, input.avatarUrl)).limit(1);
    if (!asset || asset.ownerUserId !== userId || !asset.contentType.startsWith("image/")) {
      fail("FORBIDDEN", "این تصویر به حساب شما تعلق ندارد.");
    }
  }
  try {
    await db.transaction(async (tx) => {
      if (input.username !== void 0) {
        const [credential] = await tx.select({ userId: passwordCredentials.userId }).from(passwordCredentials)
          .where(eq2(passwordCredentials.userId, userId)).limit(1);
        if (credential) {
          if (!input.username) fail("BAD_REQUEST", "برای ورود با رمز عبور، نام کاربری را نمی‌توان خالی کرد.");
          const normalized = input.username.normalize("NFKC").trim().toLocaleLowerCase("fa-IR");
          const [owner] = await tx.select({ userId: passwordCredentials.userId }).from(passwordCredentials)
            .where(eq2(passwordCredentials.username, normalized)).limit(1);
          if (owner && owner.userId !== userId) fail("CONFLICT", "این نام کاربری قبلاً استفاده شده است.");
          await tx.update(passwordCredentials).set({ username: normalized }).where(eq2(passwordCredentials.userId, userId));
        }
      }
      await tx.update(profiles).set({ ...input, lastSeenAt: /* @__PURE__ */ new Date() }).where(eq2(profiles.userId, userId));
    });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") {
      fail("CONFLICT", "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u06CC\u0627 \u0634\u0646\u0627\u0633\u0647\u0654 \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0642\u0628\u0644\u0627\u064B \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0634\u062F\u0647 \u0627\u0633\u062A.");
    }
    throw error;
  }
  return getMyProfile(userId);
}
async function setMyPassword(userId, input) {
  const db = await requireDb();
  const accountNumber = await ensureAccountNumberFor(db, userId);
  if (accountNumber < 101) fail("FORBIDDEN", "گذرواژهٔ حساب‌های Administrator و ویژه فقط از مسیر امن مالک تغییر می‌کند.");
  const profile = await ensureProfileFor(db, userId);
  if (!profile.username) fail("BAD_REQUEST", "ابتدا یک نام کاربری برای پروفایلت انتخاب کن.");
  const normalized = profile.username.normalize("NFKC").trim().toLocaleLowerCase("fa-IR");
  if (normalized === "administrator") fail("CONFLICT", "این نام کاربری برای Administrator رزرو است.");
  if (!validateLocalPassword(input.newPassword)) fail("BAD_REQUEST", "رمز عبور باید بین ۶ تا ۲۵۶ بایت باشد.");
  const [existing] = await db.select({ passwordHash: passwordCredentials.passwordHash }).from(passwordCredentials)
    .where(eq2(passwordCredentials.userId, userId)).limit(1);
  if (existing) {
    if (!input.currentPassword || !await verifyLocalPassword(input.currentPassword, existing.passwordHash)) {
      fail("UNAUTHORIZED", "رمز فعلی درست نیست.");
    }
  }
  const [owner] = await db.select({ userId: passwordCredentials.userId }).from(passwordCredentials)
    .where(eq2(passwordCredentials.username, normalized)).limit(1);
  if (owner && owner.userId !== userId) fail("CONFLICT", "این نام کاربری قبلاً استفاده شده است.");
  const passwordHash = await hashLocalPassword(input.newPassword);
  await db.transaction(async (tx) => {
    if (existing) {
      await tx.update(passwordCredentials).set({ username: normalized, passwordHash }).where(eq2(passwordCredentials.userId, userId));
    } else {
      await tx.insert(passwordCredentials).values({ userId, username: normalized, passwordHash });
    }
    await tx.update(users).set({ loginMethod: "password" }).where(eq2(users.id, userId));
  });
  return { success: true };
}
async function searchUsers(viewerUserId, input) {
  const db = await requireDb();
  const onlineAfter = new Date(Date.now() - ONLINE_WINDOW_MS);
  const queryText = input.query?.trim();
  const queryAccountNumber = queryText && /^\d+$/.test(queryText) ? Number(queryText) : void 0;
  const publicTextMatch = queryText ? and(eq2(profiles.isPrivate, false), or(like(users.name, `%${queryText}%`), like(profiles.username, `%${queryText}%`))) : eq2(profiles.isPrivate, false);
  const discoveryMatch = queryAccountNumber !== void 0 ? or(eq2(accountNumbers.accountNumber, queryAccountNumber), publicTextMatch) : publicTextMatch;
  const conditions = [
    eq2(profiles.accountStatus, "active"),
    discoveryMatch,
    input.gender ? eq2(profiles.gender, input.gender) : void 0,
    input.ageMin !== void 0 ? gte(profiles.age, input.ageMin) : void 0,
    input.ageMax !== void 0 ? lte(profiles.age, input.ageMax) : void 0,
    input.city ? eq2(profiles.city, input.city) : void 0,
    input.country ? eq2(profiles.country, input.country) : void 0,
    input.onlineOnly ? and(gte(profiles.lastSeenAt, onlineAfter), or(isNull(profiles.invisibleUntil), lte(profiles.invisibleUntil, new Date()))) : void 0,
    input.hasPhotoOnly ? isNotNull(profiles.avatarUrl) : void 0
  ];
  const rows = await db.select({
    id: users.id,
    accountNumber: accountNumbers.accountNumber,
    name: users.name,
    role: users.role,
    username: profiles.username,
    avatarUrl: profiles.avatarUrl,
    avatarEmoji: profiles.avatarEmoji,
    badgeTitle: profiles.badgeTitle,
    crownStyle: profiles.crownStyle,
    rankLevel: sql`COALESCE(${profiles.rankOverride}, CASE WHEN ${profiles.chatMessageCount} >= 700000 THEN 5 WHEN ${profiles.chatMessageCount} >= 300000 THEN 4 WHEN ${profiles.chatMessageCount} >= 100000 THEN 3 WHEN ${profiles.chatMessageCount} >= 20000 THEN 2 WHEN ${profiles.chatMessageCount} >= 1000 THEN 1 ELSE 0 END)`,
    age: profiles.age,
    gender: profiles.gender,
    city: profiles.city,
    country: profiles.country,
    bio: profiles.bio,
    lastSeenAt: profiles.lastSeenAt,
    invisibleUntil: profiles.invisibleUntil,
    isPrivate: profiles.isPrivate,
    isFriend: sql`EXISTS (SELECT 1 FROM friendships f WHERE f.userId = LEAST(${viewerUserId}, ${users.id}) AND f.friendUserId = GREATEST(${viewerUserId}, ${users.id}))`,
    membershipCount: sql`(SELECT COUNT(*) FROM room_memberships rm WHERE rm.userId = ${users.id})`
  }).from(users).innerJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(and(...conditions)).orderBy(asc(users.id)).limit(clampLimit(input.limit)).offset(clampOffset(input.offset));
  return Promise.all(rows.map(async (row) => {
    const visible = publicUser(row);
    const canViewProfile = canViewPrivateProfile(row.isPrivate, row.isFriend, row.id === viewerUserId);
    const avatarUrl = canViewProfile ? await resolveProfileAvatar(db, visible.avatarUrl) : null;
    if (canViewProfile) return { ...visible, avatarUrl, isPrivate: row.isPrivate, isFriend: Boolean(row.isFriend), canViewProfile: true };
    return { ...visible, name: "\u062D\u0633\u0627\u0628 \u062E\u0635\u0648\u0635\u06CC", username: null, avatarUrl: null, avatarEmoji: null, badgeTitle: null, crownStyle: null, role: "user", rankLevel: 0, rankTitle: "\u062D\u0633\u0627\u0628 \u062E\u0635\u0648\u0635\u06CC", age: null, gender: "unspecified", city: null, country: null, bio: null, lastSeenAt: null, isOnline: false, membershipCount: 0, isPrivate: true, isFriend: false, canViewProfile: false };
  }));
}
async function getPublicUser(viewerUserId, targetAccountNumber) {
  const db = await requireDb();
  const targetUserId = await accountNumberToUserId(db, targetAccountNumber);
  const [row] = await db.select({
    id: users.id,
    accountNumber: accountNumbers.accountNumber,
    name: users.name,
    role: users.role,
    username: profiles.username,
    avatarUrl: profiles.avatarUrl,
    avatarEmoji: profiles.avatarEmoji,
    badgeTitle: profiles.badgeTitle,
    crownStyle: profiles.crownStyle,
    rankLevel: sql`COALESCE(${profiles.rankOverride}, CASE WHEN ${profiles.chatMessageCount} >= 700000 THEN 5 WHEN ${profiles.chatMessageCount} >= 300000 THEN 4 WHEN ${profiles.chatMessageCount} >= 100000 THEN 3 WHEN ${profiles.chatMessageCount} >= 20000 THEN 2 WHEN ${profiles.chatMessageCount} >= 1000 THEN 1 ELSE 0 END)`,
    age: profiles.age,
    gender: profiles.gender,
    city: profiles.city,
    country: profiles.country,
    bio: profiles.bio,
    lastSeenAt: profiles.lastSeenAt,
    invisibleUntil: profiles.invisibleUntil,
    isPrivate: profiles.isPrivate,
    membershipCount: sql`(SELECT COUNT(*) FROM room_memberships rm WHERE rm.userId = ${users.id})`
  }).from(users).innerJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(and(eq2(users.id, targetUserId), eq2(profiles.accountStatus, "active"))).limit(1);
  if (!row) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const [friendship] = await db.select({ id: friendships.id }).from(friendships).where(
    and(
      eq2(friendships.userId, Math.min(viewerUserId, targetUserId)),
      eq2(friendships.friendUserId, Math.max(viewerUserId, targetUserId))
    )
  ).limit(1);
  const [blocked] = await db.select({ id: blockedUsers.id }).from(blockedUsers).where(and(eq2(blockedUsers.blockerUserId, viewerUserId), eq2(blockedUsers.blockedUserId, targetUserId))).limit(1);
  const [blockedByTarget] = await db.select({ id: blockedUsers.id }).from(blockedUsers).where(and(eq2(blockedUsers.blockerUserId, targetUserId), eq2(blockedUsers.blockedUserId, viewerUserId))).limit(1);
  if (blockedByTarget) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const fullProfileVisible = canViewPrivateProfile(row.isPrivate, Boolean(friendship), viewerUserId === targetUserId);
  const visible = publicUser(row);
  return {
    ...visible,
    name: fullProfileVisible ? visible.name : "حساب خصوصی",
    username: fullProfileVisible ? visible.username : null,
    avatarUrl: fullProfileVisible ? await resolveProfileAvatar(db, visible.avatarUrl) : null,
    avatarEmoji: fullProfileVisible ? visible.avatarEmoji : null,
    badgeTitle: fullProfileVisible ? visible.badgeTitle : null,
    crownStyle: fullProfileVisible ? visible.crownStyle : null,
    role: fullProfileVisible ? visible.role : "user",
    rankLevel: fullProfileVisible ? visible.rankLevel : 0,
    rankTitle: fullProfileVisible ? visible.rankTitle : "\u062D\u0633\u0627\u0628 \u062E\u0635\u0648\u0635\u06CC",
    age: fullProfileVisible ? visible.age : null,
    gender: fullProfileVisible ? visible.gender : "unspecified",
    city: fullProfileVisible ? visible.city : null,
    country: fullProfileVisible ? visible.country : null,
    bio: fullProfileVisible ? visible.bio : null,
    lastSeenAt: fullProfileVisible ? visible.lastSeenAt : null,
    isOnline: fullProfileVisible ? visible.isOnline : false,
    membershipCount: fullProfileVisible ? visible.membershipCount : 0,
    isPrivate: row.isPrivate,
    canViewProfile: fullProfileVisible,
    isFriend: Boolean(friendship),
    isBlocked: Boolean(blocked)
  };
}
async function listRooms(userId, input) {
  const db = await requireDb();
  const profile = await ensureProfileFor(db, userId);
  const favoriteRoomIds = input.kind === "favorites" ? await db.select({ roomId: favoriteRooms.roomId }).from(favoriteRooms).where(eq2(favoriteRooms.userId, userId)) : null;
  const favoriteIds = favoriteRoomIds?.map((row) => row.roomId) ?? [];
  const rows = await db.select({
    id: rooms.id,
    name: rooms.title,
    description: rooms.description,
    kind: rooms.type,
    country: rooms.country,
    creatorAccountNumber: sql`(SELECT accountNumber FROM account_numbers WHERE userId = ${rooms.creatorId} LIMIT 1)`,
    announcement: rooms.announcement,
    announcementAt: rooms.announcementAt,
    points: rooms.score,
    status: rooms.status,
    createdAt: rooms.createdAt,
    membershipRole: roomMemberships.role,
    isFavorite: sql`EXISTS (SELECT 1 FROM favorite_rooms fr WHERE fr.userId = ${userId} AND fr.roomId = ${rooms.id})`,
    memberCount: sql`(SELECT COUNT(*) FROM room_memberships members WHERE members.roomId = ${rooms.id})`
  }).from(rooms).leftJoin(
    roomMemberships,
    and(eq2(roomMemberships.roomId, rooms.id), eq2(roomMemberships.userId, userId))
  ).where(
    and(
      input.kind && input.kind !== "favorites" ? eq2(rooms.type, input.kind) : void 0,
      input.kind === "favorites" ? (favoriteIds.length ? inArray(rooms.id, favoriteIds) : sql`false`) : void 0,
      or(
        eq2(rooms.type, "public"),
        eq2(rooms.type, "official"),
        and(eq2(rooms.type, "country"), profile.country ? eq2(rooms.country, profile.country) : sql`false`),
        isNotNull(roomMemberships.id)
      )
    )
  ).orderBy(desc(rooms.score), desc(rooms.createdAt), desc(rooms.id)).limit(clampLimit(input.limit)).offset(clampOffset(input.offset));
  return rows.map((row) => ({
    ...row,
    points: asNumber(row.points),
    memberCount: asNumber(row.memberCount),
    membershipRole: row.membershipRole ?? null
  }));
}
async function createRoom(userId, input) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  if (input.kind === "official") fail("FORBIDDEN", "\u0633\u0627\u062E\u062A \u0631\u0648\u0645 \u0631\u0633\u0645\u06CC \u0641\u0642\u0637 \u0628\u0631\u0627\u06CC \u0645\u062F\u06CC\u0631 \u0645\u0645\u06A9\u0646 \u0627\u0633\u062A.");
  if (input.kind === "country" && !input.country) fail("BAD_REQUEST", "\u06A9\u0634\u0648\u0631 \u0631\u0648\u0645 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A.");
  const invitedUserIds = [...new Set(input.invitedUserIds ?? [])].filter((id) => id !== userId);
  if (invitedUserIds.length > 20) fail("BAD_REQUEST", "\u062A\u0639\u062F\u0627\u062F \u062F\u0639\u0648\u062A\u200C\u0634\u062F\u06AF\u0627\u0646 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A.");
  for (const invitedUserId of invitedUserIds) {
    if (!await userExists(db, invitedUserId)) fail("NOT_FOUND", "\u06CC\u06A9\u06CC \u0627\u0632 \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u062F\u0639\u0648\u062A\u200C\u0634\u062F\u0647 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    await assertNotBlocked(db, userId, invitedUserId);
  }
  const room = await db.transaction(async (tx) => {
    const result = await tx.insert(rooms).values({
      title: input.name,
      description: input.description ?? null,
      type: input.kind,
      country: input.kind === "country" ? input.country ?? null : null,
      creatorId: userId
    });
    const roomId = Number(result[0].insertId);
    await tx.insert(roomMemberships).values({ roomId, userId, role: "owner" });
    if (invitedUserIds.length) {
      await tx.insert(roomMemberships).values(invitedUserIds.map((memberUserId) => ({ roomId, userId: memberUserId })));
    }
    return { id: roomId };
  });
  return room;
}
async function joinRoom(userId, roomId) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const room = await getRoom(db, roomId);
  if (room.status !== "active") fail("FORBIDDEN", "\u0639\u0636\u0648\u06CC\u062A \u062F\u0631 \u0627\u06CC\u0646 \u0631\u0648\u0645 \u0645\u0645\u06A9\u0646 \u0646\u06CC\u0633\u062A.");
  if (room.type === "private") {
    const membership2 = await membershipFor(db, roomId, userId);
    if (!membership2) fail("FORBIDDEN", "\u0631\u0648\u0645 \u062E\u0635\u0648\u0635\u06CC \u0641\u0642\u0637 \u0628\u0627 \u062F\u0639\u0648\u062A \u0642\u0627\u0628\u0644 \u062F\u0633\u062A\u0631\u0633\u06CC \u0627\u0633\u062A.");
    return { roomId, role: membership2.role, joined: false };
  }
  await db.insert(roomMemberships).values({ roomId, userId, role: "member" }).onDuplicateKeyUpdate({ set: { userId: sql`${roomMemberships.userId}` } });
  const membership = await membershipFor(db, roomId, userId);
  return { roomId, role: membership?.role ?? "member", joined: true };
}
async function leaveRoom(userId, roomId) {
  const db = await requireDb();
  return db.transaction(async (tx) => {
    const [room] = await tx.select().from(rooms).where(eq2(rooms.id, roomId)).limit(1);
    if (!room) fail("NOT_FOUND", "\u0631\u0648\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    const [membership] = await tx.select().from(roomMemberships).where(and(eq2(roomMemberships.roomId, roomId), eq2(roomMemberships.userId, userId))).limit(1);
    if (!membership) fail("NOT_FOUND", "\u0639\u0636\u0648\u06CC\u062A \u0634\u0645\u0627 \u062F\u0631 \u0627\u06CC\u0646 \u0631\u0648\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    const privileged = room.creatorId === userId || membership.role === "owner" || membership.role === "moderator";
    const scorePenalty = privileged ? Math.min(PRIVILEGED_ROOM_LEAVE_SCORE_PENALTY, Math.max(asNumber(room.score), 0)) : 0;
    let score = asNumber(room.score);
    if (privileged) {
      await tx.update(rooms).set({ score: sql`GREATEST(${rooms.score} - ${PRIVILEGED_ROOM_LEAVE_SCORE_PENALTY}, 0)` }).where(eq2(rooms.id, roomId));
      const [updatedRoom] = await tx.select({ score: rooms.score }).from(rooms).where(eq2(rooms.id, roomId)).limit(1);
      if (!updatedRoom) unavailable();
      score = asNumber(updatedRoom.score);
    }
    await tx.delete(roomMemberships).where(eq2(roomMemberships.id, membership.id));
    await tx.insert(auditLogs).values({
      actorUserId: userId,
      action: "room.leave",
      targetRoomId: roomId,
      metadata: JSON.stringify({ role: membership.role, scorePenalty, score })
    });
    return { roomId, left: true, role: membership.role, scorePenalty, score };
  });
}
async function assertRoomManager(db, roomId, actorUserId) {
  const room = await getRoom(db, roomId);
  const membership = await membershipFor(db, roomId, actorUserId);
  const [actor] = await db.select({ role: users.role }).from(users).where(eq2(users.id, actorUserId)).limit(1);
  const isAdmin = actor?.role === "admin" || actor?.role === "superadmin";
  const isOwner = room.creatorId === actorUserId || membership?.role === "owner";
  if (!isAdmin && !isOwner && membership?.role !== "moderator") {
    fail("FORBIDDEN", "فقط سازنده یا مدیر مجاز این روم می‌تواند این کار را انجام دهد.");
  }
  return { room, membership, isAdmin, isOwner };
}
async function roomMembers(viewerUserId, roomId) {
  const db = await requireDb();
  await assertRoomManager(db, roomId, viewerUserId);
  const rows = await db.select({
    accountNumber: accountNumbers.accountNumber,
    username: profiles.username,
    name: users.name,
    avatarUrl: profiles.avatarUrl,
    avatarEmoji: profiles.avatarEmoji,
    badgeTitle: profiles.badgeTitle,
    crownStyle: profiles.crownStyle,
    isPrivate: profiles.isPrivate,
    isFriend: sql`EXISTS (SELECT 1 FROM friendships f WHERE f.userId = LEAST(${viewerUserId}, ${users.id}) AND f.friendUserId = GREATEST(${viewerUserId}, ${users.id}))`,
    appRole: users.role,
    role: roomMemberships.role,
    mutedUntil: roomMemberships.mutedUntil,
    joinedAt: roomMemberships.joinedAt,
  }).from(roomMemberships)
    .innerJoin(users, eq2(users.id, roomMemberships.userId))
    .leftJoin(profiles, eq2(profiles.userId, users.id))
    .leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(eq2(roomMemberships.roomId, roomId))
    .orderBy(asc(roomMemberships.joinedAt), asc(accountNumbers.accountNumber));
  const viewerAccountNumber = await ensureAccountNumberFor(db, viewerUserId);
  const now = Date.now();
  return Promise.all(rows.map(async (row) => {
    const isMe = Number(row.accountNumber) === viewerAccountNumber;
    const canViewProfile = canViewPrivateProfile(row.isPrivate, row.isFriend, isMe);
    const { isPrivate: _isPrivate, isFriend: _isFriend, ...member } = row;
    return {
      ...member,
      name: canViewProfile ? row.name : "حساب خصوصی",
      username: canViewProfile ? row.username : null,
      avatarUrl: canViewProfile ? await resolveProfileAvatar(db, row.avatarUrl) : null,
      avatarEmoji: canViewProfile ? row.avatarEmoji ?? null : null,
      badgeTitle: canViewProfile ? row.badgeTitle ?? null : null,
      crownStyle: canViewProfile ? row.crownStyle ?? null : null,
      canViewProfile,
      isMe,
      isMuted: Boolean(row.mutedUntil && new Date(row.mutedUntil).getTime() > now),
    };
  }));
}
async function resolveRoomMember(db, manager, actorUserId, roomId, targetAccountNumber) {
  const targetUserId = await accountNumberToUserId(db, targetAccountNumber);
  if (targetUserId === actorUserId || targetUserId === manager.room.creatorId) {
    fail("FORBIDDEN", "حساب خودت یا سازندهٔ روم را نمی‌توان از این مسیر مدیریت کرد.");
  }
  const membership = await membershipFor(db, roomId, targetUserId);
  if (!membership) fail("NOT_FOUND", "این کاربر عضو روم نیست.");
  if (!manager.isAdmin && !manager.isOwner && ["owner", "moderator"].includes(membership.role)) {
    fail("FORBIDDEN", "مدیر روم نمی‌تواند سمت مدیر دیگر را تغییر دهد.");
  }
  if (membership.role === "owner" && !manager.isAdmin && !manager.isOwner) {
    fail("FORBIDDEN", "فقط سازندهٔ روم یا Administrator می‌تواند مدیر روم را مدیریت کند.");
  }
  return { targetUserId, membership };
}
async function kickRoomMember(actorUserId, roomId, targetAccountNumber) {
  const db = await requireDb();
  const manager = await assertRoomManager(db, roomId, actorUserId);
  const target = await resolveRoomMember(db, manager, actorUserId, roomId, targetAccountNumber);
  await db.transaction(async (tx) => {
    await tx.delete(roomMemberships).where(eq2(roomMemberships.id, target.membership.id));
    await tx.insert(auditLogs).values({ actorUserId, targetUserId: target.targetUserId, targetRoomId: roomId, action: "room.member.kick", metadata: JSON.stringify({ targetAccountNumber }) });
  });
  return { success: true, roomId, accountNumber: targetAccountNumber };
}
async function muteRoomMember(actorUserId, roomId, targetAccountNumber, durationMinutes) {
  const db = await requireDb();
  const manager = await assertRoomManager(db, roomId, actorUserId);
  const target = await resolveRoomMember(db, manager, actorUserId, roomId, targetAccountNumber);
  const mutedUntil = durationMinutes === 0 ? null : new Date(Date.now() + durationMinutes * 60_000);
  await db.transaction(async (tx) => {
    await tx.update(roomMemberships).set({ mutedUntil }).where(eq2(roomMemberships.id, target.membership.id));
    await tx.insert(auditLogs).values({ actorUserId, targetUserId: target.targetUserId, targetRoomId: roomId, action: durationMinutes === 0 ? "room.member.unmute" : "room.member.mute", metadata: JSON.stringify({ targetAccountNumber, durationMinutes, mutedUntil }) });
  });
  return { success: true, roomId, accountNumber: targetAccountNumber, mutedUntil };
}
async function setRoomModerator(actorUserId, roomId, targetAccountNumber, moderator) {
  const db = await requireDb();
  const manager = await assertRoomManager(db, roomId, actorUserId);
  if (!manager.isAdmin && !manager.isOwner) fail("FORBIDDEN", "تعیین مدیر جدید فقط با سازندهٔ روم یا Administrator است.");
  const target = await resolveRoomMember(db, manager, actorUserId, roomId, targetAccountNumber);
  const role = moderator ? "moderator" : "member";
  await db.transaction(async (tx) => {
    await tx.update(roomMemberships).set({ role }).where(eq2(roomMemberships.id, target.membership.id));
    await tx.insert(auditLogs).values({ actorUserId, targetUserId: target.targetUserId, targetRoomId: roomId, action: moderator ? "room.member.promote" : "room.member.demote", metadata: JSON.stringify({ targetAccountNumber, role }) });
  });
  return { success: true, roomId, accountNumber: targetAccountNumber, role };
}
async function setRoomAnnouncement(actorUserId, roomId, text) {
  const db = await requireDb();
  await assertRoomManager(db, roomId, actorUserId);
  const announcement = text?.trim() || null;
  const announcementAt = announcement ? new Date() : null;
  await db.transaction(async (tx) => {
    await tx.update(rooms).set({ announcement, announcementAt }).where(eq2(rooms.id, roomId));
    await tx.insert(auditLogs).values({ actorUserId, targetRoomId: roomId, action: announcement ? "room.announcement.set" : "room.announcement.clear", metadata: JSON.stringify({ announcement }) });
  });
  return { success: true, roomId, announcement, announcementAt };
}
async function setRoomStatus(actorUserId, roomId, status) {
  const db = await requireDb();
  const manager = await assertRoomManager(db, roomId, actorUserId);
  if (!manager.isAdmin && !manager.isOwner) fail("FORBIDDEN", "تغییر وضعیت روم فقط با سازندهٔ روم یا Administrator است.");
  await db.transaction(async (tx) => {
    await tx.update(rooms).set({ status }).where(eq2(rooms.id, roomId));
    await tx.insert(auditLogs).values({ actorUserId, targetRoomId: roomId, action: "room.status.set", metadata: JSON.stringify({ status }) });
  });
  return { success: true, roomId, status };
}
async function clearRoomMessages(actorUserId, roomId) {
  const db = await requireDb();
  const manager = await assertRoomManager(db, roomId, actorUserId);
  if (!manager.isAdmin && !manager.isOwner) fail("FORBIDDEN", "پاک‌سازی پیام‌های روم فقط با سازندهٔ روم یا Administrator است.");
  const result = await db.transaction(async (tx) => {
    const [count] = await tx.select({ count: sql`COUNT(*)` }).from(messages).where(eq2(messages.roomId, roomId));
    await tx.delete(messages).where(eq2(messages.roomId, roomId));
    await tx.insert(auditLogs).values({ actorUserId, targetRoomId: roomId, action: "room.messages.clear", metadata: JSON.stringify({ deletedCount: asNumber(count?.count ?? 0) }) });
    return asNumber(count?.count ?? 0);
  });
  return { success: true, roomId, deletedCount: result };
}
async function listRoomMessages(userId, roomId, input) {
  const db = await requireDb();
  await assertRoomAccess(db, roomId, userId);
  const rows = await db.select({
    id: messages.id,
    roomId: messages.roomId,
    senderId: messages.senderId,
    recipientUserId: messages.recipientUserId,
    type: messages.type,
    body: messages.body,
    assetUrl: messages.assetUrl,
    assetMetadata: messages.assetMetadata,
    createdAt: messages.createdAt,
    editedAt: messages.editedAt,
    deletedAt: messages.deletedAt,
    senderName: users.name,
    senderUsername: profiles.username,
    senderAvatarUrl: profiles.avatarUrl,
    senderAvatarEmoji: profiles.avatarEmoji,
    senderBadgeTitle: profiles.badgeTitle,
    senderCrownStyle: profiles.crownStyle,
    senderGender: profiles.gender,
    senderRole: users.role,
    senderRoomRole: roomMemberships.role,
    senderIsPrivate: profiles.isPrivate,
    senderIsFriend: sql`EXISTS (SELECT 1 FROM friendships f WHERE f.userId = LEAST(${userId}, ${users.id}) AND f.friendUserId = GREATEST(${userId}, ${users.id}))`,
    senderAccountNumber: accountNumbers.accountNumber,
    senderMessageBubbleColor: profiles.messageBubbleColor,
    senderMessageTextColor: profiles.messageTextColor,
    senderChatMessageCount: profiles.chatMessageCount,
    senderRankOverride: profiles.rankOverride,
  }).from(messages).innerJoin(users, eq2(users.id, messages.senderId)).leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).leftJoin(roomMemberships, and(eq2(roomMemberships.roomId, messages.roomId), eq2(roomMemberships.userId, users.id))).where(eq2(messages.roomId, roomId)).orderBy(desc(messages.id)).limit(clampLimit(input.limit, 50)).offset(clampOffset(input.offset));
  return resolveMessageViews(db, rows.reverse(), userId);
}
async function recordChatSecurityEvent(db, userId, eventType, severity, summary, now) {
  try {
    const [recentEvent] = await db.select({ id: securityEvents.id }).from(securityEvents).where(and(
      eq2(securityEvents.userId, userId),
      eq2(securityEvents.eventType, eventType),
      gte(securityEvents.createdAt, new Date(now.getTime() - 5 * 60e3)),
    )).limit(1);
    if (!recentEvent) {
      await db.insert(securityEvents).values({ userId, eventType, severity, summary });
    }
  } catch {
    // Message rejection remains authoritative if the event table is not yet migrated.
  }
}
async function assertChatSendRate(db, userId, body, assetUrl = null, eventDb = db) {
  const now = new Date();
  const windowStart = new Date(now.getTime() - 60e3);
  const [lockedProfile] = await db.select({ userId: profiles.userId }).from(profiles)
    .where(eq2(profiles.userId, userId)).for("update");
  if (!lockedProfile) unavailable();
  const [recent] = await db.select({ count: sql`COUNT(*)` }).from(messages).where(and(
    eq2(messages.senderId, userId),
    gte(messages.createdAt, windowStart),
  ));
  if (asNumber(recent?.count ?? 0) >= 20) {
    await recordChatSecurityEvent(eventDb, userId, "message_flood", "high", "سامانه ارسال پیام پرتعداد را متوقف کرد.", now);
    fail("TOO_MANY_REQUESTS", "برای جلوگیری از هرزنامه، یک دقیقه صبر کن و دوباره پیام بده.");
  }

  const normalizedBody = typeof body === "string"
    ? body.normalize("NFKC").trim().replace(/\s+/g, " ").toLocaleLowerCase("fa-IR")
    : "";
  if (normalizedBody.length >= 2 || assetUrl) {
    const candidates = await db.select({ body: messages.body, assetUrl: messages.assetUrl }).from(messages).where(and(
      eq2(messages.senderId, userId),
      gte(messages.createdAt, new Date(now.getTime() - 30e3)),
    )).orderBy(desc(messages.id)).limit(20);
    const duplicate = candidates.some((item) =>
      (normalizedBody.length >= 2 && typeof item.body === "string" &&
        item.body.normalize("NFKC").trim().replace(/\s+/g, " ").toLocaleLowerCase("fa-IR") === normalizedBody) ||
      (Boolean(assetUrl) && item.assetUrl === assetUrl));
    if (duplicate) {
      await recordChatSecurityEvent(eventDb, userId, "duplicate_message", "warning", "سامانه پیام تکراری را متوقف کرد.", now);
      fail("TOO_MANY_REQUESTS", "ربات محافظ پیام تکراری را شناسایی کرد؛ کمی صبر کن و متن تازه‌ای بفرست.");
    }
  }
}
async function sendRoomMessage(userId, input) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const { membership } = await assertRoomAccess(db, input.roomId, userId, true);
  if (!membership) fail("FORBIDDEN", "ابتدا به روم بپیوند.");
  if (membership.mutedUntil && membership.mutedUntil > new Date()) fail("FORBIDDEN", "ارسال پیام در این روم تا پایان زمان سکوت محدود شده است.");
  const body = input.text?.trim() ?? null;

  const id = await db.transaction(async (tx) => {
    const asset = await getOwnedChatMedia(tx, userId, input.assetId);
    if (!asset && (!body || body.length < 2)) fail("BAD_REQUEST", "پیام متنی باید دست‌کم دو نویسه داشته باشد.");
    const mediaKind = asset ? asset.contentType.startsWith("image/") ? "image" : asset.contentType.startsWith("audio/") ? "audio" : "asset" : null;
    if (asset && input.type && input.type !== mediaKind) fail("BAD_REQUEST", "نوع پیام با نوع فایل پیوست‌شده سازگار نیست.");
    if (!asset && input.type && input.type !== "text") fail("BAD_REQUEST", "برای پیام رسانه‌ای فایل معتبر لازم است.");
    await assertChatSendRate(tx, userId, body, asset?.stableUrl ?? null, db);
    const result = await tx.insert(messages).values({
      roomId: input.roomId,
      senderId: userId,
      type: mediaKind ?? "text",
      body,
      assetUrl: asset?.stableUrl ?? null,
      assetMetadata: asset ? JSON.stringify({ fileName: asset.fileName, contentType: asset.contentType, sizeBytes: asset.sizeBytes }) : null
    });
    await tx.update(profiles).set({ chatMessageCount: sql`${profiles.chatMessageCount} + 1` }).where(eq2(profiles.userId, userId));
    return Number(result[0].insertId);
  });
  const [row] = await db.select().from(messages).where(eq2(messages.id, id)).limit(1);
  if (!row) unavailable();
  return (await resolveMessageViews(db, [row]))[0];
}
async function accountNumberToUserId(db, accountNumber) {
  const [account] = await db.select({ userId: accountNumbers.userId }).from(accountNumbers)
    .where(eq2(accountNumbers.accountNumber, accountNumber)).limit(1);
  if (!account?.userId) fail("NOT_FOUND", "کاربری با این شمارهٔ حساب پیدا نشد.");
  return account.userId;
}
async function assertPrivateThread(db, userId, otherUserId) {
  if (userId === otherUserId) fail("BAD_REQUEST", "\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u062E\u0635\u0648\u0635\u06CC \u0628\u0627 \u062E\u0648\u062F\u062A\u0627\u0646 \u0645\u062C\u0627\u0632 \u0646\u06CC\u0633\u062A.");
  if (!await userExists(db, otherUserId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const [profile] = await db.select({ isPrivate: profiles.isPrivate }).from(profiles)
    .where(eq2(profiles.userId, otherUserId)).limit(1);
  if (profile?.isPrivate) {
    const [friendship] = await db.select({ id: friendships.id }).from(friendships).where(and(
      eq2(friendships.userId, Math.min(userId, otherUserId)),
      eq2(friendships.friendUserId, Math.max(userId, otherUserId)),
    )).limit(1);
    if (!friendship) fail("FORBIDDEN", "حساب خصوصی فقط به دوستان اجازهٔ پیام خصوصی می‌دهد.");
  }
  await assertNotBlocked(db, userId, otherUserId);
}
async function filterHiddenPrivateMessages(db, userId, rows) {
  if (!rows.length) return rows;
  const ids = rows.map((row) => row.id);
  const hidden = await db.select({ messageId: messageHides.messageId }).from(messageHides).where(and(
    eq2(messageHides.userId, userId),
    inArray(messageHides.messageId, ids),
  ));
  if (!hidden.length) return rows;
  const hiddenIds = new Set(hidden.map((row) => row.messageId));
  return rows.filter((row) => !hiddenIds.has(row.id));
}
async function listPrivateThread(userId, otherAccountNumber, input) {
  const db = await requireDb();
  const otherUserId = await accountNumberToUserId(db, otherAccountNumber);
  await assertPrivateThread(db, userId, otherUserId);
  await db.update(messages).set({ readAt: new Date() }).where(and(
    isNull(messages.roomId),
    eq2(messages.senderId, otherUserId),
    eq2(messages.recipientUserId, userId),
    isNull(messages.readAt),
    isNull(messages.deletedAt),
  ));
  const rows = await db.select({
    id: messages.id,
    roomId: messages.roomId,
    senderId: messages.senderId,
    recipientUserId: messages.recipientUserId,
    type: messages.type,
    body: messages.body,
    assetUrl: messages.assetUrl,
    assetMetadata: messages.assetMetadata,
    createdAt: messages.createdAt,
    editedAt: messages.editedAt,
    deletedAt: messages.deletedAt,
    senderName: users.name,
    senderUsername: profiles.username,
    senderAvatarUrl: profiles.avatarUrl,
    senderAvatarEmoji: profiles.avatarEmoji,
    senderBadgeTitle: profiles.badgeTitle,
    senderCrownStyle: profiles.crownStyle,
    senderGender: profiles.gender,
    senderRole: users.role,
    senderAccountNumber: accountNumbers.accountNumber,
    senderMessageBubbleColor: profiles.messageBubbleColor,
    senderMessageTextColor: profiles.messageTextColor,
    senderChatMessageCount: profiles.chatMessageCount,
    senderRankOverride: profiles.rankOverride
  }).from(messages).innerJoin(users, eq2(users.id, messages.senderId)).leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(
    and(
      isNull(messages.roomId),
      or(
        and(eq2(messages.senderId, userId), eq2(messages.recipientUserId, otherUserId)),
        and(eq2(messages.senderId, otherUserId), eq2(messages.recipientUserId, userId))
      )
    )
  ).orderBy(desc(messages.id)).limit(clampLimit(input.limit, 50)).offset(clampOffset(input.offset));
  const visibleRows = await filterHiddenPrivateMessages(db, userId, rows);
  return resolveMessageViews(db, visibleRows.reverse(), userId);
}
async function sendPrivateMessage(userId, otherAccountNumber, input) {
  const db = await requireDb();
  const otherUserId = await accountNumberToUserId(db, otherAccountNumber);
  await assertCanParticipate(db, userId);
  await assertPrivateThread(db, userId, otherUserId);
  const body = input.text?.trim() ?? null;
  const id = await db.transaction(async (tx) => {
    const asset = await getOwnedChatMedia(tx, userId, input.assetId);
    if (!asset && (!body || body.length < 2)) fail("BAD_REQUEST", "پیام متنی باید دست‌کم دو نویسه داشته باشد.");
    const mediaKind = asset ? asset.contentType.startsWith("image/") ? "image" : asset.contentType.startsWith("audio/") ? "audio" : "asset" : null;
    if (asset && input.type && input.type !== mediaKind) fail("BAD_REQUEST", "نوع پیام با نوع فایل پیوست‌شده سازگار نیست.");
    if (!asset && input.type && input.type !== "text") fail("BAD_REQUEST", "برای پیام رسانه‌ای فایل معتبر لازم است.");
    await assertChatSendRate(tx, userId, body, asset?.stableUrl ?? null, db);
    const result = await tx.insert(messages).values({
      senderId: userId,
      recipientUserId: otherUserId,
      type: mediaKind ?? "text",
      body,
      assetUrl: asset?.stableUrl ?? null,
      assetMetadata: asset ? JSON.stringify({ fileName: asset.fileName, contentType: asset.contentType, sizeBytes: asset.sizeBytes }) : null
    });
    await tx.update(profiles).set({ chatMessageCount: sql`${profiles.chatMessageCount} + 1` }).where(eq2(profiles.userId, userId));
    return Number(result[0].insertId);
  });
  const [row] = await db.select().from(messages).where(eq2(messages.id, id)).limit(1);
  if (!row) unavailable();
  return (await resolveMessageViews(db, [row], userId))[0];
}
async function deletePrivateMessage(userId, messageId, scope) {
  const db = await requireDb();
  const [message] = await db.select({
    id: messages.id,
    roomId: messages.roomId,
    senderId: messages.senderId,
    recipientUserId: messages.recipientUserId,
    deletedAt: messages.deletedAt,
  }).from(messages).where(eq2(messages.id, messageId)).limit(1);
  if (!message || message.roomId !== null || (message.senderId !== userId && message.recipientUserId !== userId)) {
    fail("NOT_FOUND", "پیام خصوصی پیدا نشد.");
  }
  if (scope === "me") {
    await db.insert(messageHides).values({ messageId, userId }).onDuplicateKeyUpdate({ set: { userId } });
    return { success: true, scope: "me" };
  }
  if (message.senderId !== userId) fail("FORBIDDEN", "فقط فرستنده می‌تواند پیام را برای هر دو طرف حذف کند.");
  if (!message.deletedAt) {
    await db.update(messages).set({
      deletedAt: new Date(),
      deletedByUserId: userId,
      body: null,
      assetUrl: null,
      assetMetadata: null,
    }).where(and(eq2(messages.id, messageId), eq2(messages.senderId, userId), isNull(messages.deletedAt)));
  }
  return { success: true, scope: "everyone" };
}
async function privateInbox(userId, input) {
  const db = await requireDb();
  const rows = await db.select({
    id: messages.id,
    roomId: messages.roomId,
    senderId: messages.senderId,
    recipientUserId: messages.recipientUserId,
    type: messages.type,
    body: messages.body,
    assetUrl: messages.assetUrl,
    assetMetadata: messages.assetMetadata,
    createdAt: messages.createdAt,
    editedAt: messages.editedAt,
    deletedAt: messages.deletedAt,
    senderName: users.name,
    senderUsername: profiles.username,
    senderAvatarUrl: profiles.avatarUrl,
    senderAvatarEmoji: profiles.avatarEmoji,
    senderBadgeTitle: profiles.badgeTitle,
    senderCrownStyle: profiles.crownStyle,
    senderGender: profiles.gender,
    senderRole: users.role,
    senderAccountNumber: accountNumbers.accountNumber,
    senderMessageBubbleColor: profiles.messageBubbleColor,
    senderMessageTextColor: profiles.messageTextColor,
    senderChatMessageCount: profiles.chatMessageCount,
    senderRankOverride: profiles.rankOverride,
  }).from(messages).innerJoin(users, eq2(users.id, messages.senderId)).leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(and(isNull(messages.roomId), or(eq2(messages.senderId, userId), eq2(messages.recipientUserId, userId)))).orderBy(desc(messages.id)).limit(clampLimit(input.limit, 50)).offset(clampOffset(input.offset));
  const visibleRows = await filterHiddenPrivateMessages(db, userId, rows);
  const counterpartIds = [...new Set(visibleRows.map((row) => row.senderId === userId ? row.recipientUserId : row.senderId).filter((id) => Number.isInteger(id) && id > 0))];
  const counterpartRows = counterpartIds.length ? await db.select({
    id: users.id,
    name: users.name,
    username: profiles.username,
    avatarUrl: profiles.avatarUrl,
    avatarEmoji: profiles.avatarEmoji,
    badgeTitle: profiles.badgeTitle,
    crownStyle: profiles.crownStyle,
    role: users.role,
    accountNumber: accountNumbers.accountNumber,
  }).from(users).leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(inArray(users.id, counterpartIds)) : [];
  const signedCounterparts = await Promise.all(counterpartRows.map(async (person) => ({ ...person, avatarUrl: await resolveProfileAvatar(db, person.avatarUrl) })));
  const counterpartById = new Map(signedCounterparts.map((person) => [person.id, person]));
  const unreadRows = counterpartIds.length ? await db.select({
    senderId: messages.senderId,
    unreadCount: sql`COUNT(*)`,
  }).from(messages).where(and(
    isNull(messages.roomId),
    eq2(messages.recipientUserId, userId),
    isNull(messages.readAt),
    isNull(messages.deletedAt),
    inArray(messages.senderId, counterpartIds),
    notExists(db.select({ id: messageHides.id }).from(messageHides).where(and(
      eq2(messageHides.messageId, messages.id),
      eq2(messageHides.userId, userId),
    ))),
  )).groupBy(messages.senderId) : [];
  const unreadBySender = new Map(unreadRows.map((row) => [row.senderId, asNumber(row.unreadCount)]));
  const messageViews = await resolveMessageViews(db, visibleRows, userId);
  return visibleRows.map((row, index) => {
    const otherId = row.senderId === userId ? row.recipientUserId : row.senderId;
    const counterpart = counterpartById.get(otherId);
    return {
      ...messageViews[index],
      unreadCount: unreadBySender.get(otherId) ?? 0,
      otherUser: counterpart ? {
        accountNumber: counterpart.accountNumber,
        name: counterpart.name,
        username: counterpart.username,
        avatarUrl: counterpart.avatarUrl,
        avatarEmoji: counterpart.avatarEmoji ?? null,
        badgeTitle: counterpart.badgeTitle ?? null,
        crownStyle: counterpart.crownStyle ?? null,
        role: counterpart.role,
      } : null,
    };
  });
}
async function countUnreadPrivateMessages(userId) {
  const db = await requireDb();
  const [result] = await db.select({ unreadCount: sql`COUNT(*)` }).from(messages).where(and(
    isNull(messages.roomId),
    eq2(messages.recipientUserId, userId),
    isNull(messages.readAt),
    isNull(messages.deletedAt),
    notExists(db.select({ id: messageHides.id }).from(messageHides).where(and(
      eq2(messageHides.messageId, messages.id),
      eq2(messageHides.userId, userId),
    ))),
  ));
  return { unreadCount: asNumber(result?.unreadCount ?? 0) };
}
async function transferBetween(db, input) {
  if (input.fromUserId === input.toUserId) fail("BAD_REQUEST", "\u0627\u0646\u062A\u0642\u0627\u0644 \u0628\u0647 \u062E\u0648\u062F\u062A\u0627\u0646 \u0645\u062C\u0627\u0632 \u0646\u06CC\u0633\u062A.");
  if (!isSafeDiamondAmount(input.amount)) fail("BAD_REQUEST", "مقدار الماس باید عدد صحیح و در محدودهٔ امن سامانه باشد.");
  if (!await userExists(db, input.toUserId)) fail("NOT_FOUND", "\u062F\u0631\u06CC\u0627\u0641\u062A\u200C\u06A9\u0646\u0646\u062F\u0647 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  await ensureAccountFor(db, input.fromUserId);
  await ensureAccountFor(db, input.toUserId);
  const fromUnlimited = await isUnlimitedDiamondAdmin(db, input.fromUserId);
  const toUnlimited = await isUnlimitedDiamondAdmin(db, input.toUserId);
  return db.transaction(async (tx) => {
    if (fromUnlimited) await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, input.fromUserId));
    else {
      const debit = await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} - ${input.amount}` }).where(and(eq2(pointAccounts.userId, input.fromUserId), gte(pointAccounts.balance, input.amount)));
      if (debit[0].affectedRows !== 1) fail("BAD_REQUEST", "\u0645\u0648\u062C\u0648\u062F\u06CC \u06A9\u0627\u0641\u06CC \u0646\u06CC\u0633\u062A.");
    }
    if (toUnlimited) await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, input.toUserId));
    else {
      const credit = await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} + ${input.amount}` }).where(and(eq2(pointAccounts.userId, input.toUserId), lte(pointAccounts.balance, MAX_SAFE_DIAMONDS - input.amount)));
      if (credit[0].affectedRows !== 1) fail("BAD_REQUEST", "موجودی دریافت‌کننده از محدودهٔ عددی امن بیشتر می‌شود.");
    }
    const [fromAccount] = await tx.select({ balance: pointAccounts.balance }).from(pointAccounts).where(eq2(pointAccounts.userId, input.fromUserId)).limit(1);
    const [toAccount] = await tx.select({ balance: pointAccounts.balance }).from(pointAccounts).where(eq2(pointAccounts.userId, input.toUserId)).limit(1);
    if (!fromAccount || !toAccount) unavailable();
    await tx.insert(pointTransactions).values([
      {
        accountUserId: input.fromUserId,
        counterpartyUserId: input.toUserId,
        roomId: input.roomId ?? null,
        type: input.type,
        direction: "debit",
        amount: input.amount,
        balanceAfter: fromAccount.balance,
        note: input.note ?? null,
        performedByUserId: input.fromUserId
      },
      {
        accountUserId: input.toUserId,
        counterpartyUserId: input.fromUserId,
        roomId: input.roomId ?? null,
        type: input.type,
        direction: "credit",
        amount: input.amount,
        balanceAfter: toAccount.balance,
        note: input.note ?? null,
        performedByUserId: input.fromUserId
      }
    ]);
    return { fromBalance: fromAccount.balance, toBalance: toAccount.balance };
  });
}
async function getWallet(userId) {
  const db = await requireDb();
  const account = await ensureAccountFor(db, userId);
  const accountNumber = await ensureAccountNumberFor(db, userId);
  const transactions = await listWalletHistory(userId, { limit: 20 });
  return { accountNumber, balance: asNumber(account.balance), isUnlimited: await isUnlimitedDiamondAdmin(db, userId), transactions };
}
const SHOP_PRODUCTS = {
  message_sapphire: { kind: "message-color", title: "پالت آبی لاجوردی", price: 50, bubbleColor: "#2D65C8", textColor: "#FFFFFF" },
  message_gold: { kind: "message-color", title: "پالت طلایی", price: 50, bubbleColor: "#C89325", textColor: "#17130A" },
  message_rose: { kind: "message-color", title: "پالت رز", price: 50, bubbleColor: "#B04E74", textColor: "#FFFFFF" },
  invisibility_60m: { kind: "invisibility", title: "نامرئی‌شدن ۶۰ دقیقه", price: 100, durationMinutes: 60 },
};
async function shopCatalog(userId) {
  const db = await requireDb();
  const account = await ensureAccountFor(db, userId);
  const profile = await ensureProfileFor(db, userId);
  const now = new Date();
  return {
    balance: asNumber(account.balance),
    isUnlimited: await isUnlimitedDiamondAdmin(db, userId),
    invisibleUntil: profile.invisibleUntil,
    invisibleActive: Boolean(profile.invisibleUntil && profile.invisibleUntil > now),
    products: Object.entries(SHOP_PRODUCTS).map(([id, product]) => ({
      id,
      ...product,
      isCurrent: product.kind === "message-color"
        ? profile.messageBubbleColor === product.bubbleColor && profile.messageTextColor === product.textColor
        : Boolean(profile.invisibleUntil && profile.invisibleUntil > now),
    })),
  };
}
async function purchaseShopProduct(userId, productId) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const product = SHOP_PRODUCTS[productId];
  if (!product) fail("BAD_REQUEST", "این محصول در آرشاپ موجود نیست.");
  await ensureAccountFor(db, userId);
  await ensureProfileFor(db, userId);
  const unlimited = await isUnlimitedDiamondAdmin(db, userId);
  return db.transaction(async (tx) => {
    const [account] = await tx.select({ balance: pointAccounts.balance }).from(pointAccounts)
      .where(eq2(pointAccounts.userId, userId)).for("update").limit(1);
    const [profile] = await tx.select({
      messageBubbleColor: profiles.messageBubbleColor,
      messageTextColor: profiles.messageTextColor,
      invisibleUntil: profiles.invisibleUntil,
    }).from(profiles).where(eq2(profiles.userId, userId)).for("update").limit(1);
    if (!account || !profile) unavailable();
    if (product.kind === "message-color" && profile.messageBubbleColor === product.bubbleColor && profile.messageTextColor === product.textColor) {
      fail("BAD_REQUEST", "این پالت پیام هم‌اکنون فعال است و برای آن امتیازی کسر نشد.");
    }
    const balanceBefore = unlimited ? MAX_SAFE_DIAMONDS : asNumber(account.balance);
    if (balanceBefore < product.price) fail("BAD_REQUEST", "موجودی امتیاز برای خرید این محصول کافی نیست.");
    const balanceAfter = unlimited ? MAX_SAFE_DIAMONDS : balanceBefore - product.price;
    let invisibleUntil = profile.invisibleUntil;
    if (product.kind === "message-color") {
      await tx.update(profiles).set({ messageBubbleColor: product.bubbleColor, messageTextColor: product.textColor }).where(eq2(profiles.userId, userId));
    } else {
      const now = new Date();
      const baseTime = Math.max(now.getTime(), profile.invisibleUntil?.getTime?.() ?? 0);
      invisibleUntil = new Date(baseTime + product.durationMinutes * 60_000);
      if (invisibleUntil.getTime() - now.getTime() > 24 * 60 * 60_000) fail("BAD_REQUEST", "حداکثر زمان نامرئی‌شدن قابل ذخیره ۲۴ ساعت است.");
      await tx.update(profiles).set({ invisibleUntil }).where(eq2(profiles.userId, userId));
    }
    if (unlimited) await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, userId));
    else await tx.update(pointAccounts).set({ balance: balanceAfter }).where(eq2(pointAccounts.userId, userId));
    await tx.insert(pointTransactions).values({
      accountUserId: userId,
      type: "purchase",
      direction: "debit",
      amount: product.price,
      balanceAfter,
      note: `shop:${productId} · ${product.title}`,
      performedByUserId: userId,
    });
    return { success: true, productId, title: product.title, pointsCharged: product.price, balance: balanceAfter, invisibleUntil };
  });
}
async function listWalletHistory(userId, input) {
  const db = await requireDb();
  await ensureAccountFor(db, userId);
  return db.select({
    id: pointTransactions.id, type: pointTransactions.type, direction: pointTransactions.direction, amount: pointTransactions.amount,
    balanceAfter: pointTransactions.balanceAfter, note: pointTransactions.note, roomId: pointTransactions.roomId,
    createdAt: pointTransactions.createdAt,
    accountName: sql`(SELECT name FROM users WHERE id = ${pointTransactions.accountUserId} LIMIT 1)`. $type<string | null>(),
    accountUsername: sql`(SELECT username FROM profiles WHERE userId = ${pointTransactions.accountUserId} LIMIT 1)`. $type<string | null>(),
    accountNumber: sql`(SELECT accountNumber FROM account_numbers WHERE userId = ${pointTransactions.accountUserId} LIMIT 1)`. $type<number | null>(),
    counterpartyName: users.name, counterpartyUsername: profiles.username, counterpartyAccountNumber: accountNumbers.accountNumber,
    actorName: sql`(SELECT name FROM users WHERE id = ${pointTransactions.performedByUserId} LIMIT 1)`. $type<string | null>(),
    actorAccountNumber: sql`(SELECT accountNumber FROM account_numbers WHERE userId = ${pointTransactions.performedByUserId} LIMIT 1)`. $type<number | null>(),
  }).from(pointTransactions).leftJoin(users, eq2(users.id, pointTransactions.counterpartyUserId))
    .leftJoin(profiles, eq2(profiles.userId, pointTransactions.counterpartyUserId))
    .leftJoin(accountNumbers, eq2(accountNumbers.userId, pointTransactions.counterpartyUserId))
    .where(eq2(pointTransactions.accountUserId, userId)).orderBy(desc(pointTransactions.id)).limit(clampLimit(input.limit, 50)).offset(clampOffset(input.offset));
}
async function transferPoints(userId, toAccountNumber, amount, note) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const [recipient] = await db.select({ userId: accountNumbers.userId }).from(accountNumbers)
    .where(eq2(accountNumbers.accountNumber, toAccountNumber)).limit(1);
  const toUserId = recipient?.userId;
  if (!toUserId) fail("NOT_FOUND", "کاربری با این شمارهٔ حساب پیدا نشد.");
  await assertNotBlocked(db, userId, toUserId);
  const balances = await transferBetween(db, { fromUserId: userId, toUserId, amount, type: "transfer", note });
  return { success: true, recipientAccountNumber: toAccountNumber, ...balances };
}
async function tipRoom(userId, roomId, amount) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const { room } = await assertRoomAccess(db, roomId, userId);
  if (room.creatorId === userId) fail("BAD_REQUEST", "\u0627\u0645\u06a9\u0627\u0646 \u0627\u0645\u062a\u06cc\u0627\u0632 \u062f\u0627\u062f\u0646 \u0628\u0647 \u0631\u0648\u0645 \u062e\u0648\u062f\u062a\u0627\u0646 \u0648\u062c\u0648\u062f \u0646\u062f\u0627\u0631\u062f.");
  await ensureAccountFor(db, userId);
  await ensureAccountFor(db, room.creatorId);
  const senderUnlimited = await isUnlimitedDiamondAdmin(db, userId);
  const ownerUnlimited = await isUnlimitedDiamondAdmin(db, room.creatorId);
  return db.transaction(async (tx) => {
    if (senderUnlimited) await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, userId));
    else {
      const debit = await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} - ${amount}` })
        .where(and(eq2(pointAccounts.userId, userId), gte(pointAccounts.balance, amount)));
      if (debit[0].affectedRows !== 1) fail("BAD_REQUEST", "\u0645\u0648\u062c\u0648\u062f\u06cc \u0627\u0645\u062a\u06cc\u0627\u0632 \u06a9\u0627\u0641\u06cc \u0646\u06cc\u0633\u062a.");
    }
    if (ownerUnlimited) await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, room.creatorId));
    else await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} + ${amount}` }).where(eq2(pointAccounts.userId, room.creatorId));
    const [fromAccount] = await tx.select({ balance: pointAccounts.balance }).from(pointAccounts)
      .where(eq2(pointAccounts.userId, userId)).limit(1);
    const [toAccount] = await tx.select({ balance: pointAccounts.balance }).from(pointAccounts)
      .where(eq2(pointAccounts.userId, room.creatorId)).limit(1);
    if (!fromAccount || !toAccount) unavailable();
    await tx.insert(pointTransactions).values([
      { accountUserId: userId, counterpartyUserId: room.creatorId, roomId, type: "room_tip", direction: "debit", amount, balanceAfter: fromAccount.balance, note: `Tip for room ${roomId}`, performedByUserId: userId },
      { accountUserId: room.creatorId, counterpartyUserId: userId, roomId, type: "room_tip", direction: "credit", amount, balanceAfter: toAccount.balance, note: `Tip for room ${roomId}`, performedByUserId: userId },
    ]);
    await tx.update(rooms).set({ score: sql`${rooms.score} + ${amount}` }).where(eq2(rooms.id, roomId));
    return { success: true, roomId, fromBalance: fromAccount.balance, toBalance: toAccount.balance };
  });
}
async function toggleFriend(userId, targetAccountNumber) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const targetUserId = await accountNumberToUserId(db, targetAccountNumber);
  if (userId === targetUserId) fail("BAD_REQUEST", "\u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u062E\u0648\u062F\u062A\u0627\u0646 \u0631\u0627 \u062F\u0648\u0633\u062A \u0627\u0636\u0627\u0641\u0647 \u06A9\u0646\u06CC\u062F.");
  if (!await userExists(db, targetUserId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  await assertNotBlocked(db, userId, targetUserId);
  const first = Math.min(userId, targetUserId);
  const second = Math.max(userId, targetUserId);
  const [existing] = await db.select({ id: friendships.id }).from(friendships).where(and(eq2(friendships.userId, first), eq2(friendships.friendUserId, second))).limit(1);
  if (existing) {
    await db.delete(friendships).where(eq2(friendships.id, existing.id));
    return { isFriend: false };
  }
  await db.insert(friendships).values({ userId: first, friendUserId: second });
  return { isFriend: true };
}
async function toggleBlock(userId, targetAccountNumber) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const targetUserId = await accountNumberToUserId(db, targetAccountNumber);
  if (userId === targetUserId) fail("BAD_REQUEST", "\u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u062E\u0648\u062F\u062A\u0627\u0646 \u0631\u0627 \u0628\u0644\u0627\u06A9 \u06A9\u0646\u06CC\u062F.");
  if (!await userExists(db, targetUserId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const [existing] = await db.select({ id: blockedUsers.id }).from(blockedUsers).where(and(eq2(blockedUsers.blockerUserId, userId), eq2(blockedUsers.blockedUserId, targetUserId))).limit(1);
  if (existing) {
    await db.delete(blockedUsers).where(eq2(blockedUsers.id, existing.id));
    return { isBlocked: false };
  }
  await db.transaction(async (tx) => {
    await tx.insert(blockedUsers).values({ blockerUserId: userId, blockedUserId: targetUserId });
    await tx.delete(friendships).where(
      and(
        eq2(friendships.userId, Math.min(userId, targetUserId)),
        eq2(friendships.friendUserId, Math.max(userId, targetUserId))
      )
    );
  });
  return { isBlocked: true };
}
async function createReport(userId, input) {
  const db = await requireDb();
  const reportedUserId = await accountNumberToUserId(db, input.accountNumber);
  if (userId === reportedUserId) fail("BAD_REQUEST", "\u06AF\u0632\u0627\u0631\u0634 \u062E\u0648\u062F\u062A\u0627\u0646 \u0645\u062C\u0627\u0632 \u0646\u06CC\u0633\u062A.");
  const result = await db.insert(moderationReports).values({
    reporterUserId: userId,
    reportedUserId,
    reason: input.reason,
    details: input.details ?? null,
  });
  return { id: Number(result[0].insertId), status: "open" };
}
async function adminSummary(adminUserId) {
  const db = await requireDb();
  if (adminUserId !== void 0) await ensureAccountNumberFor(db, adminUserId);
  const [[userTotal], [roomTotal], [messageTotal], [reportTotal], [points]] = await Promise.all([
    db.select({ count: sql`COUNT(*)` }).from(users),
    db.select({ count: sql`COUNT(*)` }).from(rooms),
    db.select({ count: sql`COUNT(*)` }).from(messages),
    db.select({ count: sql`COUNT(*)` }).from(moderationReports).where(eq2(moderationReports.status, "open")),
    db.select({ total: sql`COALESCE(SUM(${pointAccounts.balance}), 0)` }).from(pointAccounts)
  ]);
  return {
    users: asNumber(userTotal?.count ?? 0),
    rooms: asNumber(roomTotal?.count ?? 0),
    messages: asNumber(messageTotal?.count ?? 0),
    openReports: asNumber(reportTotal?.count ?? 0),
    points: asNumber(points?.total ?? 0)
  };
}
async function adminUsers(input) {
  const db = await requireDb();
  const queryText = input.query?.trim();
  const queryAccountNumber = queryText && /^\d+$/.test(queryText) ? Number(queryText) : void 0;
  const rows = await db.select({
    id: users.id,
    accountNumber: accountNumbers.accountNumber,
    name: users.name,
    email: users.email,
    role: users.role,
    createdAt: users.createdAt,
    lastSignedIn: users.lastSignedIn,
    username: profiles.username,
    avatarUrl: profiles.avatarUrl,
    avatarEmoji: profiles.avatarEmoji,
    badgeTitle: profiles.badgeTitle,
    crownStyle: profiles.crownStyle,
    accountStatus: profiles.accountStatus,
    suspendedUntil: profiles.suspendedUntil,
    rankLevel: sql`COALESCE(${profiles.rankOverride}, CASE WHEN ${profiles.chatMessageCount} >= 700000 THEN 5 WHEN ${profiles.chatMessageCount} >= 300000 THEN 4 WHEN ${profiles.chatMessageCount} >= 100000 THEN 3 WHEN ${profiles.chatMessageCount} >= 20000 THEN 2 WHEN ${profiles.chatMessageCount} >= 1000 THEN 1 ELSE 0 END)`,
    rankIsManual: sql`${profiles.rankOverride} IS NOT NULL`,
    chatMessageCount: profiles.chatMessageCount,
    points: sql`COALESCE((SELECT balance FROM point_accounts pa WHERE pa.userId = ${users.id}), 0)`
  }).from(users).leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(
    and(
      input.role ? eq2(users.role, input.role) : void 0,
      queryText ? or(like(users.name, `%${queryText}%`), like(profiles.username, `%${queryText}%`), like(users.email, `%${queryText}%`), queryAccountNumber !== void 0 ? eq2(accountNumbers.accountNumber, queryAccountNumber) : void 0) : void 0
    )
  ).orderBy(desc(users.id)).limit(clampLimit(input.limit)).offset(clampOffset(input.offset));
  return rows.map((row) => {
    const expiredSuspension = isSuspensionExpired(row.accountStatus, row.suspendedUntil, new Date());
    const rankLevel = Number(row.rankLevel ?? 0);
    return {
      ...row,
      accountStatus: expiredSuspension ? "active" : row.accountStatus,
      suspendedUntil: expiredSuspension ? null : row.suspendedUntil,
      rankLevel,
      rankTitle: chatRankTitle(rankLevel),
      rankIsManual: Boolean(row.rankIsManual),
      chatMessageCount: Number(row.chatMessageCount ?? 0),
      points: Number(row.points ?? 0),
    };
  });
}
async function requestAccountDeletion(userId) {
  const db = await requireDb();
  const [target] = await db.select({ role: users.role, accountNumber: accountNumbers.accountNumber })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(eq2(users.id, userId)).limit(1);
  if (!target) fail("NOT_FOUND", "حساب کاربری پیدا نشد.");
  if (target.accountNumber === 1 || target.role === "admin" || target.role === "superadmin") {
    fail("FORBIDDEN", "حساب Administrator از مسیر حذف حساب کاربری قابل حذف نیست.");
  }
  const profile = await ensureProfileFor(db, userId);
  if (profile.accountStatus === "deleted" || profile.deletedAt) return { success: true, alreadyDeleted: true };
  const deletedAt = new Date();
  await db.transaction(async (tx) => {
    await tx.update(profiles).set({ accountStatus: "deleted", deletedAt }).where(eq2(profiles.userId, userId));
    await tx.insert(auditLogs).values({ actorUserId: userId, targetUserId: userId, action: "user.account.delete_self", metadata: JSON.stringify({ accountNumber: target.accountNumber }) });
  });
  return { success: true, deletedAt };
}
async function adminDeleteAccount(actorUserId, targetUserId, reason) {
  const db = await requireDb();
  if (actorUserId === targetUserId) fail("BAD_REQUEST", "برای حذف حساب خودت از گزینهٔ حذف حساب در پروفایل استفاده کن.");
  const [target] = await db.select({ role: users.role, accountNumber: accountNumbers.accountNumber })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(eq2(users.id, targetUserId)).limit(1);
  if (!target) fail("NOT_FOUND", "حساب کاربری پیدا نشد.");
  if (target.accountNumber === 1 || target.role === "admin" || target.role === "superadmin") {
    fail("FORBIDDEN", "حساب Administrator از این مسیر قابل حذف نیست.");
  }
  const profile = await ensureProfileFor(db, targetUserId);
  if (profile.accountStatus === "deleted" || profile.deletedAt) return { success: true, alreadyDeleted: true };
  const deletedAt = new Date();
  await db.transaction(async (tx) => {
    await tx.update(profiles).set({ accountStatus: "deleted", deletedAt }).where(eq2(profiles.userId, targetUserId));
    await tx.insert(auditLogs).values({ actorUserId, targetUserId, action: "admin.account.delete", metadata: JSON.stringify({ accountNumber: target.accountNumber, reason }) });
  });
  return { success: true, targetUserId, deletedAt };
}
async function adminRestoreDeletedAccount(actorUserId, targetUserId, reason) {
  const db = await requireDb();
  const [target] = await db.select({ role: users.role, accountNumber: accountNumbers.accountNumber })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(eq2(users.id, targetUserId)).limit(1);
  if (!target) fail("NOT_FOUND", "حساب کاربری پیدا نشد.");
  if (target.accountNumber === 1 || target.role === "admin" || target.role === "superadmin") {
    fail("FORBIDDEN", "حساب Administrator از این مسیر قابل تغییر نیست.");
  }
  const profile = await ensureProfileFor(db, targetUserId);
  if (profile.accountStatus !== "deleted" && !profile.deletedAt) fail("CONFLICT", "این حساب در وضعیت حذف‌شده نیست.");
  await db.transaction(async (tx) => {
    await tx.update(profiles).set({ accountStatus: "active", deletedAt: null, mutedUntil: null, suspendedUntil: null }).where(eq2(profiles.userId, targetUserId));
    await tx.insert(auditLogs).values({ actorUserId, targetUserId, action: "admin.account.restore", metadata: JSON.stringify({ accountNumber: target.accountNumber, reason }) });
  });
  return { success: true, targetUserId };
}
async function adminSetRole(actorUserId, targetUserId, role, reason) {
  const db = await requireDb();
  const [actor] = await db.select({ userId: users.id, accountNumber: accountNumbers.accountNumber, role: users.role })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(eq2(users.id, actorUserId)).limit(1);
  const [target] = await db.select({ userId: users.id, accountNumber: accountNumbers.accountNumber, role: users.role })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(eq2(users.id, targetUserId)).limit(1);
  if (!actor || !target) fail("NOT_FOUND", "\u062D\u0633\u0627\u0628 \u06A9\u0627\u0631\u0628\u0631\u06CC \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (!mayChangeAccountRole(actor, target)) fail("FORBIDDEN", "\u0641\u0642\u0637 Administrator \u0634\u0645\u0627\u0631\u0647\u0654 \u06F1 \u0645\u062C\u0627\u0632 \u0628\u0647 \u0627\u0639\u0637\u0627 \u06CC\u0627 \u062D\u0630\u0641 \u0646\u0642\u0634 \u0645\u062F\u06CC\u0631\u06CC\u062A\u06CC \u0627\u0633\u062A.");
  await db.transaction(async (tx) => {
    await tx.update(users).set({ role }).where(eq2(users.id, targetUserId));
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "user.set_role",
      targetUserId,
      metadata: JSON.stringify({ previousRole: target.role, role, targetAccountNumber: target.accountNumber, reason })
    });
  });
  return { success: true, targetUserId, role };
}
async function adminSetUserBadge(actorUserId, targetUserId, badgeTitle, crownStyle, reason) {
  const db = await requireDb();
  const [actor] = await db.select({ userId: users.id, accountNumber: accountNumbers.accountNumber, role: users.role })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(eq2(users.id, actorUserId)).limit(1);
  const [target] = await db.select({ userId: users.id, accountNumber: accountNumbers.accountNumber, role: users.role })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(eq2(users.id, targetUserId)).limit(1);
  if (!actor || !target) fail("NOT_FOUND", "حساب کاربری پیدا نشد.");
  if (!mayChangeAccountRole(actor, target)) fail("FORBIDDEN", "فقط Administrator شمارهٔ ۱ می‌تواند عنوان نمایشی و تاج کاربران را تعیین کند.");
  const profile = await ensureProfileFor(db, targetUserId);
  if (profile.accountStatus === "deleted" || profile.deletedAt) fail("FORBIDDEN", "برای حساب حذف‌شده نمی‌توان عنوان یا تاج تعیین کرد.");
  const normalizedTitle = badgeTitle === "none" ? null : badgeTitle;
  await db.transaction(async (tx) => {
    await tx.update(profiles).set({ badgeTitle: normalizedTitle, crownStyle }).where(eq2(profiles.userId, targetUserId));
    await tx.insert(auditLogs).values({
      actorUserId,
      targetUserId,
      action: "user.badge.assign",
      metadata: JSON.stringify({ targetAccountNumber: target.accountNumber, badgeTitle: normalizedTitle, crownStyle, reason }),
    });
  });
  return { success: true, targetUserId, badgeTitle: normalizedTitle, crownStyle };
}
async function adminChangeAccountNumber(actorUserId, targetUserId, newNumber) {
  const db = await requireDb();
  if (actorUserId === targetUserId) fail("BAD_REQUEST", "\u0634\u0645\u0627\u0631\u0647\u0654 Administrator \u0642\u0627\u0628\u0644\u200C\u062A\u063A\u06CC\u06CC\u0631 \u0646\u06CC\u0633\u062A.");
  if (newNumber < 101 || newNumber > 2e9) fail("BAD_REQUEST", "\u0634\u0645\u0627\u0631\u0647\u0654 \u062D\u0633\u0627\u0628 \u0639\u0627\u062F\u06CC \u0628\u0627\u06CC\u062F \u0627\u0632 \u06F1\u06F0\u06F1 \u0628\u0647 \u0628\u0627\u0644\u0627 \u0628\u0627\u0634\u062F.");
  if (!await userExists(db, targetUserId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  await ensureAccountNumberFor(db, targetUserId);
  const [current] = await db.select({ accountNumber: accountNumbers.accountNumber, isReserved: accountNumbers.isReserved }).from(accountNumbers).where(eq2(accountNumbers.userId, targetUserId)).limit(1);
  if (!current) unavailable();
  if (current.isReserved || current.accountNumber === 1) fail("FORBIDDEN", "\u0634\u0645\u0627\u0631\u0647\u0654 \u062D\u0633\u0627\u0628 \u0648\u06CC\u0698\u0647 \u0642\u0627\u0628\u0644\u200C\u062A\u063A\u06CC\u06CC\u0631 \u0627\u0632 \u0627\u06CC\u0646 \u0645\u0633\u06CC\u0631 \u0646\u06CC\u0633\u062A.");
  if (current.accountNumber === newNumber) return { success: true, targetUserId, accountNumber: newNumber };
  try {
    await db.transaction(async (tx) => {
      const [occupied] = await tx.select({ accountNumber: accountNumbers.accountNumber }).from(accountNumbers).where(eq2(accountNumbers.accountNumber, newNumber)).limit(1);
      if (occupied) fail("CONFLICT", "\u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647\u0654 \u062D\u0633\u0627\u0628 \u0642\u0628\u0644\u0627\u064B \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0634\u062F\u0647 \u0627\u0633\u062A.");
      const changed = await tx.update(accountNumbers).set({ accountNumber: newNumber }).where(and(eq2(accountNumbers.userId, targetUserId), eq2(accountNumbers.accountNumber, current.accountNumber), eq2(accountNumbers.isReserved, false)));
      if (changed[0].affectedRows !== 1) fail("CONFLICT", "\u0634\u0645\u0627\u0631\u0647\u0654 \u062D\u0633\u0627\u0628 \u0647\u0645\u200C\u0632\u0645\u0627\u0646 \u062A\u063A\u06CC\u06CC\u0631 \u06A9\u0631\u062F\u0647 \u0627\u0633\u062A\u061B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646.");
      await tx.insert(auditLogs).values({
        actorUserId,
        action: "user.change_account_number",
        targetUserId,
        metadata: JSON.stringify({ previousNumber: current.accountNumber, newNumber })
      });
    });
  } catch (error) {
    if (error.code === "ER_DUP_ENTRY") fail("CONFLICT", "\u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647\u0654 \u062D\u0633\u0627\u0628 \u0642\u0628\u0644\u0627\u064B \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0634\u062F\u0647 \u0627\u0633\u062A.");
    throw error;
  }
  return { success: true, targetUserId, accountNumber: newNumber };
}
async function adminAdjustPoints(actorUserId, input) {
  const db = await requireDb();
  const [accountNumberRow] = await db.select({ userId: accountNumbers.userId, accountNumber: accountNumbers.accountNumber }).from(accountNumbers).where(eq2(accountNumbers.accountNumber, input.accountNumber)).limit(1);
  const targetUserId = accountNumberRow?.userId;
  if (!targetUserId || !await userExists(db, targetUserId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647\u0654 \u062D\u0633\u0627\u0628 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (accountNumberRow.accountNumber === 1) fail("BAD_REQUEST", "حساب Administrator شمارهٔ ۱ الماس نامحدود دارد و نیازی به شارژ ندارد. برای افزایش یا کسر الماس، شمارهٔ حساب عمومی کاربر دیگری را وارد کنید.");
  await ensureAccountFor(db, targetUserId);
  const direction = input.amount > 0 ? "credit" : "debit";
  const absoluteAmount = Math.abs(input.amount);
  const result = await db.transaction(async (tx) => {
    if (input.amount < 0) {
      const debit = await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} - ${absoluteAmount}` }).where(and(eq2(pointAccounts.userId, targetUserId), gte(pointAccounts.balance, absoluteAmount)));
      if (debit[0].affectedRows !== 1) fail("BAD_REQUEST", "\u06A9\u0633\u0631 \u0627\u0645\u062A\u06CC\u0627\u0632 \u0628\u0627\u0639\u062B \u0645\u0648\u062C\u0648\u062F\u06CC \u0645\u0646\u0641\u06CC \u0645\u06CC\u200C\u0634\u0648\u062F.");
    } else {
      const credit = await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} + ${absoluteAmount}` }).where(and(
        eq2(pointAccounts.userId, targetUserId),
        lte(pointAccounts.balance, MAX_SAFE_DIAMONDS - absoluteAmount),
      ));
      if (credit[0].affectedRows !== 1) fail("BAD_REQUEST", "موجودی پس از تعدیل از محدودهٔ عددی امن بیشتر می‌شود.");
    }
    const [account] = await tx.select({ balance: pointAccounts.balance }).from(pointAccounts).where(eq2(pointAccounts.userId, targetUserId)).limit(1);
    if (!account) unavailable();
    await tx.insert(pointTransactions).values({
      accountUserId: targetUserId,
      type: "admin_adjustment",
      direction,
      amount: absoluteAmount,
      balanceAfter: account.balance,
      note: input.note,
      performedByUserId: actorUserId
    });
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "wallet.adjust_points",
      targetUserId,
      metadata: JSON.stringify({ accountNumber: input.accountNumber, amount: input.amount, note: input.note })
    });
    return account.balance;
  });
  return { success: true, balance: result };
}
async function adminModerateUser(actorUserId, input) {
  const db = await requireDb();
  if (!await userExists(db, input.userId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (input.action === "suspend") {
    const [actor] = await db.select({ role: users.role }).from(users).where(eq2(users.id, actorUserId)).limit(1);
    if (!actor || !["admin", "superadmin"].includes(actor.role)) fail("FORBIDDEN", "فقط مدیر سامانه می‌تواند حساب را مسدود کند.");
    const [target] = await db.select({ role: users.role, accountNumber: accountNumbers.accountNumber })
      .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(eq2(users.id, input.userId)).limit(1);
    if (!target || target.accountNumber === 1 || target.role === "admin" || target.role === "superadmin") {
      fail("FORBIDDEN", "حساب Administrator و مدیران سامانه از این مسیر قابل مسدودسازی نیستند.");
    }
  }
  const profile = await ensureProfileFor(db, input.userId);
  if (input.action === "restore" && (profile.accountStatus === "deleted" || profile.deletedAt)) {
    fail("CONFLICT", "برای بازیابی حساب حذف‌شده از گزینهٔ مخصوص Administrator استفاده کن.");
  }
  if (input.action === "suspend" && (profile.accountStatus === "deleted" || profile.deletedAt)) {
    fail("CONFLICT", "حساب حذف‌شده از مسیر مسدودسازی قابل تغییر نیست.");
  }
  await db.transaction(async (tx) => {
    if (input.action === "warn") {
      await tx.insert(moderationWarnings).values({
        userId: input.userId,
        issuedByUserId: actorUserId,
        reason: input.reason,
        expiresAt: input.until ?? null
      });
    } else if (input.action === "restore") {
      await tx.update(profiles).set({ accountStatus: "active", mutedUntil: null, suspendedUntil: null }).where(eq2(profiles.userId, input.userId));
    } else {
      await tx.update(profiles).set(
        input.action === "mute" ? { accountStatus: "muted", mutedUntil: input.until ?? null, suspendedUntil: null } : { accountStatus: "suspended", suspendedUntil: input.until ?? null, mutedUntil: null }
      ).where(eq2(profiles.userId, input.userId));
    }
    if (input.reportId) {
      await tx.update(moderationReports).set({ status: "resolved", reviewedByUserId: actorUserId, reviewedAt: /* @__PURE__ */ new Date() }).where(eq2(moderationReports.id, input.reportId));
    }
    await tx.insert(auditLogs).values({
      actorUserId,
      action: `user.moderate.${input.action}`,
      targetUserId: input.userId,
      metadata: JSON.stringify({ reason: input.reason, until: input.until?.toISOString() ?? null, reportId: input.reportId ?? null })
    });
  });
  return { success: true };
}
async function adminBlockUser(actorUserId, input) {
  const db = await requireDb();
  if (input.durationHours !== null && !isAdminBlockDurationHours(input.durationHours)) {
    fail("BAD_REQUEST", "مدت مسدودسازی معتبر نیست.");
  }
  if (typeof input.reason !== "string" || input.reason.trim().length < 3 || input.reason.trim().length > 500) {
    fail("BAD_REQUEST", "دلیل مسدودسازی باید بین ۳ تا ۵۰۰ نویسه باشد.");
  }
  const [actor] = await db.select({ role: users.role }).from(users).where(eq2(users.id, actorUserId)).limit(1);
  if (!actor || !["admin", "superadmin"].includes(actor.role)) fail("FORBIDDEN", "فقط مدیر سامانه می‌تواند حساب را مسدود کند.");
  if (!await userExists(db, input.userId)) fail("NOT_FOUND", "کاربر پیدا نشد.");
  await ensureProfileFor(db, input.userId);
  const [target] = await db.select({ role: users.role, accountNumber: accountNumbers.accountNumber, accountStatus: profiles.accountStatus, deletedAt: profiles.deletedAt })
    .from(users).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).leftJoin(profiles, eq2(profiles.userId, users.id))
    .where(eq2(users.id, input.userId)).limit(1);
  if (!target) fail("NOT_FOUND", "کاربر پیدا نشد.");
  if (target.accountNumber === 1 || target.role === "admin" || target.role === "superadmin") {
    fail("FORBIDDEN", "حساب Administrator و مدیران سامانه از این مسیر قابل مسدودسازی نیستند.");
  }
  if (target.accountStatus === "deleted" || target.deletedAt) fail("CONFLICT", "حساب حذف‌شده از مسیر مسدودسازی قابل تغییر نیست.");
  const now = new Date();
  const suspendedUntil = input.durationHours === null ? null : new Date(now.getTime() + input.durationHours * 60 * 60 * 1000);
  await db.transaction(async (tx) => {
    await tx.update(profiles).set({ accountStatus: "suspended", suspendedUntil, mutedUntil: null }).where(eq2(profiles.userId, input.userId));
    await tx.insert(auditLogs).values({
      actorUserId,
      targetUserId: input.userId,
      action: input.durationHours === null ? "user.block.permanent" : "user.block.temporary",
      metadata: JSON.stringify({ reason: input.reason.trim(), durationHours: input.durationHours, suspendedUntil: suspendedUntil?.toISOString() ?? null }),
    });
  });
  return { success: true, permanent: input.durationHours === null, suspendedUntil };
}
async function adminUpdateRoom(actorUserId, input) {
  const db = await requireDb();
  const [currentRoom] = await db.select({ type: rooms.type }).from(rooms).where(eq2(rooms.id, input.roomId)).limit(1);
  if (!currentRoom) fail("NOT_FOUND", "\u0631\u0648\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (input.kind !== undefined && input.kind !== currentRoom.type) {
    if (!await isUnlimitedDiamondAdmin(db, actorUserId)) fail("FORBIDDEN", "\u062A\u063A\u06CC\u06CC\u0631 \u0646\u0648\u0639 \u0631\u0648\u0645 \u0641\u0642\u0637 \u0628\u0627 Administrator \u0634\u0645\u0627\u0631\u0647\u0654 \u06F1 \u0627\u0645\u06A9\u0627\u0646\u200C\u067E\u0630\u06CC\u0631 \u0627\u0633\u062A.");
    if (input.kind === "country" && !input.country?.trim()) fail("BAD_REQUEST", "\u0628\u0631\u0627\u06CC \u062A\u0628\u062F\u06CC\u0644 \u0628\u0647 \u0631\u0648\u0645 \u06A9\u0634\u0648\u0631\u06CC\u060C \u0646\u0627\u0645 \u06A9\u0634\u0648\u0631 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.");
  }
  const update = {
    title: input.name,
    description: input.description,
    status: input.status,
    type: input.kind,
    country: input.country
  };
  await db.transaction(async (tx) => {
    await tx.update(rooms).set(update).where(eq2(rooms.id, input.roomId));
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "room.update",
      targetRoomId: input.roomId,
      metadata: JSON.stringify(update)
    });
  });
  return { success: true, roomId: input.roomId };
}
const COUNTRY_ROOM_REQUEST_FEE = 20_000;
async function setRoomFavorite(userId, roomId, favorite) {
  const db = await requireDb();
  const [room] = await db.select({ id: rooms.id }).from(rooms).where(eq2(rooms.id, roomId)).limit(1);
  if (!room) fail("NOT_FOUND", "روم پیدا نشد.");
  if (favorite) {
    await db.insert(favoriteRooms).values({ userId, roomId }).onDuplicateKeyUpdate({ set: { roomId } });
  } else {
    await db.delete(favoriteRooms).where(and(eq2(favoriteRooms.userId, userId), eq2(favoriteRooms.roomId, roomId)));
  }
  return { success: true, favorite };
}
async function getCountryRoomRequest(userId, roomId) {
 const db = await requireDb(); const [room] = await db.select({ type: rooms.type, country: rooms.country }).from(rooms).where(eq2(rooms.id, roomId)).limit(1); if (!room) fail("NOT_FOUND", "روم پیدا نشد.");
 const [m] = await db.select({ role: roomMemberships.role }).from(roomMemberships).where(and(eq2(roomMemberships.roomId, roomId), eq2(roomMemberships.userId, userId))).limit(1);
 const [request] = await db.select({ id: countryRoomRequests.id, status: countryRoomRequests.status, country: countryRoomRequests.country, reason: countryRoomRequests.reason }).from(countryRoomRequests).where(and(eq2(countryRoomRequests.roomId, roomId), eq2(countryRoomRequests.requesterUserId, userId))).orderBy(desc(countryRoomRequests.id)).limit(1);
 return { canRequest: m?.role === "owner" && room.type === "public", country: room.country, request: request ?? null };
}
async function requestCountryRoom(userId, input) {
 const db = await requireDb(); await ensureAccountFor(db, userId);
 return db.transaction(async tx => { const [room] = await tx.select({ type: rooms.type }).from(rooms).where(eq2(rooms.id,input.roomId)).limit(1); const [owner] = await tx.select({ role: roomMemberships.role }).from(roomMemberships).where(and(eq2(roomMemberships.roomId,input.roomId),eq2(roomMemberships.userId,userId))).limit(1);
 if (!room || owner?.role !== "owner") fail("FORBIDDEN","فقط مالک روم می‌تواند درخواست بدهد."); if(room.type!=="public") fail("CONFLICT","این روم درخواست روم کشوری نمی‌پذیرد.");
 const debit=await tx.update(pointAccounts).set({balance:sql`${pointAccounts.balance} - ${COUNTRY_ROOM_REQUEST_FEE}`}).where(and(eq2(pointAccounts.userId,userId),gte(pointAccounts.balance,COUNTRY_ROOM_REQUEST_FEE))); if(debit[0].affectedRows!==1) fail("BAD_REQUEST","موجودی الماس برای پرداخت ۲۰٬۰۰۰ کافی نیست.");
 const [account]=await tx.select({balance:pointAccounts.balance}).from(pointAccounts).where(eq2(pointAccounts.userId,userId)).limit(1); const ins=await tx.insert(countryRoomRequests).values({roomId:input.roomId,requesterUserId:userId,country:input.country,fee:COUNTRY_ROOM_REQUEST_FEE,pendingRoomKey:String(input.roomId)});
 await tx.insert(pointTransactions).values({accountUserId:userId,roomId:input.roomId,type:"purchase",direction:"debit",amount:COUNTRY_ROOM_REQUEST_FEE,balanceAfter:account.balance,note:`درخواست روم کشوری #${ins[0].insertId}`}); await tx.insert(auditLogs).values({actorUserId:userId,action:"room.country_request",targetRoomId:input.roomId,metadata:JSON.stringify({requestId:Number(ins[0].insertId),country:input.country,fee:COUNTRY_ROOM_REQUEST_FEE})}); return {success:true}; });
}
async function adminCountryRoomRequests() { const db=await requireDb(); return db.select({id:countryRoomRequests.id,roomId:rooms.id,roomName:rooms.title,requesterUserId:countryRoomRequests.requesterUserId,country:countryRoomRequests.country,fee:countryRoomRequests.fee,requestedAt:countryRoomRequests.requestedAt}).from(countryRoomRequests).innerJoin(rooms,eq2(rooms.id,countryRoomRequests.roomId)).where(eq2(countryRoomRequests.status,"pending")).orderBy(asc(countryRoomRequests.id)).limit(100); }
async function adminDecideCountryRoomRequest(actorUserId,input) {
 const db=await requireDb(); if(!await isUnlimitedDiamondAdmin(db,actorUserId)) fail("FORBIDDEN","فقط Administrator شمارهٔ ۱ می‌تواند درخواست را بررسی کند.");
 return db.transaction(async tx=>{ const [r]=await tx.select().from(countryRoomRequests).where(and(eq2(countryRoomRequests.id,input.requestId),eq2(countryRoomRequests.status,"pending"))).limit(1); if(!r || !maySettleCountryRoomRequest(r.status)) fail("CONFLICT","درخواست قبلاً بررسی شده یا وجود ندارد."); const now=new Date(); const changed=await tx.update(countryRoomRequests).set({status:input.decision,pendingRoomKey:null,reason:input.reason,decidedByUserId:actorUserId,decidedAt:now}).where(and(eq2(countryRoomRequests.id,input.requestId),eq2(countryRoomRequests.status,"pending"))); if(changed[0].affectedRows!==1) fail("CONFLICT","درخواست هم‌زمان بررسی شد.");
 if(input.decision==="approved") await tx.update(rooms).set({type:"country",country:r.country}).where(eq2(rooms.id,r.roomId)); else if(countryRoomDecisionRefunds(input.decision)) { await tx.update(pointAccounts).set({balance:sql`${pointAccounts.balance} + ${r.fee}`}).where(eq2(pointAccounts.userId,r.requesterUserId)); const [a]=await tx.select({balance:pointAccounts.balance}).from(pointAccounts).where(eq2(pointAccounts.userId,r.requesterUserId)).limit(1); await tx.insert(pointTransactions).values({accountUserId:r.requesterUserId,roomId:r.roomId,type:"refund",direction:"credit",amount:r.fee,balanceAfter:a.balance,note:`بازپرداخت درخواست روم کشوری #${r.id}`,performedByUserId:actorUserId}); }
 await tx.insert(auditLogs).values({actorUserId,action:`room.country_request.${input.decision}`,targetUserId:r.requesterUserId,targetRoomId:r.roomId,metadata:JSON.stringify({requestId:r.id,reason:input.reason,refunded:countryRoomDecisionRefunds(input.decision),fee:r.fee})}); return {success:true}; });
}
async function adminDiamondTransactions(input) {
  const db = await requireDb();
  return db.select({
    id: pointTransactions.id, userName: users.name, username: profiles.username, accountNumber: accountNumbers.accountNumber,
    direction: pointTransactions.direction, amount: pointTransactions.amount, type: pointTransactions.type, note: pointTransactions.note,
    createdAt: pointTransactions.createdAt,
    actorName: sql`(SELECT name FROM users WHERE id = ${pointTransactions.performedByUserId} LIMIT 1)`. $type<string | null>(),
    actorAccountNumber: sql`(SELECT accountNumber FROM account_numbers WHERE userId = ${pointTransactions.performedByUserId} LIMIT 1)`. $type<number | null>(),
    counterpartyName: sql`(SELECT name FROM users WHERE id = ${pointTransactions.counterpartyUserId} LIMIT 1)`.$type<string | null>(),
    actorUsername: sql`(SELECT username FROM profiles WHERE userId = ${pointTransactions.performedByUserId} LIMIT 1)`.$type<string | null>(),
    counterpartyUsername: sql`(SELECT username FROM profiles WHERE userId = ${pointTransactions.counterpartyUserId} LIMIT 1)`.$type<string | null>(),
    counterpartyAccountNumber: sql`(SELECT accountNumber FROM account_numbers WHERE userId = ${pointTransactions.counterpartyUserId} LIMIT 1)`.$type<number | null>(),
  }).from(pointTransactions).innerJoin(users, eq2(users.id, pointTransactions.accountUserId))
    .leftJoin(profiles, eq2(profiles.userId, pointTransactions.accountUserId))
    .leftJoin(accountNumbers, eq2(accountNumbers.userId, pointTransactions.accountUserId))
    .orderBy(desc(pointTransactions.id)).limit(clampLimit(input.limit, 100)).offset(clampOffset(input.offset));
}
async function adminAudit(input) {
  const db = await requireDb();
  return db.select({
    id: auditLogs.id,
    actorUserId: auditLogs.actorUserId,
    actorName: sql`(SELECT name FROM users WHERE id = ${auditLogs.actorUserId} LIMIT 1)`. $type<string | null>(),
    actorAccountNumber: sql`(SELECT accountNumber FROM account_numbers WHERE userId = ${auditLogs.actorUserId} LIMIT 1)`. $type<number | null>(),
    action: auditLogs.action,
    targetUserId: auditLogs.targetUserId,
    targetName: sql`(SELECT name FROM users WHERE id = ${auditLogs.targetUserId} LIMIT 1)`. $type<string | null>(),
    targetAccountNumber: sql`(SELECT accountNumber FROM account_numbers WHERE userId = ${auditLogs.targetUserId} LIMIT 1)`. $type<number | null>(),
    targetRoomId: auditLogs.targetRoomId,
    metadata: auditLogs.metadata,
    createdAt: auditLogs.createdAt
  }).from(auditLogs).where(
    and(
      input.actorUserId ? eq2(auditLogs.actorUserId, input.actorUserId) : void 0,
      input.targetUserId ? eq2(auditLogs.targetUserId, input.targetUserId) : void 0,
      input.action ? eq2(auditLogs.action, input.action) : void 0
    )
  ).orderBy(desc(auditLogs.id)).limit(clampLimit(input.limit, 50)).offset(clampOffset(input.offset));
}
function parseGameMetadata(value) {
  if (typeof value !== "string" || value.length === 0) return {};
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}

function gameResultFromRow(row, input) {
  const metadata = parseGameMetadata(row.metadata);
  const storedChoice = Object.prototype.hasOwnProperty.call(metadata, "choice") ? metadata.choice : undefined;
  if (row.gameType !== input.gameType || asNumber(metadata.bet) !== input.bet || storedChoice !== input.choice) {
    fail("CONFLICT", "شناسهٔ این درخواست قبلاً برای بازی یا مبلغ دیگری استفاده شده است.");
  }
  return {
    gameRecordId: asNumber(row.id),
    gameType: row.gameType,
    bet: asNumber(metadata.bet),
    outcome: row.outcome,
    payout: asNumber(metadata.payout),
    balance: asNumber(metadata.balance),
    multiplier: asNumber(metadata.multiplier),
    ...(storedChoice !== undefined ? { choice: storedChoice } : {}),
    ...(metadata.opponentChoice !== undefined ? { opponentChoice: metadata.opponentChoice } : {}),
    metadata,
  };
}

async function findGameByRequest(db, userId, requestId, input) {
  const [row] = await db.select().from(gameRecords).where(and(
    eq2(gameRecords.userId, userId),
    eq2(gameRecords.requestId, requestId),
  )).limit(1);
  return row ? gameResultFromRow(row, input) : null;
}

function isDuplicateKeyError(error) {
  const candidates = [error, error?.cause, error?.originalError];
  return candidates.some((candidate) => candidate && (
    candidate.code === "ER_DUP_ENTRY" || Number(candidate.errno) === 1062
  ));
}

async function settleGame(userId, input) {
  const db = await requireDb();
  const maxBet = Math.floor(MAX_SAFE_DIAMONDS / 10);
  if (!Number.isSafeInteger(input.bet) || input.bet < 1 || input.bet > maxBet ||
      !Number.isSafeInteger(input.payout) || input.payout < 0 ||
      !Number.isSafeInteger(input.score) || typeof input.requestId !== "string" || input.requestId.length !== 36) {
    fail("BAD_REQUEST", "مبلغ بازی یا شناسهٔ درخواست معتبر نیست.");
  }
  await assertCanParticipate(db, userId);
  const existing = await findGameByRequest(db, userId, input.requestId, input);
  if (existing) return existing;
  await ensureAccountFor(db, userId);
  const unlimited = await isUnlimitedDiamondAdmin(db, userId);

  try {
    return await db.transaction(async (tx) => {
      const [prior] = await tx.select().from(gameRecords).where(and(
        eq2(gameRecords.userId, userId),
        eq2(gameRecords.requestId, input.requestId),
      )).limit(1);
      if (prior) return gameResultFromRow(prior, input);

      if (unlimited) {
        await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, userId));
      } else {
        const debit = await tx.update(pointAccounts)
          .set({ balance: sql`${pointAccounts.balance} - ${input.bet}` })
          .where(and(eq2(pointAccounts.userId, userId), gte(pointAccounts.balance, input.bet)));
        if (debit[0].affectedRows !== 1) fail("BAD_REQUEST", "موجودی الماس برای این بازی کافی نیست.");
      }

      const [afterBet] = await tx.select({ balance: pointAccounts.balance })
        .from(pointAccounts).where(eq2(pointAccounts.userId, userId)).limit(1);
      if (!afterBet) unavailable();
      const debitedBalance = asNumber(afterBet.balance);
      if (!unlimited && debitedBalance > MAX_SAFE_DIAMONDS - input.payout) {
        fail("BAD_REQUEST", "موجودی پس از جایزه از محدودهٔ عددی امن بیشتر می‌شود.");
      }
      const finalBalance = unlimited ? MAX_SAFE_DIAMONDS : debitedBalance + input.payout;
      const now = new Date();
      const metadata = {
        ...(input.metadata ?? {}),
        bet: input.bet,
        payout: input.payout,
        multiplier: input.multiplier,
        balance: finalBalance,
        ...(input.choice !== undefined ? { choice: input.choice } : {}),
        ...(input.opponentChoice !== undefined ? { opponentChoice: input.opponentChoice } : {}),
      };
      const gameInsert = await tx.insert(gameRecords).values({
        userId,
        gameType: input.gameType,
        requestId: input.requestId,
        status: "completed",
        score: input.score,
        outcome: input.outcome,
        metadata: JSON.stringify(metadata),
        startedAt: now,
        endedAt: now,
      });
      const gameRecordId = Number(gameInsert[0].insertId);

      await tx.insert(pointTransactions).values({
        accountUserId: userId,
        type: "purchase",
        direction: "debit",
        amount: input.bet,
        balanceAfter: afterBet.balance,
        note: `Virtual game amount: ${input.gameType}`,
        performedByUserId: userId,
      });
      if (input.payout > 0) {
        if (unlimited) {
          await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, userId));
        } else {
          await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} + ${input.payout}` }).where(eq2(pointAccounts.userId, userId));
        }
        const [afterPayout] = await tx.select({ balance: pointAccounts.balance })
          .from(pointAccounts).where(eq2(pointAccounts.userId, userId)).limit(1);
        if (!afterPayout) unavailable();
        await tx.insert(pointTransactions).values({
          accountUserId: userId,
          type: "reward",
          direction: "credit",
          amount: input.payout,
          balanceAfter: afterPayout.balance,
          note: `Virtual game payout: ${input.gameType}`,
          performedByUserId: userId,
        });
      }
      return {
        gameRecordId,
        gameType: input.gameType,
        bet: input.bet,
        outcome: input.outcome,
        payout: input.payout,
        balance: finalBalance,
        multiplier: input.multiplier,
        ...(input.choice !== undefined ? { choice: input.choice } : {}),
        ...(input.opponentChoice !== undefined ? { opponentChoice: input.opponentChoice } : {}),
        metadata,
      };
    });
  } catch (error) {
    if (!isDuplicateKeyError(error)) throw error;
    const prior = await findGameByRequest(db, userId, input.requestId, input);
    if (prior) return prior;
    throw error;
  }
}

async function spinGame(userId, bet, requestId) {
  const roll = randomInt(0, 100);
  const multiplier = roll < 5 ? 10 : roll < 30 ? 2 : 0;
  const outcome = multiplier > 0 ? "win" : "loss";
  const result = await settleGame(userId, {
    gameType: "spin",
    bet,
    requestId,
    outcome,
    payout: bet * multiplier,
    multiplier,
    score: bet * multiplier - bet,
    metadata: { random: { roll, tier: multiplier === 10 ? "jackpot" : multiplier === 2 ? "standard_win" : "loss" } },
  });
  const storedRoll = asNumber(result.metadata?.random?.roll ?? roll);
  return {
    ...result,
    sector: storedRoll < 5 ? 0 : storedRoll < 30 ? Math.floor((storedRoll - 5) / 5) + 1 : Math.floor((storedRoll - 30) * 14 / 70) + 6,
    rules: {
      currency: "diamonds",
      payoutMeaning: "payout is the total diamond credit after the wager",
      outcomes: "roll 0-4: 10x; roll 5-29: 2x; roll 30-99: 0x",
    },
  };
}

async function diceGame(userId, bet, choice, requestId) {
  const won = randomInt(0, 100) < 30;
  const parity = won ? choice : choice === "even" ? "odd" : "even";
  const faces = parity === "even" ? [2, 4, 6] : [1, 3, 5];
  const face = faces[randomInt(0, faces.length)];
  const outcome = won ? "win" : "loss";
  const settled = await settleGame(userId, {
    gameType: "dice_odd_even",
    bet,
    requestId,
    outcome,
    payout: won ? bet * 3 : 0,
    multiplier: won ? 3 : 0,
    score: won ? bet * 2 : -bet,
    choice,
    metadata: { face, parity, disclosedWinProbability: 0.3 },
  });
  const storedFace = asNumber(settled.metadata?.face ?? face);
  const storedParity = settled.metadata?.parity ?? parity;
  return { ...settled, face: storedFace, parity: storedParity, choice: settled.choice ?? choice, rules: { winProbability: 0.3, payout: "3x total credit including wager" } };
}

async function rockPaperScissorsGame(userId, bet, choice, requestId) {
  const generated = createRockPaperScissorsOutcome(choice);
  const { opponentChoice, outcome } = generated;
  const multiplier = outcome === "win" ? 2 : outcome === "tie" ? 1 : 0;
  const result = await settleGame(userId, {
    gameType: "rock_paper_scissors",
    bet,
    requestId,
    outcome,
    payout: bet * multiplier,
    multiplier,
    score: bet * multiplier - bet,
    choice,
    opponentChoice,
    metadata: { random: { roll: generated.roll, opponentChoice } },
  });
  const storedOpponentChoice = result.metadata?.random?.opponentChoice ?? result.metadata?.opponentChoice ?? opponentChoice;
  return {
    ...result,
    opponentChoice: storedOpponentChoice,
    rules: {
      currency: "diamonds",
      payoutMeaning: "payout is the total diamond credit after the wager",
      winProbability: 0.3,
      distribution: { win: 0.3, tie: 0.3, loss: 0.4 },
      outcomes: "win: 2x; tie: 1x wager returned; loss: 0x",
    },
  };
}

async function playDiamondMiniGame(userId, input) {
  const generated = createDiamondMiniOutcome(input.gameType, input.choice);
  const payout = diamondMiniPayout(input.bet, generated.outcome);
  const settled = await settleGame(userId, {
    gameType: input.gameType,
    bet: input.bet,
    requestId: input.requestId,
    outcome: generated.outcome,
    payout,
    multiplier: generated.outcome === "win" ? 3 : 0,
    score: payout - input.bet,
    choice: generated.choice,
    metadata: { ...generated, disclosedWinProbability: 0.3, payoutMultiplier: 3 },
  });
  const metadata = settled.metadata ?? {};
  return {
    ...settled,
    ...(metadata.board ? { board: metadata.board } : {}),
    ...(metadata.memoryDeck ? { memoryDeck: metadata.memoryDeck } : {}),
    ...(metadata.matchedCards ? { matchedCards: metadata.matchedCards } : {}),
    ...(metadata.matchedPairs !== undefined ? { matchedPairs: metadata.matchedPairs } : {}),
    ...(metadata.winningNumbers ? { winningNumbers: metadata.winningNumbers } : {}),
    ...(metadata.treasureSpots ? { treasureSpots: metadata.treasureSpots } : {}),
    rules: { winProbability: 0.3, payout: "3x total credit including the game amount" },
  };
}

async function listActiveAds(input) {
  const db = await requireDb();
  const now = /* @__PURE__ */ new Date();
  return db.select({
    id: ads.id,
    title: ads.title,
    body: ads.body,
    assetUrl: ads.assetUrl,
    targetUrl: ads.targetUrl,
    startsAt: ads.startsAt,
    endsAt: ads.endsAt,
    createdAt: ads.createdAt
  }).from(ads).where(
    and(
      eq2(ads.status, "active"),
      lte(sql`COALESCE(${ads.startsAt}, ${ads.createdAt})`, now),
      or(isNull(ads.endsAt), gte(ads.endsAt, now)),
      gte(sql`DATE_ADD(COALESCE(${ads.startsAt}, ${ads.createdAt}), INTERVAL 24 HOUR)`, now)
    )
  ).orderBy(desc(ads.createdAt), desc(ads.id)).limit(clampLimit(input.limit, 20));
}
async function createAd(userId, input) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  await ensureAccountFor(db, userId);
  const unlimited = await isUnlimitedDiamondAdmin(db, userId);
  return db.transaction(async (tx) => {
    if (unlimited) await tx.update(pointAccounts).set({ balance: MAX_SAFE_DIAMONDS }).where(eq2(pointAccounts.userId, userId));
    else {
      const debit = await tx.update(pointAccounts).set({ balance: sql`${pointAccounts.balance} - ${AD_CREATION_COST_POINTS}` }).where(and(eq2(pointAccounts.userId, userId), gte(pointAccounts.balance, AD_CREATION_COST_POINTS)));
      if (debit[0].affectedRows !== 1) fail("BAD_REQUEST", "\u0645\u0648\u062C\u0648\u062F\u06CC \u0627\u0645\u062A\u06CC\u0627\u0632 \u0628\u0631\u0627\u06CC \u0633\u0627\u062E\u062A \u0622\u06AF\u0647\u06CC \u06A9\u0627\u0641\u06CC \u0646\u06CC\u0633\u062A.");
    }
    const [account] = await tx.select({ balance: pointAccounts.balance }).from(pointAccounts).where(eq2(pointAccounts.userId, userId)).limit(1);
    if (!account) unavailable();
    const adInsert = await tx.insert(ads).values({
      createdByUserId: userId,
      title: input.title,
      body: input.body ?? null,
      targetUrl: input.targetUrl ?? null,
      status: "draft"
    });
    const id = Number(adInsert[0].insertId);
    await tx.insert(pointTransactions).values({
      accountUserId: userId,
      type: "purchase",
      direction: "debit",
      amount: AD_CREATION_COST_POINTS,
      balanceAfter: account.balance,
      note: "Virtual points charged for draft ad creation",
      performedByUserId: userId
    });
    return { id, status: "draft", pointsCharged: AD_CREATION_COST_POINTS };
  });
}
async function adminAds(input) {
  const db = await requireDb();
  return db.select({
    id: ads.id,
    createdByUserId: ads.createdByUserId,
    title: ads.title,
    body: ads.body,
    assetUrl: ads.assetUrl,
    targetUrl: ads.targetUrl,
    status: ads.status,
    startsAt: ads.startsAt,
    endsAt: ads.endsAt,
    createdAt: ads.createdAt,
    updatedAt: ads.updatedAt
  }).from(ads).where(input.status ? eq2(ads.status, input.status) : void 0).orderBy(desc(ads.id)).limit(clampLimit(input.limit, 50)).offset(clampOffset(input.offset));
}
async function adminUpdateAd(actorUserId, adId, status) {
  const db = await requireDb();
  const activatedAt = new Date();
  await db.transaction(async (tx) => {
    const [ad] = await tx.select({ id: ads.id }).from(ads).where(eq2(ads.id, adId)).limit(1);
    if (!ad) fail("NOT_FOUND", "\u0622\u06AF\u0647\u06CC \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    await tx.update(ads).set(status === "active" ? {
      status,
      startsAt: activatedAt,
      endsAt: new Date(activatedAt.getTime() + AD_VISIBILITY_WINDOW_MS),
    } : { status }).where(eq2(ads.id, adId));
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "ad.update_status",
      metadata: JSON.stringify({ adId, status })
    });
  });
  return { success: true, adId, status };
}
async function listSalesAgents() {
  const db = await requireDb();
  const now = /* @__PURE__ */ new Date();
  const rows = await db.select({
    id: salesAgentDiscounts.id,
    code: salesAgentDiscounts.code,
    discountBps: salesAgentDiscounts.discountBps,
    username: sql`COALESCE(${profiles.username}, ${users.name}, CONCAT('Agent #', ${users.id}))`,
    publicName: sql`COALESCE(${profiles.username}, ${users.name}, CONCAT('Agent #', ${users.id}))`,
    accountNumber: accountNumbers.accountNumber
  }).from(salesAgentDiscounts).innerJoin(users, eq2(users.id, salesAgentDiscounts.agentUserId)).leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id)).where(
    and(
      eq2(salesAgentDiscounts.isActive, true),
      or(isNull(salesAgentDiscounts.startsAt), lte(salesAgentDiscounts.startsAt, now)),
      or(isNull(salesAgentDiscounts.expiresAt), gte(salesAgentDiscounts.expiresAt, now))
    )
  ).orderBy(asc(salesAgentDiscounts.code));
  return rows.map((row) => ({
    id: Number(row.id),
    code: String(row.code),
    discountBps: Number(row.discountBps),
    username: String(row.username ?? ""),
    publicName: String(row.publicName ?? ""),
    accountNumber: row.accountNumber == null ? null : Number(row.accountNumber),
  }));
}
async function adminSearchSalesAgentCandidates(query, limit = 20) {
  const db = await requireDb();
  const term = query.trim();
  if (term.length < 2) return [];
  const accountNumber = /^\d+$/.test(term) ? Number(term) : undefined;
  const rows = await db.select({
    id: users.id,
    username: profiles.username,
    name: users.name,
    accountNumber: accountNumbers.accountNumber,
  }).from(users)
    .innerJoin(profiles, eq2(profiles.userId, users.id))
    .leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(and(
      eq2(profiles.accountStatus, "active"),
      or(like(profiles.username, `%${term}%`), like(users.name, `%${term}%`), accountNumber !== undefined ? eq2(accountNumbers.accountNumber, accountNumber) : void 0),
    ))
    .orderBy(asc(users.id))
    .limit(Math.min(Math.max(limit, 1), 20));
  return rows.map((row) => ({
    id: Number(row.id),
    username: row.username ?? null,
    name: row.name ?? null,
    accountNumber: row.accountNumber == null ? null : Number(row.accountNumber),
  }));
}
async function adminConfigureSalesAgent(actorUserId, input) {
  const db = await requireDb();
  if (!await userExists(db, input.agentUserId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u0641\u0631\u0648\u0634\u0646\u062F\u0647 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  await db.transaction(async (tx) => {
    const [existing] = await tx.select({ id: salesAgentDiscounts.id, agentUserId: salesAgentDiscounts.agentUserId }).from(salesAgentDiscounts).where(eq2(salesAgentDiscounts.code, input.code)).limit(1);
    if (existing && existing.agentUserId !== input.agentUserId) {
      fail("CONFLICT", "\u0627\u06CC\u0646 \u06A9\u062F \u0641\u0631\u0648\u0634\u0646\u062F\u0647 \u0642\u0628\u0644\u0627\u064B \u0628\u0631\u0627\u06CC \u06A9\u0627\u0631\u0628\u0631 \u062F\u06CC\u06AF\u0631\u06CC \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A.");
    }
    if (existing) {
      await tx.update(salesAgentDiscounts).set({ discountBps: input.discountBps, isActive: input.isActive }).where(eq2(salesAgentDiscounts.id, existing.id));
    } else {
      await tx.insert(salesAgentDiscounts).values(input);
    }
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "sales_agent.configure",
      targetUserId: input.agentUserId,
      metadata: JSON.stringify({ code: input.code, discountBps: input.discountBps, isActive: input.isActive })
    });
  });
  return { success: true, ...input };
}
async function adminRemoveSalesAgent(actorUserId, discountId) {
  const db = await requireDb();
  const [actor] = await db.select({ role: users.role }).from(users).where(eq2(users.id, actorUserId)).limit(1);
  if (!actor || !["admin", "superadmin"].includes(actor.role)) fail("FORBIDDEN", "فقط مدیر سامانه می‌تواند نمایندهٔ فروش را حذف کند.");
  const [selected] = await db.select({ agentUserId: salesAgentDiscounts.agentUserId, accountNumber: accountNumbers.accountNumber })
    .from(salesAgentDiscounts).leftJoin(accountNumbers, eq2(accountNumbers.userId, salesAgentDiscounts.agentUserId))
    .where(and(eq2(salesAgentDiscounts.id, discountId), eq2(salesAgentDiscounts.isActive, true))).limit(1);
  if (!selected) fail("NOT_FOUND", "نمایندهٔ فعال پیدا نشد.");
  const now = new Date();
  let disabledCount = 0;
  await db.transaction(async (tx) => {
    const activeDiscounts = await tx.select({ id: salesAgentDiscounts.id }).from(salesAgentDiscounts)
      .where(and(eq2(salesAgentDiscounts.agentUserId, selected.agentUserId), eq2(salesAgentDiscounts.isActive, true)));
    disabledCount = activeDiscounts.length;
    if (disabledCount === 0) fail("CONFLICT", "تنظیم فعال نماینده پیدا نشد.");
    await tx.update(salesAgentDiscounts).set({ isActive: false })
      .where(and(eq2(salesAgentDiscounts.agentUserId, selected.agentUserId), eq2(salesAgentDiscounts.isActive, true)));
    await tx.update(users).set({ role: "user" }).where(and(eq2(users.id, selected.agentUserId), eq2(users.role, "sales_agent")));
    await tx.insert(auditLogs).values({
      actorUserId,
      targetUserId: selected.agentUserId,
      action: "sales_agent.remove",
      metadata: JSON.stringify({ accountNumber: selected.accountNumber ?? null, disabledDiscountCount: disabledCount, removedAt: now.toISOString() }),
    });
  });
  return { success: true, accountNumber: selected.accountNumber, disabledDiscountCount: disabledCount };
}
async function adminReports(input) {
  const db = await requireDb();
  return db.select({
    id: moderationReports.id,
    reporterUserId: moderationReports.reporterUserId,
    reportedUserId: moderationReports.reportedUserId,
    roomId: moderationReports.roomId,
    messageId: moderationReports.messageId,
    reason: moderationReports.reason,
    details: moderationReports.details,
    status: moderationReports.status,
    reviewedByUserId: moderationReports.reviewedByUserId,
    reviewedAt: moderationReports.reviewedAt,
    createdAt: moderationReports.createdAt
  }).from(moderationReports).where(input.status ? eq2(moderationReports.status, input.status) : void 0).orderBy(desc(moderationReports.id)).limit(clampLimit(input.limit, 50)).offset(clampOffset(input.offset));
}
async function adminResolveReport(actorUserId, reportId, status) {
  const db = await requireDb();
  const reviewedAt = /* @__PURE__ */ new Date();
  await db.transaction(async (tx) => {
    const [report] = await tx.select({ id: moderationReports.id, reportedUserId: moderationReports.reportedUserId }).from(moderationReports).where(eq2(moderationReports.id, reportId)).limit(1);
    if (!report) fail("NOT_FOUND", "\u06AF\u0632\u0627\u0631\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    await tx.update(moderationReports).set({ status, reviewedByUserId: actorUserId, reviewedAt }).where(eq2(moderationReports.id, reportId));
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "report.resolve",
      targetUserId: report.reportedUserId,
      metadata: JSON.stringify({ reportId, status, reviewedAt: reviewedAt.toISOString() })
    });
  });
  return { success: true, reportId, status, reviewedAt };
}
async function latestAdminNotice(userId) {
  const db = await requireDb();
  const [notice] = await db.select({ id: adminNotices.id, title: adminNotices.title, body: adminNotices.body, createdAt: adminNotices.createdAt, expiresAt: adminNotices.expiresAt }).from(adminNotices).where(and(
    eq2(adminNotices.status, "active"),
    or(isNull(adminNotices.targetUserId), eq2(adminNotices.targetUserId, userId)),
    or(isNull(adminNotices.expiresAt), gte(adminNotices.expiresAt, /* @__PURE__ */ new Date()))
  )).orderBy(desc(adminNotices.id)).limit(1);
  return notice ?? null;
}
async function adminListNotices(input = {}) {
  const db = await requireDb();
  return db.select({
    id: adminNotices.id,
    createdByUserId: adminNotices.createdByUserId,
    targetUserId: adminNotices.targetUserId,
    targetAccountNumber: accountNumbers.accountNumber,
    title: adminNotices.title,
    body: adminNotices.body,
    status: adminNotices.status,
    expiresAt: adminNotices.expiresAt,
    createdAt: adminNotices.createdAt,
  }).from(adminNotices)
    .leftJoin(accountNumbers, eq2(accountNumbers.userId, adminNotices.targetUserId))
    .orderBy(desc(adminNotices.id))
    .limit(clampLimit(input.limit, 30))
    .offset(clampOffset(input.offset));
}
async function adminCreateNotice(actorUserId, input) {
  const db = await requireDb();
  const targetAccountNumber = input.targetAccountNumber ?? null;
  let targetUserId = null;
  if (targetAccountNumber !== null) {
    const [target] = await db.select({ userId: accountNumbers.userId })
      .from(accountNumbers)
      .where(eq2(accountNumbers.accountNumber, targetAccountNumber))
      .limit(1);
    if (!target?.userId) fail("NOT_FOUND", "این شمارهٔ حساب به کاربری واگذار نشده است.");
    targetUserId = target.userId;
  }
  const expiresAt = new Date(Date.now() + input.durationDays * 24 * 60 * 60 * 1e3);
  return db.transaction(async (tx) => {
    const inserted = await tx.insert(adminNotices).values({
      createdByUserId: actorUserId,
      targetUserId,
      title: input.title,
      body: input.body,
      expiresAt,
      status: "active"
    });
    const noticeId = Number(inserted[0].insertId);
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "admin.notice.create",
      targetUserId,
      metadata: JSON.stringify({ noticeId, title: input.title, durationDays: input.durationDays, targeted: targetUserId !== null, targetAccountNumber })
    });
    return { success: true, id: noticeId, expiresAt };
  });
}
async function adminArchiveNotice(actorUserId, noticeId) {
  const db = await requireDb();
  return db.transaction(async (tx) => {
    const [notice] = await tx.select({ id: adminNotices.id, targetUserId: adminNotices.targetUserId }).from(adminNotices).where(eq2(adminNotices.id, noticeId)).limit(1);
    if (!notice) fail("NOT_FOUND", "\u067E\u06CC\u0627\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    await tx.update(adminNotices).set({ status: "archived" }).where(eq2(adminNotices.id, noticeId));
    await tx.insert(auditLogs).values({ actorUserId, action: "admin.notice.archive", targetUserId: notice.targetUserId, metadata: JSON.stringify({ noticeId }) });
    return { success: true, id: noticeId };
  });
}
async function adminSetUserRank(actorUserId, targetUserId, rankOverride, note) {
  const db = await requireDb();
  if (!await userExists(db, targetUserId)) fail("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (rankOverride !== null && (!Number.isInteger(rankOverride) || rankOverride < 0 || rankOverride > 5)) {
    fail("BAD_REQUEST", "\u0634\u0645\u0627\u0631\u0647\u0654 \u0631\u062A\u0628\u0647 \u0628\u0627\u06CC\u062F \u0628\u06CC\u0646 \u0635\u0641\u0631 \u062A\u0627 \u067E\u0646\u062C \u0628\u0627\u0634\u062F.");
  }
  const profile = await ensureProfileFor(db, targetUserId);
  const previousRank = profile.rankOverride ?? chatRankLevel(profile.chatMessageCount);
  await db.transaction(async (tx) => {
    await tx.update(profiles).set({ rankOverride }).where(eq2(profiles.userId, targetUserId));
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "user.set_chat_rank",
      targetUserId,
      metadata: JSON.stringify({ previousRank, rankOverride, note })
    });
  });
  const rankLevel = rankOverride ?? chatRankLevel(profile.chatMessageCount);
  return { success: true, targetUserId, rankLevel, rankTitle: chatRankTitle(rankLevel), automatic: rankOverride === null };
}

async function listFriends(userId) {
  const db = await requireDb();
  const rows = await db.select({ userId: users.id, accountNumber: accountNumbers.accountNumber, name: users.name, username: profiles.username, avatarUrl: profiles.avatarUrl, avatarEmoji: profiles.avatarEmoji, badgeTitle: profiles.badgeTitle, crownStyle: profiles.crownStyle, role: users.role })
    .from(friendships).innerJoin(users, eq2(users.id, sql`CASE WHEN ${friendships.userId} = ${userId} THEN ${friendships.friendUserId} ELSE ${friendships.userId} END`))
    .leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(or(eq2(friendships.userId, userId), eq2(friendships.friendUserId, userId)));
  return Promise.all(rows.filter(row => row.accountNumber != null).map(async ({ accountNumber, name, username, avatarUrl, avatarEmoji, badgeTitle, crownStyle, role }) => ({ accountNumber, name, username, avatarUrl: await resolveProfileAvatar(db, avatarUrl), avatarEmoji: avatarEmoji ?? null, badgeTitle: badgeTitle ?? null, crownStyle: crownStyle ?? null, role })));
}
async function sendRoomInvite(userId, roomId, accountNumber) {
  const db = await requireDb();
  await assertCanParticipate(db, userId);
  const targetUserId = await accountNumberToUserId(db, accountNumber);
  if (!targetUserId || targetUserId === userId) fail("BAD_REQUEST", "دوست انتخاب‌شده معتبر نیست.");
  const [friendship] = await db.select({ id: friendships.id }).from(friendships).where(and(eq2(friendships.userId, Math.min(userId, targetUserId)), eq2(friendships.friendUserId, Math.max(userId, targetUserId)))).limit(1);
  if (!friendship) fail("FORBIDDEN", "دعوت فقط برای دوستان ممکن است.");
  await assertNotBlocked(db, userId, targetUserId);
  const room = await getRoom(db, roomId);
  if (room.status !== "active") fail("FORBIDDEN", "این روم فعال نیست.");
  if (!await membershipFor(db, roomId, userId)) fail("FORBIDDEN", "برای دعوت باید عضو فعال روم باشی.");
  if (await membershipFor(db, roomId, targetUserId)) fail("CONFLICT", "این دوست از قبل عضو روم است.");
  const pendingKey = `${roomId}:${targetUserId}`;
  const [pending] = await db.select({ id: roomInvitations.id }).from(roomInvitations).where(and(eq2(roomInvitations.roomId, roomId), eq2(roomInvitations.inviteeUserId, targetUserId), eq2(roomInvitations.status, "pending"))).limit(1);
  if (pending) fail("CONFLICT", "برای این دوست دعوت در انتظار وجود دارد.");
  try { await db.insert(roomInvitations).values({ roomId, inviterUserId: userId, inviteeUserId: targetUserId, status: "pending", pendingKey }); }
  catch (error) { if (error?.code === "ER_DUP_ENTRY") fail("CONFLICT", "برای این دوست دعوت در انتظار وجود دارد."); throw error; }
  return { success: true };
}
async function listIncomingRoomInvites(userId) {
  const db = await requireDb();
  return db.select({ id: roomInvitations.id, roomId: rooms.id, roomName: rooms.name, accountNumber: accountNumbers.accountNumber, inviterName: users.name, inviterUsername: profiles.username, inviterAvatarEmoji: profiles.avatarEmoji, inviterBadgeTitle: profiles.badgeTitle, inviterCrownStyle: profiles.crownStyle, inviterRole: users.role, createdAt: roomInvitations.createdAt })
    .from(roomInvitations).innerJoin(rooms, eq2(rooms.id, roomInvitations.roomId)).innerJoin(users, eq2(users.id, roomInvitations.inviterUserId))
    .leftJoin(profiles, eq2(profiles.userId, users.id)).leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(and(eq2(roomInvitations.inviteeUserId, userId), eq2(roomInvitations.status, "pending"))).orderBy(desc(roomInvitations.id));
}
async function respondRoomInvite(userId, invitationId, response) {
  const db = await requireDb();
  await db.transaction(async tx => {
    const [invite] = await tx.select().from(roomInvitations).where(and(eq2(roomInvitations.id, invitationId), eq2(roomInvitations.inviteeUserId, userId), eq2(roomInvitations.status, "pending"))).limit(1);
    if (!invite) fail("NOT_FOUND", "دعوت در انتظار پیدا نشد.");
    const room = await getRoom(tx, invite.roomId);
    const now = new Date();
    if (response === "accepted") {
      if (room.status !== "active") fail("CONFLICT", "این روم دیگر فعال نیست.");
      if (!await membershipFor(tx, invite.roomId, userId)) await tx.insert(roomMemberships).values({ roomId: invite.roomId, userId, role: "member" });
    }
    await tx.update(roomInvitations).set({ status: response, pendingKey: null, respondedAt: now }).where(and(eq2(roomInvitations.id, invitationId), eq2(roomInvitations.inviteeUserId, userId), eq2(roomInvitations.status, "pending")));
  });
  return { success: true, status: response };
}
export {
  adminChangeAccountNumber, adminArchiveNotice, adminAds, adminAdjustPoints, adminBlockUser, adminCountryRoomRequests, adminDecideCountryRoomRequest,
  adminDeleteAccount, adminRestoreDeletedAccount,
  adminAudit, adminDiamondTransactions, adminConfigureSalesAgent, adminSearchSalesAgentCandidates, adminRemoveSalesAgent, adminCreateNotice, adminListNotices,
  adminModerateUser, adminReports, adminResolveReport, adminSetRole, adminSetUserBadge,
  adminSetUserRank, adminSummary, adminUpdateAd, adminUpdateRoom, adminUsers,
  clearRoomMessages, createAd, createReport, createRoom, deletePrivateMessage, getCountryRoomRequest, requestCountryRoom, listFriends, sendRoomInvite, listIncomingRoomInvites, respondRoomInvite, getMyProfile, getPublicUser, getWallet,
  joinRoom, kickRoomMember, leaveRoom, listActiveAds, listPrivateThread, listRoomMessages,
  listRooms, setRoomFavorite, listSalesAgents, listWalletHistory, latestAdminNotice, privateInbox,
  purchaseShopProduct, rockPaperScissorsGame, diceGame, searchUsers, sendPrivateMessage, sendRoomMessage,
  roomMembers, muteRoomMember, setRoomAnnouncement, setRoomModerator, setRoomStatus, shopCatalog,
  tipRoom, toggleBlock, toggleFriend, transferPoints, updateMyProfile, setMyPassword, uploadChatMedia, spinGame, playDiamondMiniGame,
  countUnreadPrivateMessages, requestAccountDeletion,
};


/** Reserved owner-managed accounts are listed separately so unused slots remain visible. */
async function adminListSpecialAccounts() {
  const db = await requireDb();
  await ensureReservedAccountSlots(db);
  const rows = await db
    .select({
      accountNumber: accountNumbers.accountNumber,
      userId: users.id,
      username: specialAccountCredentials.username,
      role: users.role,
    })
    .from(accountNumbers)
    .leftJoin(users, eq2(users.id, accountNumbers.userId))
    .leftJoin(specialAccountCredentials, eq2(specialAccountCredentials.userId, users.id))
    .where(and(gte(accountNumbers.accountNumber, 2), lte(accountNumbers.accountNumber, 100)))
    .orderBy(asc(accountNumbers.accountNumber));

  const byNumber = new Map(rows.map((row) => [row.accountNumber, row]));
  return Array.from({ length: 99 }, (_, index) => {
    const accountNumber = index + 2;
    const row = byNumber.get(accountNumber);
    return {
      accountNumber,
      userId: row?.userId ?? null,
      username: row?.username ?? null,
      role: row?.role ?? null,
      status: row?.userId ? "assigned" as const : "available" as const,
    };
  });
}

/** Create the account, reserve its number, initialize its profile and wallet, and audit atomically. */
async function adminCreateSpecialAccount(
  actorUserId: number,
  input: { accountNumber: number; username: string; password: string },
) {
  const accountNumber = input.accountNumber;
  const username = input.username.normalize("NFKC").trim();
  if (!Number.isInteger(accountNumber) || accountNumber < 2 || accountNumber > 100) {
    fail("BAD_REQUEST", "شمارهٔ حساب ویژه باید بین ۲ تا ۱۰۰ باشد.");
  }
  if (!/^[\p{L}\p{N}_.-]{3,32}$/u.test(username)) {
    fail("BAD_REQUEST", "نام کاربری باید ۳ تا ۳۲ نویسه و شامل حروف، عدد، نقطه، خط تیره یا زیرخط باشد.");
  }
  if (Buffer.byteLength(input.password, "utf8") < 6 || Buffer.byteLength(input.password, "utf8") > 256) {
    fail("BAD_REQUEST", "رمز عبور باید بین ۶ تا ۲۵۶ بایت باشد.");
  }

  const passwordHash = await hashLocalPassword(input.password);
  const db = await requireDb();
  return db.transaction(async (tx) => {
    await ensureReservedAccountSlots(tx);
    const [slot] = await tx
      .select({ userId: accountNumbers.userId })
      .from(accountNumbers)
      .where(eq2(accountNumbers.accountNumber, accountNumber))
      .limit(1);
    if (!slot) fail("INTERNAL_SERVER_ERROR", "جایگاه حساب ویژه در پایگاه داده آماده نیست.");
    if (slot.userId) fail("CONFLICT", "این شمارهٔ حساب قبلاً واگذار شده است.");

    const normalizedUsername = username.toLocaleLowerCase("fa-IR");
    const [credentialOwner] = await tx
      .select({ userId: specialAccountCredentials.userId })
      .from(specialAccountCredentials)
      .where(eq2(specialAccountCredentials.username, normalizedUsername))
      .limit(1);
    const [publicCredentialOwner] = await tx
      .select({ userId: passwordCredentials.userId })
      .from(passwordCredentials)
      .where(eq2(passwordCredentials.username, normalizedUsername))
      .limit(1);
    const [profileOwner] = await tx
      .select({ userId: profiles.userId })
      .from(profiles)
      .where(eq2(profiles.username, username))
      .limit(1);
    if (credentialOwner || publicCredentialOwner || profileOwner) fail("CONFLICT", "این نام کاربری قبلاً استفاده شده است.");

    const openId = `aria_special_${accountNumber}`;
    const [existingUser] = await tx
      .select({ id: users.id })
      .from(users)
      .where(eq2(users.openId, openId))
      .limit(1);
    if (existingUser) fail("CONFLICT", "حساب داخلی این شماره از قبل وجود دارد؛ با پشتیبانی بررسی کنید.");

    const inserted = await tx.insert(users).values({
      openId,
      name: username,
      email: null,
      loginMethod: "reserved-password",
      role: "user",
      lastSignedIn: new Date(),
    });
    const userId = Number(inserted[0].insertId);
    if (!Number.isInteger(userId) || userId < 1) fail("INTERNAL_SERVER_ERROR", "ساخت حساب کامل نشد.");

    await tx.update(accountNumbers).set({
      userId,
      isReserved: true,
      claimedAt: new Date(),
    }).where(eq2(accountNumbers.accountNumber, accountNumber));
    await tx.insert(specialAccountCredentials).values({
      userId,
      accountNumber,
      username: normalizedUsername,
      passwordHash,
    });
    await ensureProfileFor(tx, userId);
    await ensureAccountFor(tx, userId);
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "admin.special_account.create",
      targetUserId: userId,
      metadata: JSON.stringify({ accountNumber, username: normalizedUsername }),
    });

    return { success: true, accountNumber, userId, username: normalizedUsername };
  });
}

export { adminListSpecialAccounts, adminCreateSpecialAccount };
export { ensureAccountFor, isUnlimitedDiamondAdmin };


async function adminSecurityEvents(input = {}) {
  const db = await requireDb();
  return db.select({
    id: securityEvents.id,
    userId: securityEvents.userId,
    accountNumber: accountNumbers.accountNumber,
    username: profiles.username,
    name: users.name,
    eventType: securityEvents.eventType,
    severity: securityEvents.severity,
    summary: securityEvents.summary,
    status: securityEvents.status,
    createdAt: securityEvents.createdAt,
    reviewedAt: securityEvents.reviewedAt,
  })
    .from(securityEvents)
    .innerJoin(users, eq2(users.id, securityEvents.userId))
    .leftJoin(profiles, eq2(profiles.userId, users.id))
    .leftJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .orderBy(desc(securityEvents.id))
    .limit(clampLimit(input.limit, 50))
    .offset(clampOffset(input.offset));
}

async function adminReviewSecurityEvent(actorUserId, eventId, status) {
  const db = await requireDb();
  const [event] = await db.select({ id: securityEvents.id, userId: securityEvents.userId })
    .from(securityEvents)
    .where(eq2(securityEvents.id, eventId))
    .limit(1);
  if (!event) fail("NOT_FOUND", "هشدار امنیتی پیدا نشد.");
  const reviewedAt = new Date();
  await db.transaction(async (tx) => {
    await tx.update(securityEvents).set({ status, reviewedByUserId: actorUserId, reviewedAt })
      .where(eq2(securityEvents.id, eventId));
    await tx.insert(auditLogs).values({
      actorUserId,
      action: `security.event.${status}`,
      targetUserId: event.userId,
      metadata: JSON.stringify({ eventId }),
    });
  });
  return { success: true, eventId, status, reviewedAt };
}

export { adminSecurityEvents, adminReviewSecurityEvent };


async function listGameHistory(userId, input = {}) {
  const db = await requireDb();
  const rows = await db.select({
    id: gameRecords.id,
    gameType: gameRecords.gameType,
    status: gameRecords.status,
    score: gameRecords.score,
    outcome: gameRecords.outcome,
    metadata: gameRecords.metadata,
    startedAt: gameRecords.startedAt,
    endedAt: gameRecords.endedAt,
  }).from(gameRecords)
    .where(eq2(gameRecords.userId, userId))
    .orderBy(desc(gameRecords.id))
    .limit(clampLimit(input.limit, 20))
    .offset(clampOffset(input.offset));
  return rows.map((row) => {
    let metadata = {};
    try {
      metadata = row.metadata ? JSON.parse(row.metadata) : {};
    } catch {
      metadata = {};
    }
    const bet = Number(metadata.bet ?? 0);
    const score = Number(row.score ?? 0);
    return {
      id: row.id,
      gameType: row.gameType,
      status: row.status,
      outcome: row.outcome,
      bet,
      payout: Number(metadata.payout ?? Math.max(0, bet + score)),
      netChange: score,
      multiplier: Number(metadata.multiplier ?? 0),
      choice: metadata.choice ?? null,
      opponentChoice: metadata.opponentChoice ?? metadata.random?.opponentChoice ?? null,
      playedAt: row.endedAt ?? row.startedAt,
    };
  });
}

export { listGameHistory };


/** Reset an account password without ever returning or auditing plaintext credential material. */
async function adminResetUserPassword(
  actorUserId: number,
  input: { userId: number; newPassword: string },
) {
  if (!validateLocalPassword(input.newPassword)) {
    fail("BAD_REQUEST", "رمز جدید باید بین ۶ تا ۲۵۶ بایت باشد.");
  }
  const db = await requireDb();
  const [actor] = await db
    .select({ accountNumber: accountNumbers.accountNumber, role: users.role })
    .from(users)
    .innerJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .where(eq2(users.id, actorUserId))
    .limit(1);
  if (actor?.accountNumber !== 1 || actor.role !== "admin") {
    fail("FORBIDDEN", "بازنشانی رمز فقط برای Administrator شمارهٔ ۱ مجاز است.");
  }

  const [target] = await db
    .select({ accountNumber: accountNumbers.accountNumber, accountStatus: profiles.accountStatus })
    .from(users)
    .innerJoin(accountNumbers, eq2(accountNumbers.userId, users.id))
    .leftJoin(profiles, eq2(profiles.userId, users.id))
    .where(eq2(users.id, input.userId))
    .limit(1);
  if (!target || target.accountNumber === 1 || target.accountStatus === "deleted") {
    fail("NOT_FOUND", "حساب فعال و قابل‌بازنشانی پیدا نشد.");
  }

  const isReserved = target.accountNumber >= 2 && target.accountNumber <= 100;
  const passwordHash = await hashLocalPassword(input.newPassword);
  await db.transaction(async (tx) => {
    const credentialTable = isReserved ? specialAccountCredentials : passwordCredentials;
    const [credential] = await tx.select({ userId: credentialTable.userId })
      .from(credentialTable).where(eq2(credentialTable.userId, input.userId)).limit(1);
    if (!credential) fail("NOT_FOUND", "این حساب گذرواژهٔ محلی برای بازنشانی ندارد.");

    await tx.update(credentialTable)
      .set({ passwordHash, updatedAt: new Date() })
      .where(eq2(credentialTable.userId, input.userId));
    await tx.insert(auditLogs).values({
      actorUserId,
      action: "admin.password.reset",
      targetUserId: input.userId,
      metadata: JSON.stringify({ accountNumber: target.accountNumber }),
    });
  });
  return { success: true, accountNumber: target.accountNumber };
}

export { adminResetUserPassword };
