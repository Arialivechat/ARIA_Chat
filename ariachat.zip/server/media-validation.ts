import { Buffer } from "node:buffer";
import {
  MAX_IMAGE_UPLOAD_BYTES,
  MAX_NON_IMAGE_UPLOAD_BYTES,
  MAX_UPLOAD_BASE64_CHARS,
} from "../lib/media-limits";

export const MAX_CHAT_MEDIA_BYTES = MAX_NON_IMAGE_UPLOAD_BYTES;
export const MAX_CHAT_MEDIA_BASE64_CHARS = MAX_UPLOAD_BASE64_CHARS;

export type ChatMediaKind = "image" | "audio" | "asset";

export interface ChatMediaInput {
  base64Data: string;
  contentType: string;
  fileName: string;
}

export interface ValidatedChatMedia {
  bytes: Buffer;
  contentType: string;
  fileName: string;
  kind: ChatMediaKind;
  sizeBytes: number;
}

const ALLOWED_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "audio/mpeg",
  "audio/mp4",
  "audio/aac",
  "application/pdf",
]);

function hasSignature(bytes: Buffer, contentType: string): boolean {
  switch (contentType) {
    case "image/jpeg":
      return bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
    case "image/png":
      return bytes.length >= 8 && bytes.subarray(0, 8).equals(Buffer.from("89504e470d0a1a0a", "hex"));
    case "image/webp":
      return bytes.length >= 12 && bytes.toString("ascii", 0, 4) === "RIFF" && bytes.toString("ascii", 8, 12) === "WEBP";
    case "audio/mpeg":
      return bytes.length >= 3 && (bytes.toString("ascii", 0, 3) === "ID3" || (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0));
    case "audio/mp4":
      return bytes.length >= 12 && bytes.toString("ascii", 4, 8) === "ftyp";
    case "audio/aac":
      return bytes.length >= 2 && bytes[0] === 0xff && (bytes[1] & 0xf6) === 0xf0;
    case "application/pdf":
      return bytes.length >= 5 && bytes.toString("ascii", 0, 5) === "%PDF-";
    default:
      return false;
  }
}

function sanitizeFileName(name: string): string {
  const cleaned = name
    .replace(/[\\/]/g, "_")
    .replace(/[\u0000-\u001f\u007f]/g, "")
    .trim()
    .slice(0, 180);
  return cleaned || "attachment";
}

function sizeLimitFor(contentType: string): number {
  return contentType.startsWith("image/") ? MAX_IMAGE_UPLOAD_BYTES : MAX_NON_IMAGE_UPLOAD_BYTES;
}

function sizeLimitMessage(contentType: string): string {
  return contentType.startsWith("image/")
    ? "حجم تصویر از حد مجاز ۲۵ مگابایت بیشتر است."
    : "حجم فایل از حد مجاز ۱۰ مگابایت بیشتر است.";
}

export function validateChatMedia(input: ChatMediaInput): ValidatedChatMedia {
  const contentType = input.contentType.trim().toLowerCase().split(";")[0];
  if (!ALLOWED_TYPES.has(contentType)) {
    throw new Error("این نوع فایل پشتیبانی نمی‌شود.");
  }
  const maxBytes = sizeLimitFor(contentType);
  const maxBase64Chars = Math.ceil(maxBytes / 3) * 4;
  const encoded = input.base64Data;
  if (!encoded || encoded.length > maxBase64Chars) {
    throw new Error(sizeLimitMessage(contentType));
  }
  if (encoded.length % 4 !== 0) {
    throw new Error("محتوای فایل معتبر نیست.");
  }
  const padding = encoded.endsWith("==") ? 2 : encoded.endsWith("=") ? 1 : 0;
  const decodedSize = (encoded.length / 4) * 3 - padding;
  if (decodedSize === 0) {
    throw new Error("فایل خالی است.");
  }
  if (decodedSize > maxBytes) {
    throw new Error(sizeLimitMessage(contentType));
  }
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(encoded)) {
    throw new Error("محتوای فایل معتبر نیست.");
  }

  const bytes = Buffer.from(encoded, "base64");
  if (bytes.length === 0) {
    throw new Error("فایل خالی است.");
  }
  if (bytes.length > maxBytes) {
    throw new Error(sizeLimitMessage(contentType));
  }
  if (bytes.length !== decodedSize || bytes.toString("base64") !== encoded) {
    throw new Error("محتوای فایل معتبر نیست.");
  }
  if (!hasSignature(bytes, contentType)) {
    throw new Error("محتوای فایل با نوع اعلام‌شده سازگار نیست.");
  }

  const kind: ChatMediaKind = contentType.startsWith("image/")
    ? "image"
    : contentType.startsWith("audio/")
      ? "audio"
      : "asset";
  return {
    bytes,
    contentType,
    fileName: sanitizeFileName(input.fileName),
    kind,
    sizeBytes: bytes.length,
  };
}
