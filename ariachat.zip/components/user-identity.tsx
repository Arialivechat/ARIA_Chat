import { MaterialCommunityIcons } from "@expo/vector-icons";
import { useEffect } from "react";
import { StyleSheet, Text, View, type StyleProp, type TextStyle, type ViewStyle } from "react-native";
import Animated, { cancelAnimation, useAnimatedStyle, useReducedMotion, useSharedValue, withRepeat, withSequence, withTiming } from "react-native-reanimated";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { isProfileCrownStyle, type ProfileCrownStyle } from "@/lib/profile-badges";
import { getProfileCrownTone, isProfileAvatarEmoji } from "@/lib/profile-avatars";
import { profileBadgeTitleLabel, profileCrownLabel } from "@/lib/ui-locale-profile-badges";
import { translateProfileAvatars } from "@/lib/ui-locale-avatars";

type UserIdentityProps = {
  name: string;
  avatarEmoji?: string | null;
  badgeTitle?: string | null;
  crownStyle?: string | null;
  role?: string | null;
  roomRole?: string | null;
  style?: StyleProp<ViewStyle>;
  nameStyle?: StyleProp<TextStyle>;
  fontSize?: number;
  numberOfLines?: number;
};

type CrownTheme = { crown: string; gem: string | null; background: string; border: string };

const CUSTOM_CROWN_THEMES: Record<ProfileCrownStyle, CrownTheme> = {
  gold_blue: { crown: "#D9A514", gem: "#3478D4", background: "rgba(52, 120, 212, 0.12)", border: "rgba(217, 165, 20, 0.58)" },
  gold_red: { crown: "#D9A514", gem: "#D93636", background: "rgba(217, 54, 54, 0.12)", border: "rgba(217, 165, 20, 0.58)" },
  black_gold: { crown: "#242424", gem: "#E2B63F", background: "rgba(226, 182, 63, 0.12)", border: "rgba(226, 182, 63, 0.68)" },
};

function defaultCrownTheme(tone: "gold" | "blue"): CrownTheme {
  return tone === "gold"
    ? { crown: "#E5A900", gem: "#4D8BDD", background: "rgba(247, 190, 55, 0.14)", border: "rgba(230, 164, 35, 0.42)" }
    : { crown: "#2878D4", gem: null, background: "rgba(54, 133, 232, 0.13)", border: "rgba(54, 133, 232, 0.38)" };
}

export function UserIdentity({
  name,
  avatarEmoji,
  badgeTitle,
  crownStyle,
  role,
  roomRole,
  style,
  nameStyle,
  fontSize = 14,
  numberOfLines = 1,
}: UserIdentityProps) {
  const colors = useColors();
  const { locale, isRTL } = useLanguage();
  const crownTone = getProfileCrownTone(role, roomRole);
  const customCrown = isProfileCrownStyle(crownStyle) ? crownStyle : null;
  const isBlinking = Boolean(customCrown) || crownTone === "gold";
  const theme = customCrown ? CUSTOM_CROWN_THEMES[customCrown] : crownTone ? defaultCrownTheme(crownTone) : null;
  const opacity = useSharedValue(1);
  const animatedCrownStyle = useAnimatedStyle(() => ({ opacity: opacity.value }));
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    cancelAnimation(opacity);
    if (isBlinking && !reduceMotion) {
      // Reanimated shared values are deliberately mutable in effects; this is not React state.
      // eslint-disable-next-line react-hooks/immutability
      opacity.value = withRepeat(
        withSequence(
          withTiming(0.42, { duration: 560 }),
          withTiming(1, { duration: 560 }),
        ),
        -1,
        false,
      );
    } else {
      opacity.value = 1;
    }
    return () => cancelAnimation(opacity);
  }, [isBlinking, opacity, reduceMotion]);

  const safeEmoji = isProfileAvatarEmoji(avatarEmoji) ? avatarEmoji : null;
  const titleLabel = profileBadgeTitleLabel(locale, badgeTitle);
  const badgeLabel = customCrown
    ? profileCrownLabel(locale, customCrown)
    : crownTone === "gold"
      ? translateProfileAvatars(locale, "globalBadge")
      : crownTone === "blue"
        ? translateProfileAvatars(locale, "roomBadge")
        : null;
  const crownSize = Math.max(15, Math.round(fontSize * 1.08));
  const crown = theme ? (
    <Animated.View
      accessible
      accessibilityRole="image"
      accessibilityLabel={badgeLabel ?? "Crown"}
      style={[
        styles.crown,
        { backgroundColor: theme.background, borderColor: theme.border },
        isBlinking ? animatedCrownStyle : null,
      ]}
    >
      <MaterialCommunityIcons name="crown" size={crownSize} color={theme.crown} />
      {theme.gem ? <Text pointerEvents="none" style={[styles.gem, { color: theme.gem }]}>◆</Text> : null}
    </Animated.View>
  ) : null;

  return (
    <View style={[styles.row, { flexDirection: isRTL ? "row-reverse" : "row" }, style]}>
      <Text numberOfLines={numberOfLines} style={[styles.name, { color: colors.text, fontSize, textAlign: isRTL ? "right" : "left" }, nameStyle]}>{name}</Text>
      {titleLabel ? <View accessibilityRole="text" accessibilityLabel={titleLabel} style={[styles.titlePill, { backgroundColor: "rgba(120, 90, 190, 0.12)", borderColor: colors.border }]}><Text numberOfLines={1} style={[styles.titleText, { color: colors.tint, fontSize: Math.max(9, Math.round(fontSize * 0.72)) }]}>{titleLabel}</Text></View> : null}
      {safeEmoji ? <Text accessibilityLabel={safeEmoji} style={[styles.emoji, { fontSize: Math.max(15, Math.round(fontSize * 1.1)) }]}>{safeEmoji}</Text> : null}
      {crown}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { alignItems: "center", gap: 5, flexShrink: 1 },
  name: { fontWeight: "800", flexShrink: 1 },
  titlePill: { maxWidth: 120, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 999, borderWidth: StyleSheet.hairlineWidth },
  titleText: { fontWeight: "800" },
  emoji: { lineHeight: 22 },
  crown: { width: 24, height: 24, borderRadius: 9, borderWidth: 1, alignItems: "center", justifyContent: "center", overflow: "visible" },
  gem: { position: "absolute", bottom: -4, right: 2, fontSize: 6, lineHeight: 7, fontWeight: "900" },
});
