import { Ionicons } from "@expo/vector-icons";
import { router, type Href } from "expo-router";
import { useState } from "react";
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Modal,
  Pressable,
  Platform,
  ScrollView,
  StyleSheet,
  type StyleProp,
  Text,
  TextInput,
  View,
  type ViewStyle,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import Constants from "expo-constants";
import { getApiBaseUrl } from "@/constants/oauth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import * as Auth from "@/lib/_core/auth";
import { apiCall } from "@/lib/_core/api";
import { LOCALES } from "@/lib/locales";
import { trpc } from "@/lib/trpc";
import { translateAuth, type AuthLocaleKey } from "@/lib/ui-locale-auth";

export function Page({ children, scroll = true, bottomSafeArea = false }: { children: React.ReactNode; scroll?: boolean; bottomSafeArea?: boolean }) {
  return (
    <ScreenContainer
      edges={bottomSafeArea ? ["top", "left", "right", "bottom"] : ["top", "left", "right"]}
      containerClassName="bg-background"
      safeAreaClassName="bg-background"
      className="px-5 pt-2"
    >
      {scroll ? (
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 34, gap: 18 }}
          keyboardShouldPersistTaps="handled"
        >
          {children}
        </ScrollView>
      ) : (
        <View style={{ flex: 1, gap: 14 }}>{children}</View>
      )}
    </ScreenContainer>
  );
}

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  right,
}: {
  eyebrow?: string;
  title: React.ReactNode;
  subtitle?: string;
  right?: React.ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.header}>
      <View style={{ flex: 1 }}>
        {eyebrow ? <Text style={[styles.eyebrow, { color: colors.tint }]}>{eyebrow}</Text> : null}
        {typeof title === "string" || typeof title === "number" ? <Text style={[styles.title, { color: colors.text }]}>{title}</Text> : title}
        {subtitle ? <Text style={[styles.subtitle, { color: colors.icon }]}>{subtitle}</Text> : null}
      </View>
      {right}
    </View>
  );
}

export function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeader}>
      <Text style={[styles.sectionTitle, { color: colors.text }]}>{title}</Text>
      {action && onAction ? (
        <Pressable onPress={onAction} hitSlop={8}>
          <Text style={[styles.actionText, { color: colors.tint }]}>{action}</Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function Surface({ children, style, onPress }: { children: React.ReactNode; style?: StyleProp<ViewStyle>; onPress?: () => void }) {
  const colors = useColors();
  const content = <View style={[styles.surface, { backgroundColor: colors.surface, borderColor: colors.border }, style]}>{children}</View>;
  if (!onPress) return content;
  return <Pressable onPress={onPress} style={({ pressed }) => [pressed && { opacity: 0.86 }]}>{content}</Pressable>;
}

export function PrimaryButton({
  title,
  onPress,
  icon,
  disabled,
  quiet = false,
}: {
  title: string;
  onPress: () => void;
  icon?: keyof typeof Ionicons.glyphMap;
  disabled?: boolean;
  quiet?: boolean;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      disabled={disabled}
      onPress={onPress}
      style={({ pressed }) => [
        styles.button,
        { backgroundColor: quiet ? colors.background : colors.tint, borderColor: colors.border },
        quiet && { borderWidth: 1 },
        (pressed || disabled) && { opacity: 0.72 },
      ]}
    >
      {icon ? <Ionicons name={icon} size={18} color={quiet ? colors.tint : colors.background} /> : null}
      <Text style={[styles.buttonText, { color: quiet ? colors.tint : colors.background }]}>{title}</Text>
    </Pressable>
  );
}

export function FloatingIcon({ icon, size = 46, label, style }: { icon: keyof typeof Ionicons.glyphMap; size?: number; label?: string; style?: ViewStyle }) {
  const colors = useColors();
  return (
    <View accessible={Boolean(label)} accessibilityLabel={label} style={[styles.floatingIcon, { width: size, height: size, borderRadius: size * 0.38, backgroundColor: colors.surface, borderColor: colors.border }, style]}>
      <Ionicons name={icon} size={Math.round(size * 0.46)} color={colors.tint} />
      <View style={[styles.floatingDot, { backgroundColor: colors.warning, borderColor: colors.surface }]} />
    </View>
  );
}

export function IconButton({ icon, onPress, label }: { icon: keyof typeof Ionicons.glyphMap; onPress: () => void; label: string }) {
  const colors = useColors();
  return <Pressable accessibilityRole="button" accessibilityLabel={label} onPress={onPress} style={({ pressed }) => [styles.iconButton, styles.floatingShadow, { backgroundColor: colors.surface, borderColor: colors.border }, pressed && { transform: [{ translateY: -2 }], elevation: 7 }]}><Ionicons name={icon} size={20} color={colors.tint} /></Pressable>;
}

export function Chip({ label, active = false, onPress }: { label: string; active?: boolean; onPress?: () => void }) {
  const colors = useColors();
  return (
    <Pressable onPress={onPress} style={[styles.chip, { backgroundColor: active ? colors.tint : colors.surface, borderColor: active ? colors.tint : colors.border }]}>
      <Text style={{ color: active ? colors.background : colors.text, fontSize: 12, fontWeight: "700" }}>{label}</Text>
    </Pressable>
  );
}

export function EmptyState({ icon, title, detail }: { icon: keyof typeof Ionicons.glyphMap; title: string; detail: string }) {
  const colors = useColors();
  return (
    <View style={[styles.empty, { borderColor: colors.border }]}>
      <FloatingIcon icon={icon} size={48} />
      <Text style={[styles.emptyTitle, { color: colors.text }]}>{title}</Text>
      <Text style={[styles.subtitle, { color: colors.icon, textAlign: "center" }]}>{detail}</Text>
    </View>
  );
}

type PasswordSessionResponse = {
  sessionToken: string;
  user: { id: number; openId: string; name: string | null; email: string | null; loginMethod: string | null; lastSignedIn: string };
};

export function LoginGate({ title, authError, onRetry, redirectTo = "/(tabs)" }: { title?: string; authError?: Error | null; onRetry?: () => void; redirectTo?: Href }) {
  const colors = useColors();
  const { locale, setLocale, isRTL, t, isLocaleManuallySelected } = useLanguage();
  const copy = (key: AuthLocaleKey) => translateAuth(locale, key);
  const utils = trpc.useUtils();
  const saveLanguage = trpc.profile.update.useMutation();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [languageOpen, setLanguageOpen] = useState(false);
  const [registerMode, setRegisterMode] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const logoPath = (Constants.expoConfig?.extra as { logoUrl?: string } | undefined)?.logoUrl;
  const logoBase = getApiBaseUrl();
  const logoUri = logoPath?.startsWith("/") && logoBase ? `${logoBase}${logoPath}` : logoPath;
  const selectedLanguage = LOCALES.find((item) => item.code === locale);
  const login = async () => {
    if (!username.trim() || !password) return;
    if (registerMode && password !== confirmPassword) {
      setError(copy("passwordMismatch"));
      return;
    }
    if (registerMode && password.length < 6) {
      setError(copy("passwordMin"));
      return;
    }
    try {
      setBusy(true);
      setError("");
      const response = await apiCall<PasswordSessionResponse>(registerMode ? "/api/auth/register" : "/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ username: username.trim(), password, ...(registerMode ? { language: locale } : {}) }),
      });
      await Auth.setSessionToken(response.sessionToken);
      await Auth.setUserInfo({ ...response.user, lastSignedIn: new Date(response.user.lastSignedIn) });
      setPassword("");
      setConfirmPassword("");
      router.replace(redirectTo);
      if (!registerMode && isLocaleManuallySelected) {
        void saveLanguage.mutateAsync({ language: locale }).catch(() => undefined);
      }
      void utils.invalidate().catch(() => undefined);
    } catch (e) {
      const message = e instanceof Error ? e.message : copy("connectionError");
      if (/invalid username|invalid credentials/i.test(message)) setError(copy("invalidCredentials"));
      else if (/too many login attempts/i.test(message)) setError(copy("tooManyLogins"));
      else if (/too many registration attempts/i.test(message)) setError(copy("tooManyRegistrations"));
      else if (/USERNAME_TAKEN|already in use|قبلاً استفاده شده/i.test(message)) setError(copy("usernameTaken"));
      else if (/نام کاربری باید|invalid username/i.test(message)) setError(copy("invalidUsername"));
      else if (/رمز عبور باید بین|password.*6.*256/i.test(message)) setError(copy("passwordMin"));
      else if (/registration is temporarily unavailable|unable to complete registration/i.test(message)) setError(copy("connectionError"));
      else setError(message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : Platform.OS === "android" ? "height" : undefined}>
      <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background" safeAreaClassName="bg-background" className="px-6">
        <ScrollView style={{ flex: 1 }} contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled" keyboardDismissMode={Platform.OS === "ios" ? "interactive" : "on-drag"}>
          <View style={styles.loginWrap}>
            {logoUri ? (
              <View style={styles.logoLockup}>
                <Image source={{ uri: logoUri }} accessibilityLabel="ARIA Chat logo" resizeMode="contain" style={styles.logoImage} />
                <Text accessibilityLabel="ARIA CHAT" style={styles.logoWordmark}>ARIA CHAT</Text>
              </View>
            ) : <FloatingIcon icon="chatbubbles" size={68} label="ARIA Chat" style={{ backgroundColor: colors.tint, borderColor: colors.warning }} />}
            <Text style={[styles.brand, { color: colors.text }]}>آریا چت</Text>
            <Text style={[styles.subtitle, { color: colors.icon, textAlign: "center", maxWidth: 300 }]}>{copy("tagline")}</Text>
            <Surface style={{ width: "100%", gap: 12 }}>
              <View style={{ alignItems: isRTL ? "flex-start" : "flex-end" }}>
                <Pressable accessibilityRole="button" accessibilityLabel={`${copy("language")}: ${selectedLanguage?.name ?? locale}`} onPress={() => setLanguageOpen(true)} style={[styles.button, { minHeight: 40, paddingHorizontal: 12, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.background, flexDirection: isRTL ? "row-reverse" : "row" }]}>
                  <Ionicons name="globe-outline" size={17} color={colors.tint} />
                  <Text style={{ color: colors.text, fontWeight: "700", fontSize: 12 }}>{copy("language")}: {selectedLanguage?.name ?? locale}</Text>
                  <Ionicons name="chevron-down" size={15} color={colors.icon} />
                </Pressable>
              </View>
              <Text style={[styles.sectionTitle, { color: colors.text, textAlign: "center" }]}>{title ?? copy("loginTitle")}</Text>
              <Text style={[styles.subtitle, { color: colors.icon, textAlign: "center" }]}>{copy("intro")}</Text>
              <TextInput value={username} onChangeText={setUsername} autoCapitalize="none" autoCorrect={false} autoComplete="username" textContentType="username" maxLength={32} placeholder={copy("username")} placeholderTextColor={colors.icon} returnKeyType="next" style={[ui.input, { width: "100%", color: colors.text, borderColor: colors.border, textAlign: isRTL ? "right" : "left" }]} />
              <TextInput value={password} onChangeText={setPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete={registerMode ? "new-password" : "current-password"} textContentType={registerMode ? "newPassword" : "password"} maxLength={256} placeholder={copy("password")} placeholderTextColor={colors.icon} onSubmitEditing={registerMode ? undefined : login} returnKeyType={registerMode ? "next" : "go"} style={[ui.input, { width: "100%", color: colors.text, borderColor: colors.border, textAlign: isRTL ? "right" : "left" }]} />
              {registerMode ? <TextInput value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry autoCapitalize="none" autoCorrect={false} autoComplete="new-password" textContentType="newPassword" maxLength={256} placeholder={copy("confirmPassword")} placeholderTextColor={colors.icon} onSubmitEditing={login} returnKeyType="go" style={[ui.input, { width: "100%", color: colors.text, borderColor: colors.border, textAlign: isRTL ? "right" : "left" }]} /> : null}
              <PrimaryButton title={busy ? copy("checking") : registerMode ? copy("register") : copy("login")} icon={registerMode ? "person-add" : "arrow-forward"} disabled={busy || !username.trim() || !password || (registerMode && !confirmPassword)} onPress={login} />
              {busy ? <ActivityIndicator color={colors.tint} /> : null}
              <Pressable accessibilityRole="button" disabled={busy} onPress={() => { setRegisterMode((value) => !value); setError(""); setPassword(""); setConfirmPassword(""); }} style={{ alignSelf: "center", padding: 8 }}><Text style={{ color: colors.tint, fontWeight: "800", textAlign: "center" }}>{registerMode ? copy("switchToLogin") : copy("switchToRegister")}</Text></Pressable>
              {authError ? <View style={{ gap: 8 }}><Text style={{ color: colors.error, textAlign: "center" }}>{copy("connectionError")}</Text>{onRetry ? <PrimaryButton title={t("retry")} icon="refresh" quiet onPress={() => { void onRetry(); }} /> : null}</View> : null}
              {error ? <Text style={{ color: colors.error, textAlign: "center" }}>{error}</Text> : null}
              {registerMode ? <Text style={[ui.meta, { color: colors.icon, textAlign: "center" }]}>{copy("registrationNote")}</Text> : null}
            </Surface>
            <Text style={[styles.eyebrow, { color: colors.icon }]}>ARIA CHAT</Text>
          </View>
        </ScrollView>
        <Modal transparent visible={languageOpen} animationType="fade" onRequestClose={() => setLanguageOpen(false)}>
          <View style={{ flex: 1, backgroundColor: "rgba(4, 12, 25, 0.68)", alignItems: "center", justifyContent: "center", padding: 18 }}>
            <Surface style={{ width: "100%", maxWidth: 420, maxHeight: "85%", gap: 12 }}>
              <View style={{ flexDirection: isRTL ? "row-reverse" : "row", alignItems: "center", justifyContent: "space-between" }}>
                <Text style={{ color: colors.text, fontSize: 16, fontWeight: "800" }}>{copy("chooseLanguage")}</Text>
                <Pressable accessibilityRole="button" onPress={() => setLanguageOpen(false)} style={{ padding: 8 }}><Text style={{ color: colors.tint, fontWeight: "700" }}>{copy("close")}</Text></Pressable>
              </View>
              <ScrollView style={{ maxHeight: 480 }} keyboardShouldPersistTaps="handled" contentContainerStyle={{ gap: 7 }}>
                {LOCALES.map((item) => {
                  const active = locale === item.code;
                  return <Pressable key={item.code} accessibilityRole="button" accessibilityState={{ selected: active }} onPress={() => { void setLocale(item.code); setLanguageOpen(false); setError(""); }} style={{ minHeight: 46, borderRadius: 13, borderWidth: 1, borderColor: active ? colors.tint : colors.border, backgroundColor: active ? colors.tint : colors.background, paddingHorizontal: 13, flexDirection: item.rtl ? "row-reverse" : "row", alignItems: "center", justifyContent: "space-between" }}><Text style={{ color: active ? colors.background : colors.text, fontWeight: active ? "800" : "600" }}>{item.name}</Text>{active ? <Ionicons name="checkmark-circle" size={18} color={colors.background} /> : null}</Pressable>;
                })}
              </ScrollView>
            </Surface>
          </View>
        </Modal>
      </ScreenContainer>
    </KeyboardAvoidingView>
  );
}

export const ui = StyleSheet.create({
  row: { flexDirection: "row-reverse", alignItems: "center", gap: 10 },
  spread: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 10 },
  body: { fontSize: 14, lineHeight: 22, textAlign: "right" },
  meta: { fontSize: 11, lineHeight: 16 },
  input: { minHeight: 46, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, paddingVertical: 10, textAlign: "right", fontSize: 14 },
  avatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
});

const styles = StyleSheet.create({
  header: { flexDirection: "row-reverse", alignItems: "center", gap: 12, marginTop: 4 },
  eyebrow: { fontSize: 11, letterSpacing: 1, textAlign: "right", fontWeight: "700" },
  title: { fontSize: 26, lineHeight: 34, fontWeight: "800", textAlign: "right" },
  subtitle: { fontSize: 13, lineHeight: 20, textAlign: "right", marginTop: 3 },
  sectionHeader: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 3 },
  sectionTitle: { fontSize: 16, fontWeight: "800", textAlign: "right" },
  actionText: { fontSize: 12, fontWeight: "700" },
  surface: { borderRadius: 20, borderWidth: 1, padding: 16, gap: 10 },
  button: { minHeight: 48, borderRadius: 15, paddingHorizontal: 18, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 9 },
  buttonText: { fontSize: 14, fontWeight: "800" },
  iconButton: { width: 42, height: 42, borderRadius: 15, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  chip: { paddingHorizontal: 12, paddingVertical: 8, borderWidth: 1, borderRadius: 999 },
  floatingShadow: { shadowColor: "#2D65C8", shadowOpacity: 0.2, shadowRadius: 9, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  floatingIcon: { borderWidth: 1, alignItems: "center", justifyContent: "center", shadowColor: "#2D65C8", shadowOpacity: 0.2, shadowRadius: 9, shadowOffset: { width: 0, height: 5 }, elevation: 5 },
  floatingDot: { position: "absolute", width: 9, height: 9, borderRadius: 5, bottom: 4, right: 4, borderWidth: 1 },
  empty: { borderStyle: "dashed", borderWidth: 1, borderRadius: 20, padding: 22, alignItems: "center", gap: 8 },
  emptyIcon: { width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center", marginBottom: 3 },
  emptyTitle: { fontSize: 15, fontWeight: "800", textAlign: "center" },
  loginWrap: { flex: 1, justifyContent: "center", alignItems: "center", gap: 15, paddingBottom: 32 },
  logoLockup: { width: 144, height: 144, alignItems: "center", justifyContent: "center" },
  logoImage: { width: 144, height: 144, borderRadius: 32 },
  logoWordmark: { position: "absolute", alignSelf: "center", top: 64, color: "#FFFFFF", fontSize: 15, fontWeight: "900", letterSpacing: 1.2, textShadowColor: "#061632", textShadowRadius: 5, textShadowOffset: { width: 0, height: 1 } },
  brandMark: { height: 68, width: 68, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  brand: { fontSize: 31, fontWeight: "900" },
});
