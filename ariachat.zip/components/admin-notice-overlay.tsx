import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { Modal, Pressable, Text, View } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { trpc } from "@/lib/trpc";

export function AdminNoticeOverlay() {
  const colors = useColors();
  const me = trpc.auth.me.useQuery(undefined, { retry: false, refetchInterval: 20_000 });
  const notice = trpc.notices.latest.useQuery(undefined, {
    enabled: Boolean(me.data?.id),
    refetchInterval: 20_000,
  });
  const [dismissedId, setDismissedId] = useState<number | null>(null);
  const activeNotice = notice.data && notice.data.id !== dismissedId ? notice.data : null;

  return (
    <Modal
      visible={Boolean(activeNotice)}
      transparent
      animationType="fade"
      onRequestClose={() => activeNotice && setDismissedId(activeNotice.id)}
      statusBarTranslucent
    >
      <View style={{ flex: 1, backgroundColor: "rgba(3, 10, 24, 0.58)", alignItems: "center", justifyContent: "center", padding: 22 }}>
        <View style={{ width: "100%", maxWidth: 460, borderRadius: 24, borderWidth: 1, borderColor: colors.warning, padding: 20, gap: 12, backgroundColor: colors.surface, shadowColor: "#071A3A", shadowOpacity: 0.3, shadowRadius: 22, shadowOffset: { width: 0, height: 10 }, elevation: 12 }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 42, height: 42, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: colors.background, borderWidth: 1, borderColor: colors.border }}>
              <Ionicons name="megaphone" size={20} color={colors.warning} />
            </View>
            <Text style={{ flex: 1, color: colors.text, fontSize: 17, fontWeight: "900", textAlign: "right" }}>{activeNotice?.title ?? "اطلاعیهٔ آریا چت"}</Text>
          </View>
          <Text style={{ color: colors.text, fontSize: 14, lineHeight: 24, textAlign: "right" }}>{activeNotice?.body}</Text>
          {activeNotice?.createdAt ? <Text style={{ color: colors.icon, fontSize: 11, textAlign: "right" }}>{new Date(activeNotice.createdAt).toLocaleString("fa-IR")}</Text> : null}
          <Pressable accessibilityRole="button" onPress={() => activeNotice && setDismissedId(activeNotice.id)} style={({ pressed }) => ({ minHeight: 46, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: colors.tint, opacity: pressed ? 0.8 : 1 })}>
            <Text style={{ color: colors.background, fontSize: 14, fontWeight: "900" }}>متوجه شدم</Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
