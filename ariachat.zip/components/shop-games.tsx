import Svg, { Circle, G, Path, Polygon, Text as SvgText } from "react-native-svg";
import { useEffect, useMemo, useRef, useState } from "react";
import { Animated, Easing, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { trpc } from "@/lib/trpc";
import { canSpendDiamonds, diamondBalanceLabel } from "@/lib/diamond-balance";
import { createGameRequestId, type DiamondMiniGameResult, type DiamondMiniGameType } from "@/lib/diamond-games";

type WheelProps = {
  result: number | null;
  resultKey: number | null;
  spinning: boolean;
  onAnimationStateChange?: (animating: boolean) => void;
  label: string;
  textColor: string;
  successColor: string;
};

export function Wheel({ result, resultKey, spinning, onAnimationStateChange, label, textColor, successColor }: WheelProps) {
  const [angle] = useState(() => new Animated.Value(0));
  const [shown, setShown] = useState<{ resultKey: number; value: number } | null>(null);
  const displayedResult = resultKey !== null && shown?.resultKey === resultKey ? shown.value : null;
  const animating = result !== null && resultKey !== null && displayedResult === null;

  useEffect(() => {
    if (result === null || resultKey === null) {
      onAnimationStateChange?.(false);
      return;
    }
    let cancelled = false;
    onAnimationStateChange?.(true);
    angle.stopAnimation((current) => {
      const desired = ((351 - result * 18) % 360 + 360) % 360;
      const currentMod = ((current % 360) + 360) % 360;
      const correction = (desired - currentMod + 360) % 360;
      const destination = current + 360 * 6 + correction;
      Animated.timing(angle, {
        toValue: destination,
        duration: 4200,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start(({ finished }) => {
        if (!cancelled && finished) {
          setShown({ resultKey, value: result });
          onAnimationStateChange?.(false);
        }
      });
    });
    return () => {
      cancelled = true;
      angle.stopAnimation();
    };
  }, [angle, onAnimationStateChange, result, resultKey]);

  const rotate = angle.interpolate({ inputRange: [0, 360], outputRange: ["0deg", "360deg"], extrapolate: "extend" });
  const sectors = useMemo(() => Array.from({ length: 20 }, (_, index) => {
    const start = (index * 18 - 90) * Math.PI / 180;
    const end = ((index + 1) * 18 - 90) * Math.PI / 180;
    const radius = 96;
    const x1 = 100 + radius * Math.cos(start);
    const y1 = 100 + radius * Math.sin(start);
    const x2 = 100 + radius * Math.cos(end);
    const y2 = 100 + radius * Math.sin(end);
    const mid = (start + end) / 2;
    const fill = index === 0 ? "#D97706" : index <= 5 ? "#15803D" : "#475569";
    const prize = index === 0 ? "10×" : index <= 5 ? "2×" : "0×";
    return (
      <G key={index}>
        <Path d={`M100 100 L${x1} ${y1} A${radius} ${radius} 0 0 1 ${x2} ${y2} Z`} fill={fill} stroke="#fff" strokeWidth="1.2" />
        <SvgText x={100 + 62 * Math.cos(mid)} y={104 + 62 * Math.sin(mid)} fill="#fff" fontSize="9" textAnchor="middle" fontWeight="bold">{prize}</SvgText>
      </G>
    );
  }), []);

  const displayedPrize = displayedResult === null ? "" : displayedResult === 0 ? "10×" : displayedResult <= 5 ? "2×" : "0×";
  return (
    <View style={styles.wheelWrap} accessibilityRole="image" accessibilityLabel={displayedResult === null ? label : `${label}: ${displayedPrize}`}>
      <View pointerEvents="none" style={styles.pointer}>
        <Svg width={22} height={26} viewBox="0 0 22 26">
          <Polygon points="11,25 1,1 21,1" fill="#ef4444" stroke="#fff" strokeWidth="1.5" />
        </Svg>
      </View>
      <Animated.View style={{ transform: [{ rotate }] }}>
        <Svg width={210} height={210} viewBox="0 0 200 200">
          {sectors}
          <Circle cx="100" cy="100" r="15" fill="#111827" stroke="#fff" strokeWidth="2" />
          <Circle cx="100" cy="100" r="4" fill="#f8fafc" />
        </Svg>
      </Animated.View>
      {displayedResult !== null ? <Text style={[styles.result, { color: successColor }]}>{label}: {displayedPrize}</Text> : null}
      {spinning || animating ? <Text style={{ color: textColor }}>…</Text> : null}
    </View>
  );
}

type DiceDisplayProps = {
  face: number | null;
  resultKey: number | null;
  rolling: boolean;
  onAnimationStateChange?: (animating: boolean) => void;
  textColor: string;
  pipColor: string;
  surfaceColor: string;
  borderColor: string;
};

const pipPositions: Record<number, number[]> = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
};

export function DiceDisplay({ face, resultKey, rolling, onAnimationStateChange, textColor, pipColor, surfaceColor, borderColor }: DiceDisplayProps) {
  const [turn] = useState(() => new Animated.Value(0));
  const [shownFace, setShownFace] = useState<number | null>(null);
  useEffect(() => {
    if (rolling) {
      onAnimationStateChange?.(true);
      turn.setValue(0);
      const loop = Animated.loop(Animated.timing(turn, { toValue: 1, duration: 520, easing: Easing.linear, useNativeDriver: true }));
      loop.start();
      return () => loop.stop();
    }
    if (face === null || resultKey === null) {
      onAnimationStateChange?.(false);
      return;
    }
    onAnimationStateChange?.(true);
    turn.setValue(0);
    Animated.timing(turn, { toValue: 1, duration: 760, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start(({ finished }) => {
      if (finished) {
        setShownFace(face);
        onAnimationStateChange?.(false);
      }
    });
  }, [face, onAnimationStateChange, resultKey, rolling, turn]);

  const rotation = turn.interpolate({ inputRange: [0, 1], outputRange: ["0deg", "720deg"] });
  const visibleFace = rolling ? null : shownFace ?? face;
  const pips = visibleFace === null ? [] : pipPositions[visibleFace] ?? [];
  return (
    <Animated.View accessibilityRole="image" accessibilityLabel={visibleFace === null ? "Rolling die" : `Die showing ${visibleFace}`} style={[styles.die, { backgroundColor: surfaceColor, borderColor }, { transform: [{ rotate: rotation }] }]}>
      {visibleFace === null ? <Text style={[styles.dieQuestion, { color: textColor }]}>?</Text> : Array.from({ length: 9 }, (_, index) => (
        <View key={index} style={styles.pipCell}>
          {pips.includes(index) ? <View style={[styles.pip, { backgroundColor: pipColor }]} /> : null}
        </View>
      ))}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wheelWrap: { alignItems: "center", gap: 7, paddingTop: 10, paddingBottom: 8 },
  pointer: { position: "absolute", zIndex: 3, top: 0, left: "50%", marginLeft: -11 },
  result: { fontSize: 16, fontWeight: "900", textAlign: "center", paddingVertical: 4 },
  die: { width: 76, height: 76, borderRadius: 18, borderWidth: 1.5, alignSelf: "center", marginVertical: 8, padding: 10, flexDirection: "row", flexWrap: "wrap", shadowColor: "#000", shadowOpacity: 0.12, shadowRadius: 8, elevation: 3 },
  dieQuestion: { fontSize: 34, fontWeight: "900", alignSelf: "center", textAlign: "center", width: "100%" },
  pipCell: { width: "33.333%", height: "33.333%", alignItems: "center", justifyContent: "center" },
  pip: { width: 9, height: 9, borderRadius: 5 },
  freeGames: { gap: 6 },
  notice: { textAlign: "center", fontWeight: "700", paddingVertical: 4 },
  heading: { fontSize: 17, fontWeight: "900", textAlign: "center", paddingTop: 10 },
  board: { width: 186, height: 186, alignSelf: "center", flexDirection: "row", flexWrap: "wrap" },
  cell: { width: 62, height: 62, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  mark: { fontSize: 28, fontWeight: "900" },
  memory: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 6 },
  card: { width: 62, height: 58, alignItems: "center", justifyContent: "center", borderRadius: 8, borderWidth: 1 },
  resetButton: { alignSelf: "center", borderWidth: 1, borderRadius: 12, paddingHorizontal: 16, marginTop: 4 },
  reset: { textAlign: "center", fontWeight: "900", padding: 8 },
});


type DiamondMiniGamesProps = {
  t: (key: string) => string;
  amount: string;
  onAmountChange: (value: string) => void;
  balance: number | null;
  walletReady: boolean;
  isUnlimited: boolean;
  diamondLabel: string;
  textColor: string;
  mutedColor: string;
  accentColor: string;
  successColor: string;
  errorColor: string;
  surfaceColor: string;
  backgroundColor: string;
  borderColor: string;
  onResult: (result: DiamondMiniGameResult) => void | Promise<void>;
};

const MINI_GAME_CARDS: { gameType: DiamondMiniGameType; titleKey: string; icon: string }[] = [
  { gameType: "tic_tac_toe", titleKey: "ticTacToe", icon: "×" },
  { gameType: "memory_match", titleKey: "memoryMatch", icon: "?" },
  { gameType: "guess_number", titleKey: "guessNumber", icon: "1–10" },
  { gameType: "treasure_hunt", titleKey: "treasureHunt", icon: "◇" },
];

export function DiamondMiniGames({
  t,
  amount,
  onAmountChange,
  balance,
  walletReady,
  isUnlimited,
  diamondLabel,
  textColor,
  mutedColor,
  accentColor,
  successColor,
  errorColor,
  surfaceColor,
  backgroundColor,
  borderColor,
  onResult,
}: DiamondMiniGamesProps) {
  const [results, setResults] = useState<Partial<Record<DiamondMiniGameType, DiamondMiniGameResult>>>({});
  const [guessChoice, setGuessChoice] = useState<number | null>(null);
  const [chestChoice, setChestChoice] = useState<number | null>(null);
  const [pendingGame, setPendingGame] = useState<DiamondMiniGameType | null>(null);
  const pendingRef = useRef(false);
  const mutation = trpc.games.mini.useMutation({
    onSuccess: (rawResult) => {
      const result = rawResult as unknown as DiamondMiniGameResult;
      setResults((previous) => ({ ...previous, [result.gameType]: result }));
      void onResult(result);
    },
    onSettled: () => {
      pendingRef.current = false;
      setPendingGame(null);
    },
  });
  const numericAmount = Number(amount);
  const canPlay = walletReady && canSpendDiamonds(numericAmount, balance, isUnlimited, Math.floor(Number.MAX_SAFE_INTEGER / 10));
  const selectGuess = (value: number) => { setGuessChoice(value); setResults((previous) => ({ ...previous, guess_number: undefined })); };
  const selectChest = (value: number) => { setChestChoice(value); setResults((previous) => ({ ...previous, treasure_hunt: undefined })); };

  const play = (gameType: DiamondMiniGameType, choice?: number) => {
    if (!canPlay || mutation.isPending || pendingRef.current || ((gameType === "guess_number" || gameType === "treasure_hunt") && choice === undefined)) return;
    mutation.reset();
    pendingRef.current = true;
    setPendingGame(gameType);
    mutation.mutate({
      gameType,
      bet: numericAmount,
      requestId: createGameRequestId(),
      ...(choice !== undefined ? { choice } : {}),
    });
  };

  const renderResult = (gameType: DiamondMiniGameType) => {
    const result = results[gameType];
    if (!result) return null;
    const won = result.outcome === "win";
    return (
      <View accessibilityLiveRegion="polite" style={[miniStyles.resultBox, { borderColor, backgroundColor }]}>
        <Text style={[miniStyles.resultTitle, { color: won ? successColor : errorColor }]}>
          {t("gameResult")}: {won ? t("win") : t("loss")}
        </Text>
        {gameType === "tic_tac_toe" && result.board ? (
          <View style={miniStyles.board}>
            {result.board.map((mark, index) => (
              <View key={index} style={[miniStyles.boardCell, { backgroundColor: surfaceColor, borderColor }]}>
                <Text style={[miniStyles.boardMark, { color: mark === "X" ? accentColor : successColor }]}>{mark === "X" ? "×" : mark === "O" ? "○" : ""}</Text>
              </View>
            ))}
          </View>
        ) : null}
        {gameType === "memory_match" && result.memoryDeck ? (
          <>
            <View style={miniStyles.memoryGrid}>
              {result.memoryDeck.map((value, index) => {
                const isMatched = (result.matchedCards ?? []).includes(index);
                return (
                  <View key={index} style={[miniStyles.memoryCard, { backgroundColor: isMatched ? surfaceColor : accentColor, borderColor }]}>
                    <Text style={[miniStyles.memoryMark, { color: isMatched ? textColor : backgroundColor }]}>{isMatched ? String.fromCodePoint(0x1f600 + value) : "?"}</Text>
                  </View>
                );
              })}
            </View>
            <Text style={[miniStyles.resultDetail, { color: mutedColor }]}>{t("memoryPairs")}: {result.matchedPairs ?? 0} / 4</Text>
          </>
        ) : null}
        {gameType === "guess_number" ? (
          <Text style={[miniStyles.resultDetail, { color: mutedColor }]}>{t("winningNumbers")}: {(result.winningNumbers ?? []).join(" · ")}</Text>
        ) : null}
        {gameType === "treasure_hunt" ? (
          <Text style={[miniStyles.resultDetail, { color: mutedColor }]}>{t("treasureSpots")}: {(result.treasureSpots ?? []).join(" · ")}</Text>
        ) : null}
        <Text style={[miniStyles.resultDetail, { color: textColor }]}>
          {t("payout")}: {result.payout} {diamondLabel} · {t("balance")}: {diamondBalanceLabel(result.balance, isUnlimited)} {diamondLabel}
        </Text>
      </View>
    );
  };

  return (
    <View style={miniStyles.root}>
      <View style={[miniStyles.amountBox, { backgroundColor, borderColor }]}>
        <Text style={[miniStyles.ruleText, { color: mutedColor }]}>{t("miniRules")}</Text>
        <TextInput
          value={amount}
          onChangeText={onAmountChange}
          keyboardType="number-pad"
          accessibilityLabel={t("miniAmountLabel")}
          placeholder={t("miniAmountLabel")}
          placeholderTextColor={mutedColor}
          style={[miniStyles.amountInput, { color: textColor, borderColor }]}
        />
        <Text style={[miniStyles.resultDetail, { color: mutedColor }]}>{t("balance")}: {walletReady ? diamondBalanceLabel(balance, isUnlimited) : "—"} {diamondLabel}</Text>
      </View>
      {MINI_GAME_CARDS.map(({ gameType, titleKey, icon }) => {
        const numberGame = gameType === "guess_number";
        const treasureGame = gameType === "treasure_hunt";
        const choice = numberGame ? guessChoice : treasureGame ? chestChoice : null;
        const requiresChoice = numberGame || treasureGame;
        const buttonDisabled = !canPlay || mutation.isPending || pendingGame !== null || (requiresChoice && choice === null);
        return (
          <View key={gameType} style={[miniStyles.card, { backgroundColor: surfaceColor, borderColor }]}>
            <View style={[miniStyles.iconBadge, { backgroundColor }]}><Text style={[miniStyles.iconText, { color: accentColor }]}>{icon}</Text></View>
            <Text style={[miniStyles.title, { color: textColor }]}>{t(titleKey)}</Text>
            {numberGame ? <Text style={[miniStyles.ruleText, { color: mutedColor }]}>{t("chooseNumber")}</Text> : null}
            {treasureGame ? <Text style={[miniStyles.ruleText, { color: mutedColor }]}>{t("chooseChest")}</Text> : null}
            {numberGame ? <NumberPicker selected={guessChoice} revealed={results.guess_number?.winningNumbers ?? []} onSelect={selectGuess} disabled={mutation.isPending} accentColor={accentColor} successColor={successColor} surfaceColor={surfaceColor} borderColor={borderColor} textColor={textColor} /> : null}
            {treasureGame ? <ChestPicker selected={chestChoice} revealed={results.treasure_hunt?.treasureSpots ?? []} onSelect={selectChest} disabled={mutation.isPending} accentColor={accentColor} successColor={successColor} surfaceColor={surfaceColor} borderColor={borderColor} textColor={textColor} /> : null}
            <Pressable
              accessibilityRole="button"
              accessibilityState={{ disabled: buttonDisabled }}
              disabled={buttonDisabled}
              onPress={() => play(gameType, choice ?? undefined)}
              style={({ pressed }) => [miniStyles.playButton, { backgroundColor: accentColor, opacity: buttonDisabled ? 0.45 : pressed ? 0.72 : 1 }]}
            >
              <Text style={[miniStyles.playText, { color: backgroundColor }]}>{pendingGame === gameType ? "…" : t("playRound")}</Text>
            </Pressable>
            {renderResult(gameType)}
          </View>
        );
      })}
      {mutation.error ? <Text style={[miniStyles.error, { color: errorColor }]}>{mutation.error.message}</Text> : null}
    </View>
  );
}

function NumberPicker({ selected, revealed, onSelect, disabled = false, accentColor, successColor, surfaceColor, borderColor, textColor }: {
  selected: number | null;
  revealed: number[];
  onSelect: (value: number) => void;
  disabled?: boolean;
  accentColor: string;
  successColor: string;
  surfaceColor: string;
  borderColor: string;
  textColor: string;
}) {
  return (
    <View style={miniStyles.choiceGrid}>
      {Array.from({ length: 10 }, (_, index) => index + 1).map((value) => {
        const isSelected = selected === value;
        const isWinner = revealed.includes(value);
        return (
          <Pressable key={value} accessibilityRole="button" disabled={disabled} accessibilityState={{ selected: isSelected, disabled }} onPress={() => onSelect(value)} style={[miniStyles.choiceCell, { backgroundColor: isWinner ? successColor : isSelected ? accentColor : surfaceColor, borderColor: isWinner ? successColor : borderColor, opacity: disabled ? 0.65 : 1 }]}>
            <Text style={[miniStyles.choiceText, { color: isWinner || isSelected ? "#fff" : textColor }]}>{value}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

function ChestPicker({ selected, revealed, onSelect, disabled = false, accentColor, successColor, surfaceColor, borderColor, textColor }: {
  selected: number | null;
  revealed: number[];
  onSelect: (value: number) => void;
  disabled?: boolean;
  accentColor: string;
  successColor: string;
  surfaceColor: string;
  borderColor: string;
  textColor: string;
}) {
  return (
    <View style={miniStyles.choiceGrid}>
      {Array.from({ length: 10 }, (_, index) => index + 1).map((value) => {
        const isSelected = selected === value;
        const hasTreasure = revealed.includes(value);
        return (
          <Pressable key={value} accessibilityRole="button" disabled={disabled} accessibilityState={{ selected: isSelected, disabled }} onPress={() => onSelect(value)} style={[miniStyles.choiceCell, { backgroundColor: hasTreasure ? successColor : isSelected ? accentColor : surfaceColor, borderColor: hasTreasure ? successColor : borderColor, opacity: disabled ? 0.65 : 1 }]}>
            <Text style={[miniStyles.chestText, { color: hasTreasure || isSelected ? "#fff" : textColor }]}>{hasTreasure ? "◆" : "◇"} {value}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

const miniStyles = StyleSheet.create({
  root: { gap: 10 },
  amountBox: { gap: 8, borderWidth: 1, borderRadius: 15, padding: 12 },
  card: { alignItems: "center", gap: 9, borderWidth: 1, borderRadius: 17, padding: 13 },
  iconBadge: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
  iconText: { fontSize: 21, fontWeight: "900" },
  title: { fontSize: 17, fontWeight: "900", textAlign: "center" },
  ruleText: { fontSize: 12, lineHeight: 18, textAlign: "center" },
  amountInput: { width: "100%", borderWidth: 1, borderRadius: 11, paddingHorizontal: 12, paddingVertical: 10, textAlign: "right", fontSize: 15, fontWeight: "700" },
  playButton: { minWidth: 150, minHeight: 42, borderRadius: 12, paddingHorizontal: 18, alignItems: "center", justifyContent: "center" },
  playText: { fontSize: 14, fontWeight: "900" },
  resultBox: { width: "100%", gap: 8, borderWidth: 1, borderRadius: 13, padding: 10, marginTop: 4 },
  resultTitle: { fontSize: 14, fontWeight: "900", textAlign: "center" },
  resultDetail: { fontSize: 12, lineHeight: 18, textAlign: "center" },
  board: { width: 186, alignSelf: "center", flexDirection: "row", flexWrap: "wrap" },
  boardCell: { width: 62, height: 62, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  boardMark: { fontSize: 34, fontWeight: "900" },
  memoryGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 6 },
  memoryCard: { width: 51, height: 48, alignItems: "center", justifyContent: "center", borderRadius: 8, borderWidth: 1 },
  memoryMark: { fontSize: 22, fontWeight: "800" },
  choiceGrid: { width: "100%", flexDirection: "row-reverse", flexWrap: "wrap", justifyContent: "center", gap: 5 },
  choiceCell: { width: 43, minHeight: 39, alignItems: "center", justifyContent: "center", borderWidth: 1, borderRadius: 9 },
  choiceText: { fontSize: 14, fontWeight: "900" },
  chestText: { fontSize: 12, fontWeight: "900" },
  error: { fontSize: 13, fontWeight: "800", textAlign: "right" },
});
