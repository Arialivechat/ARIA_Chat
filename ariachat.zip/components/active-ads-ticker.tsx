import { Ionicons } from "@expo/vector-icons";
import { useEffect, useMemo, useState } from "react";
import { StyleSheet, Text, View } from "react-native";
import Animated, { cancelAnimation, Easing, useAnimatedStyle, useSharedValue, withRepeat, withTiming } from "react-native-reanimated";
import { useAuth } from "@/hooks/use-auth";
import { useColors } from "@/hooks/use-colors";
import { useLanguage } from "@/hooks/use-language";
import { trpc } from "@/lib/trpc";
import { translateShop } from "@/lib/ui-locale-shop";

export function ActiveAdsTicker() {
  const colors = useColors();
  const { locale, isRTL, t } = useLanguage();
  const { isAuthenticated } = useAuth();
  const ads = trpc.ads.activeList.useQuery({ limit: 30 }, {
    enabled: isAuthenticated,
    refetchInterval: 30_000,
    staleTime: 15_000,
  });
  const [viewportWidth, setViewportWidth] = useState(0);
  const [copyWidth, setCopyWidth] = useState(0);
  const offset = useSharedValue(0);
  const text = useMemo(
    () => (ads.data ?? [])
      .map((ad) => [ad.title.trim(), ad.body?.trim()].filter(Boolean).join(" — "))
      .filter(Boolean)
      .join("   ◆   "),
    [ads.data],
  );
  const shouldScroll = Boolean(text) && viewportWidth > 0 && copyWidth > 0;
  const copyCount = shouldScroll ? Math.max(2, Math.ceil(viewportWidth / copyWidth) + 2) : 1;
  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: offset.value }],
  }));

  useEffect(() => {
    cancelAnimation(offset);
    if (!shouldScroll) return;
    // Reanimated shared values are deliberately mutable in effects; this is not React state.
    // eslint-disable-next-line react-hooks/immutability
    offset.value = withRepeat(
      withTiming(-copyWidth, {
        duration: Math.max(1_200, Math.round((copyWidth * 1_000) / 32)),
        easing: Easing.linear,
      }),
      -1,
      false,
    );
    return () => cancelAnimation(offset);
  }, [copyWidth, offset, shouldScroll, text]);

  if (!isAuthenticated) return null;

  const statusText = ads.isLoading ? t("loading") : ads.error ? t("retry") : translateShop(locale, "noActiveAds");

  return (
    <View style={[styles.banner, { backgroundColor: colors.surface, borderColor: colors.border, flexDirection: isRTL ? "row-reverse" : "row" }]}>
      <Ionicons name="megaphone-outline" size={16} color={colors.tint} />
      {text && !ads.isLoading && !ads.error ? (
        <View
          style={styles.viewport}
          onLayout={(event) => setViewportWidth(event.nativeEvent.layout.width)}
          accessibilityLabel={text}
          accessibilityLiveRegion="polite"
        >
          <Animated.View style={[styles.track, animatedStyle]}>
            {Array.from({ length: copyCount }, (_, index) => (
              <View
                key={index}
                style={styles.copy}
                onLayout={index === 0 ? (event) => setCopyWidth(event.nativeEvent.layout.width) : undefined}
              >
                <Text
                  numberOfLines={1}
                  style={{ color: colors.text, fontSize: 12, fontWeight: "800", textAlign: isRTL ? "right" : "left", writingDirection: isRTL ? "rtl" : "ltr", flexShrink: 0 }}
                >
                  {text}
                </Text>
              </View>
            ))}
          </Animated.View>
        </View>
      ) : (
        <Text numberOfLines={1} style={[styles.status, { color: colors.icon, textAlign: isRTL ? "right" : "left" }]}>
          {statusText}
        </Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  banner: { minHeight: 36, marginHorizontal: 10, marginVertical: 5, paddingHorizontal: 10, borderWidth: 1, borderRadius: 12, alignItems: "center", gap: 8, overflow: "hidden" },
  viewport: { flex: 1, minWidth: 0, height: 32, justifyContent: "center", overflow: "hidden" },
  track: { flexDirection: "row", alignSelf: "flex-start", flexShrink: 0 },
  copy: { flexShrink: 0, paddingHorizontal: 18 },
  status: { flex: 1, fontSize: 11, fontWeight: "700" },
});
